# CPU-безопасность и генерация датасета «Герметиста» (2026-08-19)

## Инцидент: индексация задушила Hermes

**Симптом:** load average 24 на 4 ядрах, 95% steal на Hostinger, Hermes gateway
отваливался, ответы шли 50+ сек. Причина: `build_hermetica_index.py` (эмбеддинги
nomic через Ollama) — процесс llama-server жрал 339% CPU.

**Цепочка:** скрипт индексации эмбеддингов запущен в фоне → llama-server (Ollama)
разгоняется на все ядра → gateway не получает CPU → Hermes тупит/отваливается.

**Фикс (порядок):**
```bash
pkill -9 -f build_hermetica_index   # убить скрипт индексации
pkill -9 -f llama-server            # убить зависший эмбеддер (остаётся после kill скрипта!)
# проверить: ps aux | grep -E 'llama-server|build_hermetica' | grep -v grep
# проверить load: uptime (должен упасть 24 → 1-2 за несколько минут)
```

**Правило:** CPU-тяжёлые задачи (индексация эмбеддингов, fine-tune) — НЕ на
production-сервере. Только:
1. Vast.ai (GPU, $0.3-0.5/час) — основной вариант
2. Ночное окно, когда Алекс не работает — только с ограничением:
   `nice -n 19 taskset -c 1 python3 ...` (одно ядро)
   ВАЖНО: даже 1 ядро на 4-ядерном VPS со steal может поднять load до 8+ — следить.

**Что безопасно (CPU только при запросе):**
- `hermes_archiver.py` — полнотекстовый каскадный поиск
- `hermes_semantic.py` — загрузка готового embeddings.npy + cosine (без индексации)
- Любые чтения файлов

## Генерация датасета (fine-tune Qwen3-8B)

**Проблема:** датасет из чанков Sefaria без фильтра = мусор. Из 300 сгенерированных
пар все 300 отброшены фильтром — ~90% чанков иврит, остальное base64/OCR-кракозябры.

**Фильтры (в gen_dataset.py load_chunks):**
- иврит/арабские символы > 15 → drop
- alnum-соотношение > 0.88 → drop (base64/OCR-мусор)
- HTML-тегов > 5 → strip теги
- длина < 300 символов → drop

**Пайплайн:**
1. `gen_dataset.py 300` — берёт чанки из индекса (после фильтра ~2,859 чистых из 12,721),
   генерит вопрос через DeepSeek Flash (дёшево), ответ = сам чанк + [Источник: file]
2. `clean_dataset.py` — финальная отбраковка (если вдруг что-то прошло)
3. Итог: `/root/hermes-box/dataset_hermetica.jsonl` — 300 пар instruction/response

**MLflow-логирование сети:** `/root/hermes-box/scripts/log_network_mlflow.py` —
эксперимент `hermetica-network` (метрики: books_*, index_chunks, dataset_examples,
total_books, total_docs_mb). Ссылка: http://127.0.0.1:5050/#/experiments/4.

**Vast.ai fine-tune:**
- Инстанс: RTX 4090 49GB, ~$0.30/час (дешевле 3090 по dph на Калифорнии)
- Образ: `nvidia/cuda:12.4.0-runtime-ubuntu22.04` (1.5GB, быстрый) + `apt-get install python3-pip`
- torch: `pip3 install torch --index-url https://download.pytorch.org/whl/cu124` (768MB, 5-10 мин)
- Запуск обучения: tmux-сессия, НЕ nohup с кавычками (ломается экранирование):
  `tmux new-session -d -s train 'cmd > /root/train.log 2>&1'`
- Файлы: `scp -P <port> dataset_hermetica.jsonl finetune_hermetica.py root@<host>:/root/`
- Мониторинг: `ssh ... "tail -25 /root/train.log"` (SSH proxy может таймаутить — повторить)
- Скрипт: `/root/hermes-box/scripts/finetune_hermetica.py` (Qwen3-8B, bf16, LoRA r16,
  epochs 5, MAX_LEN 2048, flash_attention_2; НЕ TRL — transformers.Trainer)
