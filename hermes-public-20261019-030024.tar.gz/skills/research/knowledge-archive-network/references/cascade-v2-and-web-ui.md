# Каскад v2: 11 уровней + веб-интерфейс (обновление 2026-08-21)

## Каскад расширен с 5 до 11 уровней (hermes_archiver.py)

Порядок: локальная → Sefaria → Source Library → Internet Archive → Gutenberg →
Perseus → Harvard → Bodleian → Quran → Islamic → веб.

- **Gutenberg**: `https://gutendex.com/books?search=<q>` (без ключа). Кибалион id 14209, Каббала id 69243.
- **Perseus/Scaife**: SPA, тексты не отдаёт напрямую — возвращать ссылку на поиск.
- **Harvard LibraryCloud**: `https://api.lib.harvard.edu/v2/items.json?q=<q>&limit=N` (Accept: application/json).
- **Bodleian Oxford**: `https://digital.bodleian.ox.ac.uk/search/?q=<q>` — доступен, но API 404; ссылка.
- **Quran**: `https://api.alquran.cloud/v1/edition/format=quran-uthmani&language=ru` — 200, без ключа.
- **Islamic corpus**: IA advancedsearch с `AND mediatype:texts` для исламских текстов.

## Критический питфолл: локальный полнотекстовый поиск перебивает онлайн-архивы

Локальная база (Генон/Эвола/Наср) набирает score по общим словам («world», «being»,
«unity») на ЛЮБОЙ запрос — score≥3 не спасает. Из-за этого каскад останавливается
на уровне 1 и НЕ доходит до Source Library по запросам вроде «Ibn Arabi wahdat
al-wujud», «Poimandres origin of man» и т.п.

**Рабочий фикс (внедрён):** результат локальной базы релевантен только если
первое слово запроса есть в названии книги ИЛИ сниппете:
```python
first_word = query.split()[0].lower() if query.split() else ''
local_relevant = [r for r in local if first_word in r['book'].lower() or first_word in r['snippet'].lower()]
if local_relevant: return {'results': local_relevant, 'level': 1}
# иначе — идём в онлайн-архивы
```

## Веб-интерфейс «Герметиста» для людей

- Flask: `/root/hermetist-web/app.py`, порт 5080 (127.0.0.1)
- nginx: `location /hermetist/ { proxy_pass http://127.0.0.1:5080/; }` в gatebox
- Публично: http://76.13.77.105:8080/hermetist/ (и Funnel /hermetist/)
- Landing: тёмная, золотой заголовок ГЕРМЕСТИСТ, поле вопроса, кнопка «Спросить»
- API: `POST /api/ask {"q": "..."}` → каскад → {answer, sources, results[], report[]}
- Логика ответа: если level==1 → «Нашёл в локальной базе первоисточников», иначе
  «Найдено на уровне N (архивы)»

## Доступность архивов с сервера (проверено 2026-08-21)

| Архив | Статус |
|---|---|
| alquran.cloud | ✅ 200 |
| gutendex.com | ✅ 200 |
| api.lib.harvard.edu | ✅ 200 (JSON) |
| digital.bodleian.ox.ac.uk | ✅ 200 (HTML) |
| archive.org advancedsearch | ✅ 200 |
| scaife.perseus.org | ✅ 200 (SPA) |
| sacred-texts.com | ❌ 403 (блок серверного IP) |
| gnosis.org | ❌ 406/мёртв |
| api.sunnah.com | ❌ 403 (нужен x-api-key) |
| al-islam.org | ❌ 403 |
| iiif.lib.harvard.edu | ❌ 429 (rate limit) |

Недоступные архивы дублируются в Internet Archive (там есть их коллекции) —
обходить через IA, не тратить время на 403/406.
