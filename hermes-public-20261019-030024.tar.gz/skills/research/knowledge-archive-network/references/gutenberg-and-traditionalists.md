# Проверенные Gutenberg ID классики (2026-08-19)

Прямые URL: `https://www.gutenberg.org/cache/epub/<id>/pg<id>.txt`
Fallback: `https://www.gutenberg.org/files/<id>/<id>-0.txt`
Требование: файл > 5KB, иначе пробовать следующий URL.

| ID | Книга | Автор | Статус |
|----|-------|-------|--------|
| 1727 | The Iliad | Homer (Pope) | ✅ 700KB |
| 3160 | The Odyssey | Homer (Butler) | ✅ 728KB |
| 3134 | Histories | Herodotus | ✅ 307KB |
| 7142 | The Persian Wars | Herodotus (Rawlinson) | ✅ 1188KB |
| 7242 | Peloponnesian War | Thucydides | ✅ 90KB |
| 831 | Anabasis | Xenophon | ✅ 1016KB |
| 2577 | Cyropaedia | Xenophon | ✅ 1126KB |
| 10657 | Gallic Wars | Caesar | ✅ 941KB |
| 10658 | Civil Wars | Caesar | ✅ 631KB |
| 10828 | Alexandrian War | Caesar | ✅ 651KB |
| 291 | Annals | Tacitus | ✅ 226KB |
| 16961 | Histories | Tacitus | ✅ 324KB |
| 6400 | Twelve Caesars | Suetonius | ✅ 1389KB |
| 19725 | History of Rome | Livy | ✅ 1359KB |
| 7571 | Anabasis of Alexander | Arrian | ⚠️ 21KB — частичный! |
| 17995 | Parallel Lives | Plutarch | ✅ 141KB |
| 22067 | Germania | Tacitus | ✅ 426KB |
| 38794 | Agricola | Tacitus | ✅ 99KB |
| 16167 | Jewish War | Josephus | ✅ 896KB |
| 2848 | Antiquities of the Jews | Josephus | ✅ 2995KB |
| 1255 | City of God | Augustine | ❌ FAIL (нет в cache) |
| 1113 | Metamorphoses | Ovid | ✅ 116KB |
| 31547 | Catiline Conspiracy | Sallust | ✅ 76KB |
| 18771 | Jugurthine War | Sallust | ✅ 365KB |
| 1400 | Art of War | Sun Tzu | ✅ 1033KB |
| 7145 | Chronicle of Kings of England | William of Malmesbury | ✅ 88KB |

## Internet Archive — идентификаторы традиционалистов (проверено)

Поиск: `title:(<words>) AND creator:(<name>)` — фильтр обязателен, иначе мусор (youtube/подкасты).

| identifier | Книга |
|-----------|-------|
| hermetic-tradition-julius-evola | Evola, Hermetic Tradition |
| julius-evola-the-hermetic-tradition-...-1995 | Evola, Hermetic Tradition (1995) |
| revolt-against-the-modern-world-pdfdrive | Evola, Revolt Against Modern World |
| evola-julius-revolt-against-the-modern-world-1969_202607 | Evola, Revolt (1969) |
| the-crisis-of-the-modern-world-collected-works-of-rene-guenon-... | Guénon, Crisis of Modern World |
| rene-guenon-the-reign-of-quantity-the-signs-of-the-times_20240607 | Guénon, Reign of Quantity |
| julius-evola-the-path-of-the-cinnabar | Evola, Path of Cinnabar |
| julius-evola-introduction-to-magic-ii | Evola, Intro to Magic II |
| introduction-to-magic-rituals-...-2001-ju | Evola, Intro to Magic (2001) |
| transcendentunit0000schu | Schuon (⚠️ 401, под копирайтом) |

## Русские традиционалисты (HTML)

- **Головин:** golovinfond.ru/content/priblizhenie-k-snezhnoy-koroleve → 29KB текста
- **Дугин:** platonizm.ru/content/dugin-ag-tradicionalizm-protiv-dyavolopolisa → 29KB (plain HTTP!)

Извлечение: strip script/style → удалить теги → html.unescape → схлопнуть пробелы.
