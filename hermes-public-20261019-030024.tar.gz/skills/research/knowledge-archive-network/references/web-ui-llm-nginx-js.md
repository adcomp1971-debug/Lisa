# Веб-интерфейс: LLM-провайдер, nginx-таймауты, JS-баги (2026-08-21, в бою)

## 1. Провайдер ответа: Kimi K3 > DeepSeek для академичности
`ask_llm(q, quotes, provider)` с провайдерами kimi|deepseek|grok. Провайдер из env
HERMETIST_PROVIDER (по умолчанию kimi) или параметра запроса `{"provider":"kimi"}`.
- **Kimi K3**: thinking-модель, max_tokens 16000, temperature 1 (строго 1 — иначе 400).
  Даёт критический разбор цитат: «цитата Генона определения НЕ содержит — это фрагмент
  из Филокалии» — честная академичность, DeepSeek просто пересказывает.
- **Grok 4.6**: max_tokens 8000, api.x.ai/v1/chat/completions (XAI_API_KEY).
- **DeepSeek**: max_tokens 800, temperature 0.5 (дефолт fallback).
- Kimi думает 40-140с — заложить в таймауты (см. п.2).

## 2. Kimi думает 40-140с → nginx убивает соединение на 60с → SyntaxError
Симптом: «Долго искал а потом SyntaxError: The string did not match the expected pattern».
Причина: proxy_read_timeout по умолчанию 60с, Kimi отвечает ~90с, фронт получает обрыв,
Safari не парсит обрезанный JSON. Фикс в nginx location /hermetist/:
```nginx
proxy_read_timeout 600;
proxy_connect_timeout 60;
proxy_send_timeout 600;
proxy_buffering off;
```
Проверка: `time curl -X POST .../api/ask` — должен вернуть 200 через 80-90с, не обрыв.

## 3. JS-регекспа `/\n/g` в Python-строке = сломанный JS
`const esc = s => s.replace(/\n/g,'<br/>')` внутри Python triple-quote: Python
интерпретирует `\n` как перевод строки → в браузер уходит битый JS → кнопка «Спросить»
вообще не нажимается. Симптом: страница грузится, но кнопка мертва (не кликается).
Фикс: НЕ использовать replace(/\n/g) в inline JS. Экранировать HTML-entities через esc()
(`& < >`), переносы строк показывать CSS `white-space:pre-wrap` на .answer p.
Проверка после правок: извлечь JS из HTML и `node --check file.js` — должен пройти.

## 4. Перевод сниппетов на русский (translate_ru)
Первоисточники на английском — пользователь требует русские цитаты («Хотелось бы на
русском, а там английский»). `translate_ru(snippet)`: если кириллица < 20% — отправить в
DeepSeek «Переведи на русский язык (цитата по традиционализму/герметизму/каббале)...
Только перевод, без комментариев» (temperature 0.2, max_tokens 400), иначе вернуть как есть.
Применять к каждому сниппету ПЕРЕД показом пользователю.

## 5. Каскад: локальная база доминирует (95% файлов = Sefaria)
LOCAL_DIRS приоритизировать: traditio → traditio_ru → classics → wars → philosophy →
hermetica → sefaria (sefaria последней). Требовать ≥2 слов запроса (после стоп-слов) И
ключевое слово в НАЗВАНИИ файла — иначе результат слабый, каскад должен идти в онлайн.
«Головин приписывается везде» — потому что его русский текст содержит общие слова
(свобода, желание); фильтр по названию файла это лечит.

## 6. Веб-поиск — только скрытый резерв (никогда не показывать Википедию)
«Сеть для академиков а ты Википедию приволок». Brave веб-результаты: НЕ добавлять в
sources для отображения, использовать ТОЛЬКО для генерации ответа если архивы пусты.
Вернуть в json только archive_only (фильтр по ARCHIVE_SOURCES = local, sefaria,
sourcelibrary, gutenberg, archive.org, perseus, harvard, bodleian, islamic, quran, rsl, vostlit).
