# Sefaria bulk-download (проверено 2026-08-19) + лимиты Source Library

## Sefaria API — рабочий паттерн скачивания иудаики

Результат: 3,942 книги (~55MB) из 6,602 листьев каталога.

### 1. Индекс (каталог)
```
GET https://www.sefaria.org/api/index/   → JSON **список** из 14 корпусов
```
- Это не dict! `json.loads` → list. Каждый корпус имеет `contents` (дерево категорий).
- Корпуса: Tanakh, Mishnah, Talmud, Midrash, Halakhah, Kabbalah, Liturgy, Jewish Thought,
  Tosefta, Chasidut, Musar, Responsa, Second Temple, Reference.
- Итог: 6,602 уникальных листа (книг). Kabbalah=70, Second Temple=52, Midrash=129.

### 2. Сбор листьев (рекурсия с наследованием категорий)
```python
def collect_all(node, inherited_cats):
    cats = node.get('categories', []) or inherited_cats
    contents = node.get('contents', [])
    if not contents:  # лист
        if node.get('title'): results.append({'title': ..., 'categories': cats})
    else:
        for c in contents: results.extend(collect_all(c, cats))
```

### 3. Текст книги
```
GET https://www.sefaria.org/api/texts/<urllib.parse.quote(title)>?context=0
```
- Без ключа, щедрый rate limit (сотни запросов подряд ОК).
- **Zohar / Zohar Chadash / Tikkunei Zohar / большинство комментариев → HTTP 400**
  (premium-контент Sefaria). Не считать багом — пропускать, брать Зоар из Source Library.

### 4. flatten_text — КРИТИЧНЫЙ БАГ
Первая версия обрабатывала только dict'ы → 0 чанков даже на успешном ответе.
**Строки внутри списков НЕ обрабатывались.** Рабочая версия:
```python
def flatten_text(node, out):
    if isinstance(node, str):
        if node.strip(): out.append(node)
    elif isinstance(node, dict):
        if 'text' in node: flatten_text(node['text'], out)
        if 'he' in node:   flatten_text(node['he'], out)   # иврит
    elif isinstance(node, list):
        for item in node: flatten_text(item, out)
```
Проверка: `GET .../api/texts/Sefer%20Yetzirah?context=0` → 200, text=list(len=14),
flatten → 28 чанков (перевод + иврит).

### 5. Приоритизация
Сортировать по категории: Kabbalah(0) → Second Temple(1) → Midrash(3) → Jewish Thought(2)
→ Chasidut(4) → Musar(5) → остальное(9). Каббала и ранний иудаизм — первые.

Скрипт: `/root/hermes-box/scripts/download_sefaria_all.py`

## Source Library — ЛИМИТ 429 СУТОЧНЫЙ (не часовой!)

- Без ключа: ~5 запросов → 401. Ключ: `SOURCE_LIBRARY_API_KEY` в `.env`
  (получить: sourcelibrary.org/developers → Sign in → key, формат `sl_data_...`, 72 символа).
- **С ключом: серия ~2000 запросов → 429, и держится ЧАСЫ** (не сбрасывается за час).
  Скрипт с ретраями (20+attempt*15+random) переживает, но НЕ помогает, пока лимит не
  сбросится на следующий день.
- **Правильный паттерн:** качать с паузами (0.3-1.2с) + ретраи на 429; при упоре в 429
  НЕ ждать в цикле — запланировать продолжение cron'ом на следующее утро
  (например, 05:00), скрипт должен пропускать уже скачанные файлы.
- Каталог: `GET /api/catalog/csv` — 302 → follow (-L), 11,474 книг, 2.8MB.
- ID книги = последний сегмент URL (слаг). Текст: `GET /api/books/<id>/text?content=translation&from=N&to=N+49`
  (батчами по 50 страниц).

## Internet Archive — копирайт XX века

- `title:(...) AND creator:(...)` — обязательный фильтр, иначе мусор (youtube/подкасты).
- Классика (public domain) — качается. Авторы XX века:
  - Evola/Guénon/Nasr/Lings/Coomaraswamy — в основном ОК (см. gutenberg-and-traditionalists.md)
  - Burckhardt, Corbin, Schuon → **401/403** (под копирайтом) — не тратить время,
    искать на легальных сайтах или пропускать.

## Статус баз и модель (2026-08-19)

- Контракт/спека проекта: `/root/hermes-box/GERMETIST-SPEC.md`
- Модель: **Qwen3-8B** (LoRA, Vast.ai) — выбрана Алексом: 8B лучший баланс для 16GB RAM.
