# Веб-интерфейс «Герметиста» — критические питфоллы (2026-08-21, все в бою)

Flask `/root/hermetist-web/app.py` на 127.0.0.1:5080, nginx `location /hermetist/`.
Публично: http://76.13.77.105:8080/hermetist/. API: `POST /api/ask {"q":"..."}` →
каскад → `{answer, sources, results[], report[]}`.

## 1. `fetch('/api/ask')` перехватывается nginx `location /api/` → 5010 (GateBox), НЕ Flask
UI падал: «SyntaxError: The string did not match the expected pattern» (Safari не смог
распарсить ответ GateBox). Фикс: **относительный путь** — `fetch('api/ask')` без ведущего
слэша → идёт через `/hermetist/api/ask` → location /hermetist/ → Flask.

## 2. Частичный семантический индекс ХУЖЕ отсутствия
Индекс (embeddings.npy, 12,721 чанков) содержал ТОЛЬКО Sefaria — индексация оборвалась
на ней. Любой вопрос получал еврейские тексты как «семантически близкие» (порог 0.35–0.62
пропускал 0.67–0.68 мусор), семантика ПЕРЕБИВАЛА каскад. Жалоба: «работает только в
еврейском архиве и головина». Фикс: **отключить семантику в вебе** (`sem_results = []`),
пока индекс не покрывает все базы. Включить ТОЛЬКО после полной индексации
(traditio + classics + wars + philosophy), порог ≥ 0.6.

## 3. Русский запрос не находит англоязычные первоисточники
«Кали юга» → локальный полнотекст ищет по-русски, а Генон/Эвола на английском
(«Kali Yuga»), их файлы score 36–83, но не находятся. Фикс: словарь-транслит перед каскадом:
```python
TRANSLIT = {
    'кали юга': 'kali yuga', 'философский камень': 'philosopher stone',
    'каббала': 'kabbalah', 'сефирот': 'sephirot', 'алхимия': 'alchemy',
    'зоар': 'zohar', 'поймандр': 'poimandres', 'суфизм': 'sufism',
    'ибн араби': 'ibn arabi', 'талмуд': 'talmud', 'мишна': 'mishnah',
    'тора': 'torah', 'эманация': 'emanation', 'традиция': 'tradition',
    'гнозис': 'gnosis', 'душа': 'soul', 'дхарма': 'dharma',
}
# q_en = TRANSLIT.get(найденный_рус_термин, q)
```

## 4. Академикам НЕЛЬЗЯ показывать Википедию/веб
«Сеть для академиков а ты Википедию приволок». Веб-поиск (Brave) — только скрытый резерв
ЕСЛИ архивы ничего не дали (`if not sources`). В ответе и источниках — только
первоисточники (local/sefaria/sourcelibrary/gutenberg/archive.org/perseus/harvard/
bodleian/islamic/quran). Википедия в UI = ярость пользователя.

## 5. Локальные результаты — кликабельные «Открыть документ →»
Путь файла (`/root/hermes-box/documents/...`) конвертировать в HTTP URL через nginx alias:
```nginx
location /gatebox/sefaria/  { alias /root/hermes-box/documents/sefaria/;  default_type text/plain; charset utf-8; }
location /gatebox/traditio/ { alias /root/hermes-box/documents/traditio/; default_type text/plain; charset utf-8; }
# wars, classics, other (philosophy+hermetica+traditio_ru) — аналогично
```
⚠️ nginx (www-data) не читает /root/ → `chmod -R a+rX /root/hermes-box/documents/`
иначе 403 Forbidden. Ссылка в UI: `<a href="..." target="_blank" style="color:#c9a227">Открыть документ →</a>`.

## 6. Не отфильтровывать локальные результаты «первое слово в названии» в вебе
Ранний фильтр `if first_word not in book.lower(): continue` отбросил Генона/Эволу на
«Что значит Кали Юга» (первое слово «что» не в названии файла) — ответ остался без
источников. Релевантность решать в hermes_archiver.py (первое слово в названии ИЛИ
сниппете), в вебе показывать ВСЕ результаты каскада.

## 7. Приоритет: КАСКАД ПЕРВЫЙ, семантика — только при пустоте каскада
```python
res = cascade(q_en)          # сначала архивы
sources = [...все результаты каскада...]
if len(sources) < 2:         # потом семантика, только если каскад слабый
    sem_results = semantic_search(q, top_k=4, threshold=0.62)
```

## 8. Сборка ответа через LLM — только первоисточники
DeepSeek получает quotes из archive_only (фильтр по ARCHIVE_SOURCES), веб — никогда.
Ответ LLM структурирован: Тезис → Объяснение → Вывод. Если цитаты не отвечают на вопрос —
модель честно говорит «не содержит определения», не выдумывает.
