---
name: knowledge-archive-network
description: "Cascade search over local archives + external APIs."
version: 1.0.0
---

# Knowledge Archive Network — гибридная сеть знаний с каскадом источников

## Когда использовать

- Проект «Герметист» / «суперсеть»: RAG по архивам древних текстов + внешние источники
- Нужен ответ, которого нет в локальной базе — искать каскадом: локально → внешние API → веб
- Академический запрос: ответ ВСЕГДА с источником (архив + книга + ссылка)
- Сигнал: «сделай супер сеть», «найди ответ если нет в базе», «чтобы всё было с цитатами»

## Архитектура каскада (порядок = от быстрого/локального к медленному/внешнему)

```
ВОПРОС
  1. Локальная база (полнотекстовый поиск по *.txt)      ~0.5с
  2. Sefaria API (/api/search/<q>) — иудаика             ~1с
  3. Source Library API (/api/search?q=, Bearer)          ~2с
  4. Internet Archive (advancedsearch.php) — книги        ~2с
  5. Веб (Brave/Firecrawl)                                ~3с
  → ОТВЕТ + ИСТОЧНИК (какой архив, какая книга, ссылка)
```

## Реализация

Скрипт: `/root/.hermes/scripts/hermes_archiver.py`
```
python3 hermes_archiver.py "philosopher stone Paracelsus"
```
Возвращает `{results, level, report}`:
- `level` — какой уровень сработал (1-5)
- `report` — список ✅/❌ по уровням (виден пользователю)
- каждый результат: source + book + snippet + url

Локальные каталоги — в `LOCAL_DIRS` (добавлять новые при расширении базы).

## База «Герметиста» (состояние 2026-08-19)

| Каталог | Содержимое | Книг |
|---|---|---|
| /root/hermes-box/documents/sefaria | Иудаика (Мишна, Талмуд, каббала) | ~3,900 |
| /root/hermes-box/documents/wars | Военная история (Цезарь, Фукидид, WWI) | 150 |
| /root/hermes-box/documents/classics | Классика Gutenberg (Гомер, Тацит, Ливий) | 25 |
| /root/hermes-box/documents/traditio | Эвола, Генон (IA) | 9 |
| /root/hermes-box/documents/traditio_ru | Головин, Дугин (HTML) | 2 |
| /root/hermes-box/documents/philosophy | Source Library (докачивается) | 5→2,000 |
| /root/hermes-box/documents/hermetica | Герметика тест | 5 |

## Источники скачивания (кратко — детали в text-corpus-building)

- Source Library: ключ в .env (SOURCE_LIBRARY_API_KEY), 429 при сериях → паузы 1.2с + ретраи
- Sefaria: без ключа, щедрый; flatten_text должен обрабатывать строки в списках
- Gutenberg: прямые URL cache/epub/<id>/pg<id>.txt
- Internet Archive: title:(...) AND creator:(...) — иначе мусор
- Русские традиционалисты: golovinfond.ru (Головин), platonizm.ru (Дугин) — HTML-парсинг

## Питфоллы

- Полнотекстовый поиск по локальной базе даёт «ближайшие» результаты даже не по теме
  (иудейские тексты на запрос о Константине) — ок как level 1, но для точности нужны
  эмбеддинги (nomic-embed-text через Ollama, семантический поиск).
- Копирайт: авторы XX века (Шуон и др.) → 401 на IA; брать только public domain.
- Ответ всегда с источником — это ключевое отличие от обычного чат-бота (для академиков).
- Базу можно расширять: Sefaria-Export GitHub, Perseus (но XML API 405 — использовать
  Gutenberg для классики), Bible/патристика.

## Связанные скиллы

- `text-corpus-building` — скачивание корпусов из открытых библиотек (защищён user-owned)
- `source-library` — MCP-исследование отдельных книг (семантический поиск, цитаты)
- `lora-finetune` — LoRA fine-tune Qwen3-8B на собранном корпусе (Vast.ai)
- `experiment-tracking` — MLflow для логирования обучения
