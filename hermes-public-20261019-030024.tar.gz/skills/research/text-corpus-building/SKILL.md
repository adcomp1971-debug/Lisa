---
name: text-corpus-building
description: "Build local text corpora from open libraries."
version: 1.0.0
---

# Text Corpus Building — локальные архивы из открытых библиотек

## Когда использовать

- Строим локальный RAG-архив / датасет для fine-tune из открытых библиотек древних/философских/религиозных текстов
- Нужно скачать сотни-тысячи книг/текстов с API (Source Library, Sefaria, sacred-texts, gnosis, Levity, Internet Archive)
- Проект «Герметист»: корпус герметики + иудаики + алхимии для RAG и LoRA fine-tune
- Сигнал: «скачай весь архив», «сделай базу», «сколько займёт памяти»

## Источники (проверено 2026-08)

| Источник | Что даёт | API | Лимиты |
|---|---|---|---|
| **Source Library** (sourcelibrary.org) | 22k книг, AI-переводы, герметика/каббала/алхимия/философия | REST + MCP | **без ключа ~5 запросов → 401**; с ключом — 429 при серии |
| **Sefaria** (sefaria.org) | ~4,500 текстов иудаики: Танах, Талмуд, Мишна, Мидраш, **Каббала (Зоар, Сефер Йецира, Хейхалот)**, Второй Храм | REST, без ключа | щедрый, структурированный JSON (иврит+англ) |
| **Gnostic Society Library** (gnosis.org) | Корпус Герметикум, гимны Гермеса, Наг-Хаммади — чистый текст | HTML | — |
| **Sacred-texts.com** | эзотерика, мифология, религия | HTML | — |
| **Levity** (alchemy.levity.com) | 300+ алхимических трактатов, 3k изображений | HTML | — |
| **Internet Archive** (archive.org) | 20M+ книг (Hermetica Скотта и т.д.) | API + bulk | — |

## Source Library — детали (критично!)

### Ключ API (обязателен для bulk)
1. sourcelibrary.org/developers → Sign in (email/Google) → «Grab a free key»
2. Ключ вида `sl_data_...` (72 симв), заголовок `Authorization: Bearer <KEY>`
3. Хранить в `.env` как `SOURCE_LIBRARY_API_KEY`

### Rate limits (проверено на практике)
- **Без ключа:** ~5-10 запросов → HTTP 401 на всё. НЕ качать без ключа.
- **С ключом:** серия ~2000 быстрых запросов → HTTP 429 на всё, сброс ~1-2 часа.
- **Правило:** пауза ≥1.2с между книгами + ретраи на 429 с backoff (20-60с, до 5 попыток).
- Проверять жив ли API: один запрос → 200.

### Каталог CSV
```
curl -sL https://sourcelibrary.org/api/catalog/csv -o catalog.csv   # 302 redirect — нужен -L!
```
- ~2.8MB, ~11,500 строк. Колонки: title, author, language, year, pages, pages_transcribed, pages_translated, translation_pct, is_first_english_translation, categories, collections, url.
- **Сборка корпуса:** фильтр по `collections` (разделитель `;`), `pages_translated >= 10`, `url` содержит `/book/`. ID книги = последний сегмент url.
- Сортировать по `translation_pct` desc для топ-N.
- Устаревшие slug → ~10-15% запросов 404 (нормально, пропускать).

### Чтение текста
```
GET /api/books/<id>/text?content=translation&from=1&to=50   # максимум 50 страниц за запрос
```
Книга 300+ страниц = 6-10 запросов с паузой 0.8с.

### Оценка размера
- ~290KB текста на книгу. 500 книг ≈ 142MB текста + ~220MB эмбеддингов (nomic-embed 768 dims, ~150 чанков/книга).
- Полный архив философии (6,749 книг) ≈ 4.8GB — диск ок, но RAM при запросе ~3GB (впритык к 16GB).

## Sefaria — детали

```
GET https://www.sefaria.org/api/index/      # ~3.9MB JSON, список корпусов
GET https://www.sefaria.org/api/texts/<ref> # текст с переводом
```
- Корпуса: Tanakh (672), Mishnah (1084), Talmud (1727), Midrash (129), Halakhah (2169), **Kabbalah (70)**, Jewish Thought (140), Tosefta (226), Chasidut (96), Musar (42), Responsa (104), **Second Temple (52)**, Reference (24).
- В Kabbalah: Зоар, Сефер Йецира, Хейхалот Раббати, Бахир, Пардес Риммоним.
- В Second Temple: Бен Сира, Юбилеи, Флавий, Филон.
- Полный экспорт корпуса на GitHub (Sefaria-Export).
- Идеален для RAG по каббале: чистый структурированный текст (не OCR), иврит + англ.

## Workflow (проверенный)

1. Скачать каталог → отобрать корпус (JSON: title/url/translation_pct)
2. Запустить скрипт bulk-скачивания с ключом и rate-limit защитой
3. Пропускать уже скачанные (идемпотентность — можно перезапускать)
4. Проверить объём (`du -sh`, средний размер)
5. Ингест в RAG (hermes-rag: чанкинг → эмбеддинги nomic-embed-text → numpy-хранилище) или датасет для fine-tune (lora-finetune)

Скрипт: `scripts/download_corpus.py` — идемпотентный bulk-загрузчик с ретраями 429.

## Питфоллы

- **302 на /catalog/csv** — без `-L` получишь пустой файл (0 строк).
- **401 без ключа** — не «ключ сломан», а лимит анонима. Нужен ключ.
- **429 после быстрого прогона** — лимит сбрасывается через ~1-2 часа; ставить cron на перезапуск, не сидеть и долбить.
- **Не все slug валидны** — каталог содержит устаревшие; 404 = пропустить.
- **Пустые страницы** — переводы начинаются с `[Blank page` / `<note>` — фильтровать при сохранении.
- **Не качать в один поток без пауз** — даже с ключом убьёшь лимит (проверено: 1995 запросов → 429 на всё).

## Связанные скиллы

- `source-library` — MCP-исследование отдельных книг (семантический поиск, цитаты)
- `lora-finetune` — LoRA fine-tune на собранном корпусе (Vast.ai)
- `experiment-tracking` — MLflow для логирования обучения
- `research-workflow` — общий ресёрч
