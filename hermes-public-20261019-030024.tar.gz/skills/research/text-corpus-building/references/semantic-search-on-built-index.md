# Семантический поиск по готовому индексу — БЕЗ индексации на лету (проверено 2026-08-19)

## Проблема
Индексация эмбеддингов (bulk через Ollama) жрёт CPU и душит продакшен (см. cpu-throttling-embeddings.md).
Но ПОИСК по уже готовому индексу — это просто загрузка numpy + один запрос эмбеддинга + cosine.
Никакой нагрузки на CPU — можно запускать на проде сколько угодно.

## Паттерн (hermes_semantic.py)

Индекс: `/root/hermes-box/index/embeddings.npy` + `meta.json` (чанки).
Оба создаются индексатором; поиск только ЧИТАЕТ их.

```python
import numpy as np, json, urllib.request

INDEX_DIR = '/root/hermes-box/index'
OLLAMA_URL = 'http://127.0.0.1:11434'
EMBED_MODEL = 'nomic-embed-text'

_embeddings = None
_meta = None

def load_index():
    global _embeddings, _meta
    if _embeddings is not None:
        return
    _embeddings = np.load(f'{INDEX_DIR}/embeddings.npy')
    with open(f'{INDEX_DIR}/meta.json') as f:
        _meta = json.load(f)
    print(f"Индекс загружен: {len(_embeddings)} чанков, dim={_embeddings.shape[1]}")

def embed(text):
    req = urllib.request.Request(
        f'{OLLAMA_URL}/api/embeddings',
        data=json.dumps({'model': EMBED_MODEL, 'prompt': text[:8000]}).encode(),
        headers={'Content-Type': 'application/json'})
    d = json.loads(urllib.request.urlopen(req, timeout=60).read())
    return np.array(d['embedding'], dtype=np.float32)

def search(query, top_k=5, threshold=0.35):
    load_index()
    q = embed(query)
    dots = _embeddings @ q
    norms = np.linalg.norm(_embeddings, axis=1) * np.linalg.norm(q)
    sims = dots / (norms + 1e-9)
    idx = np.argsort(-sims)[:top_k]
    results = []
    for i in idx:
        if sims[i] < threshold:
            continue
        m = _meta[i]
        # сниппет: перечитать чанк из файла по m['file'] + m['chunk']
        results.append({'file': m['file'], 'score': round(float(sims[i]), 3), 'snippet': ...})
    return results
```

## Ключевые детали

- **meta.json** хранит: `{file, chunk, hash, size}` — по ним перечитываем чанк из исходного файла
  (индекс хранит ТОЛЬКО эмбеддинги, не текст — экономия диска).
- Чанк в файле: `start = chunk * (CHUNK_SIZE - OVERLAP)`, читать `content[start:start+CHUNK_SIZE]`.
- **threshold 0.35** — отсечь мусор (на 12k чанках иудаики релевантные ~0.55-0.57).
- Один запрос к Ollama на поиск — это секунды, не минуты; CPU нагрузка ~0.
- Если индекс частичный (только Sefaria, 12k чанков) — семантика по иудаике работает,
  по остальным базам результаты слабые. Доиндексировать остальное — на Vast.ai или ночью.

## Когда использовать вместо полнотекстового каскада

- Нужна ТОЧНОСТЬ по смыслу (не по словам): «что общего у Поймандра и Зоара» — полнотекст не найдёт.
- Индекс уже построен (embeddings.npy + meta.json на диске).
- Сервер прод — нельзя грузить CPU (этот путь безопасен).

## Связь с каскадом

hermes_archiver.py (каскад) может вызывать этот семантический поиск как уровень 1 вместо
полнотекстового — быстрее и точнее. Уровни дальше: Sefaria API → Source Library → IA → веб.
