# Internet Archive + каскадный поиск (проверено 2026-08-19)

## Internet Archive — скачивание книг (войны, мемуары, документы)

### Поиск (advancedsearch, JSON)
```
GET https://archive.org/advancedsearch.php?q=(QUERY) AND mediatype:texts&fl[]=identifier&fl[]=title&fl[]=year&rows=25&output=json
```
- Q — в кавычках `"..."` AND'ы; 3 слова достаточно.
- Возвращает `response.docs[]` с identifier/title.

### Получение текста книги
1. `GET https://archive.org/metadata/<identifier>` → `files[]`
2. Искать файл с суффиксом `_djvu.txt` (полный текст) → 
   `https://archive.org/download/<identifier>/<urlencoded_name>`
3. Fallback: любой `.txt` кроме hocr.

### Практика (download_wars_ia.py)
- Запросы по темам: WWI memoir, WWII campaign history, Caesar/Thucydides для античности.
- Скрипт: /root/hermes-box/scripts/download_wars_ia.py
- Результат: /root/hermes-box/documents/wars/ (идентификатор.txt)
- Пауза 0.5с между книгами, до 150 книг за прогон.
- Ключ/лимитов нет (IA щедрый), но не долбить: 0.5-1с пауза.

## Каскадный поиск — «гибридная сеть» (hermes_archiver.py)

Паттерн для RAG-агента, когда один источник может не найти ответ:
вопрос → локальная база → внешние API по порядку → веб.

### Цепочка (порядок важен — от быстрого/локального к медленному/внешнему)
1. **Локальная база** (полнотекстовый поиск по *.txt, ~0.4с) — score по вхождениям слов, сниппет вокруг лучшего совпадения
2. **Sefaria API** (`/api/search/<q>?size=N`) — иудаика
3. **Source Library API** (`/api/search?q=`) — с ключом Bearer
4. **Internet Archive** (`advancedsearch.php`) — книги
5. **Веб** (Brave/Firecrawl) — последний уровень

### Скрипт
- /root/.hermes/scripts/hermes_archiver.py
- `python3 hermes_archiver.py "philosopher stone Paracelsus"`
- Возвращает `{results, level, report}` — report показывает какой уровень сработал
- Каждый результат: source + book + snippet + url — источник всегда виден пользователю

### Ключевое
- Полнотекстовый поиск по локальным файлам даёт «ближайшие» результаты даже если тема
  другая (иудейские тексты на запрос о Константине) — это ок как level 1, но для точности
  нужны эмбеддинги (семантический поиск, nomic-embed-text через Ollama).
- Для академика важно: ответ всегда с источником (какой архив, какая книга, ссылка).
