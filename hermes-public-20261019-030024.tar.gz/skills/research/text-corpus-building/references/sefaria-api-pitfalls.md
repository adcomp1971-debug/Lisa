# Sefaria API — питфоллы скачивания (проверено 2026-08-19)

## flatten_text — критичный баг

Наивный рекурсивный обход, обрабатывающий только dict/list, **возвращает 0 чанков**:
строки в Sefaria JSON лежат и в list-элементах напрямую (`d['text']` = список строк,
а не dict-ов). Первый скрипт качал 0/18 книг именно из-за этого.

Рабочий вариант:

```python
def flatten_text(node, out):
    if isinstance(node, str):
        if node.strip():
            out.append(node)
    elif isinstance(node, dict):
        if 'text' in node:
            flatten_text(node['text'], out)
        if 'he' in node:
            flatten_text(node['he'], out)
    elif isinstance(node, list):
        for item in node:
            flatten_text(item, out)
```

Проверка перед массовым прогоном: один запрос → `flattened: N chunks` (N > 0).

## Zohar → 400 Bad Request

- `Zohar`, `Zohar Chadash`, `Tikkunei Zohar` — узлы-категории (isComplex):
  `/api/texts/Zohar?context=0` → **HTTP 400**. В индексе (`/api/index/`) они
  листья без содержимого (пустой `contents`).
- **Зоар брать из Source Library** (в его каталоге философии есть), НЕ из Sefaria API.
- Обычные книги (Genesis, Sefer Yetzirah, Mishnah Berakhot, Book of Jubilees) → 200 ок.

## Индекс

- `GET /api/index/` — ~3.9MB JSON, дерево из 14 корпусов. Листья = книги, у них есть `title`.
- Категории — по пути: `node['categories']` (массив) наследуется родителями; у листьев поле есть.
- 6,602 уникальных title в полном индексе.
- Сортировать по приоритету категорий: Kabbalah, Second Temple, Midrash, Jewish Thought,
  Chasidut, Musar — сначала самое ценное.

## Скорость

- API без ключа, щедрый — 80+ книг/мин при паузе 0.3с. Лимитов не наблюдалось (в отличие
  от Source Library с его 401/429).
- Структура ответа: `{ref, heRef, isComplex, text, he, versions, ...}` — text = перевод,
  he = иврит (если есть).
