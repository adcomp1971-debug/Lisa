#!/usr/bin/env python3
"""Bulk-скачивание корпуса из Source Library (sourcelibrary.org) с защитой от rate limit.

Использование:
    SOURCE_LIBRARY_API_KEY=sl_data_... python3 download_corpus.py books.json /out/dir

books.json: список [{"title":..., "url": ".../book/<id>", "translation_pct": N}, ...]
— обычно результат фильтрации каталога CSV (см. SKILL.md).

Идемпотентен: пропускает уже скачанные файлы >1KB. Перезапускаем после 429.
"""
import json
import os
import random
import sys
import time
import urllib.error
import urllib.request

KEY = os.environ.get("SOURCE_LIBRARY_API_KEY", "")
PAUSE_BOOKS = 1.2       # пауза между книгами
PAUSE_PAGES = 0.8        # пауза между запросами страниц
MAX_PAGES = 300          # максимум страниц на книгу


def fetch(url, timeout=30, max_retries=5):
    headers = {"User-Agent": "Mozilla/5.0"}
    if KEY:
        headers["Authorization"] = f"Bearer {KEY}"
    for attempt in range(max_retries):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read()
        except urllib.error.HTTPError as e:
            if e.code == 429:
                wait = 20 + attempt * 15 + random.randint(0, 10)
                print(f"  429 -> жду {wait}s (попытка {attempt+1}/{max_retries})", flush=True)
                time.sleep(wait)
            elif e.code == 401:
                print("  401: нужен SOURCE_LIBRARY_API_KEY (лимит анонима исчерпан)", flush=True)
                raise
            else:
                raise
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(5)
            else:
                raise
    raise Exception(f"429 persistent: {url[:80]}")


def get_text(book_id, max_pages=MAX_PAGES):
    pages = []
    for start in range(1, max_pages + 1, 50):
        end = start + 49
        try:
            d = json.loads(fetch(
                f"https://sourcelibrary.org/api/books/{book_id}/text"
                f"?content=translation&from={start}&to={end}"))
            batch = d.get("pages", [])
            if not batch:
                break
            pages.extend(batch)
            if len(batch) < 50:
                break
        except Exception as e:
            print(f"  ERR {book_id} p{start}: {str(e)[:80]}", flush=True)
            break
        time.sleep(PAUSE_PAGES)
    return pages


def main():
    if len(sys.argv) < 3:
        print("Usage: SOURCE_LIBRARY_API_KEY=... python3 download_corpus.py books.json /out/dir")
        sys.exit(1)
    list_path, out_dir = sys.argv[1], sys.argv[2]
    os.makedirs(out_dir, exist_ok=True)

    with open(list_path, encoding="utf-8") as f:
        books = json.load(f)

    done = skipped = 0
    failed = []
    t0 = time.time()
    for i, b in enumerate(books):
        book_id = b["url"].rstrip("/").split("/")[-1]
        out = os.path.join(out_dir, book_id + ".txt")
        if os.path.exists(out) and os.path.getsize(out) > 1000:
            skipped += 1
            continue
        pages = get_text(book_id)
        texts = []
        for p in pages:
            t = p.get("translation", "")
            if t and not t.startswith("[Blank") and not t.startswith("<note>"):
                texts.append(f"[page {p.get('page_number','?')}]\n{t}\n\n")
        if texts:
            with open(out, "w", encoding="utf-8") as f:
                f.write("".join(texts))
            done += 1
            if i % 10 == 0:
                rate = (i + 1) / (time.time() - t0) * 60
                print(f"[{i+1}/{len(books)}] done={done} rate={rate:.0f}/мин: "
                      f"{b.get('title','')[:45]} -> {os.path.getsize(out)//1024}KB", flush=True)
        else:
            failed.append(book_id)
        time.sleep(PAUSE_BOOKS)

    print(f"\nГотово: скачано={done}, пропущено={skipped}, failed={len(failed)}, "
          f"время={(time.time()-t0)/60:.0f}мин", flush=True)
    if failed:
        print("Failed sample:", failed[:5], flush=True)


if __name__ == "__main__":
    main()
