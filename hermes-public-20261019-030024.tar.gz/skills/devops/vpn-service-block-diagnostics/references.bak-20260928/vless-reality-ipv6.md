# VLESS Reality по IPv6 (когда IPv4 сервера режется у операторов)

Схема: `nginx stream :443 (ssl_preread по SNI)` → `xray :8443` (VLESS Reality, dest `www.icloud.com:443`).
По умолчанию `listen 443;` = только IPv4 ⇒ в Москве VLESS мертв ровно так же, как AWG.

## Правка (nginx.conf, stream-блок)

```
server {
    listen 443;
    listen [2a02:4780:c:8bb9::1]:443;   # НЕ wildcard!
    proxy_pass $backend;
    ssl_preread on;
}
```

- `listen [::]:443;` ПАДАЕТ: `bind() to [::]:443 failed (98: Address already in use)` — **tailscaled** держит `[fd7a:...]:443`, а wildcard-бинд конфликтует с конкретным адресом. Привязывай ровно свой публичный v6.
- `ipv6only=on` не помогает — конфликт именно wildcard vs specific.
- ufw: `443/tcp (v6) ALLOW` уже был.
- Порядок: бэкап nginx.conf → patch → `nginx -t` → `systemctl reload nginx` (reload не рвёт живые соединения) → `ss -ltn | grep ':443'` (должно быть три листенера: 0.0.0.0, tailscale fd7a, наш v6).

## Проверка end-to-end (обязательно перед выдачей)

1. Снаружи: globalping `type=http`, `protocol=HTTPS`, `port=443`, `request.host=www.icloud.com`, `locations=[{magic:'RU'}]`. Итог должен быть 6/6 finished (валидный icloud-сертификат = Reality отдаёт dest).
2. Изнутри: запустить временный xray-клиент (socks 127.0.0.1:11080) с vnext address = наш v6, `security=reality`, `publicKey` из `inbound.settings.realitySettings.settings.publicKey`, `shortId` из `shortIds[0]`, `flow=xtls-rprx-vision`, uuid любого клиента → `curl --socks5-hostname 127.0.0.1:11080 https://api.ipify.org` должен вернуть наш публичный IP. Затем процесс убить.
3. Проверить, что старый IPv4-путь жив: `curl -k --resolve www.icloud.com:443:76.13.77.105 https://www.icloud.com/`.

## Клиентская ссылка

```
vless://<uuid>@[2a02:4780:c:8bb9::1]:443?type=tcp&security=reality&pbk=<publicKey>&fp=chrome&sni=www.icloud.com&sid=<shortId>&spx=/&flow=xtls-rprx-vision#Имя-v6
```

Запасной вариант — домен `2a02-4780-c-8bb9--1.sslip.io` вместо `[v6]` (нет скобок, но зависит от DNS).
Клиенту нужен IPv6 от оператора + клиент с Reality (v2rayTun / Hiddify / Streisand).

## Клиенты XRay Reality (x-ui.db → client_traffics)

Проверка «кто онлайн»: `select email, up, down, last_online from client_traffics order by last_online desc` (epoch в секундах; делить на 1000 только если >1e12). Трафик и last_online обновляются панелью, не самим xray.
