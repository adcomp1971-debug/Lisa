# Обращение к хостеру при адресном IPv4-блоке — шаблон и правила

Когда писать: блок адресный подтверждён (чужой IP того же хостера из проблемных сетей отвечает, наш — нет; TCP/ICMP из Москвы молчат, из СПб/DE ок; серверный tcpdump показывает ноль входящих IPv4-пакетов на порт туннеля).

## Правила

- **Коротко, 10–15 строк, английский.** Длинный текст на 3 КБ саппорт не читает, а владельца раздражает. Факты тезисами: что сломалось, когда, чем проверено, что просим.
- **Никаких «ТСПУ», «РКН», «censorship», «политика».** Для саппорта это политика → тикет закроют как «not our scope». Формулировка: `destination-IP filtering on the path or upstream`, `address-scoped block`.
- **Не просить рестарт/пересборку/перенос VPS.** Явно написать «no changes to the VPS itself are needed» — иначе саппорт начнёт с ребилда.
- **Просить только два: (1)** статус фильтра/RTBH/ACL на своём аплинке и его маску (`/32` или вся подсеть); **(2)** альтернативный IPv4 **вне** текущего `/24` (лучше другой префикс/аплинк), с возможностью проверить его из проблемных сетей ДО миграции, и можно ли выдать доп. адрес рядом с текущим.
- **Указать request-id внешних проверок** (check-host) — воспроизводимость повышает шанс, что тикет уйдёт инженеру, а не в шаблонный ответ.
- **Перечислить конкретные ASN/операторов**, легших одновременно (напр. MTS AS8359, MGTS AS25513, Beeline AS8402, NCNET AS42610) — «четыре разных оператора в одном окне» = адресный блок, а не проблема клиента.
- Ключевой факт для тикета: IPv6 того же сервера работает → протокол и сервис живы, затронут только IPv4-destination.

## Шаблон

```
Subject: <IP> unreachable from <city/region> since <date UTC>, IPv6 works

Since <date UTC> our IPv4 <IP> is unreachable from several <region> ISPs
(<ASN list>). TCP <ports> and ICMP from <region> time out, while <other region>
connects OK (check-host.net, <timestamp> UTC, request IDs <ids>); IPv6 <v6> works
fine. tcpdump on the VPS shows zero IPv4 packets arriving, so they are dropped
before the host.

Please: (1) check whether <IP> is blocked by your upstream or anti-DDoS filters,
and for which prefix (/32 or <prefix>); (2) if it cannot be cleared, provide an
alternative IPv4 outside <prefix> that we can test before migrating. No changes
to the VPS itself are needed.
```

Файл отдавать владельцу в чат ОДИН раз (или текстом, если он просил «коротко»), формат — plain `.txt`, готовый к копипасту в hPanel → Support → New ticket.
