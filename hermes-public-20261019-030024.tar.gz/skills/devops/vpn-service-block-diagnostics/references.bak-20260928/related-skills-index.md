## Связанные скиллы

- `engineering-diagrams` — как объяснить владельцу картину целиком: схема узлов/входов/путей файлом-картинкой из живого состояния (собирается из тех же `awg show dump`/`ss`/NAT, что и диагностика).

- `vpn-manager` — общая VPN-диагностика (user-owned, не патчить)
- `awg-operations` — AWG-команды (user-owned, не патчить)
- `warp-egress-proxy` — egress-прокси через Cloudflare WARP (squid HTTP CONNECT) — ТОЛЬКО для приложений с HTTP-прокси поддержкой; для WhatsApp in-app proxy НЕ подходит

Детали кейса: `references/whatsapp-datacenter-ip-ban-2026-08.md`
WA TCP-прокси (протокол, деплой, проверка): `references/whatsapp-tcp-proxy.md` + `scripts/verify-whatsapp-proxy.sh`
Триаж жалобы «VPN не работает»: `scripts/check-client-config.py` — сверка `/root/*.conf` с живыми пирами (PublicKey/PSK/Address), возраст handshake и вердикт по каждому файлу.
Дельта пути данных по всем пирам (handshake vs реальный трафик): `scripts/peer-tunnel-delta.py` — помирит keepalive-only пиров с живыми и пишет, у кого реально идут байты.
IPv6-транспорт как обходной путь (открытие v6-входа, NAT66, профиль с v6-endpoint, проверка): `references/ipv6-transport-fallback.md`.
Массовая сборка v6-профилей на весь парк без правок сервера: `scripts/gen-ipv6-profiles.py` (+ `references/ipv6-profiles-recipe.md`).
Второй контур AWG на другом порту (443/udp) без обрыва живых клиентов — интерфейс, подсеть, NAT/MSS, профиль: `references/alternate-transport-contour.md`.
Кто вообще стучится в порт туннеля (фиксированное окно, исключение живых пиров, контроль длительности): `scripts/capture-tunnel-sources.sh`.
Доказательная база при обвинении в поломке — хеш-диф живого конфига против бэкапов: `scripts/compare-config-backups.py`.
Границы блокировки (наш `/32` против всей подсети/ASN + контроль по адресам чужого VPN) — `scripts/block-scope-probe.sh`.
Плейбук адресного блока РФ (масштаб блока, смена IPv4 у хостера, релей, подбор второго вход-узла с помесячной оплатой и SSH-ключом вместо пароля) — `references/ru-ip-block-playbook.md`.
Атрибуция трафика конкретного клиента на узле Xray/VLESS (кто подключён, чем пользуется, API против медиа-CDN, UDP/QUIC и IPv6-путь, клиентские ограничения AmneziaVPN) — `references/xray-node-traffic-forensics.md`.
