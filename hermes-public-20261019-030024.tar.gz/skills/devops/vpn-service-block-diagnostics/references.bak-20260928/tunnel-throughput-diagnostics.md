# Замер пропускной способности туннеля и локализация «медленно»

Зачем: отличить «виноват узел/конфиг» от «виноват канал клиент→узел» цифрами, не трогая живых клиентов.

## Правило №1: сначала потолок узла, потом туннель

```bash
curl -s -o /dev/null -w '%{speed_download}\n' "https://speed.cloudflare.com/__down?bytes=20000000"
```
Узел даёт сотни Мбит/с ⇒ «медленно» относится к участку до клиента, узел и конфиг не трогать.

## Замер через туннель (тестовый клиент, конкретная цель)

Схема: тестовые ключи (не клиентские) → временный интерфейс → маршрут только на один внешний IP → замер → полная уборка. Пир на живом сервере добавляется `awg set` на лету, без рестарта.

```bash
IF=awgtst; PEER_IP=10.9.0.199
SRV=$(grep -m1 '^PublicKey' /etc/amnezia/amneziawg/awg0.conf | sed 's/PublicKey *= *//' | tr -d '[:space:]')
CF=$(getent ahostsv4 speed.cloudflare.com | awk 'NR==1{print $1}')   # ahostsv4, не hosts

awg set awg0 peer "$(cat /root/v10/test2.pub)" preshared-key /root/v10/test2.psk allowed-ips $PEER_IP/32
ip link add dev $IF type amneziawg
ip addr add $PEER_IP/32 dev $IF
ip link set $IF mtu 1200 up
awg set $IF private-key /root/v10/test2.key peer "$SRV" preshared-key /root/v10/test2.psk \
  endpoint <адрес узла>:51820 allowed-ips 0.0.0.0/0 persistent-keepalive 25

# ОБЯЗАТЕЛЬНО: маршрут только на цель (default route = обрыв своей SSH)
ip route add $CF/32 dev $IF
ip route get $CF            # должно показать dev $IF, иначе цифры мусор

sleep 5
awg show $IF | grep -E 'handshake|transfer'   # handshake = 0 ⇒ замер невалиден
curl -s -o /dev/null -w '%{speed_download}\n' --max-time 30 "https://$CF/__down?bytes=20000000"

# уборка
ip route del $CF/32 dev $IF; ip link del $IF
awg set awg0 peer "$(cat /root/v10/test2.pub)" remove
```

## Интерпретация

- Узел сотни Мбит/с, через туннель тоже, у клиента медленно → участок клиент→узел.
- Endpoint пира не изменился после смены сети клиента → из новой сети пакеты не доходили вообще (фильтр на стороне оператора клиента), а не конфиг.
- Пакеты идут, ответов нет (rx растёт, tx стоит) → режется/теряется на транзите, смотреть `mtr -r -c 10 -n <peer_ip>`.
- Скорость одинакова при MTU 1200/1280/1420 → MTU не при чём.
- Сверка конфига перед вердиктом: Jc/Jmin/Jmax/S1/S2, MTU, DNS, AllowedIPs, PersistentKeepalive; отличаться могут только `Endpoint` и H1–H4 (парные с сервером).

## Питфолы замера

- `getent hosts` отдаёт IPv6 первым → цель уходит мимо туннеля, цифры врут.
- Ключ из конфига вырезать без префикса (`sed 's/PublicKey *= *//'`), иначе `awg set peer` падает «Key is not the correct length or format».
- Сначала проверить handshake ≠ 0, потом верить скорости.
- Пиров читать текстовым `awg show`, а не `dump` с угаданными индексами полей.
- Не отправлять конечного пользователя перебирать порты/операторов, пока не исчерпаны серверные измерения; не выдавать новый профиль без доказанной вины конфига.

## Релей (playit) как TCP-вход для сетей, режущих UDP

- Туннель создаётся только в веб-панели playit.gg; агентский CLI умеет status/attach/account/claim — создания туннелей в нём нет, планировать шаг пользователя.
- Local address туннеля привязан к хосту с агентом: релей на новый узел = агент на этом узле.
- Признак «клиент ходит через релей»: в `awg show` его endpoint — адрес playit-агента, не реальный IP клиента.
- Переключение существующего туннеля на другой узел валит остальных релейных клиентов (у них в конфиге pubkey другого сервера) → новому клиенту нужен отдельный туннель.
