# Read-only проверки хоста под security-сводку

Всё ниже — только чтение. Любое изменение (обновление, дроп-ин, firewall) — отдельным предложением после подтверждения.

## OpenSSH / auth-bypass

```bash
sshd -V 2>&1 | head -1
dpkg -l openssh-server | tail -1                         # установленная версия
ldd "$(command -v sshd)" | grep -E 'libc\.|libpam|musl'   # среда: glibc/pam или musl
ls /etc/pam.d/sshd 2>/dev/null                           # есть ли PAM-контур
sshd -T | grep -Ei '^(passwordauthentication|permitrootlogin|pubkeyauthentication|kbdinteractiveauthentication|usepam)'
grep -rEi 'passwordauthentication|permitrootlogin' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/
```

Важно: `sshd -T` — эффективный конфиг; файлы в `sshd_config.d` читаются только с суффиксом `.conf`, поэтому лежащий рядом `*.conf.bak` сейчас не действует, но это мина при переименовании — так и сказать.

```bash
awk -F: '$2 ~ /^\$/ {print $1, substr($2,1,3), length($2)}' /etc/shadow   # аккаунты с реальным хешем
awk -F: '($2 == "" || $2 == "*") {print $1}' /etc/shadow                 # без пароля
```

Версия из репозитория (вендор бэкпортит фиксы, номер пакета важнее номера upstream):

```bash
apt-cache policy openssh-server | head -4
apt-get -s upgrade | grep -c '^Inst'; apt-get -s upgrade | grep '^Inst' | grep -i security
```

## Runtime-компоненты (PHP и подобное)

```bash
command -v php; ls -d /etc/php /usr/lib/php 2>/dev/null
dpkg -l | grep -Ei 'php|monarx'
ss -lntpH | grep -Ei 'php|fpm'
```

Не использовать `pgrep -f "php|php-fpm"`: шаблон совпадает с собственной командной строки проверки.

## Периметр изнутри

```bash
ufw status verbose
iptables -L INPUT -n | head -3                            # политика по умолчанию
ss -lntupH | awk '{print $1, $5}' | grep -vE '127\.0\.0\.1|\[::1\]'
ss -lntpH "sport = :8080"                                 # порт → процесс
```

## Периметр снаружи (check-host.net API, без ключа)

Двухшаговый REST: запрос → `request_id` → результат через ~10–15 с.

```python
import json, time, urllib.request
HDR = {"Accept": "application/json", "User-Agent": "Mozilla/5.0"}
def req(u):
    return json.load(urllib.request.urlopen(urllib.request.Request(u, headers=HDR), timeout=25))
d = req(f"https://check-host.net/check-tcp?host={IP}:{PORT}&max_nodes=2")
rid = d["request_id"]; time.sleep(12)
res = req(f"https://check-host.net/check-result/{rid}")
# res: {node: [ {"time": 0.05, ...} ] | [None] | None}
```

- `res[0]` — dict c `time` → порт открыт; `None`/пустой список → закрыт/таймаут по узлу.
- Лимит частоты: держать ~10–11 портов за проход, иначе часть запросов вернётся без `request_id` (повторить через минуту).
- Обязательно включить один заведомо открытый порт как контроль — если и он «закрыт», сломан сам замер.
- `curl --socks5-hostname ... telnet://IP:PORT` как пробер не годится: rc=28 на всех портах, включая заведомо открытые.

## Как звучит вывод

По пунктам сводки, одинаковым порядком: «не применимо» с перечислением проверенных предусловий и их состоянием, затем отдельный блок «что торчит наружу по факту» и «что обновить». Без пересказа текста адвизори.