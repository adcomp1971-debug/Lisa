---
name: vast-ai-operations
description: "SSH, инференс, передача файлов на Vast.ai для Pianoid v4/v5"
category: devops
version: 1.3.0
---

# Vast.ai Operations

## Instance Lifecycle

### Создание инстанса

```bash
# 1. Найти свободный RTX 3090
vastai search offers 'verified=true gpu_ram >= 24 num_gpus = 1 gpu_name=RTX_3090' --type on-demand --raw > /tmp/offers.json
python3 -c "
import json
with open('/tmp/offers.json') as f:
    offers = json.load(f)
free = [o for o in offers if o.get('num_gpus', 0) > 0]
print(f'Free: {len(free)}')
for o in free[:5]:
    print(o['id'], '\$', round(o['dph_total'],3), '/h')
print('Cheapest:', round(min(o['dph_total'] for o in free),3))
"

# 2. Создать onstart.sh (чтобы инстанс не упал)
echo '#!/bin/bash
sleep infinity' > /tmp/onstart.sh

# 3. Создать инстанс
# Лучший вариант для скорости: nvidia/cuda (1.5GB) + pip install torch
vastai create instance <OFFER_ID> --image nvidia/cuda:12.4.0-runtime-ubuntu22.04 --disk 30 --label pianoid-v43 --onstart /tmp/onstart.sh
```

### Старт/стоп/удаление

```bash
vastai start instance <ID>
vastai stop instance <ID>
vastai destroy instance <ID>  # Подтверждение требуется всегда
```

**Подтверждение:** `yes | vastai destroy instance <ID>` **работает** (проверено 27 Jun 2026). Команда принимает stdin-пайп. Альтернативно: `vastai destroy instance <ID> -y`.

**Важно:** если инстанс был остановлен (`stop`), данные сохраняются на диске. Чтобы снова получить к ним доступ: `vastai start instance <ID>` → ждать 30-90 сек пока статус станет `running`.

### 🛑 STOP ≠ БЕСПЛАТНО: `exited` инстанс ТАРИФИЦИРУЕТСЯ за диск

**Главная денежная ловушка Vast.ai.** `vastai stop` снимает только плату за GPU. Диск продолжает арендоваться по тарифу `storage_cost` (обычно **$0.40/ГБ/мес**) до момента `destroy`.

Пример реального убытка: инстанс с `--disk 80` → $0.40 × 80 = **$32/мес** при нулевом использовании. Vast списывает это с карты автоматически при исчерпании кредита, счета приходят по $15.03 каждые ~14 дней. Забытый `exited` инстанс за 2 месяца съел **$90.18**.

**Правила (обязательны):**
1. `stop` — только если в тот же рабочий день будет `destroy` (диск тарифицируется и в статусе exited). Не уверен, что вернёшься — `destroy` сразу.
2. Перед `destroy` проверить, что ценные артефакты (адаптеры, датасеты, чекпоинты) уже скачаны локально — `ls -la` по локальным путям, не «кажется, качал».
3. `stop` без последующего `destroy` в тот же рабочий день — запрещён. Список задач по Vast закрывается только после `destroy`.
4. При завершении любой сессии с Vast — `vastai show instances`; **любая строка в выводе = проблема**, включая `exited`.

**Проверка утечки (одна команда):**
```bash
export VAST_API_KEY=$(grep -E "^VAST_API_KEY=" /root/.hermes/.env | cut -d= -f2 | tr -d '"'"'"' ')
curl -s -H "Authorization: Bearer $VAST_API_KEY" "https://console.vast.ai/api/v0/instances/" \
 | python3 -c "import json,sys; d=json.load(sys.stdin); i=d.get('instances',[]); print('ЧИСТО' if not i else [(x.get('id'),x.get('label'),x.get('actual_status'),x.get('disk_space')) for x in i])"
```

**Сумма утечки по счетам:** `https://console.vast.ai/api/v0/invoices/` — повторяющиеся одинаковые списания (например, $15.03 каждые 14 дней) = забытый диск, а не вычисления.

### Получение SSH

```bash
vastai ssh-url <INSTANCE_ID>  # выводит ssh://root@<host>:<port>
```

**CRITICAL: `vastai show instance` и `vastai ssh-url` могут показать РАЗНЫЕ хосты.** `vastai show instance` показал `ssh5.vast.ai:24102` (не работало — Connection closed), а `vastai ssh-url` выдал `ssh://root@140.228.20.108:56359` (работало). 

Правило: **всегда используйте `vastai ssh-url <ID>` для получения SSH-адреса** — он даёт реальный IP:порт. `vastai show instance` может показывать proxy-адрес, который не принимает соединения.

```bash
# Правильный способ получить SSH-адрес:
vastai ssh-url <INSTANCE_ID>
# Вывод: ssh://root@<IP>:<PORT>

# Для скрипта:
vastai ssh-url <ID> 2>&1 | grep -oP 'ssh://root@\K[^"]+'
```

### Проверка баланса

```bash
vastai show user --raw | python3 -c "
import json,sys
d=json.load(sys.stdin)
print(f'Credit: \${d.get(\"credit\",0):.2f}')
print(f'Billed: \${d.get(\"billed\",0):.2f}')
"
```

## Image Selection (CRITICAL PITFALLS)

| Image | Размер | Статус | Torch? |
|-------|:------:|--------|--------|
| `pytorch/pytorch:2.4.0-cuda12.4-cudnn9-runtime` | ~5GB | ✅ Грузится нормально (~2-3 мин) | ✅ Встроен |
| `pytorch/pytorch:2.5.1-cuda12.4-cudnn9-runtime` | ~8GB | ⚠️ Долго грузится (5-15 мин) | ✅ Встроен |
| `nvidia/cuda:12.4.0-runtime-ubuntu22.04` | ~1.5GB | ✅ Быстрая загрузка | ❌ Нет pip3 — нужен `apt-get install python3-pip` |
| `nvcr.io/nvidia/pytorch:26.05-py3` | ~15GB | ❌ Требует NGC auth | ✅ |
| `vastai/pytorch` | ~2GB | ✅ Быстрая загрузка | ❌ **НЕТ torch!** Нужен `pip3 install` |

**CRITICAL: `vastai/pytorch` НЕ содержит torch.** После создания инстанса обязательно:
```bash
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124
```
Это ~2 мин с кешированными .whl файлами.

**CRITICAL: `nvidia/cuda:12.4.0-runtime-ubuntu22.04` НЕ содержит pip3.** Образ основан на ubuntu:22.04 без Python-инструментов. После старта:
```bash
apt-get update -qq && apt-get install -y -qq python3-pip python3
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124
```
apt-get + pip install занимает ~3-4 мин. Общая загрузка образа (1.5GB) + установка быстрее чем pytorch/pytorch (8GB загрузка без pip install).

**Правила выбора:**
- Для **максимальной скорости старта** — `nvidia/cuda:12.4.0-runtime-ubuntu22.04` (1.5GB, ~2 мин загрузка, 2 мин pip install torch)
- Если `nvidia/cuda` не грузится — `pytorch/pytorch:2.5.1-cuda12.4-cudnn9-runtime` (torch предустановлен, но 8GB грузится 5-15 мин)
- `vastai/pytorch` — компромисс (быстрая загрузка + ручной pip install torch)
- `nvcr.io` образы ТОЛЬКО если есть NGC API ключ
- Загрузка образа может занимать 5-15 минут на новой машине (нет кеша)
- Если инстанс сразу падает (exited) — не хватает entrypoint, добавьте `--onstart /tmp/onstart.sh`

**При `Status: None` после создания >2 мин:**
- Проверять `vastai show instances` — если статус "-" (не `running`), образ ещё качается
- Сменить образ на `nvidia/cuda` если загрузка слишком долгая
- SSH может быть недоступен пока статус не сменится на `running`

## API Key Troubleshooting

### VAST_API_KEY env var override (critical)
Симптом: `vastai show instances` → `404 Invalid user key`, хотя ключ правильный.
Причина: `VAST_API_KEY` установлена в **пустую строку** в окружении → перекрывает `~/.config/vastai/vast_api_key`.
Проверка: `echo "$VAST_API_KEY" | cat -A` — пустая строка = проблема.
Фикс: `unset VAST_API_KEY && vastai set api-key <key>`.

## SSH и соединение

**ВАЖНО: У vastai НЕТ subcommand `ssh` или `execute`.** `vastai ssh` и `vastai execute` не существуют. Единственные способы:
1. `vastai ssh-url <ID>` — получить SSH URL для ручного подключения
2. `vastai copy` — rsync-daemon (самый надёжный способ передачи файлов)
3. Прямой SSH через proxy (часто таймаутит)

```bash
# Проверить SSH
ssh -o StrictHostKeyChecking=no -o ConnectTimeout=15 -p <PORT> root@<HOST> "nvidia-smi"

# Копировать на Vast — SCP (мелкие файлы, <5MB)
scp -P <PORT> /root/файл.mid root@<HOST>:/workspace/

# Копировать с Vast — RSYNC (надёжнее для 5-50MB, прямой SFTP)
rsync -avz --progress -e "ssh -p <PORT> -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null" \
  /root/файл.json root@<HOST>:/root/файл.json

# Копировать с Vast на локальный
rsync -avz --progress -e "ssh -p <PORT> -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null" \
  root@<HOST>:/workspace/результат.mid /root/
```

### SSH proxy connectivity issues (common)

**Симптом:** SSH через proxy (ssh3/ssh5.vast.ai) выдаёт `Connection timed out during banner exchange` или `Connection to UNKNOWN port 65535 timed out`.

**Причины и фиксы:**
- Proxy-сервер может быть перегружен — попробовать другой (ssh3 → ssh5 → ssh1)
- `vastai copy` (rsync-daemon, прямой — без proxy) обычно стабильнее
- Если `vastai copy` тоже падает — подождать 30-60 сек и повторить (временная перегрузка)
- **Не использовать `vastai execute` — его нет.** Для выполнения команд на инстансе: скопировать скрипт через `vastai copy`, потом передать интерактивно

### CRITICAL: Vast SSH proxy speed limits

Vast SSH proxy (ssh3.vast.ai, etc.) has **severe speed limits for large files** (~100 KB/s sustained):

| File size | Strategy | Typical speed |
|-----------|----------|---------------|
| < 1 MB | `scp` or `rsync` | 10-15 MB/s ✅ |
| 1-50 MB | `rsync` | 2-8 MB/s ⚠️ |
| 50-500 MB | `rsync` over SSH proxy | 100-500 KB/s ❌ |
| 500+ MB (checkpoints) | Avoid SSH proxy — see alternatives below | ~100 KB/s ❌❌ |

### Large file transfer: split + chunk rsync

```bash
# 1. Split archive into 500MB chunks on the Vast instance
ssh -p <PORT> root@<HOST> \
  "split -b 500M /tmp/large_archive.tar.gz /tmp/chunk_"

# 2. Rsync chunks over SSH proxy
mkdir -p /root/chunks
rsync -av --progress -e "ssh -p <PORT> -o StrictHostKeyChecking=no \
  -o UserKnownHostsFile=/dev/null -o ConnectTimeout=30 -o ServerAliveInterval=30" \
  root@<HOST>:/tmp/chunk_\* /root/chunks/

# 3. Reassemble locally
cat /root/chunks/chunk_\* > /root/large_archive.tar.gz
rm -rf /root/chunks/
```

**Важно:** 
- Не запускать несколько rsync параллельно на один SSH proxy — скорость падает в разы.
- `ServerAliveInterval=30` предотвращает разрыв соединения при простое.

### Instance offline/restart lifecycle

```bash
vastai start instance <ID>   # Работает даже на offline инстансах
vastai stop instance <ID>    # ⚠️ НЕ бесплатно: диск тарифицируется ($0.40/ГБ/мес) до destroy. По умолчанию — destroy
```

**Если инстанс offline:**
1. `vastai show instances | grep <ID>` — проверить статус
2. `vastai start instance <ID>` — перезапустить (данные на диске сохраняются)
3. Ждать 30-90 секунд пока статус сменится с `offline` → `running`
4. SSH/rsync снова доступен

## Запуск тренировки

### nohup через SSH (работает)

`nohup` через SSH работает нормально. Запускаем в фоне и мониторим лог:

```bash
# Запуск
ssh -o StrictHostKeyChecking=no -p <PORT> root@<HOST> 'cd /workspace && nohup python3 -u train.py --args > train.log 2>&1 & echo "PID=$!"'

# Мониторинг
ssh -p <PORT> root@<HOST> "tail -30 /workspace/train.log"
ssh -p <PORT> root@<HOST> "ps aux | grep [t]rain"
```

**Питфолл:** SSH-команда с `nohup ... &` может таймаутить на стороне Hermes (команда не возвращается сразу). Решение: добавлять `echo "PID=$!"` после `&` — команда завершается сразу после вывода PID. Если всё равно таймаутит — SSH timeout в Hermes уменьшает надёжность. Альтернатива: tmux (ниже).

### tmux (для интерактивного контроля)

```bash
ssh -p <PORT> root@<HOST> "tmux new-session -d -s train 'python3 -u train.py \
  --dataset /root/dataset.json \
  --batch-size 4 \
  --epochs 20 \
  --checkpoint-dir /root/checkpoints \
  2>&1 | tee /root/train.log'"
```

**Мониторинг:**
```bash
# Логи
ssh -p <PORT> root@<HOST> "tail -20 /root/train.log"

# GPU + память
ssh -p <PORT> root@<HOST> "nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total --format=csv,noheader"

# Проверить что тренировка идёт
ssh -p <PORT> root@<HOST> "ps aux | grep [t]rain"

# Подключиться к tmux сессии (интерактивно)
ssh -t -p <PORT> root@<HOST> "tmux attach -t train"
```

## Save-before-destroy checklist (v5 / v4.3)

### 🛑 CRITICAL ORDER: deliverable FIRST

1. **Сгенерировать результат MIDI/аудио** (inference)
2. **Отправить пользователю** (Telegram) и спросить подтверждение
3. **ТОЛЬКО ПОТОМ** сохранять чекпоинты/скрипты/датасет
4. **Проверить все running инстансы** — могут быть забытые (GPU 0%, без label)
5. Уничтожить инстансы

### Files to save — sequential order

#### 1. Мелкие файлы (датасет, логи, скрипты) — foreground `vastai copy`
```bash
mkdir -p /root/buratino/checkpoints
vastai copy C.<ID>:/root/dataset_v5.json /root/buratino/dataset_v5.json
vastai copy C.<ID>:/root/train_macro.log /root/buratino/train_macro.log
# скрипты уже локально — не нужны с Vast
```

**Если `FileExistsError`:** удалить локальный файл (может быть 0 байт-заглушка) и повторить.

#### 2. Чекпоинты (2-3 GB) — background `vastai copy` с notify
Поскольку foreground timeout ≤600s, а чекпоинты могут копироваться 5-15 минут:

```bash
terminal(command="vastai copy C.<ID>:/root/checkpoints/ /root/buratino/checkpoints/", background=true, notify_on_complete=true, timeout=600)
```

`vastai copy` использует прямой rsync-демон (не SSH proxy), скорость ~4-7 MB/s. 30 чекпоинтов по 76 MB (2.3 GB) копируются за ~5-8 мин.

**Проверка во время копирования:**
```bash
ls /root/buratino/checkpoints/ | wc -l   # сколько скачано
ls -la /root/buratino/checkpoints/ | tail -3  # последние
```

#### 3. Проверка после копирования
```bash
echo "dataset: $(ls -lah /root/buratino/dataset_v5.json)"
echo "log: $(ls -lah /root/buratino/train_macro.log)"
echo "checkpoints: $(ls /root/buratino/checkpoints/ | wc -l) files, $(du -sh /root/buratino/checkpoints/)"
echo "first:"; ls /root/buratino/checkpoints/ | head -3
echo "last:"; ls /root/buratino/checkpoints/ | tail -3
```

#### 4. Забытые инстансы — проверка всех
```bash
vastai show instances
# ЛЮБАЯ строка в выводе = трата денег прямо сейчас
# running → платит за GPU + диск
# exited  → платит за диск ($0.40/ГБ/мес), GPU не платит
# Правило: перед destroy скачать нужное, затем уничтожить ВСЁ
vastai destroy instance <ID> -y
```

**ОШИБКА, которая стоила $90.18:** ранняя версия этого скилла утверждала «уничтожить все, кроме exited (не жрут деньги)». Это неверно — `exited` платит за диск. Никогда не оставлять `exited` инстансы.

#### 5. Уничтожение
```bash
yes | vastai destroy instance <ID>
# Подтверждение: команда принимает stdin-пайп
```

#### 6. Отчёт пользователю
Формат:
- **Сохранено:** что, размеры, количество
- **Уничтожено:** ID, цена, причина
- **Баланс:** сколько осталось
- **Дальше:** что не сделано (например, микро-обучение не начато)

### Критерии: когда что использовать

| Объём | Способ | Скорость | Время для 2.3 GB |
|-------|--------|----------|-----------------|
| <100 MB | `vastai copy` foreground | 10-15 MB/s | <10 сек |
| 100 MB - 3 GB | `vastai copy` background | 4-7 MB/s | 5-15 мин |
| >3 GB или нестабильно | split + rsync chunks через SSH proxy | 100-500 KB/s | часы — лучше сохранить только скрипты+датасет |

**Критическое решение (принимать быстро):**
- Если `vastai copy` рвётся на больших файлах (см. баг: rsync error code 255 / broken pipe) — повторить, иногда второй раз работает
- Если стабильно не копируется — сохранить только скрипты+датасет, записать финальный loss, принять потерю чекпоинтов
- **Исключение:** пользователь явно сказал «сохрани всё» — использовать chunking (+split на Vast)

## Performance Benchmarks (RTX 3090, v4.3 133M params)

| Параметр | Значение |
|----------|----------|
| GPU | RTX 3090 24GB |
| Модель | 133M params, 768 dim, 8+8 layers, 12 heads |
| batch_size | 4 |
| GPU memory | ~10.3 GB (из 24 GB) |
| Скорость | ~2 батча/сек |
| Время на эпоху | ~54 мин (25,881 окон, ~6,471 батчей) |
| Стоимость | ~$0.007/эпоха ($0.129/ч) |

## Инференс (v4)

### Обычный
```bash
ssh -p <PORT> root@<HOST> "cd /workspace && python3 -u v4_infer.py /workspace/input.mid 1.5 /workspace/output.mid /workspace/checkpoints/residual_v4/residual_best.pt 2>&1"
```

### Prefix conditioning
Модифицированная версия v4_infer.py с prefix conditioning. Перед генерацией residuals decoder «просматривает» весь cold score через KV-cache prefill.
```bash
python3 -u v4_infer.py /workspace/input.mid 1.5 /workspace/output_prefix.mid /workspace/checkpoints/residual_v4/residual_best.pt
```

Температура: `1.2` — subtle, `1.5` — expressive.

## Инференс (v4.3)

**Важно:** v4.3 infer использует argparse с **именованными флагами** (не позиционные аргументы):

```bash
python3 infer_v43.py \
  --input /root/score.mid \
  --output /root/performance.mid \
  --checkpoint /root/checkpoints_v43/v43_latest.pt \
  --temperature 1.5
```

Параметры:
- `--temperature 1.2` — subtle, `1.5` — expressive
- `--top-k 40` (default)
- `--device cuda` (default)

### Полный цикл теста

1. **Установить зависимости**: `pip3 install miditoolkit`
2. **Остановить тренировку**: `pkill -f train_v43.py && sleep 5`
2. **Запустить infer** с v43_latest.pt
3. **Скопировать .mid на сервер**: `rsync root@<HOST>:/root/output.mid /root/`
4. **Отправить в Telegram**: `source /root/.hermes/.env && curl -X POST "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/sendDocument" -F chat_id=420839805 -F document=@/root/output.mid`
5. **Сохранить всё на сервер** (см. save-before-destroy выше)
6. **Уничтожить инстанс**: `vastai destroy instance <ID>`

## CUDA OOM Prevention (RTX 3090 24GB)

| Проблема | Симптом | Решение |
|----------|---------|---------|
| batch_size=2 → OOM | 23.3/24GB alloc | `batch_size=1, grad_accum=8` |
| Memory fragmentation | "reserved but unallocated" | `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True` |
| Sequence padding waste | Pad до max длины | Bucketing по длине или batch_size=1 |
| Zombie Python processes | CUDA memory занят | `kill -9 $(ps aux | grep python | grep -v grep | awk '{print $2}')` |

**Проверка перед запуском:**
```bash
nvidia-smi  # free memory > 22GB?
kill -9 $(ps aux | grep 'python' | grep -v grep | awk '{print $2}')
```

**Эффективный запуск обучения:**
```bash
PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True python3 -u train.py 2>&1 | tee train_log.txt
```

### Несколько инстансов на одной GPU
Vast.ai может запустить 2+ инстанса на одной RTX 3090/4090 (GPU sharing). Вызывает CUDA OOM даже если каждый использует ~5GB. Проверять `vastai show instances` — если два инстанса на одной machine_id, memory делится.

### Multi-GPU инстансы: GPU 0 может быть занят
На multi-GPU инстансах (2× RTX 4090) GPU 0 может быть занят другим процессом (shared machine). Всегда проверять `nvidia-smi` перед запуском и использовать `--device=cuda:1` если GPU 0 занят. В nanoGPT/PyTorch: передавать `--device=cuda:1` (или `CUDA_VISIBLE_DEVICES=1`).

## Примечания

- Не забывать выключать инстанс когда не используется — экономия бюджета
- **Telegram sendDocument** может падать через curl с exit 3 без вывода — редко, но бывает. Перезапуск с `-v` помогает диагностировать
- **Не запускать несколько rsync параллельно** на один Vast proxy — скорость падает в разы. Сериализуй передачи
