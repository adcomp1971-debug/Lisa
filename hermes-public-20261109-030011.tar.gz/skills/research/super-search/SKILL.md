---
name: super-search
description: "Умный роутер поисковых запросов — выбирает оптимальный MCP (brave-search, exa, tavily, firecrawl) под тип задачи. Единый интерфейс для всех поисковых возможностей."
version: 1.1.0
---

# Super Search

**Назначение:** автоматически выбирать лучший поисковый инструмент под тип запроса. У Hermes 4 поисковых MCP (brave-search, exa, tavily, firecrawl) + встроенный web_search. Задача скилла — не гадать, а осознанно роутить.

## Доступные инструменты

| Инструмент | MCP | Сильная сторона |
|------------|-----|-----------------|
| `mcp_brave_search_brave_web_search` | brave-search ✅ | Новости, изображения, локальный поиск, freshness фильтры (pd/pw/pm/py) |
| `mcp_brave_search_brave_news_search` | brave-search ✅ | Поиск только по новостям |
| `mcp_brave_search_brave_image_search` | brave-search ✅ | Поиск только по картинкам |
| `mcp_brave_search_brave_local_search` | brave-search ✅ | Места, бизнесы, заведения |
| `mcp_brave_search_brave_llm_context` | brave-search ✅ | Пре-извлечённый контент для LLM (RAG-ready) |
| `mcp_exa_web_search_exa` | exa | Семантический поиск, code search, company research |
| `mcp_exa_web_fetch_exa` | exa | Чистый контент с URL |
| `mcp_tavily_tavily_search` | tavily | Быстрый поиск с raw content |
| `mcp_tavily_tavily_extract` | tavily | Извлечение контента с URL |
| `mcp_tavily_tavily_crawl` | tavily | Краулинг сайта |
| `mcp_tavily_tavily_research` | tavily | Глубокий multi-source research |
| `mcp_firecrawl_firecrawl_search` | firecrawl | Поиск + extract контента (мощный) |
| `mcp_firecrawl_firecrawl_scrape` | firecrawl | Скрейпинг одной страницы (лучший) |
| `mcp_firecrawl_firecrawl_crawl` | firecrawl | Краулинг сайта (рекурсивный) |
| `mcp_firecrawl_firecrawl_extract` | firecrawl | Структурированное извлечение по схеме |
| `mcp_firecrawl_firecrawl_map` | firecrawl | Карта URLs сайта |
| `web_search` | built-in | Простой поиск (fallback) |
| `web_extract` | built-in | Быстрое извлечение контента (до 5 URL) |

> ⚠️ **Проверено 2026-09-26:** фактически подключены brave-search, firecrawl, github, playwright, source-library, agentmail, sqlite-vpnbot. **tavily подключён** (`enabled: true`, ключ в `.env`) — заработает только после рестарта gateway (его делает только Алекс). **exa НЕ подключён** (MCP вообще нет), хотя `EXA_API_KEY` лежит в `.env` — запрос к exa вернёт «unknown tool».

## Маршрутизация

### Тип 1: Новости, текущие события
**Критерии:** свежесть (<7 дней), breaking news, daily digest
**Выбор:** `mcp_brave_search_brave_news_search` (freshness=pd/pw)
**Fallback:** `mcp_tavily_tavily_search` (time_range=day/week)

### Тип 2: Факты, общие запросы, «что такое Х»
**Критерии:** общий вопрос, справочная информация
**Выбор:** `mcp_brave_search_brave_web_search` (быстрый, свежий)
**Если нужен готовый текст сразу (а не список ссылок):** `mcp_brave_search_brave_llm_context` — отдаёт пре-извлечённый, ранжированный контент одним вызовом (RAG-ready), экономит обращение к extract.
**Fallback:** `mcp_firecrawl_firecrawl_search`, `web_search`

### Тип 3: Глубокий research, multi-source анализ
**Критерии:** сравнение, обзор, аналитика, 5+ источников
**Выбор:** `mcp_tavily_tavily_research` (model=pro для сложного, mini для узкого)
**Fallback:** `mcp_firecrawl_firecrawl_agent`

### Тип 4: Документация, код, технические вопросы
**Критерии:** API docs, библиотека, туториал, код, github
**Выбор:** `mcp_firecrawl_firecrawl_search` + `mcp_firecrawl_firecrawl_scrape` (exa не подключён)
**Fallback:** `mcp_firecrawl_firecrawl_search` + `firecrawl_scrape`

### Тип 5: Скрейпинг конкретной страницы
**Критерии:** есть URL, нужен полный текст
**Выбор:** `mcp_firecrawl_firecrawl_scrape` (лучший скрейпер)
**Fallback:** `mcp_firecrawl_firecrawl_scrape`, `web_extract`

### Тип 6: Краулинг сайта (несколько страниц)
**Критерии:** нужно понять структуру сайта, собрать документацию
**Выбор:** `mcp_firecrawl_firecrawl_map` (быстрый обзор) → `firecrawl_crawl` (глубокий)
**Fallback:** `mcp_tavily_tavily_crawl`

### Тип 7: Компании, люди, LinkedIn
**Критерии:** company research, кто работает в Х, linkedin
**Выбор:** `mcp_brave_search_brave_web_search` (+`brave_local_search`) — exa не подключён
**Fallback:** `mcp_brave_search_brave_web_search`

### Тип 8: Места, бизнесы, POI
**Критерии:** рестораны, магазины, "где поесть", местные услуги
**Выбор:** `mcp_brave_search_brave_local_search` + `mcp_brave_search_brave_place_search`
**Fallback:** `web_search`

### Тип 9: Картинки, изображения
**Критерии:** find image of X, logo, photo, схема
**Выбор:** `mcp_brave_search_brave_image_search`
**Fallback:** `web_search`

### Тип 10: Структурированные данные с сайта (цены, характеристики)
**Критерии:** конкретные поля с конкретных страниц, прайсы, спецификации
**Выбор:** `mcp_firecrawl_firecrawl_extract` с JSON schema
**Fallback:** `mcp_firecrawl_firecrawl_scrape` с formats=['json']

### Тип 11: Вакансии, поиск работы
**Критерии:** найти вакансии, job search, работа
**Выбор:** `mcp_firecrawl_firecrawl_search` (агрегаторы) + `mcp_brave_search_brave_web_search` (freshness=pw для свежих)
**Fallback:** delegated subagent (toolsets=['web','search','terminal']) для обхода 8+ платформ
**Специализированные запросы:**
- `site:hh.ru "AI агент" OR "LLM" инженер удаленно` (русский рынок)
- `site:career.habr.com "DevOps" OR "MLOps" удаленная работа` (Habr)
- `site:wellfound.com "AI infrastructure" OR "AI agent" REMOTE` (стартапы)
- `site:workatastartup.com "infrastructure" OR "DevOps" remote AI` (YC)

## Протокол вызова

1. **Определи тип** запроса по таблице выше. Если сомневаешься — выбери 2-3 наиболее подходящих.
2. **Запусти лучший вариант** — один вызов, не «попробую все подряд».
3. **Если результат пустой/мусорный** — fallback на второй по счёту.
4. **4 результата = уже хватит** для ответа. Не надо 50 ссылок если первых 4 достаточно.
5. **При ответе цитируй источники** — URL + название страницы.

## Примеры

### Новости
```
Запрос: «что случилось с Nvidia за последнюю неделю»
→ mcp_brave_search_brave_news_search(query="Nvidia", freshness="pw")
```

### Deep research
```
Запрос: «сравнение DeepSeek V4 и Claude Sonnet 4 — плюсы и минусы»
→ mcp_tavily_tavily_research(input="DeepSeek V4 vs Claude Sonnet 4 comparison", model="pro")
```

### Технический вопрос
```
Запрос: «как настроить fallback провайдеры в Hermes Agent»
→ mcp_firecrawl_firecrawl_search(query="Hermes Agent fallback provider setup")
```

### Компания
```
Запрос: «что за компания Nous Research, кто основатели»
→ mcp_exa_web_search_exa(query="Nous Research founders category:company")
```

### Вакансии
```
Запрос: «найди работу AI инженером удалённо»
→ mcp_brave_search_brave_web_search(freshness="pw", query="remote AI infrastructure OR MLOps engineer 2026")
  + mcp_firecrawl_firecrawl_search(query="remote job AI infrastructure OR LLM DevOps engineer")
```

## Режим «интересное» — on-demand (запрос Алекса «найди интересное про X»)

Три домена. Роутить по домену, не спамить всеми MCP.

### 1. Разведка / OSINT
- **Dorks (работает):** brave/firecrawl с `site:`, `filetype:`, `intitle:`, `inurl:`, `"точная фраза"`, `-минус`.
- **Onion-сеть (работает):** tor активен, SOCKS `127.0.0.1:9050`, проверено `https://check.torproject.org` → 200.
  Вызов: `bash /root/.hermes/skills/research/super-search/scripts/onion-search.sh "запрос"` → Torch (~3.6 млн документов).
  - **Свой инстанс под конкретный exit** (нужен exit в стране X): отдельный `SocksPort` + `DataDirectory` в своём torrc, `StrictNodes 1`. В `ExitNodes` fingerprint пишется **с `$`**: `ExitNodes $ABCDEF…`; формат `{ABCDEF…}` → `malformed … Discarding entire list`, `Invalid router list`, tor не стартует (симптом — процесс умирает молча, `--verify-config` показывает причину).
  - **Сначала проверять сам exit:** `curl -s --max-time 45 --socks5-hostname 127.0.0.1:<port> https://api.ipify.org`. Пустой ответ = узел мёртв, к целевому сайту идти бессмысленно и ждать 2 минуты на таймауте.
  - Параметр запроса — `P=`, не `query=`. Без DB-параметра. Ответ <2 КБ = это форма, не выдача.
  - Адрес .onion «падает за 0.001 с» = устаревший или мёртвый сервис; адреса ротируются, искать актуальный через clearnet.
  - **Правила:** только чтение. Не качать файлы с .onion, не заходить на маркеты, не вводить свои креды, ничего не исполнять.
- **Открытые устройства и утечки (НЕ подключено):** Shodan, Censys, Fofa, DeHashed, Intelligence X, HIBP — ключей нет. Без ключей их не заменить.
- **Запрещено:** активные сканы (nmap/masscan/брут) по чужим адресам. Наш IP несёт VPN-клиентов и биллинг — абьюз-жалоба = блокировка адреса = смерть VPN. Пассивные сервисы (они сканируют сами) — можно.

### 2. Техно-находки
- Свежие релизы и новости: `brave_news_search` (freshness=pd/pw).
- Код и репозитории: github MCP + `gh search repos/code/issues` (gh залогинен).
- Статьи: arXiv через `web_extract`, HN/Reddit/Lobsters через brave.
- Схема: news(pd) + `gh search repos "X" --sort=updated` + arXiv — три источника, потом ответ.

### 3. Эзотерика / древние тексты
- `source-library` MCP: `search_library` → `search_concept` → `get_quote` (22k+ книг, есть иудаика).
- Скилл `knowledge-archive-network` (IA / LoC / Sefaria) и `germetist-router` (локальный RAG, Flask :5080).
- Правило Алекса: проверять по всем архивам, не отвечать «нет в базе», не качать книги под один вопрос, мусорные источники не давать.

### Формат выдачи Алексу
- Коротко, plaintext, со ссылками и датами. 3–7 находок, не 50. Без воды и без таблиц.
- Реальные результаты инструментов, не пересказ. Если ничего — сказать «пусто», не выдумывать.

## Провалы и fallback порядок

| Если первый выбор | Fallback 1 | Fallback 2 |
|-------------------|------------|------------|
| brave-search | firecrawl/search | web_search |
| hh.ru (русские вакансии) | браузер (Playwright) | веб-поиск site:hh.ru |
| tavily | firecrawl/agent | brave + exa вместе |
| firecrawl/search | tavily/search | web_search |
| firecrawl (unreachable/402) | web_search | brave_web_search |

## Важно

- **Не спамить всеми MCP подряд.** Один-два вызова — максимум.
- **Brave search** для быстрых фактов и новостей. **Firecrawl** для качественного контента. **Exa** для семантического поиска. **Tavily research** для глубокого дайва.
- Если результат пустой — не надо сразу второй MCP, попробуй переформулировать запрос.
- **Квоты Tavily:** бесплатный ключ имеет месячный лимит. При превышении возвращает `monthly_cap_reached`. Fallback на brave-search или firecrawl.
