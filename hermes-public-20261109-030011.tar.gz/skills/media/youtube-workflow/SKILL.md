---
name: youtube-workflow
description: "Complete YouTube workflow: content extraction (transcripts, summaries) and channel monitoring (RSS scouting, cron delivery)."
category: media
version: 1.0.0
author: Hermes Agent
---

# YouTube Workflow Umbrella

This skill covers the entire YouTube content lifecycle. Use the relevant subsection based on your current task.

## 1. Content Extraction (`youtube-content`)
Transform YouTube transcripts into structured content (chapters, summaries, Twitter threads, blog posts).

- **Fetch:** `python3 scripts/fetch_transcript.py "URL" --text-only --timestamps`
- **Language:** Use `--language tr,en` for specific language with fallback chain.
- **Fallbacks:** If API is blocked (common on cloud VPS), use the 4-tier fallback (ниже нумерация tier 1–4, других уровней нет):
  1. Browser description + JSON-LD metadata extraction (always works, provides chapter timestamps).
  2. `youtube-transcript-proxy` (Invidious mirrors).
  3. `youtube-audio-transcribe` (faster-whisper, takes 5-30 min).
  4. `video-summary-web-fallback` (search web for existing summaries).

**Output Formats:** Chapters, Summary, Chapter summaries, X/Thread format, Blog post.

## 2. Channel Monitoring / Scouting (`youtube-scout`)
Automated detection of new videos on specified YouTube channels via RSS + SQLite deduplication + cron delivery.

- **RSS URL pattern:** `https://www.youtube.com/feeds/videos.xml?channel_id=UC...`
- **Workflow:** Script checks RSS, saves unseen `video_id` to SQLite, outputs concise digest.
- **Cron (no_agent):** Fast, title-only delivery. Pass `--since 48` to limit to last 48h (prevents massive first-run dumps).
- **Cron (LLM):** Slower, uses `web_extract` on new video URLs to pull full description + chapters, then generates a Russian-language technical summary with "Key features" and "Useful takeaways".

**Finding Channel IDs:** Navigate to `https://www.youtube.com/@ChannelName`, extract `ytInitialData.metadata.channelMetadataRenderer.externalId` via `browser_console`.

## 3. Downloading the video FILE (not the transcript)
When the task needs pixels (editing, frame analysis, subtitles burn-in), download with `yt-dlp` and expect «Sign in to confirm you're not a bot» on any datacenter IP. Player-client juggling (`tv`, `ios`, `android`, `web_embedded`, `web_safari`) does NOT fix it; the block is IP reputation, not client.

Working route — Tor:
```bash
systemctl is-active tor                                   # tor usually already up, SOCKS 127.0.0.1:9050
curl -s --socks5-hostname 127.0.0.1:9050 --max-time 25 -o /dev/null -w '%{http_code}\n' https://www.youtube.com/   # must be 200
cd <workdir>
yt-dlp --proxy socks5h://127.0.0.1:9050 --no-playlist \
  -f "bv*[height<=1080]+ba[ext=m4a]/b[height<=720]" --merge-output-format mp4 -o "src.%(ext)s" "<url>"
```
A 37 s Shorts at 1080p came down in seconds — Tor is fast enough for clips, do not rule it out on speed.

- **Third-party Invidious/Piped/cobalt API gives you a `googlevideo.com` URL that 403s.** The signed URL carries `ip=` of the instance that minted it; only that IP can fetch it. Don't spend calls re-downloading with `-L`, Range headers or Referers — get the file from `yt-dlp` directly (via Tor) instead.
- **AV1 output breaks OpenCV.** Shorts often arrive as `av1`. `cv2.VideoCapture` then reads 0 frames with «Your platform doesn't support hardware accelerated AV1 decoding». Transcode before any frame work: `ffmpeg -i src.mp4 -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p -c:a copy work.mp4`. Verify: `/usr/bin/python3 -c "import cv2;c=cv2.VideoCapture('work.mp4');print(c.isOpened(),c.read()[0])"`.
- **Vertical Shorts:** expect e.g. 608x1080 @30fps; `ffprobe` first — resolution/fps decide whether CPU frame work is feasible.

## Linked Resources
- `scripts/fetch_transcript.py` (core transcript fetching)
- `scripts/fetch_transcript.py` (см. раздел 2 для RSS мониторинга)
- `references/output-formats.md` (formatting guidelines for summaries/threads)
- `references/full-script.md` (complete scout script example)

## Pitfalls
- **Cloud IP blocks:** YouTube aggressively blocks cloud IP ranges for direct transcript API. Default to tier 1 (browser extraction) or tier 2 (Invidious proxy) immediately.
- **Auto-dubbed videos:** Have NO caption tracks. Tier 3 (audio transcription) will transcribe the low-quality dubbed audio. Use tier 1 (browser metadata) instead.
- **Long videos (>1h):** Chunk transcripts into 40K-character overlapping segments before summarizing.
- **First cron run:** Collects ALL videos in RSS. Always use `--since 48` for recurring cron jobs.