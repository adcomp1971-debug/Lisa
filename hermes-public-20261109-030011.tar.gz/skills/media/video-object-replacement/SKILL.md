---
name: video-object-replacement
description: "Use when replacing an object or face in a video (CPU)."
category: media
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [video, opencv, ffmpeg, compositing]
    related_skills: [youtube-workflow]
---

# Video Object Replacement (CPU, ffmpeg + OpenCV)

## When to Use

- «замени голову/лицо/объект в видео», «прикрути X к Y» — весь ролик или его кусок.
- Нужно протащить наклейку/объект через кадры с трекингом, а GPU нет или платный инстанс не подтверждён.
- Монтажный материал (Shorts/клип): сначала карта шотов и пробный отрезок, потом решение по всему клипу.

Не для этого скилла: субтитры и перевод (→ `video-subtitles`), скачивание источника (→ `youtube-workflow` §3).

This is the local-CPU path: no GPU, no paid instance. Works for clips of tens of seconds at ≤1080p.

Do NOT promise After-Effects quality. Be explicit up front: local = colour tracking + compositing; realistic segmentation/inpainting of a moving subject = GPU (SAM 2 + ProPainter/LaMa on Vast.ai, money, needs confirmation).

## Procedure

1. **Get the source and look at it.** Download (see `youtube-workflow` §3 for the Tor route past YouTube's bot check), then `ffprobe` for resolution/fps/duration. Shorts-like vertical clips land at e.g. 608x1080 @30fps → ~1100 frames, fine for CPU.
2. **Transcode AV1 → H.264 before touching frames.** OpenCV reads 0 frames from AV1 with «platform doesn't support hardware accelerated AV1 decoding». `ffmpeg -i src.mp4 -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p -c:a copy work.mp4`.
3. **Map the edit points BEFORE writing the renderer.** Extract a low-fps contact sheet and look at it:
   `ffmpeg -i work.mp4 -vf "fps=0.4,scale=304:-1" frames/f_%03d.jpg`, tile the frames into one numbered grid with `cv2.putText`, run `vision_analyze` on it.
   Music-video/Shorts material is a **montage**: it cuts between close-ups, extreme close-ups, crowd shots and wide stage shots. Write down per-shot time ranges: where the subject is large and clear, where it is tiny or absent, where the frame is blown out. Do not promise «заменю во всём клипе» before this map exists.
4. **Gate the source photo before cutting anything.** Cutout quality is decided by the photo, not by the algorithm: a light/white subject on a cluttered or bright background (bottles, papers, terrazzo floor) cannot be separated cleanly — grabCut, colour masks and rembg all return holes, ragged ears and background patches. Require: homogeneous contrasty background, subject ≥ 1/3 of the frame, sharp, near-frontal. If the user's photo fails the gate, say so and ask for another one **before** rendering; polishing a bad cutout is the fastest way to a rejected clip.
   Then cut: `cv2.grabCut` rect strictly inside the subject (10 iterations) → keep the biggest connected component → **erode the alpha 4× with 3x3 kernel (choke)** → `GaussianBlur(3x3)`. The choke is what removes the pale halo; colour tuning does not. Model-based alternative for fur/hair edges (needs `rembg` on CPU): `references/cutout-quality.md`.
5. **Track the target per frame by colour when it is colour-coded.** A red balaclava / bright garment tracks far more stably than generic CSRT:
   - HSV `inRange` for red across **two** bands `(0,90,40)-(12,255,255)` and `(168,90,40)-(180,255,255)`; OR them.
   - Restrict the search: zero everything below ~50% of height, outside the central 80% of width. Reject blobs by area floor/ceiling and bbox size — this is what stops neon signage and warm skin tones from winning.
   - Score `area × 1.4` for plausible head height, `area × 0.6` elsewhere; take the argmax.
   - **Smooth the track in a second pass**: per-parameter sliding median (window ~7) then moving average (window ~5), and fill gaps with the nearest valid sample. Without this the overlay jitters visibly.
6. **Composite.** Overlay width `≈1.4–1.5 × tracked bbox width`, alpha-resized to the same size. Then, or it reads as a sticker:
   - soft shadow: filled ellipse below the overlay, heavy `GaussianBlur`, multiply the plate by `1-0.9·mask`;
   - colour grade to the scene (dark warm club ≈ BGR × [0.78, 0.90, 1.06] and overall ×0.72);
   - film grain `normal(0, 3.5–5)` and `GaussianBlur(σ≈0.6)` on the overlay only — **skip both when the overlay is under ~150 px wide**: at that size grain and blur read as mush, not as film.
7. **Hide the old subject** where it can peek out from under the overlay: `cv2.inpaint(frame, elliptical_mask, 7, INPAINT_TELEA)` over the original head/object region.
8. **Render and mux in one encode.** `cv2.VideoWriter` (mp4v) the frames, then `ffmpeg -i seg_raw.mp4 -ss START -t DUR -i src.mp4 -map 0:v -map 1:a -c:v libx264 -crf 16 -c:a aac -shortest out.mp4` (crf 16–17, not 20: the mp4v intermediate already costs a generation, a second coarse pass smears a small overlay).
9. **Self-review before sending — mandatory.** Tile frames of the *rendered* clip into a sheet, run `vision_analyze` asking exactly: is the overlay on target in every frame or does it slide, is the original colour still visible, halo/edges, size plausibility, where the track breaks. Then pull **one frame at full clip resolution** and compare it side by side with the same frame of the source — a downscaled contact sheet (300 px wide) hides mush, edge dirt and grain, which is exactly what the user sees and rejects. Fix, re-render, and only then deliver.

A ready renderer to copy and adapt: `scripts/render_seg.py <start_s> <end_s>` (colour tracking + smoothing + compositing + mux, all steps above).

## Rules for this user

- Deliver a **short segment** as the probe (6–10 s around a shot where the subject is clear), not a full-clip claim. Ask two things in the same message: which shots to process, and overlay scale — deliberately oversized meme look vs. fitted to the real head size.
- Video goes as a **file** (`send_file.py <path> "<caption>" <name>.mp4`), stills as photos (`send_photo_inline.py`). Never paste a media path into the chat text.
- Report honestly what the probe shows: track breaks, jitter, halo. «Пока криво, чиним» is accepted; a false «готово» is not.

## Pitfalls

- **Downscaled contact sheets lie.** A 300 px preview of an overlay that is ~70 px in the frame looks acceptable while the real thing is mush with dirty edges. Always confirm on a 1:1 crop of the rendered frame at delivery resolution before sending.
- **Work in a permanent directory, not the scratch cache.** The scratch dir prunes entries idle ~24 h, so a multi-day edit loses sources, masks and scripts between sessions; keep the project under `/root/<project>/` and treat scratch as throwaway probes only.
- **A single composited still is not a probe.** A frame grabbed from the video thumbnail and pasted looks like a cheap sticker; the user reads it as the final result and rejects it. If you must show a still, run the same shadow/grade/grain chain and the vision self-review first.
- **Extreme close-ups and blown-out frames break colour tracking** (subject fills >60% of frame, hue washes to white). Reject them by bbox area/height ceiling; in those shots either hand-set the bbox or skip and say so — a track that latches onto a blowout drags the overlay off the subject for the whole shot.
- **Overlay sized from bbox alone drifts** when the subject approaches the camera: clamp the size and re-check on the contact sheet of the output.
- **`cv2.imread(...) or cv2.imread(...)` throws** `ValueError: truth value of an array ... is ambiguous` — test `is None` explicitly.
- Terminal output truncation («1 lines output») hits long ffmpeg/ffprobe runs: write to a file and read it back.
