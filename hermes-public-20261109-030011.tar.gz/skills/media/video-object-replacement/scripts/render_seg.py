# Replace a colour-tracked object/head in a video segment (CPU only).
# usage: /usr/bin/python3 render_seg.py <start_sec> <end_sec>
# Adapt BASE, PHOTO, PHOTO_BOX, HSV bands, OVERLAY_SCALE, GRADE to the task.
# Source must already be H.264 (AV1 first: ffmpeg -i src.mp4 -c:v libx264 -crf 18 work.mp4)
import cv2, numpy as np, sys, subprocess, os

BASE = "/root/.hermes/cache/scratch/<task>"
SRC = f"{BASE}/work.mp4"          # H.264
OUT = f"{BASE}/probe_seg.mp4"
PHOTO = f"{BASE}/subject.jpg"     # still used as the overlay
PHOTO_BOX = (560, 40, 900, 390)   # (x0,y0,x1,y1) box around the subject, with margin
OVERLAY_SCALE = 1.45              # overlay width / tracked bbox width
GRADE = (0.78, 0.90, 1.06)        # BGR multipliers toward the scene light
BRIGHT = 0.72                     # overall brightness multiplier
START, END = float(sys.argv[1]), float(sys.argv[2])

# ---------- cut the overlay out of the still ----------
img = cv2.imread(PHOTO)
if img is None:
    sys.exit(f"cannot read {PHOTO}")
x0, y0, x1, y1 = PHOTO_BOX
crop = img[y0:y1, x0:x1].copy()
h, w = crop.shape[:2]
mask = np.zeros((h, w), np.uint8)
bgd, fgd = np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64)
cv2.grabCut(crop, mask, (34, 26, w - 68, h - 70), bgd, fgd, 10, cv2.GC_INIT_WITH_RECT)
alpha = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
k = np.ones((5, 5), np.uint8)
alpha = cv2.morphologyEx(alpha, cv2.MORPH_OPEN, k, 2)
alpha = cv2.morphologyEx(alpha, cv2.MORPH_CLOSE, k, 2)
n, lab, st, _ = cv2.connectedComponentsWithStats(alpha, 8)
if n > 1:
    alpha = np.where(lab == 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA])), 255, 0).astype(np.uint8)
for _ in range(4):                      # choke: kills the pale halo
    alpha = cv2.erode(alpha, np.ones((3, 3), np.uint8), 1)
alpha = cv2.GaussianBlur(alpha, (3, 3), 0)
ys, xs = np.where(alpha > 40)
HEAD = img[y0 + ys.min():y0 + ys.max() + 1, x0 + xs.min():x0 + xs.max() + 1].copy()
HEAD_A = alpha[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
print("overlay:", HEAD.shape[1], "x", HEAD.shape[0], flush=True)

# ---------- pass 1: colour track ----------
cap = cv2.VideoCapture(SRC)
W, H = int(cap.get(3)), int(cap.get(4))
FPS = cap.get(5) or 30

def find_target(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    m = cv2.bitwise_or(cv2.inRange(hsv, (0, 90, 40), (12, 255, 255)),
                       cv2.inRange(hsv, (168, 90, 40), (180, 255, 255)))
    m[int(H * 0.50):, :] = 0            # search zone: upper half
    m[:, :int(W * 0.10)] = 0
    m[:, int(W * 0.92):] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8), 2)
    n, lab, st, cen = cv2.connectedComponentsWithStats(m, 8)
    best = None
    for i in range(1, n):
        a = st[i, cv2.CC_STAT_AREA]
        bw, bh = st[i, cv2.CC_STAT_WIDTH], st[i, cv2.CC_STAT_HEIGHT]
        if a < 900 or bw < 25 or bh < 25 or bw > W * 0.95 or bh > H * 0.6:
            continue
        if not (W * 0.15 < cen[i][0] < W * 0.85):
            continue
        score = a * (1.4 if H * 0.05 < cen[i][1] < H * 0.45 else 0.6)
        if best is None or score > best[0]:
            best = (score, st[i, cv2.CC_STAT_LEFT], st[i, cv2.CC_STAT_TOP], bw, bh)
    return None if best is None else list(best[1:])

f0, f1 = int(START * FPS), int(END * FPS)
cap.set(cv2.CAP_PROP_POS_FRAMES, f0)
tracks = []
while len(tracks) < (f1 - f0):
    ok, fr = cap.read()
    if not ok:
        break
    tracks.append(find_target(fr))
valid = [i for i, t in enumerate(tracks) if t]
if not valid:
    sys.exit("target never found — widen the HSV bands or the search zone")
for i, t in enumerate(tracks):
    if not t:
        tracks[i] = list(tracks[min(valid, key=lambda j: abs(j - i))])
arr = np.array(tracks, np.float32)
sm = arr.copy()
for c in range(4):
    for i in range(len(arr)):
        lo, hi = max(0, i - 7), min(len(arr), i + 8)
        sm[i, c] = np.median(arr[lo:hi, c])
    sm[:, c] = np.convolve(sm[:, c], np.ones(5) / 5, mode="same")
    sm[:2, c] = sm[2:3, c]
    sm[-2:, c] = sm[-3:-2, c]
print(f"frames {len(tracks)}, found {len(valid)}", flush=True)

# ---------- pass 2: composite ----------
cap.set(cv2.CAP_PROP_POS_FRAMES, f0)
vw = cv2.VideoWriter(f"{BASE}/seg_raw.mp4", cv2.VideoWriter_fourcc(*"mp4v"), FPS, (W, H))
rng = np.random.default_rng(3)
for i in range(len(tracks)):
    ok, fr = cap.read()
    if not ok:
        break
    bx, by, bw, bh = sm[i]
    cx, cy = bx + bw / 2, by + bh / 2
    TW = int(max(48, bw * OVERLAY_SCALE))
    NH = max(1, int(HEAD.shape[0] * (TW / HEAD.shape[1])))
    ov = cv2.resize(HEAD, (TW, NH), interpolation=cv2.INTER_AREA).astype(np.float32)
    aa = cv2.resize(HEAD_A, (TW, NH), interpolation=cv2.INTER_AREA).astype(np.float32)[:, :, None] / 255.0
    sh = np.zeros((H, W), np.float32)
    ox, oy = int(cx - TW / 2), int(cy + bh * 0.12 - NH / 2)
    cv2.ellipse(sh, (int(cx), oy + NH - 8), (int(TW * 0.5), 26), 0, 0, 360, 0.7, -1)
    sh = cv2.GaussianBlur(sh, (0, 0), 18)
    plate = fr.astype(np.float32) * (1 - sh[:, :, None] * 0.85)
    for c, m in enumerate(GRADE):
        ov[:, :, c] *= m
    ov *= BRIGHT
    ov += rng.normal(0, 3.5, ov.shape).astype(np.float32)
    ov = cv2.GaussianBlur(np.clip(ov, 0, 255), (0, 0), 0.6)
    x1c, y1c = min(W, ox + TW), min(H, oy + NH)
    x0c, y0c = max(0, ox), max(0, oy)
    if x1c > x0c and y1c > y0c:
        hx0, hy0 = x0c - ox, y0c - oy
        sub = ov[hy0:hy0 + (y1c - y0c), hx0:hx0 + (x1c - x0c)]
        asub = aa[hy0:hy0 + (y1c - y0c), hx0:hx0 + (x1c - x0c)]
        plate[y0c:y1c, x0c:x1c] = sub * asub + plate[y0c:y1c, x0c:x1c] * (1 - asub)
    vw.write(np.clip(plate, 0, 255).astype(np.uint8))
vw.release(); cap.release()

r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", f"{BASE}/seg_raw.mp4",
                    "-ss", str(START), "-t", str(END - START), "-i", SRC,
                    "-map", "0:v", "-map", "1:a", "-c:v", "libx264", "-preset", "medium",
                    "-crf", "20", "-c:a", "aac", "-shortest", OUT], capture_output=True, text=True)
print("ffmpeg rc:", r.returncode, r.stderr[:200])
print("out:", OUT, os.path.getsize(OUT) if os.path.exists(OUT) else "-")
