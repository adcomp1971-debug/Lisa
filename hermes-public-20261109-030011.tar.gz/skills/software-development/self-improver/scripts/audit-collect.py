#!/usr/bin/env python3
"""Collector for the weekly self-improver audit — prints aggregates, never listings.

Why: a weekly audit that pokes the filesystem by hand costs 3M+ input tokens in
re-sent context. One script, one compact output, same evidence.

Usage:  python3 audit-collect.py            # everything
        python3 audit-collect.py skills memory   # only named sections

Sections: skills, usage, cron, memory, refcheck.
Exit code is always 0 — an audit report must not fail the cron.
"""
import json
import os
import re
import sys
import time
from collections import Counter

HOME = os.path.expanduser('~')
SK = os.path.join(HOME, '.hermes', 'skills')
WEEK = 7 * 86400


def read(path):
    try:
        with open(path, encoding='utf-8', errors='replace') as fh:
            return fh.read()
    except Exception:
        return ''


def inventory():
    rows = []
    for root, _dirs, files in os.walk(SK):
        if '/.archive' in root or 'SKILL.md' not in files:
            continue
        path = os.path.join(root, 'SKILL.md')
        txt = read(path)
        st = os.stat(path)
        m = re.search(r'^description:\s*"?(.*?)"?\s*$', txt, re.M)
        desc = m.group(1).strip().strip('"') if m else ''
        rows.append(dict(name=os.path.basename(root), path=path, bytes=st.st_size,
                         lines=txt.count('\n') + 1, mtime=st.st_mtime, dl=len(desc)))
    return rows


def sec_skills():
    s = inventory()
    print('SKILLS active=%d bytes=%d' % (len(s), sum(i['bytes'] for i in s)))
    longd = [i for i in s if i['dl'] > 60]
    print('DESC_OVER_60=%d excess=%d' % (len(longd), sum(i['dl'] - 60 for i in longd)))
    big = sorted((i for i in s if i['lines'] > 150), key=lambda i: -i['lines'])
    print('OVER_150_LINES=%d %s' % (len(big), ' '.join('%s=%d' % (i['name'], i['lines']) for i in big[:12])))
    now = time.time()
    week = sorted((i for i in s if now - i['mtime'] < WEEK), key=lambda i: -i['mtime'])
    print('EDITED_7D=%d %s' % (len(week), ' '.join('%s:%s' % (i['name'], time.strftime('%m-%d', time.localtime(i['mtime']))) for i in week)))
    print('EDITED_8_30D=%d' % sum(1 for i in s if WEEK <= now - i['mtime'] < 30 * 86400))


def sec_usage():
    try:
        usage = json.loads(read(os.path.join(SK, '.usage.json')))
    except Exception:
        usage = {}
    if isinstance(usage, list):
        usage = {i.get('name', '?'): i for i in usage}
    rows = []
    for k, v in usage.items():
        if isinstance(v, dict):
            rows.append((k, v.get('count') or v.get('uses') or v.get('use_count') or 0))
        else:
            rows.append((k, v))
    rows.sort(key=lambda r: -(r[1] or 0))
    print('USAGE_TOP %s' % ' '.join('%s=%s' % r for r in rows[:12]))
    print('USAGE_ZERO=%d %s' % (sum(1 for r in rows if not r[1]), ' '.join(n for n, c in rows if not c)))
    names = {i['name'] for i in inventory()}
    print('NO_USAGE_ENTRY %s' % ' '.join(sorted(names - {r[0] for r in rows})))


def sec_cron():
    jobs = json.loads(read(os.path.join(HOME, '.hermes', 'cron', 'jobs.json')) or '[]')
    if isinstance(jobs, dict):
        jobs = jobs.get('jobs', [])
    print('CRON jobs=%d enabled=%d failing=%d' % (
        len(jobs), sum(1 for j in jobs if j.get('enabled')),
        sum(1 for j in jobs if j.get('failure_streak') or j.get('last_status') == 'failed')))
    db = os.path.join(HOME, '.hermes', 'cron', 'executions.db')
    if os.path.exists(db):
        import sqlite3
        con = sqlite3.connect('file:%s?mode=ro' % db, uri=True)  # READ ONLY, never write
        cur = con.cursor()
        cur.execute("SELECT status, COUNT(*) FROM executions WHERE claimed_at > datetime('now','-7 days') GROUP BY status")
        print('CRON_7D %s' % dict(cur.fetchall()))
        cur.execute("SELECT COUNT(*) FROM executions WHERE status='failed' AND claimed_at > datetime('now','-14 days')")
        print('CRON_FAIL_14D=%s' % cur.fetchone()[0])
        con.close()


def sec_memory():
    for name, limit in (('MEMORY.md', 20000), ('USER.md', 2000)):
        txt = read(os.path.join(HOME, '.hermes', 'memories', name))
        entries = [e for e in txt.split('\n§\n') if e.strip()]
        dated = sum(1 for e in entries if re.search(r'\[\d{4}-\d{2}-\d{2}\]', e))
        chars = len(txt)
        print('%s chars=%d/%d (%d%%) entries=%d dated=%d' % (
            name, chars, limit, round(100 * chars / limit), len(entries), dated))


def sec_refcheck():
    import subprocess
    script = os.path.join(SK, 'software-development', 'self-improver', 'scripts', 'refcheck.py')
    if not os.path.exists(script):
        print('REFCHECK missing-script')
        return
    r = subprocess.run([sys.executable, script], capture_output=True, text=True, timeout=120)
    print('REFCHECK exit=%d %s' % (r.returncode, (r.stdout or '').strip().replace('\n', ' | ')[:600]))


SECTIONS = {'skills': sec_skills, 'usage': sec_usage, 'cron': sec_cron,
            'memory': sec_memory, 'refcheck': sec_refcheck}

if __name__ == '__main__':
    want = sys.argv[1:] or list(SECTIONS)
    for w in want:
        if w in SECTIONS:
            SECTIONS[w]()
