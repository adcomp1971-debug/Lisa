# Пробный запуск чужих агентских рантаймов на этом сервере

Класс задач: «попробуй вот этот новый агентский CLI / self-hosted оркестратор».
Пример — DeepSeek Harness (DSH, npm `@deepseek-ai/dsh`) + прототип
`deepseek-ai/dsh-superagent-prototype` (веб-панель + Router/Worker, источники GitHub/Feishu).

Как их различать при ответе на «а что он умеет»: **DSH — движок** (headless-агент, файлы,
терминал, субагенты, фоновые джобы, сессии, панель; это он «конкурент Claude Code»),
**dsh-superagent — обвязка** над ним (Source → Trigger → Eval → Ticket → Executor → PR).
Не отвечать за движок возможностями обвязки и наоборот. Из доков обвязки: воркеры идут без
подтверждений от имени OS-пользователя, а `blockedCommands`/обёртки — «дефолты, не граница
безопасности» (программу можно позвать абсолютным путём); merge от имени агента не делается,
авто-мерж по умолчанию выключен. Прототип помечен как preview — не называть его продуктом.

## 0. Правила, без которых не начинать

- Всё в `/root/lab/<tool>` (режим «посмотреть»; боевое развёртывание — §5): отдельный `--prefix` для npm, отдельный `*_HOME`
  (напр. `DSH_HOME=/root/lab/dsh-home`). Причина: Hermes держит свой managed node и свои
  глобальные пакеты — установка «как обычна» задевает рабочее окружение агента.
- Панель/сервер только `127.0.0.1`, наружу не публиковать, systemd не создавать —
  демон в tmux-сессии, снимается `tmux kill-session`.
- Источники задач (GitHub-репо, корпоративный чат) НЕ подключать, пока рантайм бежит
  под root прода. Воркеры таких оркестраторов по умолчанию работают с full-access правами
  OS-пользователя: комментарий в репо превращается в исполнение кода на сервере с VPN/БД/биллингом.
  Сначала отдельный непривилегированный юзер или Docker, потом источник.
- Пустой allowlist авторов — это и есть нужный гейт: пока в policy не внесён логин,
  ни один запрос не становится задачей. Не «упрощать» заполнением на первом прогоне.
- Аккаунты и вход в CLI (GitHub-аккаунт агента, `gh auth login`, app secret) — руки Алекса.
  Команды отдавать файлом одной строкой, секреты в чат не запрашивать.

## 1. Установка CLI (пример DSH)

```bash
# реальное имя пакета и требования — из registry, не из пересказа новости
curl -s "https://registry.npmjs.org/-/v1/search?text=<tool>&size=8"
# engines/bin/размер: https://registry.npmjs.org/<name-urlencoded>

npm i -g --prefix /root/lab/dsh-cli @deepseek-ai/dsh@<version>
export PATH=/root/lab/dsh-cli/bin:$PATH DSH_HOME=/root/lab/dsh-home
dsh --version
```

Ключ модели брать из `/root/.hermes/.env` через `export VAR="$(grep -m1 '^VAR=' ...)"` —
значение не печатать. Проверка боем до любой панели:

```bash
dsh headless "ответь одним словом: работает" > out 2> err; echo exit=$?
```

## 2. Сборка и подключение оркестратора-плагина

```bash
cd /root/lab/dsh-superagent
corepack pnpm install --frozen-lockfile      # packageManager из package.json, версию не навязывать
corepack pnpm build                          # должны появиться dist/*.mjs
dsh superagent --from-default-profile web --dump-config > /dev/null   # создаёт профиль
dsh plugin --profile superagent add "link:$PWD"
cp -a examples/profile.cordis.patch.yml $DSH_HOME/profiles/superagent/cordis.patch.yml
# в конфиге заменить stateDir на абсолютный и host/port на 127.0.0.1:<port>
scripts/dsh-superagent start
```

## 3. Проверка «по факту», а не по exit code

`scripts/<svc> start` может вернуть «Startup health check timed out», `status` —
`exit 1` и `pids: []`, при этом сервер уже слушает порт. Причина: скрипт опрашивает health
раньше, чем приложение поднимает веб-слой. Проверять независимо:

```bash
tmux ls; pgrep -af "dsh|<plugin>"
ss -ltnp | grep <port>                       # LISTEN + pid
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:<port>/
```

## 4. Панель и Management API

- `/` отдаёт **401** — нужен токен из URL, который печатается в лог:
  `.artifacts/<name>-<profile>-<ts>.log` → `?token=...`. Брать `re.search` по логу, не угадывать.
- API: `http://127.0.0.1:<port>/orchestrator/api/` + заголовок `x-orchestrator-request: 1`.
  Без него или с чужим `Origin` — 403. `GET state` (setup.problem, health, load, paused),
  `GET settings` (sources, policy, executor), `PUT settings/<block>` с `revision` (409 = устаревшая ревизия).
- Имена блоков брать из кода, а не угадывать: `src/app/settings.ts` → `BLOCKS` (`policy`, `eval`,
  `executor`, `source`) и `block.startsWith('source:')`. Отсюда источник пишется
  `PUT settings/source:github`, а `settings/sources/github` / `settings/sources.github` дают
  400 «Invalid input» — легко принять за неверный payload и начать портить данные.
  Формы: источник `{enabled, config}`; `policy.sources.github.allowed = [{"id": "<login>"}]`
  (лишнее поле `name` → 400); `executor = {model, maxWorkers, directory, prepare, blockedCommands}`.
- `blockedCommands` не должен содержать `git`, `gh`, `lark-cli`: `git` ломает worktree-подготовку,
  `gh` — это сам источник задач. Блокировать только ненужное воркеру
  (`hermes systemctl sudo awg awg-quick docker ssh x-ui`). Список — дефолт, не граница безопасности.
- `PUT` может вернуть `restarting: true` — приложение перезапускается, перед следующим запросом
  дождаться, пока сервер снова отвечает, и перечитать ревизии.
- Подтверждение пользователю давать скриншотом панели: `browser_exec` → `new_tab(url)` →
  `js`-клик по строке сайдбара (`[...document.querySelectorAll('*')].find(e => e.textContent.trim() === '<Раздел>' && e.offsetParent).click()`)
  → `capture_screenshot()` → `/usr/bin/python3 /root/send_photo_inline.py <png> "<caption>"`.
  Вид панели словами («работает») Алекс не принимает — нужен реальный экран или ответ API.

## 5. Боевое развёртывание: отдельный OS-юзер (вместо /root/lab)

Когда нужно «чтобы это реально работало у нас», воркеры не должны бежать с правами root прода
(на сервере VPN, x-ui, биллинг). Порядок:

1. `useradd -m -s /bin/bash <agentuser>` — без sudo, без групп, каталоги
   `~/.local/bin`, `~/src`, `~/<tool>_home`.
2. Отдельный node, если у системного не та мажорная версия: распаковать в `/opt/node-vX-linux-x64`,
   симлинк `/opt/node-lts`, `PATH=/opt/node-lts/bin:$HOME/.local/bin:$PATH` в `~/.bashrc`.
3. Ключ модели — в `~/.env` (`chmod 600`, `chown`), автоподгрузка из `~/.bashrc`; в чат не печатать.
4. CLI ставить с `--prefix $HOME/.local`, репозиторий клонировать в `~/src/<project>`,
   `*_HOME` — `~/<tool>_home`. Всё под `su - <agentuser> -c '<cmd>'`, иначе PATH и права root'а.
5. Панель — `127.0.0.1:<port>`, запуск в tmux под этим же юзером, без systemd (по решению оператора).

Питфоллы этого пути:
- **`<cli> plugin add` → exit 127 «pnpm was not found».** `npm i -g pnpm@X` не кладёт бинарь в PATH
  юзера, `corepack enable --install-directory` тоже не помог; рабочий фикс —
  `corepack prepare pnpm@<version> --activate` → `pnpm -v` отдаёт версию, после этого плагин встаёт.
- **`scripts/<svc> start` и `<cli> --profile <p> --no-open` порт не поднимают** (лог пустой,
  exit 0): рабочий запуск — `<cli> <plugin> --host 127.0.0.1 --port <port> --no-open` в tmux.
  Проверка — `ss -ltnp | grep <port>`, а не код возврата.
- **Приватный клон и `git fetch` в хуке `prepare`** требуют креденшелов у этого юзера:
  `gh auth setup-git`, затем дедуп — `git config --global --replace-all
  credential."https://github.com".helper '!<agent-cli> auth git-credential'` (иначе
  «helper has multiple values»), плюс `user.name`/`user.email` = аккаунт агента.
- **Хук `prepare`** получает контракт переменных окружения, а не аргументы:
  `$<TOOL>_SUPERAGENT_*_REPOSITORY`, `_PR_HEAD` (fallback `HEAD`), `_TICKET`, `_NAME`, `_DIR`.
  Рабочая схема — `git -C <клон> fetch <url> "${..._PR_HEAD:-HEAD}:refs/.../<$TICKET>"`
  и `git -C <клон> worktree add -b "agent/$..._NAME" "$..._DIR" refs/...`.
- Опрос источника идёт `pollSeconds` (по умолчанию 60) — после правки настроек событие приходит
  не сразу; ждать ≥90 с, потом смотреть `stats.received` и новые тикеты, и только потом
  делать вывод, что триггер не работает.

## 6. Что требует оператор (и что проверять самому)

Когда рантайм поднят и упирается в единственную setup-проблему «нет репозитория / нет
допущенных авторов» — не отправлять пользователя в GitHub вслепую. Сначала сам выясни, что у него
уже есть (процедура в скилле `github`, `references/auth.md`: `ssh -T git@github.com` → `Hi <login>!`,
затем `/users/<login>/repos` и `git ls-remote`), и только потом формулируй шаги.

Минимум, который закрывает оператор (руками, не агентом):

1. **Отдельный аккаунт под агента** — никогда личный аккаунт оператора. Дело не только в том,
   что PR висят под его именем: под одним логином схема не запускается вообще — GitHub не
   уведомляет о собственных действиях, а оркестратор не делает триггер из сообщения самого
   агента, поэтому `stats.received` остаётся `0` при любой комбинации `observe*`-флагов.
   Диагностика за один шаг: `<agent-cli> api notifications --jq length` → `0` = причина на уровне
   аккаунта, а не конфига (дальше флаги не крутить). Регистрация аккаунта и приглашение в репо
   с правами write — шаги оператора; задачи ставит аккаунт оператора.
2. **Репозиторий с включёнными Issues** — задачи приходят как issue/комментарий; репо без Issues
   бесполезен. Приватный, не прод.
3. **Обёртка CLI с отдельным конфигом**, чтобы не смешать с личным `gh` оператора:
   ```sh
   printf '#!/bin/sh\nGH_CONFIG_DIR="$HOME/.config/gh-agent" exec gh "$@"\n' > ~/.local/bin/gh-agent
   chmod +x ~/.local/bin/gh-agent
   ```
   путь к обёртке прописывается в конфиг источника (`cli`), вход — `gh-agent auth login` руками
   оператора, проверка — `gh-agent api user --jq .login`.
4. **Fine-grained PAT** только на этот репозиторий: `Contents: RW`, `Issues: RW`,
   `Pull requests: RW`, `Metadata: R`. Срок 90 дней. Токен в чат не просить — выдать файлом команду.
5. **Commit identity** = аккаунт агента (иначе работа выглядит как работа оператора).

Питфоллы:
- Триггер по комментарию не срабатывает, если правку текста issue сделать с уже существующим
  упоминанием — нужно **новый комментарий** `@<agent-login> <запрос>`. Так устроен опрос уведомлений.
- `gh auth status` = «not logged into any GitHub hosts» не значит, что у машины нет личности:
  SSH-ключ может быть уже привязан к аккаунту. Проверяй ключ раньше, чем спрашивать пользователя.
- Пустой allowlist не заполнять «чтобы проверить быстрее» — это и есть гейт против prompt-injection.

## 7. Что докладывать

Отчёт: что поставлено (изолированно, где), что проверено боем (ответ headless, код ответа API,
скриншот), какие setup-проблемы остались, что именно требуется от Алекса,
и отдельным абзацем — риск full-access воркеров на этом сервере.
Не называть рантайм «готовым» до его подтверждения пользователем.

Отдельно проверять изоляцию фактом, а не словами: `ss -ltnp` показывает `127.0.0.1:<port>`,
а `curl` по публичному IP сервера с коротким таймаутом возвращает `000`.

## 8. Снос стенда («убери, не нужен пока»)

1. Штатная остановка сервисным скриптом: `scripts/<svc> stop` → «stopped, automatic recovery is paused».
2. `tmux kill-session -t <session>` — снимает и демон, и его потомков.
3. Проверить: `ps -eo pid,cmd | grep -E "<tool-cli|plugin>" | grep -v grep`, `ss -ltn | grep <port>` → пусто.
4. Убедиться, что вне `/root/lab` ничего не осело: `ls -d ~/.dsh ~/.config/dsh`; npm-префикс
   был свой, но `*_HOME` мог создать каталог в `$HOME`.
5. `du -sh` по каталогам до удаления (называть освобождённый объём в отчёте), затем `rm -rf`.
6. `df -h /` до и после, финальный контроль процессов и порта.

Питфоллы сноса:
- **`pkill -f "/root/lab/<tool>/bin/<tool>"` убивает собственную оболочку Hermes** (exit -15):
  шаблон матчится на командную строку обёртки, которая уже содержит этот путь в тексте команды.
  Убивать точные PID из `ps -eo pid,cmd | grep ... | grep -v grep` (`kill <pid>`), или вообще
  обойтись `tmux kill-session` — он и есть корректный способ снять демон.
- **`rm -rf` каталога, который сейчас cwd оболочки**, валит следующий вызов
  (`getcwd: cannot access parent directories`, `cd: No such file or directory`, exit 126).
  Удаление и все последующие команды выполнять с `workdir=/root`.
- Удалять только `/root/lab/<tool>` и его `*_HOME`; ничего из `/root/.hermes` не трогать —
  ключи и конфиг Hermes к стенду не относятся.

## Питфоллы

- Веб-шаги (регистрация аккаунта, создание репо, device-код) давать **по одному экрану**: назвать
  поля так, как они подписаны на скриншоте, и ждать подтверждения. Списком из 8 пунктов оператор
  злится и делает не то; он присылает скриншот и «что дальше» — ответ ровно про этот экран.
- Длинный вывод `terminal` приходит срезанным («1 lines output») — любую диагностику писать
  в файл и читать `read_file`, либо печатать по одной короткой строке.
- `corepack pnpm` надёжнее `pnpm` из PATH: Hermes'ов node может предложить другую версию,
  а проект закрепляет `packageManager`.
- npm-пакет ищется по реальному имени (`@deepseek-ai/dsh`), а не по имени репозитория из новости:
  запрос `repos/<name>` без org часто пустой.
- Фоновый запуск через `( ... ) &` внутри terminal-обёртки отваливается (`exit -1`) —
  ставить в фореграунде с большим timeout или `background: true`.
