---
name: email-agent
description: Email agent using Himalaya CLI — read, send, reply, and manage Gmail from Hermes terminal. Setup includes Gmail app password creation, himalaya config, and common workflows.
version: 1.0.0
---

# Email Agent (Himalaya CLI + Gmail)

## Setup

### 1. Install Himalaya

```bash
curl -sSL https://raw.githubusercontent.com/pimalaya/himalaya/master/install.sh | PREFIX=/usr/local sh
```

### 2. Create Gmail App Password

1. Enable 2-Step Verification on the Google Account
2. Go to: https://myaccount.google.com/apppasswords
3. Select "Mail" → "Other" → enter name (e.g. "Hermes")
4. Click "Create" → copy the 16-character yellow password (WITH spaces)
5. **CRITICAL: Click "Готово" (Done)** to activate the password. Without this step, the password won't work.

### 3. Configure Himalaya

Config at `~/.config/himalaya/config.toml`:

```toml
[accounts.personal]
email = "you@gmail.com"
display-name = "Your Name"
default = true

backend.type = "imap"
backend.host = "imap.gmail.com"
backend.port = 993
backend.encryption.type = "tls"
backend.login = "you@gmail.com"
backend.auth.type = "password"
backend.auth.cmd = "echo -n 'xxxx xxxx xxxx xxxx'"  # spaces included, echo -n!

message.send.backend.type = "smtp"
message.send.backend.host = "smtp.gmail.com"
message.send.backend.port = 587
message.send.backend.encryption.type = "start-tls"
message.send.backend.login = "you@gmail.com"
message.send.backend.auth.type = "password"
message.send.backend.auth.cmd = "echo -n 'xxxx xxxx xxxx xxxx'"

folder.aliases.inbox = "INBOX"
folder.aliases.sent = "[Gmail]/Отправленные"   # меняется от языка Gmail! Проверить через `himalaya folder list`
folder.aliases.drafts = "[Gmail]/Черновики"
folder.aliases.trash = "[Gmail]/Корзина"
```

### 4. Enable IMAP in Gmail

1. Gmail → Settings → "Forwarding and POP/IMAP" tab
2. Enable IMAP
3. Save changes

## Common Operations

### List inbox
```bash
himalaya envelope list --page-size 10
```

### Read email
```bash
himalaya message read <ID>
```

### Search
```bash
himalaya envelope list from habr subject вакансия
```

### Send email (non-interactive)
```bash
cat << 'EOF' | himalaya template send
From: you@gmail.com
To: recipient@example.com
Subject: Test

Message body here.
EOF
```

**Important — tone verification:** Before sending business emails on behalf of the user, read the draft aloud via TTS (`text_to_speech`) so the user can confirm the tone is appropriate. Do NOT send blind — the user wants to hear how it sounds before it goes out.

### Reply to email
```bash
himalaya template reply <ID> | sed 's/^$/\\nYour reply here\\n/' | himalaya template send
```
Same tone-verification rule applies to replies.

## Pitfalls

- **Interactive workflow:** see `references/interactive-email-workflow.md` for the approve-before-send pattern and ongoing correspondence flow.
- **echo -n is critical**: Without `-n`, the trailing newline becomes part of the password and auth fails
- **Gmail folder locale mismatch:** `folder.aliases.sent = "[Gmail]/Sent Mail"` is the English default. If Gmail interface is Russian/Hebrew, real folder names differ. **Error signature:** `cannot add IMAP message → unexpected NO response: Folder doesn't exist.` The SMTP send succeeds but himalaya crashes trying to save a copy to Sent. **Fix:** run `himalaya folder list` first, update config with actual folder names.

- **⚠️ folder.aliases vs folder.alias (critical):** Use `folder.aliases.X` (plural, dotted keys under `[accounts.NAME]`). Pre-v1.2.0 docs used `[accounts.NAME.folder.alias]` (singular, sub-section) — v1.2.0 silently ignores that form. TOML parses fine but aliases don't work. On Gmail this means save-to-Sent fails *after* SMTP delivery succeeds, and `himalaya message send` exits non-zero. Any retry on that exit code re-runs SMTP = **duplicate emails** to recipients.
- **Spaces in password**: Google now formats app passwords with spaces for readability. Include them in the quoted string
- **Must click "Done"**: The modal confirmation button after password creation is required for activation
- **IMAP must be enabled**: Even with a valid app password, Gmail won't accept IMAP connections if IMAP is disabled in settings
- **Wait 10-30 seconds** after creating password before first use — sometimes takes a moment to sync
- **Two-step verification required**: App passwords are hidden if 2FA is not on
- **auth.cmd vs auth.password**: `auth.cmd` нужен, чтобы Himalaya могла отдать пароль неинтерактивно, но `echo -n '...'` в конфиге — это тот же пароль открытым текстом в файле. Держать config.toml с `chmod 600` и не отдавать его в git/чат; безопаснее — скрипт, читающий пароль из файла 600 или переменной окружения.
