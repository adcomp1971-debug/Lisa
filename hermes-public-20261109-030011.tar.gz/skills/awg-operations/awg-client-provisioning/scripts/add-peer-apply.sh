#!/bin/bash
# Атомарное добавление одного пира в работающий AWG: бэкап -> addconf -> дописать в конфиг -> проверки.
# Без рестарта: живые клиенты не рвутся. Запускать ТОЛЬКО после дословного подтверждения (vpn-safe).
#
# Использование:
#   bash add-peer-apply.sh <name> <pubkey> <ipv4-octet> <psk-file> [iface] [mode]
#   name        — метка клиента/устройства (ASCII), пишется комментарием в конфиг
#   pubkey      — публичный ключ пира (base64)
#   ipv4-octet  — последний октет в 10.9.0.0/24 (свободный!
#                 проверять: awg show <iface> | grep 'allowed ips')
#   psk-file    — путь к файлу PresharedKey
#   iface       — по умолчанию awg0
#   mode        — dual (v4+v6, умолчание) | v4 (без IPv6)
set -euo pipefail

NAME=${1:?name}
PUB=${2:?pubkey}
OCT=${3:?ipv4 octet}
PSKF=${4:?psk file}
IFACE=${5:-awg0}
MODE=${6:-dual}

PREFIX=$(grep -m1 '^Address' "/etc/amnezia/amneziawg/${IFACE}.conf" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.' | head -1)
PREFIX=${PREFIX%.}
BASE=${PREFIX%.[0-9]*}
CFG=/etc/amnezia/amneziawg/${IFACE}.conf
PSK=$(cat "$PSKF")
TS=$(date +%Y%m%d-%H%M%S)

if [ "$MODE" = "dual" ]; then
  ALLOWED="${BASE}.${OCT}/32, fd00:9::${OCT}/128"
else
  ALLOWED="${BASE}.${OCT}/32"
fi

# 0) пир уже есть?
if awg show "$IFACE" | grep -q "${BASE}.${OCT}/32"; then
  echo "ОТКАЗ: ${BASE}.${OCT} уже занят пиром в $IFACE (awg show $IFACE | grep 'allowed ips')" >&2
  exit 2
fi

cp -a "$CFG" "$CFG.bak-$TS"
echo "бэкап: $CFG.bak-$TS"
echo "пиров до: $(grep -c '^\[Peer\]' "$CFG")"

TMP=$(mktemp /tmp/peer-${NAME}.XXXX.conf)
printf '[Peer]\nPublicKey = %s\nPresharedKey = %s\nAllowedIPs = %s\n' "$PUB" "$PSK" "$ALLOWED" > "$TMP"
chmod 600 "$TMP"
awg addconf "$IFACE" "$TMP"   # только аддитивно, существующие соединения не рвутся
rm -f "$TMP"

if grep -q "$PUB" "$CFG"; then
  echo "в $CFG уже есть — пропуск"
else
  printf '\n[Peer]\n# %s\nPublicKey = %s\nPresharedKey = %s\nAllowedIPs = %s\n' "$NAME" "$PUB" "$PSK" "$ALLOWED" >> "$CFG"
fi

# проверки: пир в runtime, конфиг валиден, живые соседи целы
echo "пиров после: $(grep -c '^\[Peer\]' "$CFG")"
awg show "$IFACE" | grep -A2 "${BASE}.${OCT}" || { echo "ПИР НЕ ВИДЕН В RUNTIME" >&2; exit 3; }
awg-quick strip "$CFG" > /dev/null && echo "awg-quick strip: OK" || { echo "STRIP FAIL — конфиг битый, откат из бэкапа" >&2; exit 4; }
awg show "$IFACE" latest-handshakes | awk -v n="$(date +%s)" '$2>0 && n-$2<300 {c++} END {print (c+0)" пиров онлайн"}'
