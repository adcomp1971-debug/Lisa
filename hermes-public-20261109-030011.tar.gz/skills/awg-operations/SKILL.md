---
name: awg-operations
description: "AmneziaWG команды — MTU, пиры, конфиги, диагностика"
category: devops
version: 1.0.0
---

# AmneziaWG Operations

## Статус и диагностика

```bash
# Интерфейс
ip link show awg0
ip addr show awg0 | grep inet

# Все пиры (handshake, трафик)
awg show awg0

# Количество пиров
echo "Total peers: $(awg show awg0 peers | wc -l)"
```

## 🔴 Pitfall: systemctl is-active ≠ interface status

`systemctl is-active amneziawg-quick@awg0` может возвращать `inactive` даже когда интерфейс `awg0` полностью работоспособен (UP,LOWER\_UP). Это происходит потому что AWG использует нестандартные systemd unit-файлы, и systemd не всегда корректно отслеживает их состояние.

**Не полагаться на `systemctl is-active` для AWG.** Использовать:
```bash
# grep 'state UP' НЕ РАБОТАЕТ — AWG показывает 'state UNKNOWN'
# Правильно: проверять LOWER_UP или наличие IP и пиров
ip link show awg0 | grep -q 'LOWER_UP' && echo "interface UP" || echo "interface DOWN"
awg show awg0 | head -3  # если возвращает данные — жив
```

## 🔴 Питфол: `wg` vs `awg` — на этом сервере только `awg`

Команда `wg set awg0 peer ...` **НЕ РАБОТАЕТ** — `wg` не установлен.
Симптом: `wg: command not found`, затем `wg show awg0` показывает `0 peers active` (парсинг вывода `awg` не срабатывает при попытке `wg`).

**Всегда использовать `awg`, не `wg`.**
```bash
awg set awg0 peer <pubkey> preshared-key <(echo "<psk>") allowed-ips 10.9.0.X/32
awg show awg0 | grep -c peer  # проверка, а не wg show
```

## Изменение MTU на лету

```bash
ip link set dev awg0 mtu 1380
```

Без перевыпуска конфигов клиентам.

## 🔴 Питфол: НИКОГДА не рестартить AWG при добавлении пира

В AWG 7-8 живых пиров с активными handshake (люди, VPN). Рестарт интерфейса обрывает всех.  
**Пир добавляется на лету, без рестарта.**

### Способ 1 (рекомендуемый): `awg set` — без tmp-файла

```bash
awg set awg0 peer <public_key> \
  preshared-key <(echo "<psk>") \
  allowed-ips 10.9.0.X/32
```

Плюсы: не нужен temp-файл, одна команда, все живые пиры не дёргаются.

### Способ 2 (через `awg addconf`)

```bash
cat > /tmp/new-peer.conf << 'EOF'
[Peer]
PublicKey = <peer_public_key>
PresharedKey = <preshared_key>
AllowedIPs = 10.9.0.X/32
EOF
awg addconf awg0 /tmp/new-peer.conf
```

После любого способа — сохранить в awg0.conf для постоянности.  
**Не рестартить `systemctl restart awg-quick@awg0`!**

### Сохранение в конфиг (постоянность)

```bash
cat >> /etc/amnezia/amneziawg/awg0.conf << 'EOF'

[Peer]
PublicKey = <pubkey>
PresharedKey = <psk>
AllowedIPs = 10.9.0.X/32
EOF
```

### Проверка

```bash
awg show awg0 | grep -c peer
# Должно быть +1 от предыдущего
```

## Удаление пира

```bash
awg set awg0 peer <publickey> remove
```

## Сохранение конфига на диск (runtime → файл)

**Вариант 1 — `awg showconf` (для синхронизации runtime → файл после удаления/изменения пиров)**

⚠️ `awg showconf` выгружает только `[Interface]`-параметры и `[Peer]`-ключи — он НЕ включает `Address =`, `Table =`, `MTU =`, `DNS =` и НЕ переносит комментарии `# Имя`. После showconf ОБЯЗАТЕЛЬНО восстановить все четыре параметра и имена пиров:

```bash
awg showconf awg0 > /etc/amnezia/amneziawg/awg0.conf
grep -q '^Address' /etc/amnezia/amneziawg/awg0.conf || \
  sed -i '/^ListenPort/a Address = 10.9.0.1/24' /etc/amnezia/amneziawg/awg0.conf
```

**Вариант 2 — добавить секцию пира в конец файла** (для добавления нового пира без удаления старых):

```bash
cat >> /etc/amnezia/amneziawg/awg0.conf << 'EOF'

[Peer]
PublicKey = <pubkey>
PresharedKey = <psk>
AdvancedSecurity = on
AllowedIPs = 10.9.0.X/32
EOF
```

## Python: вычислить публичный ключ из приватного

На этом сервере нет `wg` — только `awg`. Используй Python cryptography:

```bash
python3 -c "
import base64
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import x25519

priv_b64 = '<private_key_base64>'
priv_bytes = base64.b64decode(priv_b64)
private_key = x25519.X25519PrivateKey.from_private_bytes(priv_bytes)
pub_bytes = private_key.public_key().public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw
)
print(base64.b64encode(pub_bytes).decode())
"
```

## NAT/MASQUERADE (интернет для клиентов)

```bash
iptables -t nat -L POSTROUTING -n -v | grep 10.9.0.0
```

Если пусто — NAT не работает, интернет у клиентов нет.

## 🔴 Полная диагностика "VPN не работает"

Когда клиент жалуется что VPN не работает (нет интернета, не подключается), выполнять **все 8 шагов** последовательно:

### 1. Статус интерфейса и пиров
```bash
ip link show awg0 | grep -E 'state|mtu'
awg show awg0 | grep -E '^peer:|latest handshake|allowed ips|transfer'
echo "Total peers: $(awg show awg0 peers | wc -l)"
```

### 2. Сверка публичного ключа клиента
```bash
# Что в клиентском .conf
grep '^PublicKey' /etc/amnezia/amneziawg/<client>.conf

# Что активно на сервере
awg show awg0 peers
# Сверить pubkey — если не совпадает, клиент использует не тот конфиг
```

### 3. Поиск дублирующих конфигов
```bash
ls /etc/amnezia/amneziawg/<client>*.conf /etc/amnezia/amneziawg/<client>public.key /etc/amnezia/amneziawg/<client>*public.key 2>/dev/null
# Если есть файлы вида lisa7, ana, anya, lisa7 — ключи могут не совпадать!
```

### 4. NAT / MASQUERADE
```bash
iptables -t nat -L POSTROUTING -n -v | grep '10.9.0.0'
# Должна быть строка MASQUERADE с eth0 и сетью 10.9.0.0/24
```

### 5. Firewall и FORWARD
```bash
ufw status numbered | grep -E '51820|awg'
iptables -L FORWARD -n -v | head -5
```

### 6. XRay / VLESS (если используется)
```bash
ss -tlnp | grep 8443
ps aux | grep -v grep | grep xray
# Проверить что порт слушается и процесс жив
```

### 7. Внешний IP сервера (не должен меняться)
```bash
dig +short +time=5 myip.opendns.com @208.67.222.222
# Сверить с Endpoint в клиентском .conf
# Если не совпадает — VPN не подключится никогда
```

### 8. MTU
```bash
ip addr show awg0 | grep mtu
# Стандарт для AWG: 1420. Ping через AWG не работает — это норма.
```

#### Типичные находки:
- **Дублирующий конфиг** — клиент импортировал `lisa7` вместо `lisa` → ключи не совпадают → handshake не происходит
- **Неверный Endpoint** — внешний IP изменился и старые конфиги не работают
- **lisa7 активен но не в awg show** — клиент создал конфиг на сервере, но не подключается (ключи есть в `/etc/amnezia/amneziawg/` но пир не зарегистрирован в runtime)
- **Нет handshake** — клиент онлайн но трафик не идёт

## 🔴 Развёртывание НОВОГО AWG-узла: две ловушки, из-за которых «туннель есть, интернета нет»

### 1. ufw по умолчанию ЗАПРЕЩАЕТ форвард клиентов в интернет

На новом узле (Ubuntu + ufw) `DEFAULT_FORWARD_POLICY="DROP"`: пакеты из `awgN` в `eth0` попадают в `ufw-reject-forward` и отбрасываются, **даже если** правила `awg-quick` (`FORWARD -i awgN -o eth0 -j ACCEPT`) в конфиге есть — они стоят ПОСЛЕ ufw-цепочек и не срабатывают.
Признак: узел пингуется по туннелю, но TCP/HTTP наружу не идёт; `iptables -L FORWARD -v -x` показывает счётчики на `ufw-reject-forward` и нули на ACCEPT-правилах awg-quick.

Лечение (сохраняется в `/etc/ufw/user.rules`, переживает reboot):
```bash
ufw route allow in on awgN out on eth0
# обратное направление не открывать — хватит RELATED,ESTABLISHED в ufw-before-forward
```
Проверка: `iptables -L FORWARD -n -v -x | grep -E 'reject-forward|user-forward'` → трафика в reject быть не должно.

### 2. Самопроверка туннеля «вручную» (ip link + awg set) врёт

Если интерфейс поднят вручную, маршруты к `AllowedIPs` НЕ создаются → `ping 9.9.9.9` уходит мимо туннеля через основной интерфейс сервера и «работает». Правильная самопроверка:
```bash
ip route add <цель>/32 dev awgtest          # маршрут в туннель руками
ip route get <цель>                          # убедиться, что путь идёт через awgtest
ping -I awgtest -c 2 -s 1200 -M do <цель>    # и мелкие, и крупные пакеты
curl -s -o /dev/null -w '%{http_code}' --max-time 8 http://1.1.1.1/cdn-cgi/trace  # реальный TCP
```
`curl` через туннель к `1.1.1.1/cdn-cgi/trace` отвечает `301` — это норма (редирект на https), а не сбой.
**Правило: не докладывать «узел рабочий» по ping'у — только по TCP-ответу через туннель.**

### 3. Сбой `awg-quick up`: IPv6-адрес в `AllowedIPs` пира (MTU тут НЕ при чём)

Симптом: `systemctl restart awg-quick@awgN` → unit failed, интерфейс исчезает («VPN пропал»), в `journalctl -u awg-quick@awgN`: `[#] ip -6 route add fd00:XX::2/128 dev awgN` → `RTNETLINK answers: No such device` → `[#] ip link delete dev awgN`.

Причина: в серверном конфиге у пира запись вида `AllowedIPs = 10.11.0.2/32, fd00:11::2/128`, а у узла нет глобального IPv6 — awg-quick падает на добавлении IPv6-маршрута и откатывает интерфейс.

Лечение:
```bash
sed -i 's|^AllowedIPs = 10.11.0.2/32, fd00:11::2/128|AllowedIPs = 10.11.0.2/32|' /etc/amnezia/amneziawg/awgN.conf
systemctl restart awg-quick@awgN
```
Узлу без IPv6-аплинка IPv6 клиенту не нужен — смело убирать.

⚠️ Раньше в этом скилле стоял неверный вывод «MTU=1200 валит запуск» — это была та же ошибка, списанная на MTU. Проверено: с `MTU = 1200` и AllowedIPs без IPv6 интерфейс поднимается штатно. **Не менять MTU, если видишь RTNETLINK No such device — смотреть на IPv6 в AllowedIPs.**

### 4. Отключение парольного входа на новом узле: `sshd_config` не работает, нужен drop-in

На Ubuntu 24.04 `PasswordAuthentication no` в `/etc/ssh/sshd_config` НЕ действует — drop-in `/etc/ssh/sshd_config.d/50-cloud-init.conf` перебивает его (директива `Include` стоит в начале файла, первое значение выигрывает). Отключать пароли надо файлом `/etc/ssh/sshd_config.d/00-no-password.conf` (приоритет выше, чем у 50-cloud-init). Для парольного входа при самом первом заходе локально ставят `sshpass` — уместен только в деплой-скриптах на первом заходе, в дальнейшем не нужен.

## Известные пиры

| IP | Имя | Примечание |
|----|-----|-----------|
| `10.9.0.10` | Алекс | конфиг утерян (DefaultVPN) |
| `10.9.0.100` | Москва / Артём | конфиг moscow.conf |
| `10.9.0.101` | Саша | конфиг sasha.conf, Саша.conf |
| `10.9.0.104` | ludvig | конфиг ludvig.conf |
| `10.9.0.105` | Аня (lisa) | конфиг lisa.conf |
| `10.9.0.106` | Натусик | конфиг Натусик.conf |
| `10.9.0.107` | Valera | конфиг valera.conf, 12 Jul 2026 |
| `10.9.0.115` | Катерина | конфиг Катерина.conf |
| `10.9.0.103` | Ruslan | активный, ~15 ГБ отдано |
| `10.9.0.108` | Yulia (Юля) | активная, ~11 ГБ |
| `10.9.0.109` | Mama | активная, ~8 ГБ |
| `10.9.0.111` | Katya | активная, ~9 ГБ |
| `10.9.0.112` | Alex | заведён 2026-08-20, трафика ноль |
| `10.9.0.114` | Лена Папина | заведена 2026-09-17, трафика ноль |

Последние шесть строк восстановлены из бэкапа конфига матчем по `PublicKey` — в живом `awg0.conf` комментариев с именами нет вообще.

> **Важно:** `lisa7` имеет отдельный публичный ключ (`e74/YKD0WuWCY1vx5Ge0c+OBoh8sDaq+tMKQra6lqEk=`) отличный от основного `lisa`. Это НЕ баг — это отдельный конфиг, но Аня могла случайно его использовать.

**Всегда проверять `awg show awg0` для актуального списка.** Не полагаться на память для статуса пиров — живой пир может числиться мёртвым в старых заметках, и наоборот.

Таблица ниже — историческая: имена в ней восстановлены по конфигам и бэкапам, у части пиров `# Имя` в живом конфиге уже нет. Имена в конфиге пропадают после `awg showconf` (он не переносит комментарии), восстанавливать из бэкапов и матчить по `PublicKey`.

## Смена порта на существующем узле (обход блокировки 443/udp)

РОССИЙСКИЕ ОПЕРАТОРЫ РЕЖУТ 443/udp К ИНОСТРАННЫМ АДРЕСАМ. Признак: у клиента рукопожатие не завершается (в `awg show` счётчик rx растёт только на 148-байтных init'ах), а `awg1` на 443/udp за всё время имеет НОЛЬ рукопожатий при живом awg0 на 51820.

```bash
# бэкап и правка
sed -i 's|^ListenPort = .*|ListenPort = 51820|' /etc/amnezia/amneziawg/awgN.conf
ufw allow 51820/udp && ufw delete allow 443/udp
systemctl restart awg-quick@awgN     # на изолированном узле (единственный пир) — безопасно
```

⚠️ Последствия для клиентов: меняется `Endpoint` в их конфиге — на живом узле с несколькими клиентами это означает перевыпуск всем. Делать только когда порт действительно режется.

## Вход по TCP рядом с AWG (VLESS + Reality) — когда UDP у клиента не проходит

РОССИЙСКИЕ ОПЕРАТОРЫ ЧАСТО РЕЖУТ UDP К НАШИМ АДРЕСАМ ЦЕЛИКОМ (не только 443/udp): признак — клиент подключается с одной сети (Wi-Fi) и не подключается с другой (LTE), а узел не видит от него ни одного пакета с мобильного адреса. Перебор портов помогает не всегда, релей playit тоже не универсален. Надёжное решение — второй вход по TCP на **том же узле**: VLESS + Reality. Ставится за ~3 минуты, AWG на узле не трогает, оба входа живут независимо.

```bash
# 1. Xray-core (официальный установщик)
bash -c "$(curl -sL https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install

# 2. ключи и параметры
xray x25519                          # даёт privateKey/publicKey
xray uuid
head -c 8 /dev/urandom | od -An -tx1 | tr -d ' \n'   # shortId

# 3. /usr/local/etc/xray/config.json — inbound vless, порт 443,
#    streamSettings.security=reality, dest/serverNames=<чужой сайт с TLS1.3+h2>,
#    clients: [{id: uuid, flow: "xtls-rprx-vision"}], decryption: "none"
ufw allow 443/tcp
systemctl enable --now xray
xray run -test -c /usr/local/etc/xray/config.json
```

Питфоллы:
- **Не брать apple/icloud как `dest`/`sni`** — Xray сам предупреждает: такой target повышает риск блокировки IP. Нейтрально и доступно из РФ: `www.samsung.com` (проверено: TLS1.3 + ALPN h2).
- `dest` должен реально отвечать с узла по TLS1.3 с ALPN h2 — проверять `openssl s_client -connect <dest>:443 -tls1_3 -alpn h2`.
- Проверка канала — не «сервис active», а реальный клиент: поднять клиентский конфиг на другом хосте (SOCKS-инбаунд) и `curl --socks5-hostname 127.0.0.1:PORT https://api.ipify.org` → должен вернуть IP узла. Замер скорости — `curl -w '%{speed_download}'` через тот же SOCKS.
- Клиентская ссылка: `vless://<uuid>@<ip>:443?type=tcp&security=reality&pbk=<pub>&fp=chrome&sni=<sni>&sid=<sid>&flow=xtls-rprx-vision&encryption=none#<tag>`
- **AmneziaVPN (то самое приложение «Амнезия») — полноценный XRay-клиент:** принимает `vless://`-ссылку вставкой из буфера (в UI: «Добавить VPN» → вставить ссылку в поле ключа → кнопка Insert), а также импортирует VMESS/VLESS/Shadowsocks/.json. Ссылку отдавать ОДНОЙ строкой, без переносов (разрыв строки ломает импорт) — если файлом, то строка должна быть копируема целиком. Приложение AmneziaWG (только AWG) такую ссылку не понимает — это разные приложения, не путать в инструкции клиенту.
- Перед выдачей ссылки сверить её параметры с конфигом узла (`/usr/local/etc/xray/config.json`: uuid, shortIds, serverNames, dest, flow) и пер-парность ключа: `xray x25519 -i <privateKey>` → поле `Password (PublicKey)` должно совпасть с `pbk` в ссылке.
- Бинарь xray на автономном узле — `/usr/local/bin/xray` (официальный установщик); путь `/usr/local/x-ui/bin/xray-linux-amd64` — это ОСНОВНОЙ сервер (x-ui), на новом узле его нет.

## Добавление клиента из конфига, присланного пользователем

Когда пользователь присылает .conf файл клиента и просит добавить пир на сервер:

1. **Извлеки приватный ключ** из `[Interface]/PrivateKey` в конфиге
2. **Вычисли публичный ключ** через Python (см. секцию выше)
3. **Добавь пира в AWG** через временный файл + `awg addconf`:
   ```bash
   cat > /tmp/new-peer.conf << 'EOF'
   [Peer]
   PublicKey = <вычисленный_pubkey>
   PresharedKey = <preshared_key_из_конфига_клиента>
   AllowedIPs = <IP_из_Address_клиента>/32
   EOF
   awg addconf awg0 /tmp/new-peer.conf
   ```
4. **Сохрани в постоянный конфиг:**
   ```bash
   cat >> /etc/amnezia/amneziawg/awg0.conf << 'EOF'

   [Peer]
   PublicKey = <pubkey>
   PresharedKey = <psk>
   AdvancedSecurity = on
   AllowedIPs = <IP>/32
   EOF
   ```
5. **Верни файл пользователю** — отправь через Telegram sendDocument **как .conf**, не .txt:
   ```bash
   cp /path/to/file /tmp/client-name-awg.conf
   source /root/.hermes/.env
   curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument" \
     -F "chat_id=420839805" \
     -F "document=@/tmp/client-name-awg.conf"
   ```
   ⚠️ Пользователь требует **.conf** для AWG конфигов. .txt вызывает ярость. Всегда .conf.

## 🔴 AdvancedSecurity — уточнение для этого сервера

**На этом сервере** `AdvancedSecurity = off` в dump для **всех** пиров (включая работающие) — это норма, не баг, не чинить.

Проверка dump:
```bash
awg show awg0 dump | grep <pubkey>
# Последнее поле показывает AdvancedSecurity runtime
# off = норма для всех пиров на этом сервере
```

## Dead peer cleanup — bulk removal via config edit

Пиры без единого handshake и с нулевым трафиком висят мёртвым грузом. Порядок работ:

1. показать пользователю список (IP, имя, дата последнего handshake, трафик) — удаление только после отдельного подтверждения;
2. снять пиры на ЖИВОМ интерфейсе через `awg set <iface> peer <pubkey> remove` — живые клиенты не дёргаются;
3. те же блоки `[Peer]` убрать из конфига, чтобы после ребута не вернулись.

Никогда не начинать с `awg-quick down/up` или `systemctl restart` — это рвёт живых (см. питфол выше).

### 🔴 Питфол: имена пиров теряются, а статус в заметках врёт

`awg showconf` выгружает только параметры и НЕ переносит комментарии `# Имя` — после любой синхронизации runtime → файл все имена пропадают, остаются голые `[Peer]`/`AllowedIPs`.
Восстанавливать имена из бэкапов конфига (`/root/backups/*<iface>*.conf*`, `/root/*<iface>*.conf*`) и матчить **по `PublicKey`, а не по порядку блоков**: порядок в `dump` и в файле разный.

Живость пира — только из `awg show <iface> dump` сейчас, не из прошлых отчётов и не из памяти: там пир бывает записан мёртвым, хотя он онлайн с гигабайтами трафика. Ошибка «этот пир мёртв» стоит доверия ко всему отчёту.

Инвентарь одной командой: `scripts/awg-peers.py <iface>` (имена из живого конфига и бэкапов, живые/мёртвые, возраст handshake). `--dead-keys` печатает только ключи пиров с нулевым трафиком — то, что безопасно снимать; `--dead-keys --all` добавляет и тех, у кого трафик был (это бывшие клиенты, решать вручную).

### 1. Identify dead peers — по `dump`, а не по тексту `awg show`

`awg show` — человеческий вывод, парсить его регулярками легко ошибиться. Машинный формат — `dump`, колонки: `pubkey, psk, endpoint, allowed-ips, latest-handshake, rx, tx, keepalive`.

```bash
awg show awg0 dump | awk -F'\t' 'NR>1{print $4, "hs="$5, "rx="$6, "tx="$7}'
# hs=0      → рукопожатий не было НИКОГДА (мёртв с момента создания)
# hs=<unix> → перевести: date -u -d @<hs>
```

Мёртвый = `hs=0` и `rx=0 tx=0`. Пир с нулевым handshake, но ненулевым трафиком — это клиент, который когда-то работал: не трогать без разбора.

Проверить конкретный IP:
```bash
awg show awg0 dump | awk -F'\t' '$4 ~ /10\.9\.0\.102/{print $4,$5,$6,$7}'
```

### 2. Backup конфига

```bash
cp /etc/amnezia/amneziawg/awg0.conf /etc/amnezia/amneziawg/awg0.conf.bak.$(date +%Y%m%d_%H%M%S)
```

### 3. Удалить пиры из конфига

Если мёртвые пиры в конце файла (последние `[Peer]` блоки):

```bash
# Посчитать строки до мёртвых пиров (включая живые), обрезать хвост
head -n <NUM_LINES> /etc/amnezia/amneziawg/awg0.conf > /tmp/awg0-fixed.conf
mv /tmp/awg0-fixed.conf /etc/amnezia/amneziawg/awg0.conf
```

**⚠️ Перед удалением проверить, что у пира нет .conf файла на сервере** — если конфиг есть, клиент может переустанавливать его.

```bash
# Проверка: есть ли конфиг для этого пира
grep -r "<public-key>" /etc/amnezia/amneziawg/*.conf /etc/amnezia/amneziawg/*.key 2>/dev/null
# Если нашёлся — НЕ удалять без подтверждения
```

### 4. Снять пиры с живого интерфейса — БЕЗ рестарта

Правка файла сама интерфейс не меняет, а `systemctl restart awg-quick@awg0` (и `awg-quick down/up`) рвут всех живых клиентов — НЕЛЬЗЯ. Снимать точечно:

```bash
for k in <pubkey1> <pubkey2> ...; do awg set awg0 peer "$k" remove; done
awg show awg0 dump | tail -n +2 | wc -l    # уменьшилось ровно на N
```

После этого runtime и файл совпадают, рестарт не нужен ни сейчас, ни при ребуте: мёртвых блоков в файле уже нет.

Откат (если пир всё-таки нужен): взять его `PublicKey`/`PresharedKey`/`AllowedIPs` из бэкапа конфига и вернуть тем же `awg set ... preshared-key <(echo ...) allowed-ips ...` — без рестарта.

⚠️ На релее (awg2, отдельный хост) все команды те же — только через `ssh -i <ключ> root@<IP>`; интерфейс и конфиг живут там, локальный `awg show awg2` ничего не покажет.

### 5. Verify

```bash
awg show awg0 | grep -E '^peer:|  latest handshake|  allowed ips'
# Мёртвые пиры исчезли, живые восстановят handshake через секунды
```

## 🔴 Pitfall: чистка мёртвых пиров может сломать живые конфиги

При удалении пиров без handshake — **НЕ УДАЛЯЙ** пиры, у которых есть конфиг на сервере, даже если handshake нет. Клиент может переустанавливать конфиг / настраивать новое устройство.

Пример (28 Jun 2026): пир Саши 10.9.0.102 не имел handshake и был удалён при чистке. Но конфиг `Саша.conf` существовал и был установлен на ноутбуке пользователя. Пришлось восстанавливать пир через `awg addconf`.

**Правило:** Перед удалением любого пира:
1. Проверить, есть ли `.conf` файл с соответствующим публичным ключом
2. Если есть — **не удалять**, пир может понадобиться клиенту
3. Если нет — удалять безопасно

```bash
# Проверка: есть ли конфиг для этого пира
grep -r "<public-key>" /etc/amnezia/amneziawg/*.conf /etc/amnezia/amneziawg/*.key 2>/dev/null
# Если нашёлся — не удалять без подтверждения
```
