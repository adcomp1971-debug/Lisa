GateBox+landing на nginx: /var/www/gatebox/, API :5010 /api/. Прокси: /dash/→9119, /xui/→49624, /mivtzar/→8081, /swarm/→:8878. NGINX: sites-available/gatebox. URL: gpu-qwen.tail0c8f2f.ts.net
§
[2026-09-13] AWG: Full Tunnel (0.0.0.0/0 + ::/0) с СЕРВЕРНЫМИ параметрами (Jc/Jmin/S/H; Jmin=40, H1-H4=1106007595/1284786334/1463045443/1537700372) — единственное решение для РФ-клиентов: IG+ChatGPT+TG+Озон/ВБ/Яндекс/ВК, IP 76.13.77.105 не блокируется; Split Tunnel НЕ работает (список CDN бесконечен, ChatGPT на Cloudflare без покрытия). IPv6: на awg0 fd00:9::1/64 + forwarding=1 + NAT66 + FORWARD + /etc/iptables/rules.v6; клиентам Address=10.9.0.X/32, fd00:9::X/128, AllowedIPs=0.0.0.0/0, ::/0 + IPv6 DNS (без ::/0 — утечка IPv6 мимо VPN, Instagram тормозит). Клиенты: Ирина .113, Валера .107, Лена Папина .114 (16.09); заняты .10, .100-.115, свободны .116+. ПИТФОЛЛ: PSK/PrivateKey клиента ОБЯЗАНЫ совпадать с пиром (awg show awg0 dump) — старые gatebox-конфиги давали другие PSK → «не работает вообще». Обновлённые конфиги /root/awg-updated/*.conf, 46 мусорных gatebox-*.conf → .archive-gatebox/. .conf слать с уникальным именем.
§
[2026-08-21] Vast.ai: unset VAST_API_KEY перед вызовом; перед убийством инстанса — чекпоинты+датасет+логи. Hostinger исходящий ~55KB/s — файлы >500MB наружу не тащить. Vast China/Henan ~54KB/s бесполезен, брать ЕС/США. HUGGINGFACE_TOKEN в .env 401.
§
MLflow: http://76.13.77.105:8080 (обязательно :8080, nginx→:5050). Funnel ts.net и домашний Wi‑Fi Алекса режут :8080 — открывать с мобильного или AWG. systemd mlflow-server. experiment hermetica-network, hermetist v1.
§
Config.yaml: python3 heredoc (не patch/write_file на системные пути). После правки: wc -c, grep fallback_providers, yaml.safe_load. yaml.dump() маскирует ключи — проверять длину после записи.
§
[2026-08-30] Релеи Claude/Codex: codex-grok :4455, codex-kimi :4448, codex-ds :4446, claude-grok :4454 (пустой ответ = ошибка парсера messages-формата, НЕ релея). Мертвы/квота 0: codex-lc :4447 (402 LongCat), claude-lc :4451. claude-kimi :4453 отдаёт ПУСТОЙ content (K3 thinking) — Kimi только через :4448. Claude Code через релеи слабо держит агентский цикл — настройка через delegate_task Grok. Codex-обёртки: --skip-git-repo-check. Релеи отвечают только своим форматом (Responses vs Messages; stunnel — HTTPS).
§
Когда пользователь повторяет термин — это ключевое слово, не ошибка произношения. «Нос ресетч» = Nous Research.
§
[2026-07-10] Конвенция памяти: каждая новая запись начинается с даты [YYYY-MM-DD]. Старые не датировать. config.yaml = единственный источник правды для fallback/providers.
§
Доставка файлов: .conf/.yaml/.json → .txt (iPad не открывает), AWG .conf → .conf, команды по одной в .txt через sendDocument, без md/tables/инлайн в теле. chat_id=420839805. Готовые скрипты: /root/send_file.py <путь> "<подпись>" [имя_файла] — отправка sendDocument (MEDIA-в-ответе на iPad НЕ доходит).
§
РЕСТАРТ GATEWAY — ТОЛЬКО АЛЕКС. Даже при crash-loop. systemctl restart hermes-gateway (terminal блокирует SIGTERM изнутри). Никогда самовольно.
§
Sochen Bituach (брат, страховой агент Израиль): Hermes Box RAG на ивритских документах (Menora/Shloma/Migdal + car_insurance + life_prices), 200 клиентов на русском, DS Flash + nomic-embed-text, бот sochen-bot.py. Формат: .xlsx таблицы, всё на русском (брат плохо читает иврит).
§
[2026-08-21] Vision: auxiliary.vision = deepseek/deepseek-flash (v4-flash/v4-pro image_url НЕ принимают, vision-exp устарел с 09-11). max_tokens≥1500. Fallback gemini-3.6-flash. Скрипт scripts/vision-analyze.py проверен живьём 2026-09-13.
§
⚡ АБСОЛЮТНОЕ ПРАВИЛО: НИКОГДА не цитировать текст голосового сообщения пользователя. Ни в теле ответа, ни в подписи. Пришло голосовое → понял суть → ответил по делу. Без единого слова из оригинала. Нарушение = удаление. Пользователь в крайней ярости от жратвы токенов на эти цитаты.
§
Alex's full name: Alex Skver (Alex Verny на DeepSeek). Жена Anna «Лиса» (chat_id 347164465, Liskaanka bot) — ведический астролог Джйотиш из Шимлы: работает В ТРАДИЦИИ брахмана Шимлы (практикует, не «учится»), услуги: натальные карты по времени/месту рождения, звёздные карты, годовые прогнозы, мухурта, история космологии (от вед до пуран). Лендинг :8092 /var/www/anna-astrologer обновлён 06.09 под это позиционирование. Планируют пожить в Шимле ($700-800/мес на двоих, местная аренда 2BHK Mashobra ₹18-25k + еда, БЕЗ Airbnb — туристические цены не нужны). Аналитика для Анны: финансы/геополитика (Bloomberg/Reuters/Forbes), без оппозиции и пропаганды.
§
[2026-07-18] Скрипты ~/.hermes/scripts/: context_offload.py (>15k, exit 0/1/80/99), progress_harness.py. >2 tool calls подряд → execute_code. Cron context-offload-watchdog 12ч.
§
[2026-07-25] GLM (z.ai) — не удалять из конфига, ключ активен. Balance API нет (404) — balance-monitor проверяет активность ключа, не баланс.
§
[2026-07-27] AgentMail MCP: ключ в config.yaml, node build/index.js, 25 tools, 2 инбокса.
§
[2026-08] OmniRoute systemd (:20128, автозапуск). PATH в unit обязателен (nvm node v24). Free-модели oc/*-free flaky — резерв.
§
[2026-08-03] DeepSeek request_timeout_seconds=300, stale_timeout=60 в config.yaml. Таймауты провайдеров НЕ должны равняться cron inactivity watchdog (600s) — иначе watchdog убивает job до срабатывания fallback (паттерн vasily-freelance 'fallback chain exhausted', session-prune 2026-08-02).
§
[2026-09-12] Роутинг: main=deepseek-flash (V4.1: reasoning+vision, 1M ctx, $0.15/$0.60 off-peak, cache-hit $0.003; peak ×2 = 01-04/06-10 UTC пн-пт). Fallback: glm-5.3 ($1.40/$4.40)→grok-4.20-reasoning→deepseek-v4-pro→gemini-3.6-flash→gpt-5.6-luna (luna дороже Flash ×4.3, принимает только max_completion_tokens, ключ sk-proj pay-as-you-go). Gemini 3.8-flash нестабильна (2/5) — брать 3.6/3.5/3.7. deepseek-v4-pro не снимают, у Pro нет vision. Проверка цепочки: /root/.hermes/scripts/probe_routing.py.
§
[2026-09] РФ-специфика (клиенты): WhatsApp «открывается, не ходит» = битый iOS после РКН, лечится переустановкой без iCloud; два VPN на iOS несовместимы; VLESS в РФ сторе — v2RAGE (id 6761075402), проверка через itunes lookup country=ru. Одним EU дата-центровым IP нельзя одновременно обойти РКН и пройти антибот Wildberries (498 и на eth0, и на WARP — оба дата-центры); Озон/Яндекс/ВК/dns-shop с сервера открываются (307/302/401). Решение: 2 профиля (Yulia-Instagram full / Yulia-Magaziny split) + ручное переключение; «один конфиг = всё» — только с РФ-VPS (Selectel/Timeweb) + policy routing на EU-сервере, предложено, не куплено.
§
[2026-08-09] graphiti-sync: MEMORY_FILE=~/.hermes/memories/MEMORY.md; neo4j драйвер в venv /usr/local/lib/hermes-agent/venv (cron no_agent = sys.executable).
§
[2026-09-10] Cron-среда: 19 active (список и расписания — в AGENTS.md); execute_code BLOCKED (security policy) — агрегацию делать через terminal+python3. Встроенный web_search (search_backend=brave) не резолвится («no registered web search provider») — звать MCP brave напрямую. Firecrawl: ключ валиден, MCP активен, extract_backend=firecrawl; при 402 — fallback web_search (YC/Habr/Upwork); баланс кредитов только в дашборде (API не отдаёт). nginx sites-enabled читает .bak как живые сайты.
§
[2026-08-16] SSH: sshd_config с Include + PasswordAuthentication no (reload, не restart). Пароль root: /root/.ssh/root-password-20260816.txt (600). cloud-init НЕ трогать НИКОГДА: runcmd Hostinger заблокирован (/var/lib/cloud/instances/hvps-3f7773c3e82786f7/scripts/runcmd.disabled — он ставил пароль root каждый boot). После ребута: ufw 22/80/443/51820/8080/8081+ts+awg0; x-ui 49624 только ts; NAT PostUp.
§
[2026-08-13] Kimi K3 API квирки: принимает ТОЛЬКО temperature=1 (thinking-модель, иначе HTTP 400 «invalid temperature»). Reasoning жрёт токены: для серьёзных задач max_tokens ≥ 8000, при 4000 длинные ответы (bash-скрипты) обрываются на первой строке.
§
[2026-08-21→22] «Герметист» — веб http://76.13.77.105:8080/hermetist/ (Flask :5080), systemd hermetist-web.service (Restart=always). Спека /root/hermes-box/GERMETIST-SPEC.md. Ответчик DeepSeek V4 Flash (HERMETIST_PROVIDER=deepseek; менять в systemd + рестарт hermetist-web; «кто управляет Герметистом» = provider). 32B в UI не подключать без «да». Детали: маршруты архивов → скилл germetist-router; источники/фиксы (РГБ aleph, Востлит, Пушкинский Дом БЛДР, authors.json 9 авторов, алиасы падежей, семантика nomic 122174×768, Sefaria локально, LoC) → скилл hermetist + references/. Vast 32B: Qwen3-32B+LoRA hermetica-v2 (инстанс 48282413 hermetist-v3, RTX A6000), infer_v2.py :8001, туннель ssh -N -L 8001:127.0.0.1:8001, provider=vast32, ответ ~66с, <think>-блоки не показывать. v1 Qwen3-8B GGUF /root/hermetica-q4.gguf зацикливается. Книга Алекса «Правда стоит на одной ноге» (kimi.page).
§
[2026-08-19] Source Library MCP https://sourcelibrary.org/api/mcp, ключ SOURCE_LIBRARY_API_KEY в .env. Rate limit: паузы 1.2с+, ретраи 20-60с. Скилл research/source-library.
§
[2026-08-20] Hostinger 4 CPU: ЗАПРЕЩЕНО грузить ядра (эмбеддинги nomic/llama-server, ollama create, индексация Герметиста, fine-tune). Load>6 → Telegram polling degraded, Hermes «отваливается». Повтор 19.08 и 20.08. Тяжёлое ТОЛЬКО Vast.ai. Локально: nice 19 + 1 ядро, иначе не запускать. cpu-guard cron убивает нарушителей.
§
Для многошаговых операций (инференс на GPU, передача GB-файлов, деплой) — делегировать Grok 4.6 сразу, не тащить в основном контексте. «Не тащи сам гнида, используй делегацию агентов всю мощь стэка». Передавать субагенту полный контекст: SSH, порты, размеры, что уже сделано.
§
[2026-09-12] Качество > экономия: при жалобе на «тупость» («Гермес стал тупой» на Flash) сначала вернуть Grok 4.6 как main, потом обсуждать смену платформы (интересовался DeepSeek Harness: dsh, preview v0.1, npx @deepseek-ai/dsh). Периодически тестирует стек — сравнить модели на одном вопросе («уровень ума и поиска»); ждёт цитаты из первоисточников (сканы SL/IA) выше гладкого пересказа; давать ответ модели как есть + свой разбор слабых мест (нет цитат, нельзя проверить, нет имён исследователей).
§
[2026-09-04] Изменения, которые Hermes МОЖЕТ сделать инструментами (cron через cronjob_manage/tool_call, apt, конфиги, файлы, skill_manage) — делать САМОМУ сразу, НЕ слать Алексу команды файлом («ТЫ что идиот, сделай всё сам мудак»). Синим файлом слать ТОЛЬКО то, что физически может выполнить только Алекс: рестарт hermes-gateway, hermes update (нельзя из gateway). Команды — по одной в .txt. cron-задачи менять через отложенный инструмент cronjob_manage (tool_search → cronjob_manage), не hermes cron CLI от имени Алекса.
§
[2026-08-26] Hermes LSP (hermes lsp): включён, wait_mode=document, wait_timeout=5s. Работает ТОЛЬКО для файлов внутри git-worktree — вне git семантики нет (только in-process синтаксис). Установлены: pyright, typescript, bash, yaml, rust-analyzer, dockerfile-ls (добавлен 08-26). gopls/vue/svelte/php/terraform и пр. НЕ ставить — нет таких проектов. DAP в Hermes отсутствует.
§
state.db (Hermes session DB): НИКОГДА не открывать живую внешним sqlite3 на запись/checkpoint/vacuum/recover, пока gateway работает (повредило БД 26.08); .recover из CLI даёт пустую БД — не подменять живую. Восстановление только на копии или при остановленном gateway. Ночной backup: hermes backup -q (не cp живого). Мониторинг: scripts/state-db-health.sh. Признак проблемы — лог «a live process holds a deleted state.db-wal inode» → нужен рестарт gateway (только Алекс); retired-WAL заархивирован в /root/.hermes/state-archives/.
§
[2026-08-28] User-owned скиллы (docx/pdf/xlsx/email-agent/web-research/spec-driven-dev и др.) — рабочие инструменты, НЕ архивировать/удалять за zero-use, даже если давно не использовались. Алекс: «Зачем их удалять, они тебе не нужны что ли?»
§
[2026-08-31] Telegram-боты (3): @AmseujBot / @liska_hermes_bot = Hermes gateway (Алекс произносит «амнеус» = Amseuj, это НЕ Liskaanka); @Liskaanka_Bot — для Ани (liskaanka-bot.service, /root/liskaanka_bot.py, свой getUpdates); @smd_quiet_bot (vpnbot.service, /opt/vpnbot — aiogram «LEMMY VPN»: trial/подписки/оплата/выдача AWG-конфигов, ADMIN_IDS=420839805, .env с BOT_TOKEN/FERNET_KEY, SQLite; только личка, групповой режим не поддержан). Проверка владельца токена: POST /getMe.
§
[2026-09-03] БПЛА «UAV-001» (определение проекта и цель — USER.md): фюзеляж 1.75м. Методика крыла: S=2mg/(ρV²Cl), b=√(AR·S), нагрузка 50-90 г/дм² универсал / 90-150 быстрый. При 12кг/2.5м/AR7: S~0.9м², срыв ~48км/ч. Полный вес и профиль не дал — расчёт ориентировочный.
§
[2026-08-24] РАБОЧИЙ ПРОЦЕСС (обязательный): spec-driven-dev скилл. Любое изменение прода/кода/конфига — 4 фазы: grill-me (допрос) → to-spec (спека) → to-tickets (шаги) → TDD (тест сначала). Никакого прода с первого промпта. «Ну!» = дефолты без переспроса. Мелкая диагностика/чтение — без спеки.
§
[2026-09-05] Лендинги на nginx: shimla-landing (пример, :8091, /var/www/shimla-landing), anna-astrologer (:8092, /var/www/anna-astrologer — лендинг Анны). Правки: файлы в /var/www/, server-блок в /etc/nginx/sites-available/ через terminal heredoc (write_file отказывает для /etc/nginx), ln -sf в sites-enabled, nginx -t && reload, ufw allow порт.
§
[2026-09-10] Аудит безопасности: Docker обходил UFW — фикс /usr/local/bin/docker-wan-guard.sh + юнит docker-wan-guard.service (After=docker, enabled, идемпотентный). Закрыто снаружи (ufw deny in on eth0): 11434 Ollama, 3000 WebUI, 5050 MLflow, 7474/7687 Neo4j, 8002 RAG, 8787 core, 20128 OmniRoute, 1080 danted — НЕ через смену bind на 127.0.0.1 (контейнеры ходят в Ollama по docker-сети). stunnel: foreground=yes в /etc/stunnel/anthropic-relay{,-kimi}.conf + юниты stunnel-anthropic.service/stunnel-anthropic-kimi.service (Restart=always, enabled), LSB stunnel4 отключён. Проверка снаружи — check-host.net (Tor/WARP дают ложные 000). SSH 22/443/51820 не тронуты.
§
[2026-09-13] Команды Алексу: он в Blink Shell на iPad, серверных команд там нет («systemctl: command not found»). Давать ОДНОЙ строкой с SSH: ssh root@76.13.77.105 "systemctl restart hermes-gateway && sleep 2 && systemctl is-active hermes-gateway". Признак: промпт blink> = локально, root@srv1593922:~# = на сервере. Долгие операции (архивы, инференс, прогоны моделей) — отвечать сразу после старта и присылать результат одним сообщением, без пауз «ещё считает».
§
[2026-09] Алекс физически в Израиле: советы и цены в ₪ по рынку IL (не РФ), вопросы Google Play регион. Авто-рынок Рампе: Deepal S05/S07/S07 PHEV 179 990-201 990 ₪, S05 Max б/у 160к ₪, интерес к BYD/Geely/MG/Leapmotor/Voyah. Правило подбора: экосистема/совместимость → цена НОВОГО → оценка б/у. Жена Анна «Лиса» с iPhone → Apple Watch, Huawei на iOS урезан. GPT-6 Astra (gpt-6-astra) — его ВНЕШНИЙ АНАЛИТИК для аудитов (VPN/безопасность/архитектура): прогонять через API в фоне, max_completion_tokens 8000; в fallback без его команды не ставить. Формат запросов: «проверь X, делегируй Astra, не забудь про живых клиентов VPN».
§
[2026-09-14] Внедрено: (1) hermes-sandbox — изоляция кода в Docker (прод-файлы denied, сеть off, OOM-kill 512М, non-root; образ hermes-sandbox:latest, /root/sandbox/Dockerfile; скилл code-sandbox). ПИТФОЛЛ: timeout вокруг docker run НЕ работает — docker CLI игнорит SIGTERM, нужен фоновый убийца по имени. (2) memory.provider=holographic (локальный SQLite: facts/entities/FTS5/HRR, auto_extract=true, /root/.hermes/memory_store.db; config.yaml править только python-heredoc — patch/write_file блокируются). (3) skills hub (100k, official Nous): ClawHub community НЕ ставить; реестр почищен от orphaned, docker-management+agentmail обновлены, grok/scrapling/fastmcp/rest-graphql-debug сохранены с локальными правками (--force перезапишет).
§
[2026-09-14] Правило по скиллам (выбор Алекса, вариант Б): community-скиллы из hub СМОТРЕТЬ можно, но ставить — ТОЛЬКО после явного «да» на конкретный (показать что делает, ждать подтверждения). Official (Nous Research) — можно без спроса. Старое «community — НИКОГДА» в SOUL.md обновлено на это.
§
[2026-09-15] Hermes v0.21.3 (2026.9.14, HEAD dfc28b61). Community-плагин dynamic-workflows (lingjiuu, заброшен) отваливается при каждом обновлении — лечится локальным патчем вручную (детали и команда проверки — в скилле hermes-agent). Бэкапы плагинов держать в /root/plugins-backup/: в ~/.hermes/plugins/ любая подпапка сканируется как плагин (уже стоило двух лишних рестартов).