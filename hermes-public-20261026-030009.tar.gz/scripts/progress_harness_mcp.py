#!/usr/bin/env python3
"""
MCP server for Progress Harness — tracks long-running task progress.

Exposes tools:
  - progress_init: Start a new session
  - progress_checkpoint: Save checkpoint
  - progress_status: Show current progress
  - progress_resume: Get resume info
  - progress_list: List sessions

Transport: stdio (for Hermes Native MCP client)
"""

import json
import sys
from pathlib import Path

SCRIPTS_DIR = Path.home() / ".hermes" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

from progress_harness import ProgressHarness, DEFAULT_PROGRESS_DIR


def send_response(data: dict) -> None:
    print(json.dumps(data), flush=True)


def send_error(request_id: str | None, code: int, message: str):
    send_response({
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": code, "message": message},
    })


def send_result(request_id: str | None, result: dict):
    send_response({
        "jsonrpc": "2.0",
        "id": request_id,
        "result": result,
    })



def send_tool_result(request_id: str | None, payload: dict):
    """MCP tools/call result must carry content[] — wrap any payload as text."""
    send_result(request_id, {
        "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False, default=str)}],
        "isError": False,
    })

def handle_tool_call(req: dict) -> None:
    req_id = req.get("id")
    params = req.get("params", {})
    tool = params.get("name", "")
    args = params.get("arguments", {})

    harness = ProgressHarness(
        progress_dir=Path(args.get("progress_dir")) if args.get("progress_dir") else DEFAULT_PROGRESS_DIR,
        session_id=args.get("session_id"),
    )

    match tool:
        case "progress_init":
            desc = args.get("description", "")
            if not desc:
                send_error(req_id, -32000, "description required")
                return
            result = harness.init_session(
                task_description=desc,
                session_id=args.get("session_id"),
                force=args.get("force", False),
            )
            send_tool_result(req_id, {"session": result})

        case "progress_checkpoint":
            action = args.get("action", "")
            state = args.get("state")
            result = harness.save_checkpoint(
                action=action,
                state=state,
            )
            send_tool_result(req_id, {"checkpoint": result})

        case "progress_status":
            progress = harness.load_progress()
            if progress:
                send_tool_result(req_id, {"session": progress})
            else:
                send_tool_result(req_id, {"session": None, "message": "No active session"})

        case "progress_resume":
            info = harness.resume_last()
            send_tool_result(req_id, {"resume_info": info})

        case "progress_list":
            sessions = harness.list_sessions(limit=args.get("limit", 10))
            send_tool_result(req_id, {"sessions": sessions})

        case _:
            send_error(req_id, -32601, f"Tool '{tool}' not found")


def handle_initialize(req: dict) -> None:
    req_id = req.get("id")
    send_result(req_id, {
        "protocolVersion": "2024-11-05",
        "capabilities": {
            "tools": {
                "listChanged": False,
            },
        },
        "serverInfo": {
            "name": "progress-harness",
            "version": "1.0.0",
        },
    })


def handle_list_tools(req: dict) -> None:
    req_id = req.get("id")
    send_result(req_id, {
        "tools": [
            {
                "name": "progress_init",
                "description": "Initialize a new progress tracking session",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "description": {"type": "string", "description": "Task description"},
                        "session_id": {"type": "string", "description": "Unique session ID (optional, auto-generated if omitted)"},
                        "force": {"type": "boolean", "description": "Overwrite existing session", "default": False},
                        "progress_dir": {"type": "string", "description": "Override progress directory"},
                    },
                    "required": ["description"],
                },
            },
            {
                "name": "progress_checkpoint",
                "description": "Save a checkpoint in the current session",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "description": "What was accomplished"},
                        "state": {"type": "object", "description": "Optional state snapshot"},
                        "progress_dir": {"type": "string"},
                        "session_id": {"type": "string"},
                    },
                    "required": ["action"],
                },
            },
            {
                "name": "progress_status",
                "description": "Get current session progress status",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "progress_dir": {"type": "string"},
                        "session_id": {"type": "string"},
                    },
                },
            },
            {
                "name": "progress_resume",
                "description": "Get resume information — last checkpoint, next steps, blockers",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "progress_dir": {"type": "string"},
                        "session_id": {"type": "string"},
                    },
                },
            },
            {
                "name": "progress_list",
                "description": "List recent progress sessions",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "limit": {"type": "number", "description": "Max sessions to return", "default": 10},
                        "progress_dir": {"type": "string"},
                    },
                },
            },
        ],
    })


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue

        method = req.get("method", "")
        match method:
            case "initialize":
                handle_initialize(req)
            case "tools/list":
                handle_list_tools(req)
            case "tools/call":
                handle_tool_call(req)
            case "notifications/initialized":
                pass
            case _:
                send_error(req.get("id"), -32601, f"Method '{method}' not found")


if __name__ == "__main__":
    main()
