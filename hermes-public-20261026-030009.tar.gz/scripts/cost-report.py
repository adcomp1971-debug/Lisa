#!/usr/bin/env python3
"""Cost report — weekly LLM spend estimate from state.db"""
import sqlite3
import os
import sys
from datetime import datetime, timedelta

STATE_DB = os.path.expanduser("~/.hermes/state.db")
WINDOW_DAYS = int(sys.argv[1]) if len(sys.argv) > 1 else 7
DAILY_ALERT_THRESHOLD = float(os.environ.get("COST_ALERT_THRESHOLD", "7.0"))

# Approximate $/1K tokens (input, output) — off-peak ставки (peak ×2: 01-04 и 06-10 UTC, пн-пт)
MODEL_COSTS = {
    # актуальные (2026-09-11, офиц. доки)
    "deepseek-flash": (0.00015, 0.00060),      # V4.1-Flash: $0.15/$0.60 off-peak, cache-hit $0.003
    "deepseek-v4-pro": (0.00066, 0.00198),     # V4-Pro-0813: $0.66/$1.98 off-peak (vision НЕТ)
    "grok-4.20-reasoning": (0.00125, 0.00250),
    "grok-4.20-non-reasoning": (0.00125, 0.00250),
    "grok-4.6": (0.00200, 0.00600),
    "grok-4.7": (0.00200, 0.00600),
    "grok-4.3": (0.00125, 0.00250),
    "kimi-k3": (0.00040, 0.00160),
    "gpt-5.6-luna": (0.00030, 0.00120),
    "gpt-6-astra": (0.01000, 0.05000),
    "gemini-3.8-flash": (0.00005, 0.00020),
    "gemini-3.7-flash": (0.00005, 0.00020),
    "glm-5.3": (0.00140, 0.00440),             # $1.40/$4.40 за 1M, cached input $0.26
    "glm-5.3-flash": (0.00015, 0.00050),
    "glm-5.2": (0.00140, 0.00440),
    # устаревшие алиасы (история)
    "deepseek-v4-flash": (0.00015, 0.00060),
    "deepseek-chat": (0.00015, 0.00060),
    "LongCat-2.0": (0.00050, 0.00150),
    "glm-5.2-old": (0.00040, 0.00120),
    "gemini-3.1-flash": (0.00000, 0.00000),  # free tier
    "gemini-2.5-flash": (0.00000, 0.00000),  # free tier
    "gemini-3.5-flash": (0.00005, 0.00020),
    "gpt-4o-mini": (0.00015, 0.00060),
    "claude-sonnet-4.6": (0.00300, 0.01500),
    "claude-fable-5": (0.01500, 0.07500),
    "hermes-agent": (0.00000, 0.00000),
}

def estimate_cost(model_name, tokens_in, tokens_out):
    costs = MODEL_COSTS.get(model_name, (0.00020, 0.00080))
    return (tokens_in * costs[0] + tokens_out * costs[1]) / 1000

def main():
    if not os.path.exists(STATE_DB):
        print("No state.db found")
        return
    
    conn = sqlite3.connect(STATE_DB)
    cutoff = (datetime.utcnow() - timedelta(days=WINDOW_DAYS)).timestamp()
    
    # Session-level token summary
    sess_rows = conn.execute("""
        SELECT billing_provider, model,
               SUM(input_tokens), SUM(output_tokens),
               COUNT(*) as sessions
        FROM sessions
        WHERE started_at > ?
          AND input_tokens > 0
        GROUP BY billing_provider, model
        ORDER BY SUM(input_tokens + output_tokens) DESC
    """, (cutoff,)).fetchall()
    
    conn.close()
    
    if not sess_rows:
        print(f"No session data in last {WINDOW_DAYS} days")
        return
    
    # Group
    by_provider = {}
    for prov, model, inp, out, sess_count in sess_rows:
        p = prov or "unknown"
        m = model or "unknown"
        key = f"{p}/{m}"
        d = by_provider.setdefault(key, {"tokens_in": 0, "tokens_out": 0, "sessions": 0, "cost": 0.0})
        d["tokens_in"] += inp or 0
        d["tokens_out"] += out or 0
        d["sessions"] += sess_count
        d["cost"] += estimate_cost(m, inp or 0, out or 0)
    
    total_in = sum(d["tokens_in"] for d in by_provider.values())
    total_out = sum(d["tokens_out"] for d in by_provider.values())
    total_cost = sum(d["cost"] for d in by_provider.values())
    total_sess = sum(d["sessions"] for d in by_provider.values())
    
    print(f"📊 Cost Report — Last {WINDOW_DAYS} days (thru {datetime.utcnow().strftime('%Y-%m-%d')})")
    print(f"{'='*60}")
    print(f"Total sessions: {total_sess}")
    print(f"Total tokens: {total_in + total_out:,} (in: {total_in:,}, out: {total_out:,})")
    print(f"Est. cost: ${total_cost:.2f}")
    print(f"Monthly: ${total_cost / WINDOW_DAYS * 30:.2f} (${total_cost / WINDOW_DAYS:.2f}/day)")
    print()
    print(f"{'Provider/Model':<32} {'Tokens':>10} {'Sess':>5} {'Est.$':>8}")
    print(f"{'-'*60}")
    for key, d in sorted(by_provider.items(), key=lambda x: -x[1]["cost"]):
        t = d["tokens_in"] + d["tokens_out"]
        print(f"{key:<32} {t:>10,} {d['sessions']:>5} ${d['cost']:>6.2f}")
    print(f"{'-'*60}")
    print(f"{'TOTAL':<32} {total_in + total_out:>10,} {total_sess:>5} ${total_cost:>6.2f}")

    # Daily cost alert check
    daily_cost = total_cost / WINDOW_DAYS
    if daily_cost > DAILY_ALERT_THRESHOLD:
        print(f"\n⚠️ DAILY COST ALERT: ${daily_cost:.2f}/day exceeds ${DAILY_ALERT_THRESHOLD:.2f}/day threshold")
        sys.exit(1)
    else:
        print(f"\n✅ Daily cost ${daily_cost:.2f}/day within ${DAILY_ALERT_THRESHOLD:.2f}/day threshold")

if __name__ == "__main__":
    main()
