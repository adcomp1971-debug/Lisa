#!/usr/bin/env bash
# Василий — Мониторинг сервера
# Проверяет статус всех критических сервисов. Выводит тревогу если что-то упало.
set -uo pipefail

LOG=/root/.hermes/logs/vasily-health.log
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
ALERT=""

check_svc() {
    local name=$1 svc=$2
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
        echo "$TS $name=OK" >> "$LOG"
    else
        echo "$TS $name=DOWN" >> "$LOG"
        ALERT="$ALERT🔴 $name DOWN\n"
    fi
}

check_svc "nginx"      "nginx"
check_svc "xray"       "x-ui"
check_svc "ollama"     "ollama"
check_svc "guardrails" "guardrails"
check_svc "tailscale"  "tailscaled"
check_svc "ssh"        "ssh"

# Диск
DISK=$(df -h / | awk 'NR==2{print $5}' | tr -d '%')
echo "$TS disk=${DISK}%" >> "$LOG"
if [ "$DISK" -gt 85 ] 2>/dev/null; then
    ALERT="$ALERT⚠️ Диск: ${DISK}%\n"
fi

# Память
MEM=$(free | awk '/Mem:/{printf "%.0f", $3/$2*100}')
echo "$TS mem=${MEM}%" >> "$LOG"
if [ "$MEM" -gt 90 ] 2>/dev/null; then
    ALERT="$ALERT⚠️ Память: ${MEM}%\n"
fi

if [ -n "$ALERT" ]; then echo -e "$ALERT"; fi
echo "$TS done" >> "$LOG"
