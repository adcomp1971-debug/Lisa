#!/usr/bin/env bash
set -uo pipefail
DIR=/root/.hermes/backups
KEEP=3
LOG=/root/.hermes/logs/backup-cleaner.log
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
cd "$DIR" || exit 1
# Удаляем старые папки hermes-* (nightly-backup.sh создаёт папки, НЕ zip!)
DELETED=$(ls -dt "$DIR"/hermes-* 2>/dev/null | tail -n +$((KEEP+1)) | xargs -r rm -rf -- 2>/dev/null | wc -l)
REMAIN=$(ls -d "$DIR"/hermes-* 2>/dev/null | wc -l)
echo "$TS deleted=$DELETED remain=$REMAIN" >> "$LOG"
