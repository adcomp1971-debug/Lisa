#!/usr/bin/env bash
set -uo pipefail
LOG=/root/.hermes/logs/auto-update.log
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
ENV_FILE=/root/.hermes/.env
[ -f "$ENV_FILE" ] && source "$ENV_FILE"

ADMIN_ID=420839805
BOT_TOKEN=${TELEGRAM_BOT_TOKEN:-}

notify() { [ -n "$BOT_TOKEN" ] && curl -sf --max-time 10 -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" -d "chat_id=$ADMIN_ID&text=$1" >/dev/null 2>&1; }

CHECK=$(hermes update --check 2>&1)
COMMITS=$(echo "$CHECK" | grep -oE "[0-9]+ commit" | grep -oE "[0-9]+" | head -1)

echo "$TS commits_behind=${COMMITS:-unknown}" >> "$LOG"

if [ -z "$COMMITS" ] || [ "$COMMITS" -lt 20 ]; then
  exit 0
fi

notify "🔄 Hermes: $COMMITS коммитов позади. Сделать бэкап и обновить? Ответь: hermes update --yes"
echo "$TS notified admin: $COMMITS commits" >> "$LOG"
