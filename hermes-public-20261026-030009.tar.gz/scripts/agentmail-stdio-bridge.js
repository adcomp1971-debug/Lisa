#!/usr/bin/env node
import { Client } from '/root/.nvm/versions/node/v24.15.0/lib/node_modules/agentmail-mcp/node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js';
import { StreamableHTTPClientTransport } from '/root/.nvm/versions/node/v24.15.0/lib/node_modules/agentmail-mcp/node_modules/@modelcontextprotocol/sdk/dist/esm/client/streamableHttp.js';
import { Server } from '/root/.nvm/versions/node/v24.15.0/lib/node_modules/agentmail-mcp/node_modules/@modelcontextprotocol/sdk/dist/esm/server/index.js';
import { StdioServerTransport } from '/root/.nvm/versions/node/v24.15.0/lib/node_modules/agentmail-mcp/node_modules/@modelcontextprotocol/sdk/dist/esm/server/stdio.js';
import { ListToolsRequestSchema, CallToolRequestSchema } from '/root/.nvm/versions/node/v24.15.0/lib/node_modules/agentmail-mcp/node_modules/@modelcontextprotocol/sdk/dist/esm/types.js';

const ENDPOINT = new URL('https://mcp.agentmail.to/mcp');
const VERSION = '1.0.0';

async function main() {
  const apiKey = process.env.AGENTMAIL_API_KEY;
  if (!apiKey) { console.error('AGENTMAIL_API_KEY required'); process.exit(1); }

  const remote = new StreamableHTTPClientTransport(ENDPOINT, {
    requestInit: {
      headers: {
        'x-api-key': apiKey,
        'X-AgentMail-MCP-Bridge': 'hermes-bridge/1.0.0',
        'User-Agent': 'hermes-agentmail/1.0.0',
      },
    },
  });

  const server = new Server(
    { name: 'agentmail', version: VERSION },
    { capabilities: { tools: { listChanged: true } } }
  );
  const client = new Client({ name: 'hermes-agentmail-bridge', version: VERSION });

  server.setRequestHandler(ListToolsRequestSchema, () => client.listTools());
  server.setRequestHandler(CallToolRequestSchema, (req) => client.callTool(req.params));

  await client.connect(remote);
  await server.connect(new StdioServerTransport());
  console.error('agentmail MCP bridge connected');
}
main().catch(e => { console.error(e.message); process.exit(1); });
