#!/usr/bin/env python3
"""Weekly stack cost report — обновлён 2026-08-09 (убрал мёртвый OpenRouter, добавил Moonshot/GLM)."""
import subprocess, json, os
from datetime import datetime

def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True).stdout.strip()

def get_env(name):
    with open("/root/.hermes/.env") as f:
        for line in f:
            if line.startswith(name + "="):
                return line.split("=", 1)[1].strip().strip("'\"")
    return None

# DeepSeek balance
ds_balance = "?"
try:
    ds_key = get_env("DEEPSEEK_API_KEY")
    if ds_key:
        r = subprocess.run(
            f'curl -s https://api.deepseek.com/user/balance -H "Authorization: Bearer {ds_key}"',
            shell=True, capture_output=True, text=True, timeout=10
        )
        d = json.loads(r.stdout)
        bis = d.get('balance_infos', [])
        if bis:
            ds_balance = f"${float(bis[0].get('total_balance', 0)):.2f}"
        else:
            ds_balance = f"${d.get('balance', '?'):.2f}"
except Exception:
    pass

# Moonshot (Kimi) balance
ms_balance = "?"
try:
    ms_key = get_env("KIMI_API_KEY")
    if ms_key:
        r = subprocess.run(
            f'curl -s https://api.moonshot.ai/v1/users/me/balance -H "Authorization: Bearer {ms_key}"',
            shell=True, capture_output=True, text=True, timeout=10
        )
        d = json.loads(r.stdout)
        ms_balance = f"${d.get('data', {}).get('available_balance', '?'):.2f}"
except Exception:
    pass

# GLM (z.ai) balance
glm_balance = "?"
try:
    glm_key = get_env("GLM_API_KEY")
    if glm_key:
        r = subprocess.run(
            f'curl -s https://open.bigmodel.cn/api/paas/v4/balance -H "Authorization: Bearer {glm_key}"',
            shell=True, capture_output=True, text=True, timeout=10
        )
        d = json.loads(r.stdout)
        b = d.get('data', {}).get('total', {})
        glm_balance = f"¥{b.get('available_balance', '?'):.2f}"
except Exception:
    pass

# Headroom stats
headroom_tokens = "?"
headroom_saved = "?"
try:
    log = sh("tail -30 /root/.headroom/logs/proxy.log 2>/dev/null")
    for line in log.split("\n"):
        if "Input tokens" in line:
            headroom_tokens = line.split(":")[-1].strip().replace(",", "")
        if "Tokens saved" in line:
            headroom_saved = line.split(":")[-1].strip().replace(",", "")
except Exception:
    pass

now = datetime.now().strftime("%d.%m.%Y %H:%M")
report = f"""📊 **Еженедельный отчёт стека** ({now})

**Балансы:**
• DeepSeek: {ds_balance}
• Moonshot/Kimi: {ms_balance}
• GLM (z.ai): {glm_balance}

**Headroom (Claude/Codex токены):**
• Пропущено: {headroom_tokens}
• Сэкономлено: {headroom_saved}

**Воркеры:**
• DeepSeek TUI: $0.014/M токенов
• Qwen 3.7 Plus: от $0.002/задача
• Claude Code: $3-15 (через Headroom)
• Codex: $5-30 (по команде)
"""
print(report)
