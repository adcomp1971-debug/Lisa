#!/usr/bin/env bash
# state-db-health.sh — read-only integrity check of state.db + size trend.
# Watchdog pattern: SILENT when healthy, alert to Telegram when broken.
# NEVER writes to state.db. Uses Hermes venv python (same sqlite as gateway).
set -u

HERMES_HOME="/root/.hermes"
STATE_DB="$HERMES_HOME/state.db"
CHAT_ID="420839805"
PY="/usr/local/lib/hermes-agent/venv/bin/python3"

# 1. Integrity check (read-only, safe while gateway runs)
RESULT=$("$PY" - "$STATE_DB" <<'PYEOF' 2>&1
import sqlite3, sys
db = sys.argv[1]
try:
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    r = con.execute("PRAGMA integrity_check").fetchall()
    con.close()
    if r and r[0][0] == "ok":
        print("OK")
    else:
        print("CORRUPT: " + "; ".join(str(x[0]) for x in r[:5]))
except Exception as e:
    print("ERROR: %s" % e)
PYEOF
)

if [ "$RESULT" != "OK" ]; then
    MSG="[$(date -u +%FT%TZ)] state.db INTEGRITY BROKEN: $RESULT"
    echo "$MSG"
    TOKEN=$(grep -E '^TELEGRAM_BOT_TOKEN=' "$HERMES_HOME/.env" | head -1 | cut -d= -f2- | tr -d "\"'")
    if [ -n "$TOKEN" ]; then
        curl -s -X POST "https://api.telegram.org/bot${TOKEN}/sendMessage" \
            -d chat_id="$CHAT_ID" \
            --data-urlencode "text=🚨 state.db INTEGRITY BROKEN
$RESULT
Файл: $STATE_DB
НЕ рестартить gateway самому. Восстановление: из state.db.old (rescue) или ночного бэкапа." >/dev/null 2>&1
    fi
    exit 1
fi

# 2. Size trend: warn if state.db shrank dramatically (e.g. replaced by empty db)
SIZE=$(stat -c %s "$STATE_DB" 2>/dev/null || echo 0)
TREND_FILE="$HERMES_HOME/state/.db_size"
if [ -f "$TREND_FILE" ]; then
    OLD=$(cat "$TREND_FILE")
    if [ "$OLD" -gt 104857600 ] && [ "$SIZE" -lt $((OLD / 2)) ]; then
        echo "[$(date -u +%FT%TZ)] state.db SIZE DROP: was ${OLD}, now ${SIZE}"
        exit 1
    fi
fi
echo "$SIZE" > "$TREND_FILE"

exit 0
