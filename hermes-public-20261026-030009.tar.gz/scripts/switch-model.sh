#!/bin/bash
# Switch model to deepseek-chat (DeepSeek Pro) and restart gateway
sleep 2
python3 -c "
import yaml
with open('/root/.hermes/config.yaml', 'r') as f:
    c = yaml.safe_load(f)
c['model']['default'] = 'deepseek-chat'
c['model']['provider'] = 'deepseek'
with open('/root/.hermes/config.yaml', 'w') as f:
    yaml.dump(c, f, default_flow_style=False, allow_unicode=True)
print('Model switched to deepseek-chat')
"
SVC=hermes-gateway
systemctl restart $SVC
echo "Gateway restarted at $(date)"
