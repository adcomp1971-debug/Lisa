#!/bin/bash
sleep 3
systemctl restart hermes-gateway
