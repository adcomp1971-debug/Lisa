#!/usr/bin/env python3
"""
Skills v2 Code Generator — генератор code-скиллов для Python + Hermes

Usage:
    skill_code_gen.py create-skill <name> --description "..."
    skill_code_gen.py add-script <skill-name> <script-name> --code "..."
    skill_code_gen.py generate-loader <skill-name>
    skill_code_gen.py list-scripts <skill-name>
"""

import argparse
import ast
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

SKILLS_DIR = Path.home() / ".hermes" / "skills"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _checksum(content: str) -> str:
    return hashlib.sha256(content.encode()).hexdigest()[:12]


def create_skill(name: str, description: str) -> dict:
    skill_dir = SKILLS_DIR / name
    if skill_dir.exists():
        return {"error": f"Skill '{name}' already exists at {skill_dir}"}

    scripts_dir = skill_dir / "scripts"
    refs_dir = skill_dir / "references"
    tmpl_dir = skill_dir / "templates"

    scripts_dir.mkdir(parents=True)
    refs_dir.mkdir(parents=True)
    tmpl_dir.mkdir(parents=True)

    skill_md = skill_dir / "SKILL.md"
    skill_md.write_text(
        "---\n"
        f"name: {name}\n"
        f"description: {description}\n"
        "version: 1.0.0\n"
        "---\n"
        "\n"
        f"# {name}\n"
        "\n"
        f"{description}\n"
        "\n"
        "## Scripts\n"
        "\n"
        "Auto-loaded from `scripts/` directory.\n"
    )

    (scripts_dir / "__init__.py").write_text("")

    (scripts_dir / "main.py").write_text(
        "#!/usr/bin/env python3\n"
        '"""Main entry point."""\n'
        "\n"
        "def run(*args, **kwargs):\n"
        '    """Run the skill."""\n'
        "    return {\"status\": \"ok\"}\n"
        "\n"
        'if __name__ == "__main__":\n'
        "    run()\n"
    )

    (refs_dir / "api.md").write_text(
        f"# {name} API Reference\n"
        "\n"
        "## Functions\n"
        "\n"
        "### `run(*args, **kwargs)`\n"
        "\n"
        "Main entry point.\n"
    )

    metadata = {
        "name": name,
        "description": description,
        "created_at": _now(),
        "version": "1.0.0",
        "scripts": {
            "main.py": {
                "checksum": _checksum((scripts_dir / "main.py").read_text()),
                "created_at": _now(),
            }
        },
    }
    (skill_dir / ".metadata.json").write_text(json.dumps(metadata, indent=2))

    return {
        "status": "ok",
        "skill": name,
        "path": str(skill_dir),
        "scripts": ["main.py"],
    }


def add_script(skill_name: str, script_name: str, code: str = None) -> dict:
    skill_dir = SKILLS_DIR / skill_name
    if not skill_dir.exists():
        return {"error": f"Skill '{skill_name}' not found"}

    scripts_dir = skill_dir / "scripts"
    if not scripts_dir.exists():
        scripts_dir.mkdir(parents=True)

    script_path = scripts_dir / script_name

    if code is None:
        code = (
            "#!/usr/bin/env python3\n"
            f'"""{script_name} — {skill_name} module."""\n'
            "\n"
            "def run():\n"
            '    """Main function."""\n'
            "    pass\n"
            "\n"
            'if __name__ == "__main__":\n'
            "    run()\n"
        )

    try:
        ast.parse(code)
    except SyntaxError as e:
        return {"error": f"Syntax error in {script_name}: {e}"}

    script_path.write_text(code)
    script_path.chmod(0o755)

    meta_path = skill_dir / ".metadata.json"
    if meta_path.exists():
        meta = json.loads(meta_path.read_text())
        meta.setdefault("scripts", {})[script_name] = {
            "checksum": _checksum(code),
            "created_at": _now(),
        }
        meta_path.write_text(json.dumps(meta, indent=2))

    return {"status": "ok", "script": str(script_path), "checksum": _checksum(code)}


def generate_loader(skill_name: str) -> dict:
    skill_dir = SKILLS_DIR / skill_name
    if not skill_dir.exists():
        return {"error": f"Skill '{skill_name}' not found"}

    scripts_dir = skill_dir / "scripts"
    if not scripts_dir.exists():
        return {"error": "scripts/ directory not found"}

    py_files = [f for f in scripts_dir.glob("*.py") if f.name != "__init__.py"]

    lines = [
        "#!/usr/bin/env python3",
        f'"""{skill_name} — auto-generated loader."""',
        "",
        "import importlib",
        "import sys",
        "from pathlib import Path",
        "",
        "SCRIPTS = {",
    ]

    for py_file in py_files:
        module_name = py_file.stem
        lines.append(f'    "{module_name}": "{py_file.name}",')

    lines.extend(
        [
            "}",
            "",
            "def load(name: str):",
            '    """Load a script module by name."""',
            "    if name not in SCRIPTS:",
            f'        raise ImportError(f"Script ©{{name}}© not found in {skill_name}")',
            "",
            "    scripts_dir = Path(__file__).parent",
            "    if str(scripts_dir) not in sys.path:",
            "        sys.path.insert(0, str(scripts_dir))",
            "",
            "    return importlib.import_module(name)",
            "",
            "def list_scripts():",
            '    """List all available scripts."""',
            "    return list(SCRIPTS.keys())",
            "",
            "try:",
            '    main = load("main")',
            "except ImportError:",
            "    main = None",
            "",
        ]
    )

    loader_code = "\n".join(lines) + "\n"
    loader_path = scripts_dir / "__init__.py"
    loader_path.write_text(loader_code)

    return {
        "status": "ok",
        "loader": str(loader_path),
        "scripts_loaded": [f.stem for f in py_files],
    }


def list_scripts(skill_name: str) -> dict:
    skill_dir = SKILLS_DIR / skill_name
    if not skill_dir.exists():
        return {"error": f"Skill '{skill_name}' not found"}

    scripts_dir = skill_dir / "scripts"
    if not scripts_dir.exists():
        return {"error": "scripts/ directory not found"}

    scripts = []
    for py_file in sorted(scripts_dir.glob("*.py")):
        scripts.append(
            {
                "name": py_file.name,
                "size": py_file.stat().st_size,
                "modified": datetime.fromtimestamp(py_file.stat().st_mtime).isoformat(),
            }
        )

    meta_path = skill_dir / ".metadata.json"
    metadata = {}
    if meta_path.exists():
        metadata = json.loads(meta_path.read_text())

    return {
        "status": "ok",
        "skill": skill_name,
        "scripts": scripts,
        "metadata": metadata.get("scripts", {}),
    }


def main():
    parser = argparse.ArgumentParser(description="Skills v2 Code Generator")
    subparsers = parser.add_subparsers(dest="command")

    cs = subparsers.add_parser("create-skill")
    cs.add_argument("name")
    cs.add_argument("--description", default="Auto-generated skill")

    als = subparsers.add_parser("add-script")
    als.add_argument("skill_name")
    als.add_argument("script_name")
    als.add_argument("--code", default=None, help="Python code or @path/to/file.py")

    gl = subparsers.add_parser("generate-loader")
    gl.add_argument("skill_name")

    ls = subparsers.add_parser("list-scripts")
    ls.add_argument("skill_name")

    args = parser.parse_args()

    if args.command == "create-skill":
        result = create_skill(args.name, args.description)
    elif args.command == "add-script":
        code = args.code
        if code and code.startswith("@"):
            code = Path(code[1:]).read_text()
        result = add_script(args.skill_name, args.script_name, code)
    elif args.command == "generate-loader":
        result = generate_loader(args.skill_name)
    elif args.command == "list-scripts":
        result = list_scripts(args.skill_name)
    else:
        parser.print_help()
        return

    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
