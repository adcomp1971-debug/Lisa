#!/usr/bin/env python3
"""
Tavily MCP Server — search + extract for Hermes Agent.
Uses tavily-python SDK. Runs as stdio MCP server.

2026-09-28: переписан под mcp 2.0 — в SDK 2.0 у низкоуровневого Server больше нет
декораторов list_tools()/call_tool() (и bundled FastMCP удалён), вместо них
mcp.server.MCPServer + @tool(). Имена инструментов (tavily_search / tavily_extract)
и их семантика сохранены.
"""
import os
import sys

# ── cron-runtime guard (2026-09-28) ───────────────────────────────────────
# Hermes запускает python-MCP-серверы managed-интерпретатором
# (~/.hermes/tools/python-*), у которого нет site-packages, поэтому mcp/tavily
# не видны и сервер падает в mcp-stderr.log. Перезапускаемся на первом
# интерпретаторе, где нужные модули импортируются. См. скилл cron-reliability §12.
_NEEDED = ("mcp", "tavily")


def _ensure_runtime():
    import glob
    import subprocess

    def _ok(exe):
        try:
            return subprocess.run(
                [exe, "-c", "import " + ", ".join(_NEEDED)],
                capture_output=True, timeout=30,
            ).returncode == 0
        except Exception:
            return False

    if _ok(sys.executable):
        return
    candidates = ["/usr/local/lib/hermes-agent/venv/bin/python"]
    candidates += sorted(glob.glob("/root/.hermes/installs/*/environments/*/venv/bin/python"))
    for exe in candidates:
        if (os.path.exists(exe)
                and os.path.realpath(exe) != os.path.realpath(sys.executable)
                and _ok(exe)):
            os.execv(exe, [exe, os.path.abspath(__file__)] + sys.argv[1:])
    raise SystemExit("cron-runtime guard: нет интерпретатора с %s" % (", ".join(_NEEDED),))


_ensure_runtime()

from mcp.server import MCPServer  # noqa: E402
from tavily import TavilyClient  # noqa: E402

API_KEY = os.environ.get("TAVILY_API_KEY") or os.environ.get("MCP_TAVILY_API_KEY")
mcp = MCPServer("tavily")


def _client() -> TavilyClient:
    if not API_KEY:
        raise RuntimeError("TAVILY_API_KEY not set")
    return TavilyClient(api_key=API_KEY)


@mcp.tool()
def tavily_search(
    query: str,
    max_results: int = 5,
    search_depth: str = "basic",
    include_answer: bool = True,
    topic: str = "general",
    days: int | None = None,
) -> str:
    """Search the web using Tavily API. Returns results with titles, URLs and snippets.

    Args:
        query: Search query.
        max_results: Max results (1-20).
        search_depth: "basic" or "advanced".
        include_answer: Include AI-generated answer.
        topic: "general" or "news".
        days: For topic="news" — only results from the last N days.
    """
    kwargs = {
        "query": query,
        "max_results": max_results,
        "search_depth": search_depth,
        "include_answer": include_answer,
        "topic": topic,
    }
    if days and topic == "news":
        kwargs["days"] = days

    result = _client().search(**kwargs)

    out = []
    if result.get("answer"):
        out.append("**Answer:** %s\n" % result["answer"])
    out.append("**Results (%d):**\n" % len(result.get("results", [])))
    for r in result.get("results", []):
        out.append("• %s" % r.get("title", "N/A"))
        out.append("  URL: %s" % r.get("url", ""))
        out.append("  %s" % (r.get("content", "") or "")[:300])
        out.append("")
    return "\n".join(out)


@mcp.tool()
def tavily_extract(urls: list[str]) -> str:
    """Extract clean page content from URLs using Tavily API.

    Args:
        urls: URLs to extract.
    """
    result = _client().extract(urls=urls)
    out = []
    for r in result.get("results", []):
        out.append("**%s**" % r.get("url", ""))
        out.append((r.get("raw_content", "") or "")[:5000])
        out.append("")
    return "\n".join(out)


if __name__ == "__main__":
    mcp.run(transport="stdio")
