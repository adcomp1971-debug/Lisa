#!/usr/bin/env bash
set -uo pipefail
THRESHOLD=75
DB=/root/.hermes/state.db
LOG=/root/.hermes/logs/spend-alert.log
ENV_FILE=/root/.hermes/.env
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
TODAY=$(date -u +%Y-%m-%d)
[ -f "$ENV_FILE" ] && source "$ENV_FILE"
ADMIN_ID=420839805
BOT_TOKEN=${TELEGRAM_BOT_TOKEN:-}

SPEND=$(sqlite3 "$DB" "SELECT ROUND(COALESCE(SUM(actual_cost_usd),SUM(estimated_cost_usd),0),2) FROM sessions WHERE started_at >= strftime('%s','now','-7 days');" 2>/dev/null)
SPEND=${SPEND:-0}
echo "$TS spend7d=$SPEND threshold=$THRESHOLD" >> "$LOG"

# анти-спам: не слать если уже алертили сегодня
grep -q "$TODAY ALERTED" "$LOG" 2>/dev/null && exit 0

OVER=$(echo "$SPEND > $THRESHOLD" | bc -l 2>/dev/null)
if [ "$OVER" = "1" ] && [ -n "$BOT_TOKEN" ]; then
  curl -sf --max-time 10 -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" -d "chat_id=$ADMIN_ID&text=💸 Расход за 7д: \$$SPEND (порог \$$THRESHOLD). Скачок — проверь не ушёл ли fallback на Claude/GPT." >/dev/null 2>&1
  echo "$TS ALERTED" >> "$LOG"
fi
