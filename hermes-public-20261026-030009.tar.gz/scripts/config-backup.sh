#!/usr/bin/env bash
set -euo pipefail

BACKUP_DIR="/root/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="${BACKUP_DIR}/config-backup-${TIMESTAMP}.tar.gz"
KEEP_COUNT=7

# Temp workdir
WORKDIR=$(mktemp -d)
trap 'rm -rf "$WORKDIR"' EXIT

echo "[+] Creating backup: ${BACKUP_FILE}"

# --- Collect files ---

# 1. Nginx gatebox config
if [ -f /etc/nginx/sites-available/gatebox ]; then
    mkdir -p "${WORKDIR}/etc/nginx/sites-available"
    cp /etc/nginx/sites-available/gatebox "${WORKDIR}/etc/nginx/sites-available/"
    echo "  [+] /etc/nginx/sites-available/gatebox"
else
    echo "  [!] /etc/nginx/sites-available/gatebox not found, skipping"
fi

# 2. Hermes config
if [ -f /root/.hermes/config.yaml ]; then
    mkdir -p "${WORKDIR}/root/.hermes"
    cp /root/.hermes/config.yaml "${WORKDIR}/root/.hermes/"
    echo "  [+] /root/.hermes/config.yaml"
else
    echo "  [!] /root/.hermes/config.yaml not found, skipping"
fi

# 3. Hermes .env (credentials)
if [ -f /root/.hermes/.env ]; then
    mkdir -p "${WORKDIR}/root/.hermes"
    cp /root/.hermes/.env "${WORKDIR}/root/.hermes/"
    echo "  [+] /root/.hermes/.env"
else
    echo "  [!] /root/.hermes/.env not found, skipping"
fi

# 4. AmneziaWG configs
if [ -d /etc/amnezia/amneziawg ]; then
    CONF_COUNT=$(ls -1 /etc/amnezia/amneziawg/*.conf 2>/dev/null | wc -l)
    if [ "$CONF_COUNT" -gt 0 ]; then
        mkdir -p "${WORKDIR}/etc/amnezia/amneziawg"
        cp /etc/amnezia/amneziawg/*.conf "${WORKDIR}/etc/amnezia/amneziawg/"
        echo "  [+] /etc/amnezia/amneziawg/*.conf (${CONF_COUNT} files)"
    else
        echo "  [!] No .conf files in /etc/amnezia/amneziawg, skipping"
    fi
else
    echo "  [!] /etc/amnezia/amneziawg not found, skipping"
fi

# 5. x-ui DB
if [ -f /etc/x-ui/x-ui.db ]; then
    mkdir -p "${WORKDIR}/etc/x-ui"
    cp /etc/x-ui/x-ui.db "${WORKDIR}/etc/x-ui/"
    echo "  [+] /etc/x-ui/x-ui.db"
else
    echo "  [!] /etc/x-ui/x-ui.db not found, skipping"
fi

# --- Check that we collected something ---
if [ "$(ls -A "$WORKDIR" 2>/dev/null)" = "" ]; then
    echo "[FAIL] No files were collected — nothing to backup!"
    exit 1
fi

# --- Create tar.gz ---
tar -czf "${BACKUP_FILE}" -C "${WORKDIR}" .
echo "[+] Archive created: ${BACKUP_FILE}"

# --- Rotate old backups ---
BACKUP_COUNT=$(ls -1 "${BACKUP_DIR}"/config-backup-*.tar.gz 2>/dev/null | wc -l)
if [ "$BACKUP_COUNT" -gt "$KEEP_COUNT" ]; then
    echo "[+] Rotating old backups (keeping last ${KEEP_COUNT})..."
    ls -1t "${BACKUP_DIR}"/config-backup-*.tar.gz | tail -n +$((KEEP_COUNT + 1)) | while read -r old; do
        rm -f "$old"
        echo "  Removed: ${old}"
    done
fi

echo "[SUCCESS] Backup complete: ${BACKUP_FILE}"
du -h "${BACKUP_FILE}" | awk '{print "  Size: " $1}'
exit 0
