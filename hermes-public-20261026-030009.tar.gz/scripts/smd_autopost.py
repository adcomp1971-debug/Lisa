#!/usr/bin/env python3
"""Auto-poster: collects top posts from subscribed channels and posts to Smd news.

Usage:
    /usr/bin/python3 smd_autopost.py              # Last 24h, all channels
    /usr/bin/python3 smd_autopost.py --hours 12   # Last 12h
    /usr/bin/python3 smd_autopost.py --dry-run    # Preview only, no posting
"""

import asyncio
import sys
import argparse
from datetime import datetime, timezone, timedelta
from telethon import TelegramClient, functions

API_ID = 36633463
API_HASH = "6227801e5ea910daccde171aeec5b7da"
SESSION_FILE = "/root/.hermes/telegram_session"

# Target channel: Smd news (found via contacts.SearchRequest)
SMD_NEWS_ID = 3825583356

# Source channels — Алекс даст список позже, пока те что со скриншота
SOURCE_CHANNELS = {
    "Анатолий Шарий": "@ASupersharij",
    "Фронтовая птичка": "@frontbird",
    "Win-Win": "@victorstepanych",
    "Dambiev": "@ChDambiev",
    "Мир в Моменте": "@MIrvMomente",
}

MIN_POST_LENGTH = 100  # Skip templated/short posts
MAX_POSTS_PER_CHANNEL = 2
MAX_TOTAL_POSTS = 8

EMOJI_MAP = {
    "Украин": "🇺🇦", "Росси": "🇷🇺", "США": "🇺🇸", "Иран": "🇮🇷",
    "Кита": "🇨🇳", "ЕС": "🇪🇺", "НАТО": "🔵", "Белгород": "🏙️",
    "Курск": "⚔️", "Донбасс": "⚔️", "Крым": "🏝️",
    "Орешник": "🚀", "удар": "💥", "дрон": "🛸", "ПВО": "🛡️",
    "переговор": "🤝", "сделк": "📝", "нефт": "🛢️",
}


def add_emoji(text: str) -> str:
    """Add relevant emoji prefix based on content."""
    for keyword, emoji in EMOJI_MAP.items():
        if keyword.lower() in text.lower():
            return f"{emoji} {text}"
    return f"📰 {text}"


async def get_smd_channel(client):
    """Get Smd news channel entity via search."""
    result = await client(functions.contacts.SearchRequest(q="Smd news", limit=5))
    for chat in result.chats:
        if chat.title == "Smd news":
            return chat
    raise ValueError("Smd news channel not found")


async def collect_posts(client, hours: int, channels: dict) -> list[dict]:
    """Collect top posts from all channels."""
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    all_posts = []

    for name, uname in channels.items():
        try:
            entity = await client.get_entity(uname)
            messages = await client.get_messages(entity, limit=40)
            count = 0
            for msg in messages:
                if not msg.text or len(msg.text) < MIN_POST_LENGTH:
                    continue
                if msg.date and msg.date < cutoff:
                    continue
                all_posts.append({
                    "channel": name,
                    "date": msg.date,
                    "text": msg.text[:500],
                    "views": getattr(msg, "views", 0) or 0,
                })
                count += 1
                if count >= MAX_POSTS_PER_CHANNEL:
                    break
        except Exception as e:
            print(f"  ✗ {name}: {e}", file=sys.stderr)

    # Sort by date (newest first), take top N
    all_posts.sort(key=lambda p: p["date"], reverse=True)
    return all_posts[:MAX_TOTAL_POSTS]


def format_post(post: dict) -> str:
    """Format a single post for Telegram."""
    dt = post["date"].strftime("%H:%M") if post["date"] else ""
    text = post["text"]
    # Truncate long posts gracefully
    if len(text) > 400:
        text = text[:397] + "..."
    return add_emoji(f"*{post['channel']}* ({dt})\n{text}")


async def run(hours: int = 24, dry_run: bool = False):
    """Main: collect posts and send to Smd news."""
    client = TelegramClient(SESSION_FILE, API_ID, API_HASH)
    await client.start()

    # Collect
    print(f"Collecting posts from {len(SOURCE_CHANNELS)} channels (last {hours}h)...", file=sys.stderr)
    posts = await collect_posts(client, hours, SOURCE_CHANNELS)

    if not posts:
        print("No posts found.", file=sys.stderr)
        await client.disconnect()
        return

    # Format
    date_str = datetime.now().strftime("%d.%m.%Y")
    header = f"📋 *Дайджест новостей* — {date_str}\n\n"
    body = "\n\n".join(format_post(p) for p in posts)
    message = header + body

    if dry_run:
        print("=== DRY RUN (not posted) ===")
        print(message)
    else:
        smd = await get_smd_channel(client)
        await client.send_message(smd, message, parse_mode="markdown")
        print(f"✓ Posted {len(posts)} posts to Smd news", file=sys.stderr)

    await client.disconnect()


def main():
    parser = argparse.ArgumentParser(description="Smd news auto-poster")
    parser.add_argument("--hours", type=int, default=24, help="Hours back to collect")
    parser.add_argument("--dry-run", action="store_true", help="Preview without posting")
    args = parser.parse_args()
    asyncio.run(run(args.hours, args.dry_run))


if __name__ == "__main__":
    main()
