#!/usr/bin/env python3
"""Vision: DeepSeek Flash (V4.1, нативный vision), fallback Gemini 3.7 Flash.
ВНИМАНИЕ: deepseek-flash — reasoning-модель, токены уходят в reasoning ДО текста.
При max_tokens < 2500 ответ может прийти пустым."""
import base64, json, urllib.request, sys

path = sys.argv[1]
with open(path, 'rb') as f:
    b64 = base64.b64encode(f.read()).decode()

env = {}
with open('/root/.hermes/.env') as f:
    for line in f:
        line = line.strip()
        if '=' in line and not line.startswith('#'):
            k, v = line.split('=', 1)
            env[k] = v.strip().strip('"').strip("'")

prompt = 'Опиши подробно что на этом изображении. Ответ на русском.'
content = [
    {'type': 'text', 'text': prompt},
    {'type': 'image_url', 'image_url': {'url': f'data:image/jpeg;base64,{b64}', 'detail': 'low'}},
]


def _text(d):
    msg = ((d.get('choices') or [{}])[0].get('message') or {})
    return (msg.get('content') or '').strip()


def call_ds():
    key = env.get('DEEPSEEK_API_KEY') or ''
    if not key:
        raise RuntimeError('no DEEPSEEK_API_KEY')
    payload = {
        'model': 'deepseek-flash',
        'messages': [{'role': 'user', 'content': content}],
        'max_tokens': 5000,
    }
    req = urllib.request.Request(
        'https://api.deepseek.com/v1/chat/completions',
        data=json.dumps(payload).encode(),
        headers={'Authorization': f'Bearer {key}', 'Content-Type': 'application/json'},
    )
    with urllib.request.urlopen(req, timeout=90) as resp:
        d = json.loads(resp.read())
    txt = _text(d)
    if not txt:
        raise RuntimeError('empty content (thinking ate tokens)')
    return txt


def call_gemini():
    key = env.get('GEMINI_API_KEY') or env.get('GOOGLE_API_KEY') or ''
    if not key:
        raise RuntimeError('no GEMINI_API_KEY')
    payload = {
        'model': 'gemini-3.6-flash',
        'messages': [{'role': 'user', 'content': content}],
        'max_tokens': 2000,
    }
    req = urllib.request.Request(
        'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
        data=json.dumps(payload).encode(),
        headers={'Authorization': f'Bearer {key}', 'Content-Type': 'application/json'},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        d = json.loads(resp.read())
    return _text(d) or 'ERROR: empty gemini'


try:
    print(call_ds())
except Exception as e:
    try:
        print(call_gemini())
    except Exception as e2:
        print(f'ERROR: ds={e}; gemini={e2}')
        sys.exit(1)
