#!/bin/bash
# neo4j-healthcheck — проверка Neo4j без LLM
# Молчит если всё ок (no_agent: пустой stdout = тихо)
# Если Neo4j не отвечает — рестартит контейнер и пишет алерт

if curl -sI --connect-timeout 5 http://localhost:7474 >/dev/null 2>&1; then
    # Neo4j жив — тихо выходим (пустой stdout = ничего не отправляем)
    exit 0
fi

# Neo4j мёртв — пробуем рестарт
echo "⚠️ Neo4j не отвечает! Рестартую контейнер..."

if docker restart graphiti-neo4j >/dev/null 2>&1; then
    sleep 10
    if curl -sI --connect-timeout 5 http://localhost:7474 >/dev/null 2>&1; then
        echo "✅ Neo4j перезапущен и работает."
    else
        echo "❌ Neo4j перезапущен, но всё ещё не отвечает. Нужен ручной фикс."
    fi
else
    echo "❌ Не удалось перезапустить контейнер graphiti-neo4j."
fi
