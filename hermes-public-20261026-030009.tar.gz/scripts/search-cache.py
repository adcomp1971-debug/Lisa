#!/usr/bin/env python3
"""
Hermes Agent Search Cache System
SQLite-backed cache for search queries to reduce redundant API calls.
Database: ~/.hermes/search_cache.db
"""

import hashlib
import json
import os
import sqlite3
import sys
import textwrap
import time


DB_PATH = os.path.expanduser("~/.hermes/search_cache.db")


# ── Database helpers ──────────────────────────────────────────────────────────

def _get_conn() -> sqlite3.Connection:
    """Get a connection to the SQLite database, creating tables if needed."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    _ensure_table(conn)
    return conn


def _ensure_table(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS cache (
            query_hash    TEXT PRIMARY KEY,
            query         TEXT NOT NULL,
            result_json   TEXT NOT NULL,
            created_at    REAL NOT NULL,
            ttl_seconds   INTEGER NOT NULL DEFAULT 300
        )
        """
    )


def _hash(query: str) -> str:
    return hashlib.md5(query.encode()).hexdigest()


# ── Public API ────────────────────────────────────────────────────────────────

def cache_get(query: str, ttl: int = 300):
    """
    Return cached result dict if a fresh entry exists, otherwise None.

    A cached entry is considered fresh if its age (now - created_at)
    is less than *its own* ttl_seconds (which may differ from the *ttl*
    passed here — the stored TTL is the one that was set when the entry
    was written).
    """
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT query, result_json, created_at, ttl_seconds FROM cache WHERE query_hash = ?",
            (_hash(query),),
        ).fetchone()

        if row is None:
            return None

        age = time.time() - row["created_at"]
        stored_ttl = row["ttl_seconds"]

        if age >= stored_ttl:
            # Expired — remove it
            conn.execute("DELETE FROM cache WHERE query_hash = ?", (_hash(query),))
            conn.commit()
            return None

        # Convert the stored TTL to the requested TTL for freshness check
        # (we use the *requested* ttl as an additional filter if caller wants
        #  a stricter window than the stored one)
        if age >= ttl:
            return None

        return {
            "query": row["query"],
            "result": json.loads(row["result_json"]),
            "created_at": row["created_at"],
            "ttl_seconds": row["ttl_seconds"],
        }
    finally:
        conn.close()


def cache_set(query: str, result_json: str, ttl: int = 300) -> None:
    """Store a search result in the cache (insert or replace)."""
    conn = _get_conn()
    try:
        conn.execute(
            """
            INSERT OR REPLACE INTO cache (query_hash, query, result_json, created_at, ttl_seconds)
            VALUES (?, ?, ?, ?, ?)
            """,
            (_hash(query), query, result_json, time.time(), ttl),
        )
        conn.commit()
    finally:
        conn.close()


def cache_purge() -> int:
    """Delete expired cache entries. Returns number of deleted rows."""
    conn = _get_conn()
    try:
        now = time.time()
        cursor = conn.execute("DELETE FROM cache WHERE (created_at + ttl_seconds) <= ?", (now,))
        conn.commit()
        return cursor.rowcount
    finally:
        conn.close()


def cache_clear() -> None:
    """Delete all cached entries."""
    conn = _get_conn()
    try:
        conn.execute("DELETE FROM cache")
        conn.commit()
    finally:
        conn.close()


def cache_stats() -> dict:
    """Return aggregate cache statistics."""
    conn = _get_conn()
    try:
        row = conn.execute(
            """
            SELECT
                COUNT(*)                                       AS total,
                COALESCE(MIN(created_at), 0)                   AS oldest,
                COALESCE(MAX(created_at), 0)                   AS newest,
                COALESCE(SUM(LENGTH(result_json) + LENGTH(query) + 32), 0) AS size_bytes
            FROM cache
            """
        ).fetchone()

        now = time.time()
        # Count how many entries are still fresh (by their own TTL)
        fresh = conn.execute(
            "SELECT COUNT(*) FROM cache WHERE (created_at + ttl_seconds) > ?",
            (now,),
        ).fetchone()[0]
        expired = row["total"] - fresh

        return {
            "total": row["total"],
            "fresh": fresh,
            "expired": expired,
            "oldest": row["oldest"],
            "newest": row["newest"],
            "size_bytes": row["size_bytes"],
            "hits": 0,   # in-memory counters not persisted; CLI interface owns these
            "misses": 0,
        }
    finally:
        conn.close()


# ── CLI helpers ───────────────────────────────────────────────────────────────

def _format_stats(stats: dict) -> str:
    """Pretty-print cache statistics."""
    lines = []
    lines.append("╒══════════════════════════════════════════╕")
    lines.append("│       Search Cache Statistics            │")
    lines.append("╞══════════════════════════════════════════╡")

    total = stats["total"]
    fresh = stats["fresh"]
    expired = stats["expired"]

    lines.append(f"  Total entries      : {total}")
    if total > 0:
        lines.append(f"  Fresh entries      : {fresh}  ({fresh/total*100:.1f}%)")
        lines.append(f"  Expired entries    : {expired}  ({expired/total*100:.1f}%)")
    else:
        lines.append(f"  Fresh entries      : 0")
        lines.append(f"  Expired entries    : 0")

    size = stats["size_bytes"]
    if size > 1024 * 1024:
        size_str = f"{size / (1024*1024):.2f} MiB"
    elif size > 1024:
        size_str = f"{size / 1024:.2f} KiB"
    else:
        size_str = f"{size} bytes"

    lines.append(f"  Database size      : {size_str}")

    if stats["oldest"] > 0:
        oldest_dt = time.strftime(
            "%Y-%m-%d %H:%M:%S UTC", time.gmtime(stats["oldest"])
        )
        lines.append(f"  Oldest entry       : {oldest_dt}")
    else:
        lines.append(f"  Oldest entry       : N/A")

    if stats["newest"] > 0:
        newest_dt = time.strftime(
            "%Y-%m-%d %H:%M:%S UTC", time.gmtime(stats["newest"])
        )
        lines.append(f"  Newest entry       : {newest_dt}")
    else:
        lines.append(f"  Newest entry       : N/A")

    lines.append("╘══════════════════════════════════════════╛")
    return "\n".join(lines)


def _print_usage() -> None:
    print(
        textwrap.dedent(
            """\
            Usage:
              python search-cache.py get "query" [ttl]       Get cached result (JSON or empty)
              python search-cache.py set "query" "json" [ttl] Store result
              python search-cache.py stats                    Show cache statistics
              python search-cache.py clear                    Clear all cache entries

            Arguments:
              query   - The search query string
              json    - JSON string of the result to cache
              ttl     - Time-to-live in seconds (default: 300)

            Examples:
              python search-cache.py get "python requests" 600
              python search-cache.py set "hello world" '{"result": "data"}' 300
              python search-cache.py stats
              python search-cache.py clear
            """
        )
    )


# ── Entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    if len(sys.argv) < 2:
        # Default for cron: purge expired entries
        deleted = cache_purge()
        print(f"Purged {deleted} expired entr{'y' if deleted == 1 else 'ies'}.")
        sys.exit(0)

    command = sys.argv[1].lower()

    if command == "get":
        if len(sys.argv) < 3:
            print("Error: 'get' requires a query argument.")
            sys.exit(1)
        query = sys.argv[2]
        ttl = int(sys.argv[3]) if len(sys.argv) > 3 else 300
        result = cache_get(query, ttl=ttl)
        if result is None:
            print("")
        else:
            print(json.dumps(result["result"], ensure_ascii=False))

    elif command == "set":
        if len(sys.argv) < 4:
            print("Error: 'set' requires query and result_json arguments.")
            sys.exit(1)
        query = sys.argv[2]
        result_json = sys.argv[3]
        ttl = int(sys.argv[4]) if len(sys.argv) > 4 else 300
        cache_set(query, result_json, ttl=ttl)
        print(f"Cached: {query[:60]}{'…' if len(query) > 60 else ''}")

    elif command == "stats":
        stats = cache_stats()
        print(_format_stats(stats))

    elif command == "clear":
        cache_clear()
        print("Cache cleared.")

    elif command == "purge":
        deleted = cache_purge()
        print(f"Purged {deleted} expired entr{'y' if deleted == 1 else 'ies'}.")

    else:
        print(f"Unknown command: {command}")
        _print_usage()
        sys.exit(1)


if __name__ == "__main__":
    main()
