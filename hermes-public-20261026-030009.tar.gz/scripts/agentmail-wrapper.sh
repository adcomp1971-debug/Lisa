#!/bin/bash
# Wrapper for agentmail-mcp — loads AGENTMAIL_API_KEY from .env
set -a
source /root/.hermes/.env
set +a
exec npx -y agentmail-mcp "$@"
