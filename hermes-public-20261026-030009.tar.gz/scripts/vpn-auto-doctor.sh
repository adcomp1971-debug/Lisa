#!/usr/bin/env bash
# VPN Auto-Doctor — диагностический скрипт
# Вызывается cron'ом каждые 30 мин. Вывод читается агентом для принятия решений.
set -euo pipefail

echo "=== VPN AUTO-DOCTOR REPORT ==="
echo "TIME: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
echo ""

# --- 1. СЕРВИСЫ ---
echo "--- SERVICES ---"
for svc in awg-quick@awg0 x-ui tailscaled nginx; do
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
        echo "SVC_OK: $svc"
    else
        echo "SVC_DOWN: $svc"
    fi
done
echo ""

# --- 2. ДИСК ---
echo "--- DISK ---"
for mp in / /var /tmp; do
    df -h "$mp" 2>/dev/null | tail -1 | awk -v mp="$mp" '{print "DISK: "mp" size="$2" used="$3" avail="$4" use="$5}'
done
echo ""

# --- 3. ПАМЯТЬ ---
echo "--- MEMORY ---"
free -h | awk 'NR==2{print "MEM: total="$2" used="$3" free="$4" avail="$7}'
echo ""

# --- 4. LOAD ---
echo "--- LOAD ---"
uptime | awk -F'load average:' '{print "CPU_LOAD:" $2}'
echo ""

# --- 5. VPN ПОРТЫ (AWG + XRay) ---
echo "--- VPN PORTS ---"
# AWG порт (стандартный 51820, смотрим из конфига)
AWG_PORT=$(awk '/^ListenPort/ {print $3}' /etc/amnezia/amneziawg/awg0.conf 2>/dev/null || echo "unknown")
echo "AWG_PORT: $AWG_PORT"
ss -tuln | grep -q ":$AWG_PORT " && echo "AWG_LISTEN: yes" || echo "AWG_LISTEN: no"

# XRay порт (ищем в конфигах 3x-ui)
XR_PORT=$(grep -r '"port"' /usr/local/x-ui/bin/config.json 2>/dev/null | head -1 | grep -oP '\d{4,5}' || echo "unknown")
echo "XRAY_PORT: $XR_PORT"
ss -tuln | grep -q ":$XR_PORT " && echo "XRAY_LISTEN: yes" || echo "XRAY_LISTEN: no"
echo ""

# --- 6. AWG КЛИЕНТЫ (количество) ---
echo "--- AWG CLIENTS ---"
CLIENTS=$(awg show 2>/dev/null | grep -c 'peer:' || echo "0")
echo "AWG_PEERS: $CLIENTS"
echo ""

# --- 7. АПТАЙМ ---
echo "--- UPTIME ---"
uptime -p

echo "=== END REPORT ==="
