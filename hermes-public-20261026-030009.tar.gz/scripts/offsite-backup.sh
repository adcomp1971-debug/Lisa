#!/usr/bin/env bash
# Hermes Offsite Backup — ИСПРАВЛЕНО 2026-09-20 (код-аудит Grok).
#
# Что было не так и что исправлено:
#  1. `set -uo pipefail` без -e + `tar ... 2>/dev/null` → падение tar скрывалось,
#     создавался пустой/битый архив, старые копии уже удалялись. → `set -euo pipefail`,
#     ошибки tar видны, архив проверяется на размер и целостность.
#  2. Пароль root и .env архивировались в /tmp без шифрования → при краше файл оставался.
#     → ВРЕМЕННЫЙ ФАЙЛ ТОЛЬКО В ЗАЩИЩЁННОМ КАТАЛОГЕ с umask 077, удаляется всегда (trap).
#  3. `echo "github OK"` стоял ВНЕ проверки push → лог врал об успехе при провале.
#     → честный лог по факту результата.
#  4. `git push --force` затирал историю. → обычный push (без --force).
#  5. Нет блокировки → два запуска (cron + ручной) перетирали файлы. → flock.
#  6. KEEP=4 при недельном cron = 4 недели. → KEEP=12 (3 месяца).
#  7. Не проверялось, не попали ли секреты в публичный архив. → grep-проверка перед push.
set -euo pipefail

BACKUP_DIR=/root/backups/offsite
HERMES_HOME=/root/.hermes
TS=$(date -u +%Y%m%d-%H%M%S)
LOG="$HERMES_HOME/logs/offsite-backup.log"
PASSFILE=/root/.backup-passphrase
KEEP=12
TMPDIR_LOCAL="$BACKUP_DIR/tmp"

log() { echo "[$(date -u '+%F %T')] $*" >> "$LOG"; }

# --- блокировка от наложений ---
mkdir -p "$BACKUP_DIR" "$TMPDIR_LOCAL"
chmod 700 "$TMPDIR_LOCAL"
exec 9>"$BACKUP_DIR/.lock"
if ! flock -n 9; then
  log "уже выполняется — выход"
  exit 0
fi

umask 077
log "=== Offsite Backup Start ==="

PUBLIC_ARCHIVE="$BACKUP_DIR/hermes-public-$TS.tar.gz"
SECRETS_ARCHIVE="$BACKUP_DIR/hermes-secrets-$TS.tar.gz.gpg"
TMP_SEC="$TMPDIR_LOCAL/secrets-$TS.tar.gz"

# страховка: временный файл с секретами удаляется в любом случае
cleanup() {
  [ -f "$TMP_SEC" ] && shred -u "$TMP_SEC" 2>/dev/null || rm -f "$TMP_SEC" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# ---------- 1. ПУБЛИЧНЫЙ АРХИВ (без секретов) ----------
log "создаю публичный архив..."
tar czf "$PUBLIC_ARCHIVE" \
  --exclude='skills/.archive' \
  --exclude='*__pycache__*' \
  --exclude='*.pyc' \
  --exclude='*.log' \
  --exclude='.env' \
  -C /etc/nginx sites-available \
  -C "$HERMES_HOME" config.yaml cron/jobs.json memories/ scripts/ skills/

# проверка: архив не пустой и валидный gzip
if [ ! -s "$PUBLIC_ARCHIVE" ] || ! gzip -t "$PUBLIC_ARCHIVE" 2>/dev/null; then
  log "❌ публичный архив битый — ПРЕРЫВАЮ (старые копии не тронуты)"
  rm -f "$PUBLIC_ARCHIVE"
  exit 1
fi
log "  public: $(stat -c %s "$PUBLIC_ARCHIVE") байт"

# ---------- 1a. ПРОВЕРКА: не просочились ли секреты ----------
# -a: обрабатывать всё как текст; фильтруем плейсхолдеры (xxx, EXAMPLE, your-, <...>) и бинарный мусор
SECRET_HITS=$(tar xzOf "$PUBLIC_ARCHIVE" 2>/dev/null \
  | grep -aoE '(sk-[a-zA-Z0-9]{20,}|am_us_[a-f0-9]{20,}|fish_[a-f0-9]{20,}|AIza[a-zA-Z0-9_-]{20,}|BEGIN [A-Z ]{0,20}PRIVATE KEY)' \
  | grep -avE 'x{6,}|X{6,}|0{6,}|EXAMPLE|example|your|YOUR|placeholder|dummy|<|>|\`|^\||\|$' | wc -l || true)
if [ "${SECRET_HITS:-0}" -gt 0 ]; then
  log "🚨 В ПУБЛИЧНОМ АРХИВЕ НАЙДЕНЫ СЕКРЕТЫ ($SECRET_HITS совпадений) — ПРЕРЫВАЮ, пуш отменён!"
  rm -f "$PUBLIC_ARCHIVE"
  exit 1
fi
log "  ✅ проверка на секреты пройдена"
tar tzf "$PUBLIC_ARCHIVE" > "$BACKUP_DIR/manifest-public-$TS.txt" 2>/dev/null || true

# ---------- 2. ЗАШИФРОВАННЫЙ АРХИВ (секреты) ----------
if [ ! -f "$PASSFILE" ]; then
  log "⚠️ нет $PASSFILE — секреты НЕ бэкапятся!"
else
  log "создаю зашифрованный архив..."
  tar czf "$TMP_SEC" \
    -C "$HERMES_HOME" .env memory_store.db \
    -C /etc/amnezia amneziawg \
    -C /opt/vpnbot/data vpnbot.db

  if [ ! -s "$TMP_SEC" ]; then
    log "❌ временный архив секретов пустой — пропускаю"
  else
    gpg --batch --yes --quiet --symmetric --cipher-algo AES256 \
        --passphrase-file "$PASSFILE" -o "$SECRETS_ARCHIVE" "$TMP_SEC" 2>>"$LOG"
    # проверка: gpg-архив валиден и содержит данные
    # проверка: файл непустой и начинается с gpg-заголовка (list-packets требует пароль для симметричных)
if [ -s "$SECRETS_ARCHIVE" ] && head -c 2 "$SECRETS_ARCHIVE" | grep -q $'\x8c'; then
      log "  secrets: $(stat -c %s "$SECRETS_ARCHIVE") байт (зашифрован, проверен)"
    else
      log "❌ gpg-архив невалиден"
      rm -f "$SECRETS_ARCHIVE"
    fi
  fi
fi
cleanup

# ---------- 3. PUSH В GITHUB (до чистки!) ----------
PUSH_OK=0
cd "$BACKUP_DIR"
if [ ! -d .git ]; then
  git init -q
  git remote add origin "git@github.com:adcomp1971-debug/Lisa.git"
  git checkout -q -b main
fi
git add hermes-public-*.tar.gz manifest-public-*.txt 2>/dev/null || true
[ -f "$SECRETS_ARCHIVE" ] && git add hermes-secrets-*.tar.gz.gpg 2>/dev/null || true
# -u: зафиксировать УДАЛЕНИЯ (чистка старых manifest). Без этого маска не раскрывается
# на несуществующие файлы, удаления не коммитятся и рабочее дерево остаётся грязным.
git add -u . 2>/dev/null || true

if git diff --cached --quiet 2>/dev/null; then
  log "нечего коммитить"
  PUSH_OK=1
else
  git commit -q -m "offsite $TS" 2>>"$LOG" || true
  if git push -q origin main 2>>"$LOG"; then
    log "✅ GitHub push OK"
    PUSH_OK=1
  else
    log "❌ GitHub push FAILED (копия осталась локально в $BACKUP_DIR)"
  fi
fi

# ---------- 4. ЧИСТКА СТАРЫХ (только если push успешен) ----------
if [ "$PUSH_OK" -eq 1 ]; then
  # ВАЖНО: `|| true` обязателен. Без него, если файлов под маску нет, ls вернёт 2,
  # pipefail + set -e уронят скрипт ПОСЛЕ успешного push (cron покажет "Script exited with code 2").
  ls -t "$BACKUP_DIR"/hermes-public-*.tar.gz 2>/dev/null | tail -n +$((KEEP+1)) | xargs -r rm -f || true
  ls -t "$BACKUP_DIR"/hermes-secrets-*.tar.gz.gpg 2>/dev/null | tail -n +$((KEEP+1)) | xargs -r rm -f || true
  ls -t "$BACKUP_DIR"/manifest-*.txt 2>/dev/null | tail -n +$((KEEP*2+1)) | xargs -r rm -f || true
  ls -t "$BACKUP_DIR"/hermes-config-*.tar.gz 2>/dev/null | tail -n +2 | xargs -r rm -f || true
  log "старые копии вычищены (храню $KEEP)"
else
  log "⚠️ push не прошёл — старые копии НЕ удаляю (сохраняю как есть)"
fi

log "=== Backup Complete (push_ok=$PUSH_OK) ==="
echo "offsite: public=$(du -h "$PUBLIC_ARCHIVE" 2>/dev/null | cut -f1) secrets=$(du -h "$SECRETS_ARCHIVE" 2>/dev/null | cut -f1) push=$([ $PUSH_OK -eq 1 ] && echo OK || echo FAILED)"
