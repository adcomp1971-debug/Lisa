#!/usr/bin/env python3
"""
Context Compression Middleware — standalone tool for Hermes Agent.
Auto-offloads large tool results to disk to keep context window clean.

Usage:
    # Analyse a tool result (stdout → compressed placeholder or original)
    context_offload.py check --tool-name scrape --input-file /path/to/result.txt

    # Estimate context window usage across a message list
    context_offload.py estimate --messages-file /tmp/messages.json

    # Compress old write tool calls in a messages file (80% threshold)
    context_offload.py compress-files --messages-file /tmp/messages.json --threshold 0.8

    # Summarise full session, save to disk, return short pointer
    context_offload.py summarise --messages-file /tmp/messages.json --model deepseek-v4-flush

    # Watch a directory of tool outputs, auto-offload > threshold
    context_offload.py watch --dir /tmp/hermes-tool-output/ --threshold 15000

Exit codes:
    0 — result fits, no action taken
    1 — result offloaded (output is the [OFFLOAD: ...] replacement)
    80 — near threshold (80% of context window)
    99 — overflow (session summarised)
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import textwrap
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

# ------------------------------------------------------------------------- #
# Tunable constants                                                         #
# ------------------------------------------------------------------------- #
MAX_RESULT_LENGTH = 15_000          # chars (~4000 tokens) before offloading
CONTEXT_WINDOW = 128_000            # default context window (tokens) — override
PROTECT_LAST = 20                   # never touch the last N messages
FILE_TOOL_NAMES = frozenset({
    "write_file", "edit_file", "append_file", "remove_file",
    "browser_navigate", "browser_click", "browser_type",
})
PREVIEW_LINES = 10                 # how many first lines to keep in placeholder

OFFLOAD_DIR = Path("/tmp/hermes-context")

LLM_SUMMARISE_PROMPT = """You are a context compression assistant.
Given the conversation below, produce a concise summary that preserves:
  - all file paths created / modified
  - all key decisions made
  - all open tasks and their current status
  - any error messages and their resolution

Output format: Markdown, max 200 lines.
"""

SUMMARY_DIR = OFFLOAD_DIR


# ------------------------------------------------------------------------- #
# Helpers                                                                   #
# ------------------------------------------------------------------------- #
def ensure_dirs() -> None:
    OFFLOAD_DIR.mkdir(parents=True, exist_ok=True)
    SUMMARY_DIR.mkdir(parents=True, exist_ok=True)


def estimate_tokens(text: str) -> int:
    """Rough heuristic: ~4 chars per token for mixed content."""
    return len(text) // 4


def short_preview(text: str, max_lines: int = PREVIEW_LINES) -> str:
    lines = text.split("\n", max_lines)
    out = "\n".join(lines[:max_lines])
    return out


# ------------------------------------------------------------------------- #
# Operation  1 — check / offload a single tool result                       #
# ------------------------------------------------------------------------- #
def check_tool_result(tool_name: str, content: str) -> tuple[str, int]:
    """
    Returns (output, exit_code).
    If the result fits → returns (content, 0).
    If the result is too big → saves to disk, returns (placeholder, 1).
    """
    ensure_dirs()
    length = len(content)
    if length <= MAX_RESULT_LENGTH:
        return content, 0

    uid = uuid.uuid4().hex[:12]
    out_path = OFFLOAD_DIR / f"{uid}.json"
    payload = {
        "schema": "hermes-tool-result-v1",
        "tool": tool_name,
        "original_length": length,
        "timestamp": int(time.time()),
        "preview": short_preview(content, PREVIEW_LINES),
        "data": content,
    }
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2))

    tokens_est = estimate_tokens(content)
    placeholder = (
        f"[OFFLOAD: {out_path}  "
        f"tool={tool_name}  "
        f"{length}chars/~{tokens_est}tok  "
        f"preview={short_preview(content, PREVIEW_LINES)}]"
    )
    return placeholder, 1


# ------------------------------------------------------------------------- #
# Operation  2 — estimate context window usage                              #
# ------------------------------------------------------------------------- #
@dataclass
class ContextStats:
    total_chars: int
    total_tokens_est: int
    window_tokens: int
    ratio: float
    exit_code: int
    messages_total: int
    messages_protected: int


def estimate_context(messages: list[dict],
                     window_tokens: int = CONTEXT_WINDOW,
                     protect_last: int = PROTECT_LAST) -> ContextStats:
    text = json.dumps(messages, ensure_ascii=False)
    total_chars = len(text)
    total_tokens = estimate_tokens(text)
    ratio = total_tokens / window_tokens
    ratio = min(ratio, 1.0)

    if ratio >= 0.95:
        exit_code = 99
    elif ratio >= 0.80:
        exit_code = 80
    else:
        exit_code = 0

    return ContextStats(
        total_chars=total_chars,
        total_tokens_est=total_tokens,
        window_tokens=window_tokens,
        ratio=round(ratio, 3),
        exit_code=exit_code,
        messages_total=len(messages),
        messages_protected=protect_last,
    )


# ------------------------------------------------------------------------- #
# Operation  3 — compress old file tool calls (≥80% window)                 #
# ------------------------------------------------------------------------- #
def compress_file_calls(messages: list[dict],
                        threshold: float = 0.80,
                        window_tokens: int = CONTEXT_WINDOW,
                        protect_last: int = PROTECT_LAST) -> tuple[list[dict], bool]:
    """
    Walks messages in reverse, skipping the last `protect_last`.
    If a message is a tool call to a file-related tool and we are already over `threshold`,
    replaces its content with a file pointer.
    Returns (modified_messages, did_compress).
    """
    stats = estimate_context(messages, window_tokens, protect_last)
    if stats.ratio < threshold:
        return messages, False

    cutoff = len(messages) - protect_last
    modified = list(messages)
    did_compress = False

    for i, msg in enumerate(modified):
        if i >= cutoff:
            break
        if msg.get("role") != "tool":
            continue
        tool_name = msg.get("name", "")
        if tool_name not in FILE_TOOL_NAMES:
            continue
        content = msg.get("content", "")
        if len(content) < 500:
            continue

        uid = uuid.uuid4().hex[:12]
        out_path = OFFLOAD_DIR / f"file-call-{uid}.json"
        payload = {
            "schema": "hermes-file-tool-v1",
            "tool": tool_name,
            "timestamp": int(time.time()),
            "data": content,
        }
        out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2))

        replacement = (
            f"[FILE-CALL-OFFLOAD: {out_path}  tool={tool_name}  "
            f"{len(content)}chars]"
        )
        msg["content"] = replacement
        did_compress = True

    return modified, did_compress


# ------------------------------------------------------------------------- #
# Operation  4 — full session summarisation (overflow fallback)             #
# ------------------------------------------------------------------------- #
def summarise_session(messages: list[dict]) -> tuple[str, Path]:
    """
    Dumps full messages to disk, returns placeholder pointing to the dump.
    LLM summarisation is left to the caller (Hermes agent) because we don't
    want this middleware to hold an LLM dependency.
    """
    ensure_dirs()
    ts = int(time.time())

    json_path = OFFLOAD_DIR / f"session-dump-{ts}.json"
    md_path = SUMMARY_DIR / f"session-log-{ts}.md"

    json_path.write_text(json.dumps(messages, ensure_ascii=False, indent=2))

    # Create a skeletal markdown log so a human or LLM can skim it quickly.
    lines = ["# Session Log", f"Timestamp: {ts}", f"Messages: {len(messages)}", ""]
    for m in messages:
        role = m.get("role", "?")
        name = m.get("name", "")
        content = m.get("content", "")
        snippet = short_preview(content, 3).replace("\n", " ⏎ ")
        lines.append(f"- **{role}/{name}**: {snippet}")
    md_path.write_text("\n".join(lines))

    placeholder = (
        f"[SESSION-OVERFLOW: summary={md_path}  json_dump={json_path}  "
        f"messages={len(messages)}]"
    )
    return placeholder, md_path


# ------------------------------------------------------------------------- #
# CLI interface                                                             #
# ------------------------------------------------------------------------- #
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="context_offload",
        description="Context Compression Middleware for Hermes Agent",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    # ---- check ----
    c1 = sub.add_parser("check", help="Check a single tool result; offload if too big")
    c1.add_argument("--tool-name", required=True)
    c1.add_argument("--input-file", help="Path to file with tool result (default: stdin)")
    c1.add_argument("--max-length", type=int, default=MAX_RESULT_LENGTH)

    # ---- estimate ----
    c2 = sub.add_parser("estimate", help="Estimate context-window usage")
    c2.add_argument("--messages-file", required=True)
    c2.add_argument("--window-tokens", type=int, default=CONTEXT_WINDOW)

    # ---- compress-files ----
    c3 = sub.add_parser("compress-files",
                        help="Replace old file tool calls with pointers when ≥ threshold")
    c3.add_argument("--messages-file", required=True)
    c3.add_argument("--threshold", type=float, default=0.80)
    c3.add_argument("--window-tokens", type=int, default=CONTEXT_WINDOW)
    c3.add_argument("--outfile", help="Where to write modified messages (default: stdout)")

    # ---- summarise ----
    c4 = sub.add_parser("summarise", help="Dump full session to disk, return pointer")
    c4.add_argument("--messages-file", required=True)

    # ---- watch ----
    c5 = sub.add_parser("watch", help="Watch a directory; auto-offload large results")
    c5.add_argument("--dir", required=True)
    c5.add_argument("--threshold", type=int, default=MAX_RESULT_LENGTH)
    c5.add_argument("--interval", type=float, default=2.0)

    return p


def read_input(path: str | None) -> str:
    if path and path != "-":
        return Path(path).read_text(encoding="utf-8")
    return sys.stdin.read()


def load_messages(path: str) -> list[dict]:
    raw = Path(path).read_text(encoding="utf-8")
    return json.loads(raw)


def dump_messages(messages: list[dict], path: str | None) -> None:
    s = json.dumps(messages, ensure_ascii=False, indent=2)
    if path:
        Path(path).write_text(s, encoding="utf-8")
    else:
        sys.stdout.write(s + "\n")


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.cmd == "check":
        global MAX_RESULT_LENGTH
        MAX_RESULT_LENGTH = args.max_length
        content = read_input(args.input_file)
        output, code = check_tool_result(args.tool_name, content)
        sys.stdout.write(output)
        return code

    if args.cmd == "estimate":
        msgs = load_messages(args.messages_file)
        stats = estimate_context(msgs, args.window_tokens)
        sys.stdout.write(
            f"total_chars={stats.total_chars}  "
            f"tokens_est={stats.total_tokens_est}  "
            f"window={stats.window_tokens}  "
            f"ratio={stats.ratio}  "
            f"exit_code={stats.exit_code}\n"
        )
        return stats.exit_code

    if args.cmd == "compress-files":
        msgs = load_messages(args.messages_file)
        new_msgs, changed = compress_file_calls(
            msgs, args.threshold, args.window_tokens
        )
        dump_messages(new_msgs, args.outfile)
        return 0 if not changed else 80

    if args.cmd == "summarise":
        msgs = load_messages(args.messages_file)
        placeholder, path = summarise_session(msgs)
        sys.stdout.write(placeholder + "\n")
        return 99

    if args.cmd == "watch":
        watch_dir = Path(args.dir)
        watch_dir.mkdir(parents=True, exist_ok=True)
        sys.stdout.write(f"Watching {watch_dir} for files > {args.threshold} chars\n")
        sys.stdout.flush()
        processed: set[str] = set()
        try:
            while True:
                for fp in watch_dir.glob("*.json"):
                    key = f"{fp}:{fp.stat().st_mtime}"
                    if key in processed:
                        continue
                    processed.add(key)
                    try:
                        data = json.loads(fp.read_text())
                        content = data.get("content", data.get("result", ""))
                        if len(content) > args.threshold:
                            out, code = check_tool_result(
                                data.get("tool", "unknown"), content
                            )
                            if code == 1:
                                sys.stdout.write(f"Offloaded: {fp.name}\n")
                                sys.stdout.flush()
                    except Exception:
                        pass
                time.sleep(args.interval)
        except KeyboardInterrupt:
            return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
