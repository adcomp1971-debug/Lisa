#!/usr/bin/env python3
"""Healthcheck для codex-relay сервисов. Пишет в stdout если проблема — silent если всё ок."""
import http.client
import json
import time

relays = [
    ("DeepSeek V4 Pro", 4446),
    ("LongCat-2.0", 4447),
    ("GLM 5.2", 4448),
]

errors = []
for name, port in relays:
    for attempt in range(2):
        try:
            conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
            conn.request("GET", "/v1/models")
            resp = conn.getresponse()
            data = json.loads(resp.read())
            models = data.get("data", [])
            if not models:
                errors.append(f"{name} (:{port}) — 0 models returned")
            conn.close()
            break  # success — skip retry
        except Exception as e:
            if attempt == 1:  # last attempt failed
                errors.append(f"{name} (:{port}) — {e}")
            else:
                time.sleep(1)  # brief pause before retry

if errors:
    print("❌ Codex relay healthcheck FAILED:\n" + "\n".join(errors))
