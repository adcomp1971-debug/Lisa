"""
Library of Congress API Client
==============================
Production-ready клиент для интеграции с API Library of Congress.
Не требует API-ключа. Поддерживает retry, пагинацию, кэширование.

Автор: Code Review для Гермеса
Дата: 2026-08-22
"""

import requests
import time
import json
from typing import Optional, Dict, Any, List, Iterator
from dataclasses import dataclass
from urllib.parse import urlencode


@dataclass
class LOCSearchResult:
    """Результат поиска из Library of Congress."""
    title: str
    url: str
    item_id: Optional[str]
    description: Optional[str]
    created_published_date: Optional[str]
    subjects: List[str]
    image_url: Optional[str]
    raw_data: Dict[str, Any]

    @classmethod
    def from_api_item(cls, item: Dict[str, Any]) -> "LOCSearchResult":
        """Создает объект результата из сырого ответа API."""
        return cls(
            title=item.get("title", "Без названия"),
            url=item.get("url", ""),
            item_id=item.get("id", None),
            description=item.get("description", [None])[0] if isinstance(item.get("description"), list) else item.get("description"),
            created_published_date=item.get("date", None),
            subjects=item.get("subject", []),
            image_url=item.get("image_url", [None])[0] if isinstance(item.get("image_url"), list) else item.get("image_url"),
            raw_data=item
        )


class LibraryOfCongressClient:
    """
    Клиент для работы с API Library of Congress.

    Базовый URL: https://www.loc.gov/search/
    Формат: JSON (через параметр fo=json)
    Лимиты: ~200 запросов/минуту (неофициально)
    Ключ API: НЕ ТРЕБУЕТСЯ
    """

    BASE_URL = "https://www.loc.gov/search/"
    COLLECTIONS_URL = "https://www.loc.gov/collections/"
    PICTURES_URL = "https://www.loc.gov/pictures/search/"

    # Официальные фильтры API
    AVAILABLE_FILTERS = {
        "format": "online-format",      # book, image, manuscript, map, etc.
        "language": "language",         # russian, english, french, etc.
        "location": "location",         # country, city
        "dates": "dates",               # YYYY или YYYY/YYYY
        "partof": "partof",             # принадлежность к коллекции
        "contributor": "contributor",   # автор, издатель
        "subject": "subject",           # тема
    }

    def __init__(
        self,
        timeout: int = 30,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        rate_limit_delay: float = 0.3,
        user_agent: str = "LOC-Python-Client/1.0 (Research Project)"
    ):
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.rate_limit_delay = rate_limit_delay
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": user_agent,
            "Accept": "application/json"
        })

    def _make_request(self, url: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Выполняет HTTP-запрос с retry-логикой и обработкой ошибок.

        Returns:
            dict: Распарсенный JSON-ответ

        Raises:
            requests.HTTPError: при HTTP-ошибках (4xx, 5xx)
            requests.ConnectionError: при проблемах соединения
        """
        last_exception = None

        for attempt in range(1, self.max_retries + 1):
            try:
                # Rate limiting — вежливое поведение
                if attempt > 1:
                    time.sleep(self.retry_delay * (attempt - 1))
                else:
                    time.sleep(self.rate_limit_delay)

                response = self.session.get(
                    url,
                    params=params,
                    timeout=self.timeout
                )

                # Обработка 429 Too Many Requests
                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", 5))
                    time.sleep(retry_after)
                    continue

                response.raise_for_status()
                return response.json()

            except requests.exceptions.Timeout as e:
                last_exception = e
                continue
            except requests.exceptions.ConnectionError as e:
                last_exception = e
                continue
            except requests.exceptions.HTTPError as e:
                if response.status_code in (500, 502, 503, 504):
                    last_exception = e
                    continue
                raise

        raise last_exception or requests.RequestException(
            f"Failed after {self.max_retries} attempts"
        )

    def search(
        self,
        query: str,
        page: int = 1,
        per_page: int = 25,
        filters: Optional[Dict[str, str]] = None,
        sort: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Поиск по каталогу Library of Congress.

        Args:
            query: Поисковый запрос (поддерживает boolean: AND, OR, NOT)
            page: Номер страницы (начиная с 1)
            per_page: Количество результатов на страницу (max 100)
            filters: Словарь фильтров. Ключи: format, language, location, dates, etc.
            sort: Сортировка. Варианты: "relevance", "date", "title"

        Returns:
            dict: Полный JSON-ответ от API

        Example:
            >>> client = LibraryOfCongressClient()
            >>> results = client.search("Tolstoy", filters={"language": "russian", "format": "book"})
        """
        params = {
            "q": query,
            "fo": "json",
            "sp": page,
            "c": min(per_page, 100)  # API ограничивает 100
        }

        # Применяем фильтры
        if filters:
            for key, value in filters.items():
                if key in self.AVAILABLE_FILTERS:
                    api_key = self.AVAILABLE_FILTERS[key]
                    params["fa"] = f"{api_key}:{value}"
                else:
                    params[key] = value

        if sort:
            params["sb"] = sort

        return self._make_request(self.BASE_URL, params)

    def search_iter(
        self,
        query: str,
        max_results: int = 1000,
        per_page: int = 25,
        filters: Optional[Dict[str, str]] = None
    ) -> Iterator[LOCSearchResult]:
        """
        Итератор по всем результатам поиска с автоматической пагинацией.

        Args:
            query: Поисковый запрос
            max_results: Максимальное количество результатов для выборки
            per_page: Результатов на страницу
            filters: Фильтры поиска

        Yields:
            LOCSearchResult: Объект результата поиска
        """
        page = 1
        fetched = 0

        while fetched < max_results:
            data = self.search(query, page=page, per_page=per_page, filters=filters)
            results = data.get("results", [])

            if not results:
                break

            for item in results:
                if fetched >= max_results:
                    return
                yield LOCSearchResult.from_api_item(item)
                fetched += 1

            page += 1

    def get_item(self, item_url: str) -> Dict[str, Any]:
        """
        Получает детальную информацию о конкретном элементе по его URL.

        Args:
            item_url: Прямой URL элемента из каталога

        Returns:
            dict: Детальные метаданные элемента
        """
        params = {"fo": "json"}
        return self._make_request(item_url, params)

    def search_collections(self, query: str = "", page: int = 1) -> Dict[str, Any]:
        """
        Поиск по коллекциям Library of Congress.

        Args:
            query: Поисковый запрос по коллекциям
            page: Номер страницы
        """
        params = {
            "fo": "json",
            "sp": page
        }
        if query:
            params["q"] = query

        return self._make_request(self.COLLECTIONS_URL, params)

    def search_pictures(self, query: str, page: int = 1) -> Dict[str, Any]:
        """
        Поиск по изображениям (Prints & Photographs).

        Args:
            query: Поисковый запрос
            page: Номер страницы
        """
        params = {
            "q": query,
            "fo": "json",
            "sp": page
        }
        return self._make_request(self.PICTURES_URL, params)

    def get_russian_collection(self, page: int = 1, per_page: int = 25) -> Dict[str, Any]:
        """
        Быстрый доступ к материалам на русском языке.
        """
        return self.search(
            query="*",
            page=page,
            per_page=per_page,
            filters={"language": "russian"}
        )


# ═══════════════════════════════════════════════════════════════
# ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ
# ═══════════════════════════════════════════════════════════════

def demo_basic_search():
    """Демо: базовый поиск."""
    client = LibraryOfCongressClient()

    print("═" * 60)
    print("ДЕМО 1: Поиск 'Leo Tolstoy' (книги на русском)")
    print("═" * 60)

    results = client.search(
        query="Leo Tolstoy",
        filters={
            "language": "russian",
            "format": "book"
        },
        per_page=5
    )

    print(f"Всего найдено: {results.get('search', {}).get('hits', 'N/A')}")
    print()

    for item in results.get("results", [])[:3]:
        result = LOCSearchResult.from_api_item(item)
        print(f"📖 {result.title}")
        print(f"   URL: {result.url}")
        print(f"   Дата: {result.created_published_date or 'не указана'}")
        print(f"   Темы: {', '.join(result.subjects[:3]) if result.subjects else 'нет'}")
        print()


def demo_iterator():
    """Демо: итератор с автопагинацией."""
    client = LibraryOfCongressClient()

    print("═" * 60)
    print("ДЕМО 2: Итератор по результатам (первые 10)")
    print("═" * 60)

    for i, result in enumerate(client.search_iter("Dostoevsky", max_results=10)):
        print(f"{i+1}. {result.title}")


def demo_collections():
    """Демо: работа с коллекциями."""
    client = LibraryOfCongressClient()

    print("═" * 60)
    print("ДЕМО 3: Коллекции, связанные с Россией")
    print("═" * 60)

    collections = client.search_collections(query="Russia")
    for coll in collections.get("results", [])[:5]:
        print(f"📚 {coll.get('title', 'Без названия')}")
        print(f"   Описание: {coll.get('description', 'Нет описания')[:100]}...")
        print()


def demo_advanced_filters():
    """Демо: продвинутые фильтры и диапазоны дат."""
    client = LibraryOfCongressClient()

    print("═" * 60)
    print("ДЕМО 4: Книги по русской истории (1800–1900)")
    print("═" * 60)

    # Примечание: фильтр дат в API LoC работает через fa=dates:1800/1900
    results = client.search(
        query="Russia history",
        filters={
            "language": "russian",
            "format": "book",
            "dates": "1800/1900"
        },
        per_page=5
    )

    for item in results.get("results", [])[:3]:
        result = LOCSearchResult.from_api_item(item)
        print(f"• {result.title} ({result.created_published_date or 'дата неизвестна'})")


if __name__ == "__main__":
    demo_basic_search()
    print("\n")
    demo_iterator()
    print("\n")
    demo_collections()
    print("\n")
    demo_advanced_filters()
