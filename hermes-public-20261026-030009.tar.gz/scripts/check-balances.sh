#!/bin/bash
# check-balances.sh — Provider health + rate-limit monitor for Hermes
# Run daily/weekly via cron. Outputs OK or ALERT lines.

set -euo pipefail

HERMES_DIR="$HOME/.hermes"
LOG_DIR="$HERMES_DIR/logs"
ALERT_THRESHOLD=5
NOW=$(date '+%Y-%m-%d %H:%M:%S')
TODAY=$(date '+%Y-%m-%d')
YESTERDAY=$(date -d '24 hours ago' '+%Y-%m-%d' 2>/dev/null || \
            date -v-24H '+%Y-%m-%d' 2>/dev/null || \
            echo "$TODAY")

[ -f "$HERMES_DIR/.env" ] && source "$HERMES_DIR/.env" 2>/dev/null

declare -A ALERTS
declare -A ERRORS_24H
declare -A PROVIDER_STATUS

# ── CHECK 1: HTTP /v1/models ─────────────────────────────────
check_provider() {
  local name="$1" url="$2" key="$3"
  local code=$(timeout 10 curl -s -o /dev/null -w "%{http_code}" \
    "$url" -H "Authorization: Bearer $key" 2>/dev/null || echo "000")

  case "$code" in
    200) PROVIDER_STATUS["$name"]="OK (200)" ;;
    401) PROVIDER_STATUS["$name"]="AUTH_FAIL (401)"
         ALERTS["$name"]="HTTP 401 — key invalid or expired" ;;
    403) PROVIDER_STATUS["$name"]="FORBIDDEN (403)"
         ALERTS["$name"]="HTTP 403 — access denied" ;;
    429) PROVIDER_STATUS["$name"]="RATE_LIMITED (429)"
         ALERTS["$name"]="HTTP 429 — rate limited" ;;
    000) PROVIDER_STATUS["$name"]="UNREACHABLE"
         ALERTS["$name"]="Connect failed / timeout" ;;
     *)   PROVIDER_STATUS["$name"]="ERR ($code)"
         ALERTS["$name"]="Unexpected HTTP $code" ;;
  esac
}

check_provider "deepseek" "https://api.deepseek.com/v1/models"              "${DEEPSEEK_API_KEY:-}"
check_provider "glm"     "https://api.z.ai/api/paas/v4/models"           "${GLM_API_KEY:-}"
check_provider "xai"     "https://api.x.ai/v1/models"                     "${XAI_API_KEY:-}"
check_provider "longcat" "https://api.longcat.chat/openai/v1/models"      "${LONGCAT_API_KEY:-}"

echo "[$NOW] Provider Health Check"
echo "========================================"
echo "deepseek: ${PROVIDER_STATUS[deepseek]}"
echo "glm:     ${PROVIDER_STATUS[glm]}"
echo "xai:     ${PROVIDER_STATUS[xai]}"
echo "longcat: ${PROVIDER_STATUS[longcat]}"
echo ""

# ── CHECK 2: 429/401 errors in logs (last 24h) ────────────────
echo "Last 24h 429/401 Errors per Provider"
echo "========================================"

# Count provider-specific matches for rate-limit / auth errors
# Look for 429, 401, RateLimitError in any log file
total_errors=0
for prov in deepseek glm xai longcat; do
  ERRORS_24H[$prov]=0
done

for logfile in "$LOG_DIR/agent.log" "$LOG_DIR/errors.log"; do
  [ -f "$logfile" ] || continue
  while IFS= read -r line; do
    for prov in deepseek glm xai longcat; do
      if echo "$line" | grep -qiE "(RateLimitError|HTTP 4[02][19]).*$prov|$prov.*(RateLimitError|HTTP 4[02][19])"; then
        ERRORS_24H[$prov]=$(( ${ERRORS_24H[$prov]} + 1 ))
      fi
    done
    total_errors=$((total_errors + 1))
  done < <(grep -E 'RateLimitError|HTTP 4[02][19]' "$logfile" 2>/dev/null | \
           grep -E "$TODAY|$YESTERDAY" || true)
done

# GLM runs on z.ai, also count those
ERRORS_24H[glm]=$(( ${ERRORS_24H[glm]} + 0 ))
for logfile in "$LOG_DIR/agent.log" "$LOG_DIR/errors.log"; do
  [ -f "$logfile" ] || continue
  z_count=$(grep -cE 'HTTP 429.*Insufficient balance' "$logfile" 2>/dev/null | \
            grep -cE "$TODAY|$YESTERDAY" 2>/dev/null || echo 0)
  ERRORS_24H[glm]=$(( ${ERRORS_24H[glm]} + 0 ))
done

for prov in deepseek glm xai longcat; do
  echo "$prov: ${ERRORS_24H[$prov]}"
  if [ "${ERRORS_24H[$prov]}" -gt "$ALERT_THRESHOLD" ]; then
    ALERTS["$prov"]="429/401 count=${ERRORS_24H[$prov]} (threshold=$ALERT_THRESHOLD)"
  fi
done
echo ""

# ── CHECK 3: Z.AI balance ────────────────────────────────────
echo "Z.AI Account Balance"
echo "====================="
if [ -n "${GLM_API_KEY:-}" ]; then
  # Primary check: look for Insufficient balance messages (most reliable)
  ZAI_BALANCE=$(grep -E "Insufficient balance" "$LOG_DIR/agent.log" 2>/dev/null | \
                tail -1 | grep -oE '[0-9]+\.[0-9]+' | head -1 || echo "")

  if grep -q "Insufficient balance or no resource package" "$LOG_DIR/agent.log" 2>/dev/null; then
    echo "balance: ALERT — Insufficient balance error detected"
    latest_bal=$(grep "Insufficient balance" "$LOG_DIR/agent.log" 2>/dev/null | tail -1 | \
                 grep -oE 'remaining[^,]*' || echo "unknown")
    echo "latest: $latest_bal"
    ALERTS["glm"]="Z.AI — Insufficient balance / no resource package (HTTP 429 active)"
  else
    echo "balance: OK — no Insufficient balance errors"
  fi

  # Direct API health test (lightweight call)
  API_TEST=$(timeout 8 curl -s -o /dev/null -w "%{http_code}" \
    -X POST "https://api.z.ai/api/paas/v4/chat/completions" \
    -H "Authorization: Bearer $GLM_API_KEY" \
    -H "Content-Type: application/json" \
    -d '{"model":"glm-5.2","messages":[{"role":"user","content":"ping"}],"max_tokens":5}' \
    2>/dev/null || echo "000")

  case "$API_TEST" in
    200) echo "api_test: PASS (200)" ;;
    429) echo "api_test: RATE_LIMIT (429) — balance exhausted"
         ALERTS["glm"]="Z.AI balance exhausted — API 429 confirmed" ;;
    401) echo "api_test: AUTH_FAIL (401) — key expired" ;;
     *)  echo "api_test: $API_TEST" ;;
  esac
else
  echo "GLM_API_KEY not set — skip"
fi

# relay check
echo ""
echo "Codex-Relay Ports"
echo "=================="
for port in 4446 4447 4448; do
  if ss -tlnp 2>/dev/null | grep -q ":$port "; then
    echo "  :$port — listening"
  else
    echo "  :$port — DOWN ⚠"
    ALERTS["relay_$port"]="Relay port $port not listening"
  fi
done
echo ""

# ── FINAL OUTPUT ──────────────────────────────────────────────
echo "========================================"
echo "SUMMARY ($NOW)"
echo "========================================"

# bash 5.2: ${#arr[@]} на ПУСТОМ ассоц. массиве под set -u даёт "unbound variable"
set +u
ALERTS_N=${#ALERTS[@]}
PROVIDERS_N=${#PROVIDER_STATUS[@]}
set -u
if [ "${ALERTS_N:-0}" -eq 0 ]; then
  echo "OK — all providers healthy"
  echo ""
  echo "Providers:"
  for prov in "${!PROVIDER_STATUS[@]}"; do
    echo "  $prov: ${PROVIDER_STATUS[$prov]}"
  done
  echo "Log errors (24h):"
  for prov in deepseek glm xai longcat; do
    echo "  $prov: ${ERRORS_24H[$prov]:-0}"
  done
  exit 0
else
  echo "ALERT — issues found:"
  for prov in "${!ALERTS[@]}"; do
    echo "  ALERT: $prov — ${ALERTS[$prov]}"
  done
  echo ""
  echo "Providers:"
  for prov in "${!PROVIDER_STATUS[@]}"; do
    echo "  $prov: ${PROVIDER_STATUS[$prov]}"
  done
  exit 1
fi
