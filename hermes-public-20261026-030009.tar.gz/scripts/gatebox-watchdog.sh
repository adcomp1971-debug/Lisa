#!/bin/bash
# GateBox watchdog — checks if index.html was modified
CURRENT_HASH=$(sha256sum /var/www/gatebox/index.html | cut -d' ' -f1)
STORED_HASH_FILE="/var/backups/gatebox/last-hash.txt"

if [ -f "$STORED_HASH_FILE" ]; then
    STORED_HASH=$(cat "$STORED_HASH_FILE")
    if [ "$CURRENT_HASH" != "$STORED_HASH" ]; then
        echo "⚠️ GateBox index.html CHANGED. Hash was: $STORED_HASH, now: $CURRENT_HASH"
        echo "$CURRENT_HASH" > "$STORED_HASH_FILE"
    fi
else
    echo "$CURRENT_HASH" > "$STORED_HASH_FILE"
    echo "GateBox watchdog initialized. Hash: $CURRENT_HASH"
fi
