#!/usr/bin/env python3
"""Сторож работоспособности VPN: playit-релей, AWG-сервисы, публичный IP, молчащие пиры.

Запуск: no_agent cron. При проблеме печатает алерт в stdout и ВСЕГДА выходит с кодом 0
(Hermes доставляет непустой stdout; ненулевой код = «script failed» и ложные cron-инциденты).
Дедуп: state-файл, повторный алерт по той же причине не чаще REPEAT_ALERT_H.
"""
import json
import shlex
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

STATE = Path("/root/.hermes/state/vpn-health-watch.json")
SILENT_AFTER_H = 24        # пир молчит дольше — считаем «отвалился» (был handshake, но давно)
REPEAT_ALERT_H = 0         # 0 = повторов без изменений нет вообще (жалоба Алекса на спам)
RELAY_LOG = Path("/var/log/playit/playit.log")
PUBLIC_IP_FILES = ("/root/vpn-dual-out/Alex.conf",)

# Входной узел для РФ-клиентов (Melbicom, awg2 + Xray Reality)
NODE_HOST = "195.238.126.76"
NODE_KEY = "/root/.ssh/relay-ams"
NODE_NAMES = {"10.11.0.2": "Юля", "10.11.0.3": "Ирина", "10.11.0.4": "Людвиг"}


def sh(cmd, timeout=15):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip()
    except Exception as e:      # noqa: BLE001
        return f"__err__{e}"


def load_state():
    try:
        return json.loads(STATE.read_text())
    except Exception:           # noqa: BLE001
        return {}


def save_state(s):
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(s, ensure_ascii=False, indent=1))


def awg_peers(iface):
    """[(allowed_ip, endpoint, handshake_sec_ago)]  — в dump handshake это Unix-timestamp!"""
    out = sh(f"awg show {iface} dump")
    peers = []
    if not out or out.startswith("__err__"):
        return peers
    for line in out.splitlines()[1:]:
        p = line.split("\t")
        if len(p) > 6:
            try:
                ts = int(p[4])
            except ValueError:
                ts = 0
            # в `awg show dump` это Unix-timestamp, а не «секунд назад»
            hs_ago = (int(time.time()) - ts) if ts > 0 else 0
            peers.append((p[3], p[2], hs_ago))
    return peers


def node_sh(cmd, timeout=25):
    """Команда на входном узле awg2 через ssh (BatchMode: только по ключу)."""
    full = ("ssh -i " + shlex.quote(NODE_KEY) + " -o BatchMode=yes -o StrictHostKeyChecking=no"
            " -o ConnectTimeout=10 root@" + NODE_HOST + " " + shlex.quote(cmd))
    return sh(full, timeout=timeout)


# Канонизация имён: один человек может быть на нескольких входах (awg0 и узел awg2)
CANON = {
    "irina": "Ирина", "ирина": "Ирина",
    "ludvig": "Людвиг", "людвиг": "Людвиг",
    "valera": "Валера", "валера": "Валера",
    "yulya": "Юля", "юля": "Юля", "yulka": "Юля",
    "yulia": "Юля", "yulia-2": "Юля (2)",
    "anya": "Аня", "katerina": "Катерина", "katya": "Катя",
    "lena-papina": "Лена П.", "mama": "Мама", "natusik": "Натусик",
    "ruslan": "Руслан", "sasha-102": "Саша 102", "sasha-110": "Саша 110",
    "alex": "Алекс", "alex-10": "Алекс 10",
}


def canon(name):
    return CANON.get(str(name).strip().lower(), str(name).strip())


def fmt_ago(sec):
    if sec <= 0:
        return "ни разу"
    d = sec / 86400
    if d >= 1:
        return f"{d:.1f} д"
    return f"{sec / 3600:.1f} ч"


def names_map():
    """allowed-ip -> имя профиля (по файлам выданных конфигов)"""
    m = {}
    for d in ("/root/vpn-dual-out", "/root/vpn-relay-out"):
        if not Path(d).exists():
            continue
        for f in Path(d).glob("*.conf"):
            for line in f.read_text(errors="ignore").splitlines():
                if line.strip().startswith("Address"):
                    for tok in line.split("=", 1)[1].split(","):
                        tok = tok.strip().split("/")[0]
                        if tok.startswith("10.9.0."):
                            m.setdefault(tok, f.stem)
    for ip, nm in NODE_NAMES.items():
        m.setdefault(ip, nm)
    return m


def main():
    state = load_state()
    now = datetime.now(timezone.utc)
    problems = []

    # 1. AWG-интерфейсы
    for iface in ("awg0", "awg1"):
        st = sh(f"systemctl is-active awg-quick@{iface}")
        if st != "active":
            problems.append(f"🔴 AWG {iface}: сервис {st or 'не отвечает'} — туннель лежит")

    # 2. playit-релей
    pl = sh("systemctl is-active playit")
    if pl != "active":
        problems.append(f"🔴 playit: сервис {pl or 'не отвечает'} — релейные клиенты (Юлька и др.) без входа")
    else:
        # ошибки аутентификации/регистрации за последний час
        if RELAY_LOG.exists():
            cutoff = now - timedelta(hours=1)
            errs = 0
            for line in RELAY_LOG.read_text(errors="ignore").splitlines()[-400:]:
                if "ERROR" not in line and "WARN" not in line:
                    continue
                try:
                    ts = datetime.strptime(line[:26], "%Y-%m-%dT%H:%M:%S.%f").replace(tzinfo=timezone.utc)
                except ValueError:
                    continue
                if ts >= cutoff:
                    errs += 1
            if errs >= 5:
                problems.append(f"🟡 playit: {errs} ошибок/варнов в логе за час (залипание регистрации → перезапустить playit)")

    # 3. публичный IP (смена = мгновенно ломает всех, кто на IP-конфигах)
    ip4 = sh("curl -s --max-time 8 https://api.ipify.org")
    ip6 = sh("curl -s --max-time 8 -6 https://api64.ipify.org")
    prev_ip = state.get("ip4")
    if ip4 and not ip4.startswith("__err__"):
        if prev_ip and prev_ip != ip4:
            problems.append(f"🔴 Публичный IPv4 изменился: {prev_ip} → {ip4}. Проверь ufw/NAT/DNS и обнови конфиги клиентов.")
        state["ip4"] = ip4
    if ip6 and not ip6.startswith("__err__"):
        state["ip6"] = ip6

    # 3b. Входной узел awg2 (Melbicom): сервисы + Xray Reality + пиры.
    #     Узел несёт клиентов, которым режут основной вход, поэтому падение узла = авария.
    node_down = False
    for svc in ("awg-quick@awg2", "xray"):
        st = node_sh(f"systemctl is-active {svc}")
        if st != "active":
            node_down = True
            problems.append(f"🔴 Узел awg2: сервис {svc} — {st or 'нет ответа'}")
    listen = node_sh("ss -lun 2>/dev/null | grep -c ':51820'; ss -tln 2>/dev/null | grep -c ':443'")
    if listen and not listen.startswith("__err__"):
        parts = [x.strip() for x in listen.splitlines() if x.strip()]
        if len(parts) >= 2 and (parts[0] == "0" or parts[1] == "0"):
            problems.append(f"🔴 Узел awg2: порт не слушается (51820/udp={parts[0]}, 443/tcp={parts[1]})")
    elif listen.startswith("__err__") or not listen:
        node_down = True
        problems.append("🔴 Узел awg2: ssh недоступен — вход для РФ-клиентов не проверен")

    # 4. молчащие пиры. Считаем по человеку: если он жив хотя бы на одном входе — не «отвалился».
    #    (hs == 0 = handshake не зафиксирован вовсе — конфиг выдан, но человек не подключался;
    #     если он не подключался НИГДЕ, это не «отвалился» и не алертится.)
    nm = names_map()
    person = {}   # имя -> {канал: секунд_назад}
    for iface in ("awg0", "awg1"):
        for addr, ep, hs in awg_peers(iface):
            ip = addr.split("/")[0]
            if not ip.startswith(("10.9.0.", "10.8.0.")):
                continue
            if ep in ("(none)", "", "(hidden)"):
                continue                      # ни разу не подключался — не «отвалился»
            if hs == 0:
                continue                      # handshake не зафиксирован — нет данных, не алертим
            person.setdefault(canon(nm.get(ip, ip)), {})[iface] = hs
    if not node_down:
        ndump = node_sh("awg show awg2 dump")
        if ndump and not ndump.startswith("__err__"):
            for line in ndump.splitlines()[1:]:
                p = line.split("\t")
                if len(p) > 6:
                    ip = p[3].split("/")[0]
                    if ip not in NODE_NAMES:
                        continue
                    try:
                        ts = int(p[4])
                    except ValueError:
                        ts = 0
                    if ts <= 0:
                        continue
                    person.setdefault(canon(NODE_NAMES[ip]), {})["awg2"] = int(time.time()) - ts

    silent = []
    for name, chans in sorted(person.items()):
        if any(h <= SILENT_AFTER_H * 3600 for h in chans.values()):
            continue                      # жив хотя бы на одном входе
        detail = ", ".join(f"{c} {fmt_ago(h)}" for c, h in sorted(chans.items()))
        silent.append(f"{name} — {detail}")

    # Дедуп по ИМЕНАМ, без метрик времени. Строка «Ирина — awg0 12.3 д» меняется каждый час
    # (счётчик растёт), поэтому сравнение строк целиком превращало дедуп в ежечасный спам.
    prev_silent = state.get("silent") or []
    had_state = "silent" in state
    prev_names = {s.split(" — ")[0] for s in prev_silent}
    cur_names = {s.split(" — ")[0] for s in silent}
    added = sorted(cur_names - prev_names)
    back = sorted(prev_names - cur_names)
    state["silent"] = silent

    by_name = {s.split(" — ")[0]: s for s in silent}
    if added:
        problems.append(f"🟡 Отвалились (нет связи > {SILENT_AFTER_H} ч): "
                        + ", ".join(by_name[n] for n in added))
        state["silent_alert_ts"] = now.isoformat()
    if back and had_state:
        problems.append("✅ Вернулись в строй: " + ", ".join(back))
        state["silent_alert_ts"] = now.isoformat()

    last_alert = state.get("silent_alert_ts")
    due = False
    if REPEAT_ALERT_H > 0:
        if last_alert:
            try:
                due = (now - datetime.fromisoformat(last_alert)) > timedelta(hours=REPEAT_ALERT_H)
            except ValueError:
                due = True
        else:
            due = True
    if due and silent and not added and not back:
        # страховка: включается только если REPEAT_ALERT_H > 0
        problems.append(f"🟡 Всё ещё молчат ({len(silent)}): " + ", ".join(silent))
        state["silent_alert_ts"] = now.isoformat()
    if not silent:
        state.pop("silent_alert_ts", None)

    state["ts"] = now.isoformat()
    save_state(state)

    if problems:
        print("VPN health " + now.strftime("%d.%m %H:%M UTC"))
        for p in problems:
            print(p)
    # Всегда 0: алерт — это доставленное сообщение, а не сбой скрипта.
    return 0


if __name__ == "__main__":
    sys.exit(main())
