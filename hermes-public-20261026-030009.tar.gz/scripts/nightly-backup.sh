#!/usr/bin/env bash
# Nightly Hermes backup — конфиги, skills, cron, память, .env
set -e

BACKUP_DIR="/root/.hermes/backups"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_PATH="${BACKUP_DIR}/hermes-${TIMESTAMP}"
RETENTION_DAYS=30

mkdir -p "$BACKUP_PATH"

echo "=== Hermes Nightly Backup: ${TIMESTAMP} ==="

# 1. Config
cp /root/.hermes/config.yaml "$BACKUP_PATH/config.yaml" 2>/dev/null && echo "  config.yaml ✓" || echo "  config.yaml ✗"

# 2. .env (backup, маскировка ключей для безопасности)
if [ -f /root/.hermes/.env ]; then
    cp /root/.hermes/.env "$BACKUP_PATH/.env"
    echo "  .env ✓"
fi

# 3. Memory DB
cp /root/.hermes/memory.db "$BACKUP_PATH/" 2>/dev/null && echo "  memory.db ✓" || echo "  memory.db ✗"

# 4. State DB (БЕЗОПАСНО: sqlite backup API через venv python — тот же sqlite, что у Hermes; cp живого файла ЗАПРЕЩЁН)
if /usr/local/lib/hermes-agent/venv/bin/python3 - "$BACKUP_PATH/state.db" <<'PY' 2>/dev/null
import sqlite3, sys
src = sqlite3.connect("/root/.hermes/state.db")
dst = sqlite3.connect(sys.argv[1])
src.backup(dst)
dst.close(); src.close()
PY
then
    echo "  state.db ✓"
else
    echo "  state.db ✗"
fi

# 5. Skills list
ls -la /root/.hermes/skills/ > "$BACKUP_PATH/skills-list.txt" 2>/dev/null && echo "  skills-list ✓" || echo "  skills-list ✗"

# 6. Cron jobs (через hermes CLI — внешний sqlite3 на живую БД ЗАПРЕЩЁН)
hermes cron list > "$BACKUP_PATH/cron-jobs.txt" 2>/dev/null && echo "  cron-jobs ✓" || echo "  cron-jobs ✗"

# 7. Profiles
if [ -d /root/.hermes/profiles ]; then
    cp -r /root/.hermes/profiles "$BACKUP_PATH/profiles" 2>/dev/null && echo "  profiles ✓"
fi

# 8. Skills content (только свои, не системные)
mkdir -p "$BACKUP_PATH/skills"
if [ -d /root/.hermes/skills ]; then
    tar czf "$BACKUP_PATH/skills/skills.tar.gz" -C /root/.hermes skills/ 2>/dev/null && echo "  skills.tar.gz ✓"
fi

# 9. Config backup (nginx, AWG)
cp /etc/amnezia/amneziawg/awg0.conf "$BACKUP_PATH/" 2>/dev/null && echo "  awg0.conf ✓"
cp /etc/nginx/sites-available/gatebox "$BACKUP_PATH/" 2>/dev/null && echo "  gatebox (nginx) ✓"

echo "=== Backup size ==="
du -sh "$BACKUP_PATH"

# Rotate old backups
find "$BACKUP_DIR" -maxdepth 1 -type d -name "hermes-*" -mtime +${RETENTION_DAYS} -exec rm -rf {} \; 2>/dev/null && \
    echo "Pruned backups older than ${RETENTION_DAYS} days" || true

echo "=== Done ==="
