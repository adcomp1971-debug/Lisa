#!/usr/bin/env bash
# Hermes Agent auto-update — безопасное обновление с перезапуском gateway
set -euo pipefail

echo "[UPDATE] $(date -u '+%Y-%m-%d %H:%M:%S UTC') — Starting update..."

# 1. Стоп gateway
echo "[UPDATE] Stopping gateway..."
systemctl stop hermes-gateway 2>/dev/null || true
sleep 2

# 2. Обновление
echo "[UPDATE] Running hermes update..."
hermes update --yes 2>&1

# 3. Проверка
echo "[UPDATE] Checking version..."
hermes --version 2>&1

# 4. Старт gateway
echo "[UPDATE] Starting gateway..."
systemctl start hermes-gateway
sleep 3

# 5. Проверка статуса
STATUS=$(systemctl is-active hermes-gateway 2>/dev/null || echo "unknown")
echo "[UPDATE] Gateway status: $STATUS"
echo "[UPDATE] Done at $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
