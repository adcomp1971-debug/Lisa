#!/usr/bin/env bash
# Василий — Почтовый страж (с дедупликацией)
# Проверяет ТОЛЬКО новые письма (после последней проверки).
set -uo pipefail

LOG=/root/.hermes/logs/vasily-mail.log
MARKER=/root/.hermes/logs/vasily-mail-marker
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
ALERT=""

# Последний обработанный ID
LAST_ID=$(cat "$MARKER" 2>/dev/null || echo "0")

# Получаем последние 20 писем с ID
MAIL_TABLE=$(himalaya envelope list --folder INBOX --page-size 20 2>/dev/null)

# Вытаскиваем только ID и subject/from (пропускаем заголовки таблицы)
NEW_MAIL=""
MAX_ID="$LAST_ID"

while IFS= read -r line; do
    # Пропускаем заголовки и разделители
    [[ "$line" =~ ^\|[-\ ]+\| ]] && continue
    [[ "$line" =~ ^\|.*ID.*\| ]] && continue
    
    # Парсим ID из таблицы: | 49357 | ...
    id=$(echo "$line" | awk -F'|' '{gsub(/ /,"",$2); print $2}')
    [[ ! "$id" =~ ^[0-9]+$ ]] && continue
    
    # Только новые (ID > последнего обработанного)
    if [ "$id" -gt "$LAST_ID" ] 2>/dev/null; then
        NEW_MAIL="$NEW_MAIL
$line"
        if [ "$id" -gt "$MAX_ID" ] 2>/dev/null; then
            MAX_ID="$id"
        fi
    fi
done <<< "$MAIL_TABLE"

# Нет новых писем — тихо
if [ -z "$NEW_MAIL" ]; then
    echo "$TS ok (last_id=$LAST_ID)" >> "$LOG"
    exit 0
fi

# --- Проверяем только НОВЫЕ письма ---

# Госорганы
GOV_KEYWORDS="btl.gov.il|bituah|קנס|דוח|חוב|תשלום|הוצאה לפועל|עיריי|police.gov.il|court.gov.il|government"
GOV_HITS=$(echo "$NEW_MAIL" | grep -iE "$GOV_KEYWORDS" || true)
if [ -n "$GOV_HITS" ]; then
    ALERT="$ALERT🏛 ГОС. ПИСЬМО!\n$GOV_HITS\n\n"
fi

# Посылки
PARCEL_KEYWORDS="AliExpress|tracking|доставк|посылк|отправлен|прибыл|пункт выдачи|aliexpress.com|parcel"
PARCEL_HITS=$(echo "$NEW_MAIL" | grep -iE "$PARCEL_KEYWORDS" || true)
if [ -n "$PARCEL_HITS" ]; then
    ALERT="$ALERT📦 ПОСЫЛКА!\n$PARCEL_HITS\n\n"
fi

# Ответы работодателей
EMPLOYER_HITS=$(echo "$NEW_MAIL" | grep -iE "@habr.com|@hh.ru" | grep -v "Вы откликнулись" || true)
if [ -n "$EMPLOYER_HITS" ]; then
    ALERT="$ALERT💼 ОТВЕТ РАБОТОДАТЕЛЯ!\n$EMPLOYER_HITS\n\n"
fi

# --- Отчёт ---
if [ -n "$ALERT" ]; then
    echo -e "$ALERT"
    echo "$TS ALERT (ids ${LAST_ID}→${MAX_ID})" >> "$LOG"
else
    echo "$TS new_but_quiet (ids ${LAST_ID}→${MAX_ID})" >> "$LOG"
fi

# Обновляем маркер
echo "$MAX_ID" > "$MARKER"
