#!/bin/bash
set -e

echo "========== HERMES CONFIG.YAML =========="
wc -l /root/.hermes/config.yaml
cat /root/.hermes/config.yaml

echo "========== BURATINO CONFIG.YAML =========="
wc -l /root/.hermes/profiles/buratino/config.yaml
cat /root/.hermes/profiles/buratino/config.yaml

echo "========== AGENTS.MD =========="
cat /root/.hermes/AGENTS.md

echo "========== SOUL.MD =========="
cat /root/.hermes/SOUL.md

echo "========== NGINX SITES =========="
for f in /etc/nginx/sites-enabled/*; do
  echo "--- $f ---"
  cat "$f"
done

echo "========== ENV (KEYS ONLY, NO SECRETS) =========="
grep -vE 'API_KEY|TOKEN|SECRET|PASSWORD' /root/.hermes/.env 2>/dev/null | grep -v '^\s*$' | head -20

echo "========== HERMES GATEWAY SYSTEMD =========="
cat /etc/systemd/system/hermes-gateway.service
echo "---"
cat /etc/systemd/system/hermes-gateway-buratino.service 2>/dev/null || echo "not found"

echo "========== X-UI SYSTEMD =========="
cat /etc/systemd/system/x-ui.service

echo "========== AWG CONFIG =========="
grep -v 'PrivateKey' /etc/amnezia/amneziawg/awg0.conf

echo "========== GATEWAY GUARD =========="
cat /root/.hermes/scripts/gateway-guard.py 2>/dev/null | head -30
echo "..."

echo "========== CRON LIST =========="
hermes cron list 2>&1

echo "========== HERMES VERSION =========="
hermes --version 2>&1 | head -3

echo "========== MATRIX: ALL SCRIPTS =========="
ls -la /root/.hermes/scripts/
for f in /root/.hermes/scripts/*; do
  echo "--- $(basename $f) ---"
  head -20 "$f"
done
