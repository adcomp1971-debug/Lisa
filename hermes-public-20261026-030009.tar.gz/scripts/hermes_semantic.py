#!/usr/bin/env python3
"""Семантический поиск «Герметиста» — по готовому векторному индексу (numpy).
Быстро: загрузка эмбеддингов + cosine, без индексации на лету."""
import json, os, sys
import numpy as np
import urllib.request

INDEX_DIR = '/root/hermes-box/index'
OLLAMA_URL = 'http://127.0.0.1:11434'
EMBED_MODEL = 'nomic-embed-text'

_embeddings = None
_meta = None

def load_index():
    global _embeddings, _meta
    if _embeddings is not None:
        return
    emb_path = os.path.join(INDEX_DIR, 'embeddings.npy')
    meta_path = os.path.join(INDEX_DIR, 'meta.json')
    if not os.path.exists(emb_path) or not os.path.exists(meta_path):
        raise FileNotFoundError(f"Индекс не найден: {INDEX_DIR}")
    _embeddings = np.load(emb_path)
    with open(meta_path) as f:
        _meta = json.load(f)
    print(f"Индекс загружен: {len(_embeddings)} чанков, dim={_embeddings.shape[1]}", flush=True)

def embed(text):
    req = urllib.request.Request(
        f'{OLLAMA_URL}/api/embeddings',
        data=json.dumps({'model': EMBED_MODEL, 'prompt': text[:8000]}).encode(),
        headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=60) as resp:
        d = json.loads(resp.read())
        return np.array(d['embedding'], dtype=np.float32)

def search(query, top_k=5, threshold=0.35):
    load_index()
    q = embed(query)
    # cosine similarity
    dots = _embeddings @ q
    norms = np.linalg.norm(_embeddings, axis=1) * np.linalg.norm(q)
    sims = dots / (norms + 1e-9)
    idx = np.argsort(-sims)[:top_k]
    results = []
    for i in idx:
        if sims[i] < threshold:
            continue
        m = _meta[i]
        # Читаем сниппет из файла
        fpath = os.path.join('/root/hermes-box/documents', m['file'])
        snippet = ''
        try:
            with open(fpath, encoding='utf-8', errors='ignore') as f:
                content = f.read()
            chunk_size = 1200
            start = m['chunk'] * (chunk_size - 150)
            snippet = content[start:start+chunk_size][:400]
        except Exception:
            pass
        results.append({
            'file': m['file'],
            'chunk': m['chunk'],
            'score': round(float(sims[i]), 3),
            'snippet': snippet,
        })
    return results

if __name__ == '__main__':
    q = ' '.join(sys.argv[1:]) or 'philosopher stone'
    import time
    t0 = time.time()
    print(f"\nЗапрос: {q}\n")
    for r in search(q):
        print(f"  [{r['score']:.3f}] {r['file'][:70]}")
        print(f"    {r['snippet'][:250]}")
    print(f"\nВремя: {time.time()-t0:.2f}s")
