#!/bin/bash
# daily-sources-collector.sh — сбор всех источников для вечернего дайджеста
# no_agent режим. Выхлоп: структурированный markdown.
set -euo pipefail

echo "# 📡 Источники за $(date +'%d %B %Y')"
echo ""

# ============================================================
# 1. GitHub Releases — подписанные репозитории
# ============================================================
echo "━━━ GitHub Releases ━━━"
echo ""

REPOS=(
  "NousResearch/hermes-agent"
  "deepseek-ai/deepseek-v4"
  "anthropics/claude-code"
  "openai/codex"
  "ggml-org/llama.cpp"
  "nvidia/nemo"
  "nvidia/cosmos"
)

for REPO in "${REPOS[@]}"; do
  DATA=$(curl -sL "https://api.github.com/repos/$REPO/releases?per_page=2" 2>/dev/null)
  REPO_NAME=$(echo "$REPO" | cut -d/ -f2)
  echo "$DATA" | python3 -c "
import json,sys
try:
    data=json.load(sys.stdin)
    if isinstance(data,list) and len(data)>0:
        r=data[0]
        tag=r['tag_name']
        date=r['published_at'][:10]
        body=(r.get('body') or '').split('\n')[0][:120]
        print(f'**{tag}** ({date}) — $REPO_NAME')
        if body: print(f'  {body}')
        if len(data)>1:
            print(f'  ← Previous: {data[1][\"tag_name\"]} ({data[1][\"published_at\"][:10]})')
    else:
        print(f'$REPO_NAME: (no releases)')
except: pass
" 2>/dev/null
done
echo ""

# ============================================================
# 2. GitHub Trending — AI/ML/Agents (новые звёзды за 7 дней)
# ============================================================
echo "━━━ GitHub Trending (AI/ML — новые звёзды) ━━━"
echo ""
curl -sL "https://api.github.com/search/repositories?q=topic:ai+stars:>2000+pushed:>$(date -d '7 days ago' +%Y-%m-%d)&sort=stars&order=desc&per_page=6" 2>/dev/null | python3 -c "
import json,sys
data=json.load(sys.stdin)
items=data.get('items',[])
if not items: print('(nothing new this week)')
for r in items[:6]:
    desc=(r['description'] or '')[:100]
    topics=', '.join(r.get('topics',[])[:3])
    extra=f' [{topics}]' if topics else ''
    print(f\"★ {r['stargazers_count']:,} | {r['full_name']}{extra}\")
    if desc: print(f'  {desc}')
    print()
" 2>/dev/null

# ============================================================
# 3. NVIDIA Technical Blog — последние 5 постов
# ============================================================
echo "━━━ NVIDIA Technical Blog ━━━"
echo ""
curl -sL "https://developer.nvidia.com/blog/" 2>/dev/null | python3 -c "
import sys,re
html=sys.stdin.read()
# Ищем заголовки и ссылки в структуре блога
# Паттерн: ссылка внутри <h3> под article
articles=re.findall(r'<article[^>]*>(.*?)</article>',html,re.DOTALL)
found=[]
for art in articles:
    # Ищем ссылку
    link_m=re.search(r'href=\"(https://developer\.nvidia\.com/blog/[a-z0-9-]+(?:-[a-z0-9]+)*/)\"',art)
    # Ищем заголовок
    title_m=re.search(r'<h3[^>]*>(.*?)</h3>',art,re.DOTALL)
    # Ищем категорию
    cat_m=re.search(r'<span[^>]*class=\"[^\"]*cat[^\"]*\"[^>]*>(.*?)</span>',art,re.DOTALL)
    title=title_m.group(1).strip() if title_m else ''
    # чистим HTML из заголовка
    title=re.sub(r'<[^>]+>','',title).strip()
    link=link_m.group(1) if link_m else ''
    cat=cat_m.group(1).strip() if cat_m else ''
    if title and link:
        found.append((cat,title,link))

for cat,title,link in found[:5]:
    if cat: print(f'[{cat}]', end=' ')
    print(f'{title[:80]}')
    print(f'  {link}')
    print()
if not found:
    # fallback: ищем все ссылки вида /blog/...
    all_links=re.findall(r'href=\"(https://developer\.nvidia\.com/blog/[a-z0-9-]+(?:-[a-z0-9]+)*/)\"',html)
    seen=set()
    for l in all_links:
        if l not in seen and len(seen)<5:
            seen.add(l)
            print(f'• {l.split(\"/\")[-2].replace(\"-\",\" \")[:70]}')
            print(f'  {l}')
            print()
" 2>/dev/null

# ============================================================
# 4. HuggingFace Daily Papers — через RSS
# ============================================================
echo "━━━ HuggingFace Daily Papers ━━━"
echo ""
# HF daily papers API
curl -sL "https://huggingface.co/api/daily_papers?limit=5" 2>/dev/null | python3 -c "
import json,sys
try:
    data=json.load(sys.stdin)
    for p in data[:5]:
        paper=p.get('paper',p)
        title=paper.get('title','')
        paper_id=paper.get('id','')
        url=f'https://huggingface.co/papers/{paper_id}' if paper_id else ''
        authors=paper.get('authors',[])
        author=', '.join([a.get('name','') for a in authors[:2]])
        # дата публикации
        pub_date=paper.get('publishedAt','')[:10]
        print(f'📄 {title[:100]}')
        if author: print(f'  {author} | {pub_date}')
        if url: print(f'  {url}')
        print()
except Exception as e:
    print(f'(API error: {e})')
" 2>/dev/null

# ============================================================
# 5. Hacker News — топ за 48 часов (>50 pts)
# ============================================================
echo "━━━ Hacker News Top (48h, >50 pts) ━━━"
echo ""
curl -sL "https://news.ycombinator.com/" 2>/dev/null | python3 /root/.hermes/scripts/hn_parser.py

echo "---"
echo "Собрано: $(date +'%H:%M UTC')"
