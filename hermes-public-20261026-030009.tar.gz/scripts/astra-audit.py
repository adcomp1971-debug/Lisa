#!/usr/bin/env python3
"""Полный аудит Hermes моделью gpt-6-astra (внешний сильный аналитик).

Собирает срез: config.yaml (без секретов), слои памяти, библиотеку скиллов,
системные метрики, cron, логи ошибок -> отправляет один запрос -> сохраняет отчёт.
READ-ONLY по отношению к системе: ничего не меняет, только читает и вызывает API.
"""
import json
import os
import subprocess
import urllib.request
from datetime import datetime, timezone

BASE = "/root/.hermes"
OUT = "/root/.hermes/audit/20260923"
os.makedirs(OUT, exist_ok=True)


def sh(cmd, timeout=60):
    try:
        return subprocess.run(cmd, shell=True, capture_output=True, text=True,
                              timeout=timeout).stdout.strip()
    except Exception as e:  # noqa: BLE001
        return f"[err: {e}]"


def read(path, limit=None):
    try:
        s = open(path, encoding="utf-8", errors="replace").read()
        return s if limit is None else s[:limit]
    except Exception as e:  # noqa: BLE001
        return f"[err: {e}]"


def env(name):
    for line in read(f"{BASE}/.env").splitlines():
        if line.startswith(name + "="):
            return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def config_slice():
    import yaml
    c = yaml.safe_load(read(f"{BASE}/config.yaml")) or {}
    keep = ["model", "fallback_providers", "delegation", "auxiliary", "compression",
            "memory", "mcp_servers", "providers", "security", "approvals", "terminal",
            "web", "tools", "skills", "cron", "tts", "logging"]
    out = {}
    for k in keep:
        if k in c:
            out[k] = c[k]
    # вычистить любые ключи/токены
    def scrub(o, depth=0):
        if depth > 8:
            return o
        if isinstance(o, dict):
            return {k: ("***SET***" if any(t in k.lower() for t in ("key", "token", "secret", "password", "passwd"))
                        else scrub(v, depth + 1)) for k, v in o.items()}
        if isinstance(o, list):
            return [scrub(v, depth + 1) for v in o]
        return o
    return json.dumps(scrub(out), ensure_ascii=False, indent=1)


def child_reports():
    parts = []
    for name in ("skills-plan.md", "memory-plan.md", "system-plan.md"):
        p = os.path.join(OUT, name)
        if os.path.exists(p):
            parts.append(f"### {name}\n{read(p)}")
    return "\n\n".join(parts) if parts else "(дополнительные отчёты субагентов пока отсутствуют)"


def main():
    facts = []
    facts.append("## Системные факты (живьём)\n```\n" + "\n".join([
        "date: " + sh("date -u"),
        "uptime: " + sh("uptime"),
        "disk: " + sh("df -h / | tail -1"),
        "mem: " + sh("free -h | sed -n '1,3p'"),
        "top_rss: " + sh("ps aux --sort=-rss | sed -n '2,7p' | awk '{print $4\"% \"$6\" \"$11}'"),
        "hermes_version: " + sh("hermes --version 2>&1 | head -2"),
        "state_db: " + sh("ls -la /root/.hermes/state.db /root/.hermes/state.db-wal 2>/dev/null"),
        "du_hermes: " + sh("du -sh /root/.hermes/state.db /root/.hermes/logs /root/.hermes/sessions /root/.hermes/cache /root/.hermes/skills 2>/dev/null"),
        "skills_count: " + sh("find /root/.hermes/skills -name SKILL.md -not -path '*/.archive/*' | wc -l"),
        "memory_sizes: " + sh("python3 -c \"print('MEMORY', len(open('/root/.hermes/memories/MEMORY.md',encoding='utf-8').read())); print('USER', len(open('/root/.hermes/memories/USER.md',encoding='utf-8').read()))\""),
        "sessions_count: " + sh("ls /root/.hermes/sessions | wc -l"),
    ]) + "\n```")

    facts.append("## Cron-джобы\n```\n" + sh("hermes cron list 2>&1 | head -60") + "\n```")
    facts.append("## Юниты failed / ключевые сервисы\n```\n" + sh("systemctl --failed --no-legend | head -20; echo ---; systemctl is-active hermes-gateway x-ui awg-quick@awg0 playit cf-contour-xray 2>&1") + "\n```")
    facts.append("## Топ ошибок в логах за 7 дней\n```\n" + sh(r"""grep -hE 'ERROR|CRITICAL|Traceback|timeout|402|429' /root/.hermes/logs/*.log /root/.hermes/agent.log* 2>/dev/null | sed -E 's/[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9:.,]+//' | sed -E 's/[0-9]{2,}/N/g' | sort | uniq -c | sort -rn | head -25""") + "\n```")

    prompt = f"""Ты — внешний аудитор персонального ИИ-агента Hermes Agent (Nous Research), работающего на прод-сервере (Hostinger VPS, 4 CPU, 15 ГБ RAM, диск 193 ГБ занят на 64%).

Владелец: Алекс (Израиль, работает ТОЛЬКО с iPad через Telegram). Hermes обслуживает: VPN (AmneziaWG, 17 пиров, релей playit.gg из-за адресной блокировки IPv4 московскими операторами), панель 3x-ui/Xray VLESS Reality, RAG-проект «Герметист» (древние тексты), ботов, cron-дайджесты, MLflow, десятки systemd-сервисов.

ЗАДАЧА: полный аудит трёх областей и приоритизированный план чистки/оптимизации.
1. ПАМЯТЬ (4 слоя): MEMORY.md (лимит 20000 символов), USER.md (лимит 2000), AGENTS.md (runtime-состояние), архитектурные .md в /root/.hermes. Найди: дубли, противоречия, устаревшее, процедуры, которые должны жить в скиллах, а не в памяти; раздели «факт, нужный каждой сессии» vs «лог/история».
2. СКИЛЛЫ (82 активных, 18 в архиве): дубли-кластеры, кандидаты в архив, внутренние дубли в жирных SKILL.md. Учти: есть защищённые (безопасность/доставка/аварийные) — их трогать нельзя.
3. СИСТЕМА: что тормозит или может сломать агента; известная проблема — медиана ~199k токенов контекста на вызов в долгой telegram-сессии (главная статья расходов, 91% расхода пришлось на одну сессию); state.db 533 МБ; swap 2.3/4 ГБ.
4. ПРАВИЛА/БЕЗОПАСНОСТЬ: противоречия между правилами, опасные разрешения, что стоит ужесточить.

ФОРМАТ ОТВЕТА (строго, без вступлений и вежливости):
## P0 — критично (сделать сразу)
## P1 — важно
## P2 — можно потом
Для каждого пункта: что именно (конкретные файлы/записи/скиллы), почему, что делать (конкретное действие), ожидаемый эффект (символы/МБ/токены/риск).
## Что удалить из памяти (список записей по идентификатору начала записи)
## Что удалить/архивировать из скиллов
## Что НЕ трогать и почему
## Итог: оценка экономии и главные 3 действия

Будь конкретен и приземлён: у хоста нет лишних ресурсов, каждое предложение должно быть исполнимо на этом сервере. Не предлагай переустановки и миграции без нужды.

=== ДАННЫЕ ===

{facts[0]}

{facts[1]}

{facts[2]}

{facts[3]}

## config.yaml (секреты вычищены)
```yaml
{config_slice()}
```

## MEMORY.md (постоянная память, разделитель §)
```
{read(f'{BASE}/memories/MEMORY.md')}
```

## USER.md
```
{read(f'{BASE}/memories/USER.md')}
```

## AGENTS.md (runtime-справочник)
```
{read(f'{BASE}/AGENTS.md', 30000)}
```

## Инвентарь скиллов (use_count, дней с последнего использования)
```
{read(os.path.join(OUT, 'skills-inventory.txt'))}
```

## Отчёты субагентов
{child_reports()}
"""

    if os.environ.get("DRY_RUN"):
        p = os.path.join(OUT, "astra-prompt.txt")
        open(p, "w", encoding="utf-8").write(prompt)
        print(f"DRY_RUN: prompt {len(prompt)} символов -> {p}")
        return

    key = env("OPENAI_API_KEY")
    if not key:
        raise SystemExit("OPENAI_API_KEY не найден в .env")
    body = json.dumps({
        "model": "gpt-6-astra",
        "messages": [
            {"role": "system", "content": "Ты — старший инженер-аудитор. Отвечай по-русски, конкретно, без воды и без комплиментов. Только факты, находки и действия."},
            {"role": "user", "content": prompt},
        ],
        "max_completion_tokens": int(os.environ.get("MAX_TOKENS", "32000")),
    }).encode()

    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
    )
    started = datetime.now(timezone.utc).isoformat()
    with urllib.request.urlopen(req, timeout=900) as r:
        resp = json.loads(r.read())

    text = resp["choices"][0]["message"]["content"]
    usage = resp.get("usage", {})
    path = os.path.join(OUT, "astra-audit.md")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# Аудит Hermes моделью gpt-6-astra\n\n- старт: {started}\n- usage: {usage}\n- размер входа: {len(prompt)} символов\n\n---\n\n{text}\n")

    # отправить отчёт Алексу файлом
    sh(f"python3 /root/send_file.py {path} 'Аудит Hermes от Astra' 2>&1 | tail -2", timeout=120)
    print(f"OK: {path} ({len(text)} символов), usage={usage}")


if __name__ == "__main__":
    main()
