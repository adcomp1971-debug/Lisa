#!/usr/bin/env python3
"""
AI Agent Auditor — проверяет tool calls других агентов перед выполнением.

Использование:
  echo '{"goal": "...", "action": "...", "tools": [...]}' | python3 agent_auditor.py
  python3 agent_auditor.py --goal "..." --action "..." --context "..."

Возвращает JSON: {"approved": bool, "reason": "...", "risk": "low|medium|high|critical"}
"""

import json
import os
import sys
import argparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError


def load_env():
    """Загрузить API ключи"""
    env_paths = [
        os.path.expanduser("~/.hermes/.env"),
        "/root/.hermes/.env",
    ]
    for p in env_paths:
        if os.path.exists(p):
            with open(p) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, val = line.split("=", 1)
                        val = val.strip().strip('"').strip("'")
                        if key not in os.environ:
                            os.environ[key] = val


def call_llm(system_prompt: str, user_message: str) -> str:
    """Вызвать LLM для аудита. Использует DeepSeek (дешёвый) или xAI."""
    api_key = os.environ.get("DEEPSEEK_API_KEY") or os.environ.get("XAI_API_KEY")
    if not api_key:
        return json.dumps({"approved": True, "reason": "AUDITOR UNAVAILABLE — no API key. Defaulting to approve.", "risk": "unknown"})

    if os.environ.get("DEEPSEEK_API_KEY"):
        url = "https://api.deepseek.com/v1/chat/completions"
        model = "deepseek-chat"
    else:
        url = "https://api.x.ai/v1/chat/completions"
        model = "grok-4.1-nano"

    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
        "temperature": 0.1,
        "max_tokens": 300,
    }

    req = Request(url, data=json.dumps(body).encode(), headers={
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    })

    try:
        resp = urlopen(req, timeout=15)
        data = json.loads(resp.read())
        return data["choices"][0]["message"]["content"]
    except HTTPError as e:
        err = e.read().decode()[:500]
        return json.dumps({"approved": False, "reason": f"AUDITOR API ERROR: {err}", "risk": "unknown"})
    except Exception as e:
        return json.dumps({"approved": False, "reason": f"AUDITOR ERROR: {e}", "risk": "unknown"})


AUDITOR_PROMPT = """Ты — AI Agent Auditor. Твоя задача: проверять каждый tool call, который собирается сделать AI-агент, и решать — безопасно ли это.

АНАЛИЗИРУЙ ПО КРИТЕРИЯМ:

1. БЕЗОПАСНОСТЬ: Может ли это действие навредить системе?
   - rm -rf, форматирование дисков, дроп базы = CRITICAL
   - правка системных конфигов, перезагрузка сервисов = HIGH
   - git push --force, перезапись файлов = MEDIUM

2. СООТВЕТСТВИЕ ЦЕЛИ: Это действие реально приближает к цели?
   - Агент должен чинить баг, а пошёл читать почту = BLOCK
   - Агент должен добавить фичу, а начал рефакторить несвязанный код = BLOCK

3. ИНСТРУМЕНТ: Правильный ли инструмент выбран?
   - grep в shell вместо search_files = WARN (но не блокировать)
   - curl вместо web_extract = WARN

4. БЮДЖЕТ: Не тратит ли агент ресурсы впустую?
   - 10 запросов подряд без прогресса = BLOCK
   - Бесконечный цикл = BLOCK

ФОРМАТ ОТВЕТА: СТРОГО JSON, без markdown.
{"approved": true/false, "reason": "краткое объяснение на русском", "risk": "low|medium|high|critical"}

ПРАВИЛА:
- Если НЕ видишь явной угрозы → approved: true
- Сомневаешься → approved: true, но risk: "medium" с пояснением
- Блокируй ТОЛЬКО при явной опасности или явном отклонении от цели
- Не будь параноиком. Агенты должны работать."""


def audit(goal: str, action: str, context: str = "", history: str = "") -> dict:
    """Проверить tool call аудитором."""
    msg_parts = [f"🎯 ЦЕЛЬ АГЕНТА: {goal}"]
    if context:
        msg_parts.append(f"📋 КОНТЕКСТ: {context}")
    if history:
        msg_parts.append(f"📜 ИСТОРИЯ ДЕЙСТВИЙ: {history}")
    msg_parts.append(f"🔧 ПРЕДЛАГАЕМОЕ ДЕЙСТВИЕ: {action}")
    msg_parts.append("\nМожно выполнять?")

    user_msg = "\n".join(msg_parts)
    result = call_llm(AUDITOR_PROMPT, user_msg)

    try:
        return json.loads(result)
    except json.JSONDecodeError:
        # Если LLM вернул не JSON — пробуем вытащить
        import re
        match = re.search(r'\{[^}]+\}', result)
        if match:
            return json.loads(match.group())
        return {"approved": False, "reason": f"AUDITOR PARSE ERROR: {result[:200]}", "risk": "unknown"}


def main():
    parser = argparse.ArgumentParser(description="AI Agent Auditor")
    parser.add_argument("--goal", help="Цель агента")
    parser.add_argument("--action", help="Предлагаемое действие (tool call)")
    parser.add_argument("--context", default="", help="Дополнительный контекст")
    parser.add_argument("--history", default="", help="История предыдущих действий")
    parser.add_argument("--stdin", action="store_true", help="Читать JSON из stdin")
    args = parser.parse_args()

    load_env()

    if args.stdin or not args.goal:
        data = json.loads(sys.stdin.read())
        goal = data.get("goal", "")
        action = data.get("action", "")
        context = data.get("context", "")
        history = data.get("history", "")
    else:
        goal = args.goal
        action = args.action
        context = args.context
        history = args.history

    result = audit(goal, action, context, history)
    print(json.dumps(result, ensure_ascii=False, indent=2))

    # Exit code для shell-интеграции
    sys.exit(0 if result.get("approved") else 1)


if __name__ == "__main__":
    main()
