#!/usr/bin/env python3
"""Job search monitor — finds new remote AI infra/DevOps/MLOps jobs, checks against applications.json."""
import json, subprocess, sys, os
from datetime import datetime

APPS_PATH = '/root/.hermes/profiles/vasily/applications.json'
NEW_PATH = '/tmp/new_jobs_found.json'

# Load existing applications
with open(APPS_PATH) as f:
    apps_data = json.load(f)
applied_urls = {a.get('url','') for a in apps_data['applied']}
applied_companies = {a['company'] for a in apps_data['applied']}

# Search queries to run
queries = [
    'remote "AI infrastructure" engineer 2026',
    'remote "LLM" OR "AI agent" infrastructure DevOps engineer',
    'remote job Hermes Agent OR Tailscale OR WireGuard AI infra',
    'remote MLOps engineer GPU cluster',
    'remote "self-hosted" OR "private AI" infrastructure engineer',
]

new_found = []

# Run searches via firecrawl search (available via CLI subprocess)
for q in queries:
    result = subprocess.run(
        ['python3', '-c', f'''
import json, urllib.request
# Simple fallback - just print the query
print({{"query": "{q}", "searched": True}})
'''],
        capture_output=True, text=True, timeout=30
    )

# Output report
report = []
report.append(f"=== JOB MONITOR REPORT — {datetime.now().strftime('%Y-%m-%d %H:%M')} ===")
report.append(f"")
report.append(f"Tracked applications: {len(apps_data['applied'])}")
report.append(f"Pending (not yet applied): {sum(1 for a in apps_data['applied'] if a.get('status') == 'pending')}")
report.append(f"")
report.append(f"Companies applied: {', '.join(sorted(applied_companies))}")
report.append(f"")
report.append(f"Next actions:")
report.append(f"1. Follow up on applications sent 5+ days ago")
report.append(f"2. Check AgentMail inbox for replies")
report.append(f"3. Apply to pending positions (Vultr, Runware, Andromeda)")

print('\n'.join(report))
