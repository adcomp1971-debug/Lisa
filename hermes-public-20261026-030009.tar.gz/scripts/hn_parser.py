#!/usr/bin/env python3
"""Parse Hacker News HTML from stdin, output top stories by points.
HN HTML structure:
  <tr class="athing submission">   ← title
    <span class="titleline"><a href="...">Title</a></span>
  </tr>
  <tr>                              ← subtext (score is here)
    <span class="score">NN points</span>
  </tr>
"""
import sys, re

html = sys.stdin.read()
chunks = html.split("</tr>")

title_re = re.compile(r'class="titleline"><a[^>]*href="([^"]+)"[^>]*>([^<]+)</a>')
score_re = re.compile(r'class="score"[^>]*>(\d+)\s+points?<')

results = []
pending_title = None

for chunk in chunks:
    # Check for title
    tm = title_re.search(chunk)
    if tm:
        pending_title = (tm.group(1), tm.group(2).strip())
    
    # Check for score — pairs with the immediately preceding title
    sm = score_re.search(chunk)
    if sm and pending_title:
        pts = int(sm.group(1))
        url, title = pending_title
        title = title.replace("&#x27;", "'").replace("&quot;", '"').replace("&amp;", "&")
        if url.startswith("http"):
            results.append((pts, title, url))
        pending_title = None
    elif sm and not pending_title:
        # Score without preceding title — skip (internal pages, etc.)
        pass
    
    # If chunk has title but score follows later, keep title for next iteration
    if not sm and not tm:
        # Neither title nor score — if we had a title and this chunk has no score, 
        # it might span across — but actually the structure is strict, so this handles noise
        pass

results.sort(key=lambda x: -x[0])
for pts, title, url in results[:20]:
    if pts >= 40:
        print(f"{pts}pts | {title[:95]}")
        print(f"  {url}")
        print()

if not results:
    print("(no HN results parsed)")
