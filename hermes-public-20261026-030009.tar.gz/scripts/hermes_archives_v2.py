#!/usr/bin/env python3
"""Герметист archives v2: только источники, которые отдают РЕАЛЬНЫЙ текст.

Не подключает каталог как книгу. Русский запрос всегда переводится;
непереведённая кириллица в внешние архивы не уходит.
"""
from __future__ import annotations

import html
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Optional

UA = "HermetistArchivesV2/1.0"
PER_ARCHIVE_TIMEOUT = 8.0
GLOBAL_DEADLINE = 25.0
MAX_ITEMS = 4

SOURCE_LIB_API = "https://sourcelibrary.org/api"
SOURCE_LIB_MCP = "https://sourcelibrary.org/api/mcp"

_RUSSIAN_CLASSICS = (
    "pushkin", "пушкин", "derzhavin", "державин", "belinsky", "белинск",
    "nekrasov", "некрасов", "dobrolyubov", "добролюбов", "chekhov", "чехов",
    "gogol", "гоголь", "turgenev", "тургенев", "lermontov", "лермонтов",
    "krylov", "крылов", "saltykov", "салтыков", "ostrovsky", "островск",
    "works of pushkin", "works of derzhavin", "works of vissarion",
    "poems of n.a. nekrasov",
)

_STOP = {
    "что", "как", "такое", "это", "кто", "где", "почему", "зачем", "когда",
    "какой", "какая", "какие", "по", "о", "и", "в", "на", "не", "мне", "с",
    "у", "для", "про", "книги", "книга", "about", "the", "and", "what", "who",
    "why", "how", "does", "is", "are", "of", "to", "in", "a", "an", "on",
}

_TRANSLIT = {
    "герметический корпус": "Corpus Hermeticum",
    "герметического корпуса": "Corpus Hermeticum",
    "герметическом корпусе": "Corpus Hermeticum",
    "герметич": "hermetic hermeticism",
    "герметизм": "hermeticism hermetic",
    "герметисты": "hermetists hermetic",
    "герметистов": "hermetists hermetic",
    "практики": "practices practice",
    "практик": "practice practices",
    "теургия": "theurgy",
    "теургии": "theurgy",
    "ямвлих": "Iamblichus",
    "ямвлиха": "Iamblichus",
    "алхимия": "alchemy",
    "алхимии": "alchemy",
    "парацельс": "Paracelsus",
    "парацельса": "Paracelsus",
    "зойар": "zohar",
    "зоар": "zohar",
    "енох": "enoch",
    "еноха": "enoch",
    "кали-юга": "kali yuga",
    "кали юга": "kali yuga",
    "генон": "Guenon",
    "генона": "Guenon",
    "геноне": "Guenon",
    "эвола": "Evola",
    "современном мире": "modern world",
    "современный мир": "modern world",
    "поймандр": "Poimandres Pymander",
    "поимандр": "Poimandres",
    "асклепий": "Asclepius",
    "трисмегист": "Trismegistus",
    "гермес": "Hermes",
    "каббала": "kabbalah",
    "сефирот": "sephiroth",
    "коран": "quran",
}


def _load_sl_key() -> str:
    key = os.environ.get("SOURCE_LIBRARY_API_KEY", "")
    if key:
        return key
    try:
        with open("/root/.hermes/.env") as f:
            for ln in f:
                if ln.startswith("SOURCE_LIBRARY_API_KEY="):
                    return ln.split("=", 1)[1].strip().strip('"').strip("'")
    except Exception:
        pass
    return ""


SOURCE_LIB_KEY = _load_sl_key()


def _now() -> float:
    return time.monotonic()


def translate_query(query: str) -> str:
    q = (query or "").strip()
    if not q:
        return ""
    low = q.lower()
    out = low
    for ru, en in sorted(_TRANSLIT.items(), key=lambda x: -len(x[0])):
        out = out.replace(ru, " " + en + " ")
    parts = []
    for w in re.split(r"[\s,.;:!?«»\"']+", out):
        if not w or w in _STOP or len(w) < 2:
            continue
        if re.search(r"[а-яё]", w):
            continue
        parts.append(w)
    joined = " ".join(parts).strip()
    jl = joined.lower()
    extra = []
    if "hermeticum" in jl or "corpus" in jl:
        extra.extend(["Poimandres", "Pymander", "Trismegistus"])
    if "hermetist" in jl or "hermetic" in jl:
        extra.extend(["Hermetic", "Kybalion"])
    if extra:
        joined = (joined + " " + " ".join(extra)).strip()
    return joined


def _empty_result(source: str, status: str, http_status: Optional[int],
                  elapsed_ms: int, diagnostics: str, items=None) -> dict:
    return {
        "source": source,
        "status": status,
        "http_status": http_status,
        "elapsed_ms": elapsed_ms,
        "items": items or [],
        "diagnostics": diagnostics,
    }


def _http(url: str, timeout: float, method="GET", data=None, headers=None):
    h = {"User-Agent": UA, "Accept": "*/*"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read(1_200_000)
        return resp.status, raw


def _classify_http_err(e: Exception) -> str:
    if isinstance(e, TimeoutError) or "timed out" in str(e).lower():
        return "timeout"
    if isinstance(e, urllib.error.HTTPError):
        if e.code == 429:
            return "rate_limited"
        if e.code in (401, 403, 451):
            return "blocked"
        return "parse_error"
    return "parse_error"


def _is_russian_classic(title: str, authors: str, snippet: str) -> bool:
    blob = f"{title} {authors} {snippet}".lower()
    return any(x in blob for x in _RUSSIAN_CLASSICS)


def _item(title, authors=None, year=None, language=None, snippet="",
          url="", page=None, similarity=None):
    return {
        "title": title or "",
        "authors": authors or "",
        "year": year or "",
        "language": language or "",
        "snippet": (snippet or "").strip(),
        "url": url or "",
        "page": page,
        "locator": str(page) if page not in (None, "") else "",
        "similarity": similarity,
    }


def _ok_items(items: List[dict]) -> List[dict]:
    out = []
    for it in items:
        sn = it.get("snippet") or ""
        if len(sn) < 40:
            continue
        if not it.get("url"):
            continue
        if _is_russian_classic(it.get("title") or "", it.get("authors") or "", sn):
            continue
        out.append(it)
        if len(out) >= MAX_ITEMS:
            break
    return out


# ----- Source Library (passages only; never catalog /search) -----
def search_sourcelibrary(query: str, timeout: float = PER_ARCHIVE_TIMEOUT) -> dict:
    source = "sourcelibrary"
    t0 = _now()
    q = translate_query(query)
    if not q:
        return _empty_result(source, "empty", None, int((_now() - t0) * 1000),
                             "no latin query after translation")
    headers = {
        "User-Agent": UA,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if SOURCE_LIB_KEY:
        headers["Authorization"] = f"Bearer {SOURCE_LIB_KEY}"
    http_status = None
    passages = []
    diag = []
    last_err = None
    for tool in ("search_translations", "search_concept"):
        remain = timeout - (_now() - t0)
        if remain < 1.5:
            break
        payload = {
            "jsonrpc": "2.0", "id": 1, "method": "tools/call",
            "params": {"name": tool, "arguments": {"query": q, "limit": 8}},
        }
        try:
            st, raw = _http(SOURCE_LIB_MCP, remain, method="POST",
                            data=json.dumps(payload).encode(), headers=headers)
            http_status = st
            d = json.loads(raw.decode("utf-8", "replace"))
            text = ""
            for part in ((d.get("result") or {}).get("content") or []):
                if isinstance(part, dict) and part.get("type") == "text":
                    text = part.get("text") or ""
                    break
            parsed = json.loads(text) if text else (d.get("result") or {})
            got = parsed.get("passages") or parsed.get("results") or []
            diag.append(f"{tool}:{len(got)}")
            passages.extend(got)
        except Exception as e:
            last_err = e
            diag.append(f"{tool}:{_classify_http_err(e)}")
            continue
    elapsed = int((_now() - t0) * 1000)
    if not passages and last_err and not diag:
        return _empty_result(source, _classify_http_err(last_err), http_status,
                             elapsed, str(last_err)[:160])
    items = []
    seen = set()
    for p in passages:
        title = p.get("title") or ""
        author = p.get("author") or ""
        snippet = re.sub(r"<[^>]+>", " ", p.get("snippet") or "")
        snippet = re.sub(r"\s+", " ", snippet).strip()
        url = p.get("short_url") or p.get("url") or ""
        page = p.get("page")
        key = (title[:80], page, snippet[:40])
        if key in seen:
            continue
        seen.add(key)
        sim = p.get("similarity")
        items.append(_item(title, author, str(p.get("published") or ""),
                           p.get("language") or p.get("snippet_language"),
                           snippet, url, page, sim))
        blob = f"{title} {author} {snippet}".lower()
        if "guenon" in q.lower() and not any(x in blob for x in ("rené", "rene ", "tradition", "crisis", "vedanta", "guénon")):
            if any(x in blob for x in ("monkey", "cercopith", "makis", "singe")):
                items.pop()
                continue
    items = _ok_items(items)
    status = "ok" if items else "empty"
    return _empty_result(source, status, http_status, elapsed,
                         "; ".join(diag) + f" q={q}", items)


# ----- Internet Archive: real djvu.txt -----
def _ia_snippet(ident: str, words: List[str], timeout: float):
    st, raw = _http(f"https://archive.org/metadata/{ident}", min(timeout, 4))
    md = json.loads(raw.decode("utf-8", "replace"))
    server = md.get("server") or ""
    dirp = md.get("dir") or ""
    txt_name = None
    for f in (md.get("files") or []):
        n = f.get("name") or ""
        if n.endswith("_djvu.txt") or n.endswith("_text.pdf.txt") or n.endswith(".txt"):
            if n.endswith("_djvu.txt"):
                txt_name = n
                break
            if txt_name is None and "meta" not in n.lower():
                txt_name = n
    if not txt_name or not server:
        return None, None
    url = f"https://{server}{dirp}/{urllib.parse.quote(txt_name)}"
    st, raw = _http(url, min(timeout, 5))
    text = raw.decode("utf-8", "replace")
    low = text.lower()
    pos = -1
    for w in words:
        p = low.find(w.lower())
        if p != -1 and (pos == -1 or p < pos):
            pos = p
    if pos == -1:
        pos = 0
    start = max(0, pos - 120)
    snip = re.sub(r"\s+", " ", text[start:start + 500]).strip()
    page = (pos // 1800) + 1 if pos else None
    return snip, page


def search_internet_archive(query: str, timeout: float = PER_ARCHIVE_TIMEOUT) -> dict:
    source = "internet_archive"
    t0 = _now()
    q = translate_query(query)
    if not q:
        return _empty_result(source, "empty", None, int((_now() - t0) * 1000),
                             "no latin query")
    words = []
    for w in q.split():
        wl = w.strip(".,")
        if len(wl) > 3 and wl.lower() not in words:
            words.append(wl)
    words = words[:5]
    q_ia = " AND ".join(f'"{w}"' for w in words[:2]) if len(words) >= 2 else f'"{q}"'
    url = (
        "https://archive.org/advancedsearch.php?q="
        + urllib.parse.quote(q_ia)
        + "+AND+mediatype:texts+AND+!access-restricted-item:true"
        + "&fl[]=identifier&fl[]=title&fl[]=creator&fl[]=date&fl[]=language"
        + "&rows=6&output=json"
    )
    try:
        st, raw = _http(url, min(timeout, 5))
        d = json.loads(raw.decode("utf-8", "replace"))
        docs = d.get("response", {}).get("docs") or []
        items = []
        for doc in docs:
            if _now() - t0 > timeout - 0.5:
                break
            ident = doc.get("identifier") or ""
            title = doc.get("title") or ""
            if not ident or _is_russian_classic(title, str(doc.get("creator") or ""), ""):
                continue
            blob = title.lower()
            cores = [w.lower() for w in words if len(w) > 4][:3]
            if cores and not any(w in blob for w in cores):
                # keep candidate; snippet check later
                pass
            try:
                snip, page = _ia_snippet(ident, words, timeout - (_now() - t0))
            except Exception:
                continue
            if not snip or len(snip) < 40:
                continue
            blob2 = (title + " " + snip).lower()
            cores = [w.lower() for w in words if len(w) > 3]
            if cores and not any(w in blob2 for w in cores):
                continue
            if "guenon" in " ".join(words).lower() and "guenon" not in blob2 and "guénon" not in blob2:
                continue
            creator = doc.get("creator") or ""
            if isinstance(creator, list):
                creator = ", ".join(creator[:2])
            items.append(_item(
                title[:120], str(creator)[:80], str(doc.get("date") or "")[:10],
                str(doc.get("language") or ""), snip,
                f"https://archive.org/details/{ident}", page,
            ))
            if len(items) >= MAX_ITEMS:
                break
        items = _ok_items(items)
        elapsed = int((_now() - t0) * 1000)
        return _empty_result(source, "ok" if items else "empty", st, elapsed,
                             f"q={q_ia} docs={len(docs)}", items)
    except Exception as e:
        elapsed = int((_now() - t0) * 1000)
        code = getattr(e, "code", None)
        return _empty_result(source, _classify_http_err(e), code, elapsed, str(e)[:160])


# ----- Wikisource: search snippets are real text -----
def search_wikisource(query: str, timeout: float = PER_ARCHIVE_TIMEOUT) -> dict:
    source = "wikisource"
    t0 = _now()
    q = translate_query(query)
    if not q:
        return _empty_result(source, "empty", None, int((_now() - t0) * 1000), "no latin query")
    items = []
    http_status = None
    last_status_name = None
    langs = [("en", "https://en.wikisource.org"), ("la", "https://la.wikisource.org")]
    q_try = q
    if "Hermeticum" in q or "hermetic" in q.lower():
        q_try = "Pymander OR Poimandres OR Kybalion"
    for lang, base in langs:
        remain = timeout - (_now() - t0)
        if remain < 1:
            break
        url = (
            f"{base}/w/api.php?action=query&list=search&srsearch="
            + urllib.parse.quote(q_try if lang == "en" else q)
            + "&srlimit=5&format=json"
        )
        try:
            st, raw = _http(url, remain)
            http_status = st
            d = json.loads(raw.decode("utf-8", "replace"))
            for hit in (d.get("query") or {}).get("search") or []:
                title = hit.get("title") or ""
                snip = html.unescape(re.sub(r"<[^>]+>", " ", hit.get("snippet") or ""))
                snip = re.sub(r"\s+", " ", snip).strip()
                page_url = f"{base}/wiki/{urllib.parse.quote(title.replace(' ', '_'))}"
                items.append(_item(title, "", "", lang, snip, page_url, title))
        except urllib.error.HTTPError as e:
            last_status_name = _classify_http_err(e)
            http_status = e.code
            if e.code == 429:
                time.sleep(0.4)
                continue
        except Exception as e:
            last_status_name = _classify_http_err(e)
            continue
    if not items and last_status_name and http_status:
        elapsed = int((_now() - t0) * 1000)
        return _empty_result(source, last_status_name, http_status, elapsed, f"q={q}")
    items = _ok_items(items)
    elapsed = int((_now() - t0) * 1000)
    return _empty_result(source, "ok" if items else "empty", http_status, elapsed,
                         f"q={q}", items)


# ----- Gutenberg: opensearch + plaintext -----
def search_gutenberg(query: str, timeout: float = PER_ARCHIVE_TIMEOUT) -> dict:
    source = "gutenberg"
    t0 = _now()
    q = translate_query(query)
    if not q:
        return _empty_result(source, "empty", None, int((_now() - t0) * 1000), "no latin query")
    q_gb = "Kybalion" if ("hermetic" in q.lower() or "hermeticum" in q.lower() or "poimandres" in q.lower()) else q
    url = "https://www.gutenberg.org/ebooks/search/?query=" + urllib.parse.quote(q_gb.split()[0] if len(q_gb.split()[0]) > 4 else q_gb) + "&format=json"
    try:
        st, raw = _http(url, min(timeout, 5))
        data = json.loads(raw.decode("utf-8", "replace"))
        titles = data[1] if isinstance(data, list) and len(data) > 1 else []
        authors = data[2] if isinstance(data, list) and len(data) > 2 else []
        hrefs = data[3] if isinstance(data, list) and len(data) > 3 else []
        items = []
        for i, href in enumerate(hrefs[1:6], start=1):
            if _now() - t0 > timeout - 0.8:
                break
            m = re.search(r"/ebooks/(\d+)", href or "")
            if not m:
                continue
            gid = m.group(1)
            title = titles[i] if i < len(titles) else ""
            author = authors[i] if i < len(authors) else ""
            if _is_russian_classic(title, author, ""):
                continue
            txt_url = f"https://www.gutenberg.org/cache/epub/{gid}/pg{gid}.txt"
            try:
                st2, raw2 = _http(txt_url, min(4, timeout - (_now() - t0)))
                text = raw2.decode("utf-8", "replace")
            except Exception:
                continue
            # skip license header
            body = text
            marker = "*** START OF"
            p0 = text.find(marker)
            if p0 != -1:
                body = text[p0:p0 + 80000]
            low = body.lower()
            pos = -1
            for w in q.lower().split():
                if len(w) < 4:
                    continue
                p = low.find(w)
                if p != -1 and (pos == -1 or p < pos):
                    pos = p
            if pos == -1:
                pos = min(4000, max(0, len(body) // 10))
            snip = re.sub(r"\s+", " ", body[max(0, pos - 80):pos + 420]).strip()
            if len(snip) < 40:
                continue
            items.append(_item(
                title.strip(), author.strip(), "", "en", snip,
                f"https://www.gutenberg.org/ebooks/{gid}", f"pg{gid}",
            ))
            if len(items) >= MAX_ITEMS:
                break
        items = _ok_items(items)
        elapsed = int((_now() - t0) * 1000)
        return _empty_result(source, "ok" if items else "empty", st, elapsed, f"q={q}", items)
    except Exception as e:
        elapsed = int((_now() - t0) * 1000)
        return _empty_result(source, _classify_http_err(e), getattr(e, "code", None),
                             elapsed, str(e)[:160])


# ----- alquran.cloud: real ayat -----
_QURAN_HINTS = ("quran", "koran", "коран", "ayah", "sura", "сура", "ayat", "аят")


def search_quran(query: str, timeout: float = PER_ARCHIVE_TIMEOUT) -> dict:
    source = "quran"
    t0 = _now()
    low = (query or "").lower()
    if not any(h in low for h in _QURAN_HINTS):
        return _empty_result(source, "empty", None, int((_now() - t0) * 1000),
                             "query not quran-related")
    q = translate_query(query) or query
    word = next((w for w in q.split() if w.lower() not in _QURAN_HINTS and len(w) > 3), "light")
    url = f"https://api.alquran.cloud/v1/search/{urllib.parse.quote(word)}/all/en.sahih"
    try:
        st, raw = _http(url, timeout)
        d = json.loads(raw.decode("utf-8", "replace"))
        items = []
        for m in ((d.get("data") or {}).get("matches") or [])[:MAX_ITEMS]:
            surah = m.get("surah") or {}
            num = m.get("numberInSurah")
            text = m.get("text") or ""
            loc = f"{surah.get('number')}:{num}"
            items.append(_item(
                f"Quran {loc}", "Saheeh International", "", "en", text,
                f"https://quran.com/{surah.get('number')}/{num}", loc,
            ))
        items = _ok_items(items)
        elapsed = int((_now() - t0) * 1000)
        return _empty_result(source, "ok" if items else "empty", st, elapsed, f"word={word}", items)
    except Exception as e:
        elapsed = int((_now() - t0) * 1000)
        return _empty_result(source, _classify_http_err(e), getattr(e, "code", None),
                             elapsed, str(e)[:160])


def _unsupported(name: str, reason: str) -> Callable:
    def fn(query: str, timeout: float = PER_ARCHIVE_TIMEOUT) -> dict:
        return _empty_result(name, "unsupported", None, 0, reason, [])
    fn.__name__ = f"search_{name}"
    return fn


search_sefaria = _unsupported("sefaria", "Cloudflare 403 from this host")
search_loc = _unsupported("loc", "Cloudflare 403")
search_harvard = _unsupported("harvard", "HTTP 429 LibraryCloud")
search_perseus = _unsupported("perseus", "Scaife SPA / hopper 503; no full-text search API")
search_bodleian = _unsupported("bodleian", "IIIF/catalog, no full-text search")
search_gallica = _unsupported("gallica", "SRU catalog ok; texteBrut captcha/blocked")
search_openlibrary = _unsupported("openlibrary", "catalog only, no passage text")
search_google_books = _unsupported("google_books", "quota 429")
search_hathitrust = _unsupported("hathitrust", "blocked 403")
search_trismegistos = _unsupported("trismegistos", "TLS cert fail")
search_zeno = _unsupported("zeno", "timeout")
search_sacred_texts = _unsupported("sacred_texts", "site now SPA wrapper, no treatise HTML")
search_rsl = _unsupported("rsl", "ALEPH catalog only, no full text")
search_vostlit = _unsupported("vostlit", "search contract unconfirmed")


LIVE_SEARCHERS: Dict[str, Callable] = {
    "sourcelibrary": search_sourcelibrary,
    "internet_archive": search_internet_archive,
    "wikisource": search_wikisource,
    "gutenberg": search_gutenberg,
    "quran": search_quran,
}

ALL_SEARCHERS = dict(LIVE_SEARCHERS)
ALL_SEARCHERS.update({
    "sefaria": search_sefaria,
    "loc": search_loc,
    "harvard": search_harvard,
    "perseus": search_perseus,
    "bodleian": search_bodleian,
    "gallica": search_gallica,
    "openlibrary": search_openlibrary,
    "google_books": search_google_books,
    "hathitrust": search_hathitrust,
    "trismegistos": search_trismegistos,
    "zeno": search_zeno,
    "sacred_texts": search_sacred_texts,
    "rsl": search_rsl,
    "vostlit": search_vostlit,
})


def search_archives(query: str, topic: None = None, include_unsupported: bool = False) -> dict:
    """Parallel search. Never returns a stub as a found book."""
    t0 = _now()
    pool = dict(ALL_SEARCHERS) if include_unsupported else dict(LIVE_SEARCHERS)
    results = []
    with ThreadPoolExecutor(max_workers=min(6, len(pool))) as ex:
        futs = {ex.submit(fn, query, PER_ARCHIVE_TIMEOUT): name for name, fn in pool.items()}
        try:
            for fut in as_completed(futs, timeout=GLOBAL_DEADLINE):
                name = futs[fut]
                try:
                    results.append(fut.result())
                except Exception as e:
                    results.append(_empty_result(name, "parse_error", None,
                                                 int((_now() - t0) * 1000), str(e)[:160]))
        except TimeoutError:
            for fut, name in futs.items():
                if not fut.done():
                    results.append(_empty_result(name, "timeout", None,
                                                 int((_now() - t0) * 1000), "global deadline"))
    elapsed = int((_now() - t0) * 1000)
    return {
        "query": query,
        "translated": translate_query(query),
        "topic": topic,
        "elapsed_ms": elapsed,
        "archives": results,
    }


if __name__ == "__main__":
    import sys
    q = " ".join(sys.argv[1:]) or "Corpus Hermeticum"
    res = search_archives(q)
    print(json.dumps(res, ensure_ascii=False, indent=2)[:8000])
