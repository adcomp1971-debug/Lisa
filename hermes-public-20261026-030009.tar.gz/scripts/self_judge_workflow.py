#!/usr/bin/env python3
"""
Self-Judge Workflow — multi-agent verification pipeline.
Usage: python3 self_judge_workflow.py --changes-desc "changed nginx config" --files "/etc/nginx/sites-available/gatebox" [--ports "80,443"] [--urls "https://example.com"]

Exit codes:
  0 = PASS (all checks passed)
  1 = PARTIAL (some failed)
  2 = FAIL (critical failures)
"""

import argparse
import json
import os
import subprocess
import sys
import time
import yaml
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(description="Self-Judge Verification Pipeline")
    parser.add_argument("--changes-desc", required=True, help="What was changed")
    parser.add_argument("--files", nargs="*", default=[], help="Files changed")
    parser.add_argument("--ports", nargs="*", default=[], help="Ports to check")
    parser.add_argument("--urls", nargs="*", default=[], help="URLs to check via curl")
    parser.add_argument("--services", nargs="*", default=[], help="Systemd services to check")
    parser.add_argument("--config-files", nargs="*", default=[], help="YAML/JSON config files to validate")
    parser.add_argument("--output", help="Path to write JSON verdict")
    return parser.parse_args()


def check_file_exists(path):
    p = Path(path)
    if p.exists():
        size = p.stat().st_size
        return {"check": "file_exists", "target": path, "status": "PASS", "detail": f"exists, {size} bytes"}
    return {"check": "file_exists", "target": path, "status": "FAIL", "detail": "file not found"}


def check_config_valid(path):
    p = Path(path)
    if not p.exists():
        return {"check": "config_valid", "target": path, "status": "FAIL", "detail": "file not found"}
    
    ext = p.suffix.lower()
    content = p.read_text()
    
    try:
        if ext in (".yaml", ".yml"):
            yaml.safe_load(content)
            return {"check": "config_valid", "target": path, "status": "PASS", "detail": "valid YAML"}
        elif ext == ".json":
            json.loads(content)
            return {"check": "config_valid", "target": path, "status": "PASS", "detail": "valid JSON"}
        elif ext == ".toml":
            import tomllib
            tomllib.loads(content)
            return {"check": "config_valid", "target": path, "status": "PASS", "detail": "valid TOML"}
        elif ext in (".py",):
            # syntax check
            result = subprocess.run(
                ["python3", "-c", f"import py_compile; py_compile.compile('{path}', doraise=True)"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                return {"check": "config_valid", "target": path, "status": "PASS", "detail": "valid Python syntax"}
            return {"check": "config_valid", "target": path, "status": "FAIL", "detail": f"Python syntax error: {result.stderr.strip()}"}
        else:
            return {"check": "config_valid", "target": path, "status": "SKIP", "detail": f"unsupported format: {ext}"}
    except Exception as e:
        return {"check": "config_valid", "target": path, "status": "FAIL", "detail": str(e)}


def check_port(port):
    result = subprocess.run(
        ["ss", "-tlnp", f"sport = :{port}"],
        capture_output=True, text=True, timeout=5
    )
    if "LISTEN" in result.stdout:
        return {"check": "port_listening", "target": f"port {port}", "status": "PASS", "detail": "LISTEN"}
    return {"check": "port_listening", "target": f"port {port}", "status": "FAIL", "detail": "not listening"}


def check_url(url):
    result = subprocess.run(
        ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", "--connect-timeout", "5", url],
        capture_output=True, text=True, timeout=10
    )
    code = result.stdout.strip()
    if code and code[0] in ("2", "3"):
        return {"check": "http_ok", "target": url, "status": "PASS", "detail": f"HTTP {code}"}
    return {"check": "http_ok", "target": url, "status": "FAIL", "detail": f"HTTP {code or 'timeout'}"}


def check_service(name):
    result = subprocess.run(
        ["systemctl", "is-active", name],
        capture_output=True, text=True, timeout=5
    )
    status = result.stdout.strip()
    if status == "active":
        return {"check": "service_active", "target": name, "status": "PASS", "detail": "active"}
    return {"check": "service_active", "target": name, "status": "FAIL", "detail": status}


def main():
    args = parse_args()
    results = []
    
    print(f"=== Self-Judge Verification ===")
    print(f"Changes: {args.changes_desc}")
    print()
    
    # 1. File existence checks
    if args.files:
        print("--- File Checks ---")
        for f in args.files:
            r = check_file_exists(f)
            results.append(r)
            print(f"  [{r['status']}] {r['target']}: {r['detail']}")
    
    # 2. Config validation
    if args.config_files:
        print("--- Config Validation ---")
        for f in args.config_files:
            r = check_config_valid(f)
            results.append(r)
            print(f"  [{r['status']}] {r['target']}: {r['detail']}")
    
    # 3. Port checks
    if args.ports:
        print("--- Port Checks ---")
        for p in args.ports:
            r = check_port(p)
            results.append(r)
            print(f"  [{r['status']}] {r['target']}: {r['detail']}")
    
    # 4. URL checks
    if args.urls:
        print("--- HTTP Checks ---")
        for u in args.urls:
            r = check_url(u)
            results.append(r)
            print(f"  [{r['status']}] {r['target']}: {r['detail']}")
    
    # 5. Service checks
    if args.services:
        print("--- Service Checks ---")
        for s in args.services:
            r = check_service(s)
            results.append(r)
            print(f"  [{r['status']}] {r['target']}: {r['detail']}")
    
    # Verdict
    fails = [r for r in results if r['status'] == 'FAIL']
    passes = [r for r in results if r['status'] == 'PASS']
    skips = [r for r in results if r['status'] == 'SKIP']
    
    print()
    if not fails:
        verdict = "PASS"
        print("=== ✅ VERDICT: PASS ===")
    elif any(r['check'] in ('http_ok', 'port_listening', 'service_active') for r in fails):
        verdict = "FAIL"
        print("=== ❌ VERDICT: FAIL (critical check failed) ===")
    else:
        verdict = "PARTIAL"
        print("=== ⚠️  VERDICT: PARTIAL ===")
    
    print(f"  {len(passes)} passed, {len(fails)} failed, {len(skips)} skipped")
    for r in fails:
        print(f"  ❌ {r['check']}: {r['target']} — {r['detail']}")
    
    # Output JSON if requested
    if args.output:
        output = {
            "verdict": verdict,
            "changes": args.changes_desc,
            "timestamp": time.time(),
            "results": results,
            "summary": {
                "total": len(results),
                "passed": len(passes),
                "failed": len(fails),
                "skipped": len(skips)
            }
        }
        with open(args.output, 'w') as f:
            json.dump(output, f, indent=2)
        print(f"\nOutput written to {args.output}")
    
    return 0 if verdict == "PASS" else (1 if verdict == "PARTIAL" else 2)


if __name__ == "__main__":
    sys.exit(main())
