#!/usr/bin/env python3
"""Монитор балансов API-провайдеров. Алерт в Telegram при балансе < порога или HTTP 429/402.
Создан 2026-08-09 после suspension Moonshot 08-08. Cron: 2x/день (09:00, 21:00).
Исправлен 2026-08-16: реальный API key вместо литерала Bearer *** .
"""
import subprocess, json, os, sys, shlex
from datetime import datetime

CHAT_ID = "420839805"
BOT_TOKEN = None
THRESHOLD_USD = 2.0

def sh(cmd, timeout=15):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip(), r.returncode
    except Exception as e:
        return str(e), -1

def get_env(name):
    with open("/root/.hermes/.env") as f:
        for line in f:
            if line.startswith(name + "="):
                return line.split("=", 1)[1].strip().strip("'\"")
    return None

def send_alert(text):
    global BOT_TOKEN
    if not BOT_TOKEN:
        BOT_TOKEN = get_env("TELEGRAM_BOT_TOKEN")
    if not BOT_TOKEN:
        return
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    subprocess.run(
        f'curl -s -X POST {url} -d chat_id={CHAT_ID} -d text={shlex.quote(text)} '
        f'-d parse_mode=Markdown > /dev/null 2>&1',
        shell=True, timeout=15
    )

problems = []
report_lines = []

# DeepSeek
try:
    key = get_env("DEEPSEEK_API_KEY")
    if key:
        out, code = sh(
            'curl -s --connect-timeout 10 https://api.deepseek.com/user/balance '
            f'-H "Authorization: Bearer {shlex.quote(key)}"'
        )
        d = json.loads(out)
        bis = d.get("balance_infos", [])
        bal = float(bis[0].get("total_balance", 0)) if bis else 0
        report_lines.append(f"DeepSeek: ${bal:.2f}")
        if bal < THRESHOLD_USD:
            problems.append(f"🔴 DeepSeek balance ${bal:.2f} < ${THRESHOLD_USD}")
except Exception as e:
    problems.append(f"DeepSeek check error: {e}")

# Moonshot (Kimi)
try:
    key = get_env("KIMI_API_KEY")
    if key:
        out, code = sh(
            'curl -s --connect-timeout 10 https://api.moonshot.ai/v1/users/me/balance '
            f'-H "Authorization: Bearer {shlex.quote(key)}"'
        )
        if '"suspended"' in out or '"insufficient"' in out.lower() or "429" in out[:50]:
            problems.append("🔴 Moonshot/Kimi: ACCOUNT SUSPENDED (insufficient balance)")
        else:
            d = json.loads(out)
            bal = float(d.get("data", {}).get("available_balance", 0))
            report_lines.append(f"Moonshot/Kimi: ${bal:.2f}")
            if bal < THRESHOLD_USD:
                problems.append(f"🔴 Moonshot/Kimi balance ${bal:.2f} < ${THRESHOLD_USD}")
except Exception as e:
    problems.append(f"Moonshot check error: {e}")

# GLM (z.ai) — публичного balance API нет (404). Проверяем доступность ключа.
try:
    key = get_env("GLM_API_KEY")
    if key:
        out, code = sh(
            'curl -s -o /dev/null -w "%{http_code}" --connect-timeout 10 '
            'https://api.z.ai/api/paas/v4/models '
            f'-H "Authorization: Bearer {shlex.quote(key)}"'
        )
        st = (out or "").strip()
        if st == "200":
            report_lines.append("GLM: ключ активен (баланс только в дашборде z.ai)")
        elif st in ("401", "403"):
            problems.append(f"🔴 GLM: ключ отклонён (HTTP {st})")
        else:
            report_lines.append(f"GLM: HTTP {st or 'нет ответа'}")
except Exception as e:
    problems.append(f"GLM check error: {e}")


msg = "💰 **Балансы** " + datetime.now().strftime("%d.%m %H:%M") + "\n" + "\n".join(report_lines)
if problems:
    msg += "\n\n" + "\n".join(problems)
    send_alert(msg)

print(msg)
