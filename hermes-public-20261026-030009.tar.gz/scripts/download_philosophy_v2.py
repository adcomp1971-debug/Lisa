#!/usr/bin/env python3
"""Скачивание 2000 книг философии с rate-limit защитой: паузы + ретраи на 429."""
import json, os, time, urllib.request, urllib.error, sys, random

OUT_DIR = '/root/hermes-box/documents/philosophy'
os.makedirs(OUT_DIR, exist_ok=True)

KEY = 'sl_data_852698919a0a58b5edb4e6a301b1f32ad2f87541b767ff47e3deb5578b384915'

def fetch(url, timeout=30, max_retries=5):
    for attempt in range(max_retries):
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': 'Mozilla/5.0',
                'Authorization': f'Bearer {KEY}',
            })
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read()
        except urllib.error.HTTPError as e:
            if e.code == 429:
                wait = 20 + attempt * 15 + random.randint(0, 10)
                print(f'  429 → жду {wait}с (попытка {attempt+1}/{max_retries})', flush=True)
                time.sleep(wait)
            elif e.code == 401:
                print(f'  401: ключ не принят', flush=True)
                raise
            else:
                raise
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(5)
            else:
                raise
    raise Exception(f'429 persistent: {url[:80]}')

def get_text(book_id, max_pages=300):
    pages = []
    for start in range(1, max_pages + 1, 50):
        end = start + 49
        try:
            d = json.loads(fetch(
                f'https://sourcelibrary.org/api/books/{book_id}/text?content=translation&from={start}&to={end}'))
            batch = d.get('pages', [])
            if not batch:
                break
            pages.extend(batch)
            if len(batch) < 50:
                break
        except Exception as e:
            print(f'  ERR {book_id} p{start}: {str(e)[:80]}', flush=True)
            break
        time.sleep(0.8)
    return pages

def main():
    with open('/root/hermes-box/documents/philosophy-2000.json', encoding='utf-8') as f:
        books = json.load(f)

    done = 0
    skipped = 0
    failed = []
    start_t = time.time()
    for i, b in enumerate(books):
        book_id = b['url'].rstrip('/').split('/')[-1]
        out = os.path.join(OUT_DIR, book_id + '.txt')
        if os.path.exists(out) and os.path.getsize(out) > 1000:
            skipped += 1
            continue
        pages = get_text(book_id)
        texts = []
        for p in pages:
            t = p.get('translation', '')
            if t and not t.startswith('[Blank') and not t.startswith('<note>'):
                texts.append(f"[page {p.get('page_number','?')}]\n{t}\n\n")
        if texts:
            with open(out, 'w', encoding='utf-8') as f:
                f.write(''.join(texts))
            done += 1
            size = os.path.getsize(out)
            if i % 10 == 0:
                el = time.time() - start_t
                rate = (i+1) / el * 60
                print(f"[{i+1}/{len(books)}] done={done} rate={rate:.0f}/мин: {b.get('title','')[:45]} → {size//1024}KB", flush=True)
        else:
            failed.append(book_id)
            if len(failed) < 10:
                print(f"[{i+1}/{len(books)}] FAIL {b.get('title','')[:50]}", flush=True)
        time.sleep(1.2)

    el = time.time() - start_t
    print(f"\nГотово: скачано={done}, пропущено={skipped}, failed={len(failed)}, время={el/60:.0f}мин", flush=True)
    if failed:
        print("Failed sample:", failed[:5], flush=True)

if __name__ == '__main__':
    main()
