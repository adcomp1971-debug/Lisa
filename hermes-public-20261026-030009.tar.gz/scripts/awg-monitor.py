#!/usr/bin/env python3
"""Monitor AWG peers and alert when a new peer connects (gets handshake).
Compares current state with previous snapshot.

Run as no_agent=True cron job. When a new peer appears, exits with non-zero
and prints the alert message (no_agent=True delivers stdout verbatim).
"""
import json
import os
import subprocess
from pathlib import Path

STATE_FILE = Path("/tmp/awg_monitor_state.json")

def get_peers():
    """Get current peer states: {allowed_ip: handshake_sec, ...}"""
    raw = subprocess.run(
        ["awg", "show", "awg0", "dump"],
        capture_output=True, text=True, timeout=10
    )
    if raw.returncode != 0:
        return {}
    
    peers = {}
    lines = [l.strip() for l in raw.stdout.strip().split("\n") if l.strip()]
    for line in lines[1:]:  # skip interface line
        parts = line.split("\t")
        if len(parts) > 6:
            ip = parts[3]
            try:
                hs = int(parts[4]) if parts[4].isdigit() else 0
            except (ValueError, IndexError):
                hs = 0
            peers[ip] = hs
    return peers


def load_state():
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {}


def save_state(peers):
    STATE_FILE.write_text(json.dumps(peers))


def format_hs(hs_sec):
    if hs_sec == 0:
        return "нет handshake"
    elif hs_sec < 60:
        return f"{hs_sec} сек"
    elif hs_sec < 3600:
        return f"{hs_sec // 60} мин"
    elif hs_sec < 86400:
        return f"{hs_sec // 3600} ч"
    else:
        return f"{hs_sec // 86400} дн"


def main():
    current = get_peers()
    previous = load_state()
    
    if not previous:
        # First run — just save state and exit quietly
        save_state(current)
        return
    
    alerts = []
    
    for ip, hs in current.items():
        prev_hs = previous.get(ip, 0)
        
        # New peer connected (had no handshake before, now has one)
        if prev_hs == 0 and hs > 0 and hs < 600:
            # Try to find name from config
            name = ip
            config_dir = Path("/etc/amnezia/amneziawg")
            if config_dir.exists():
                for conf in config_dir.glob("*.conf"):
                    content = conf.read_text()
                    if ip.split("/")[0] in content:
                        name = conf.stem
                        break
            
            alerts.append(
                f"🔔 **Новый пир подключился к AWG!**\n"
                f"└ {name} ({ip})\n"
                f"└ Handshake: {format_hs(hs)} назад"
            )
        
        # Brand new peer that just appeared
        if ip not in previous:
            name = ip
            config_dir = Path("/etc/amnezia/amneziawg")
            if config_dir.exists():
                for conf in config_dir.glob("*.conf"):
                    content = conf.read_text()
                    if ip.split("/")[0] in content:
                        name = conf.stem
                        break
            
            if hs > 0 and hs < 600:
                alerts.append(
                    f"🔔 **Новый клиент подключился к AWG!**\n"
                    f"└ {name} ({ip})\n"
                    f"└ Handshake: {format_hs(hs)} назад"
                )
    
    # Save current state for next run
    save_state(current)
    
    if alerts:
        print("\n\n".join(alerts))
        # non-zero exit so cron sends the output
        raise SystemExit(1)


if __name__ == "__main__":
    main()
