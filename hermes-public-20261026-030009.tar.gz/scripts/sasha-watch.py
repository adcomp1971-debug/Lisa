#!/usr/bin/env python3
"""Наблюдатель за подключением клиентов (Саша .102, Людвиг .104, Валера .107).

Пока нужный клиент не подключился — молчит. Как только у пира появился свежий
handshake и пошли байты — один раз печатает строку отчёта (no_agent cron доставит
её в чат) и запоминает, что про этого пира уже сообщил, чтобы не повторяться.
"""
import json
import subprocess
import time

STATE = "/root/.hermes/state/sasha-watch.json"
WATCH = {
    "10.9.0.102": "Саша",
    "10.9.0.104": "Людвиг",
    "10.9.0.107": "Валера",
}
FRESH = 600       # handshake не старше 10 минут = подключение живое
MIN_BYTES = 4096  # отсекаем единичные служебные пакеты


def main():
    try:
        st = json.load(open(STATE))
    except Exception:
        st = {}
    fired = set(st.get("fired", []))

    out = subprocess.run(["awg", "show", "awg0", "dump"], capture_output=True, text=True).stdout
    now = int(time.time())
    msgs = []
    for row in out.strip().split("\n")[1:]:
        f = row.split("\t")
        ip = f[3].split("/")[0]
        if ip not in WATCH or ip in fired:
            continue
        ep, hs, rx, tx = f[2], int(f[4]), int(f[5]), int(f[6])
        if hs > 0 and rx >= MIN_BYTES and now - hs < FRESH:
            via = "РЕЛЕЙ" if ep.startswith("127.") else "прямой вход"
            msgs.append(
                f"{WATCH[ip]} ПОДКЛЮЧИЛСЯ ({via}): рукопожатие {now - hs} с назад, "
                f"скачано {rx/1048576:.1f} МБ, отдано {tx/1048576:.1f} МБ."
            )
            fired.add(ip)

    if msgs:
        st["fired"] = sorted(fired)
        st["at"] = now
        json.dump(st, open(STATE, "w"))
        print("\n".join(msgs))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
