#!/usr/bin/env python3
"""Синхронизация Hermes memory → Graphiti knowledge graph.
Запускать по cron раз в час или при обновлении memory.

Логика:
1. Читает текущую Hermes memory из MEMORY.md
2. Добавляет новые записи в Neo4j (которых ещё нет)
3. Чистит устаревшие
4. Выводит статистику
"""
import os, sys, json, re, hashlib
from datetime import datetime, timezone

# ── cron-runtime guard (2026-09-28) ───────────────────────────────────────
# Cron запускает .py-скрипты интерпретатором шлюза (sys.executable). После
# смены runtime-поколения Hermes 25.09.2026 это managed-python БЕЗ
# site-packages, поэтому модули, стоящие в venv, скрипту не видны.
# Перезапускаемся на первом интерпретаторе, где нужные модули есть.
# См. скилл cron-reliability §12.
_NEEDED = ("neo4j",)


def _ensure_runtime():
    import glob, os, subprocess, sys

    def _ok(exe):
        try:
            return subprocess.run(
                [exe, "-c", "import " + ", ".join(_NEEDED)],
                capture_output=True, timeout=30,
            ).returncode == 0
        except Exception:
            return False

    if _ok(sys.executable):
        return
    candidates = ["/usr/local/lib/hermes-agent/venv/bin/python"]
    candidates += sorted(glob.glob("/root/.hermes/installs/*/environments/*/venv/bin/python"))
    for exe in candidates:
        if (os.path.exists(exe)
                and os.path.realpath(exe) != os.path.realpath(sys.executable)
                and _ok(exe)):
            os.execv(exe, [exe, os.path.abspath(__file__)] + sys.argv[1:])
    raise SystemExit("cron-runtime guard: нет интерпретатора с %s" % (", ".join(_NEEDED),))


_ensure_runtime()

from neo4j import GraphDatabase

NEO4J_URI = os.getenv("NEO4J_URI", "bolt://localhost:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASS = os.getenv("NEO4J_PASS", "graphiti123")
MEMORY_FILE = os.path.expanduser("~/.hermes/memories/MEMORY.md")
STATE_FILE = os.path.expanduser("~/.hermes/graphiti_state.json")

CATEGORIES = {
    "project": "Проект", "person": "Человек", "tool": "Инструмент",
    "server": "Сервер", "config": "Конфигурация", "rule": "Правило",
    "knowledge": "Знание"
}

TECH_TERMS = [
    "Hermes", "Codex", "Claude", "LongCat", "GLM", "DeepSeek",
    "Gateway", "Relay", "Nginx", "Tailscale", "Docker",
    "Neo4j", "Graphiti", "MCP", "API", "Buratino", "Pianoid",
    "Vast", "AWG", "VPN", "Telegram", "GitHub", "OpenAI", "xAI",
    "Groq", "Stunnel", "LLM", "IDE"
]
PERSON_NAMES = ["Алекс", "Дима", "Аня", "Артём", "Тимур", "Женя", "Лиса", "Саша"]


def parse_memory_file():
    """Читает MEMORY.md и возвращает список записей с хешами."""
    if not os.path.exists(MEMORY_FILE):
        print(f"Файл {MEMORY_FILE} не найден")
        return []
    
    with open(MEMORY_FILE, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    
    # Разделяем по § (разделитель записей)
    entries = []
    for line in content.split('§'):
        line = line.strip()
        if line and len(line) > 20:
            entries.append({
                "content": line[:1000],
                "hash": hashlib.md5(line.encode()).hexdigest()[:12]
            })
    return entries


def categorize(text):
    """Определяет категорию записи."""
    tl = text.lower()
    if any(w in tl for w in ["проект", "буратино", "buratino", "pianoid", "v5", "v6"]):
        return "project"
    if any(w in tl for w in ["алекс", "дима", "аня", "артём", "тимур", "женя", "лиса", "саша"]):
        return "person"
    if any(w in tl for w in ["relay", "релей", "codex", "hermes", "gateway", "claude", "модель", "провайдер"]):
        return "tool"
    if any(w in tl for w in ["сервер", "vps", "hostinger", "nginx", "tailscale", "vpn", "awg"]):
        return "server"
    if any(w in tl for w in ["config", "конфиг", "настройк", "yaml", ".env"]):
        return "config"
    if any(w in tl for w in ["правил", "запрещен", "нельзя", "только", "всегда"]):
        return "rule"
    return "knowledge"


def extract_entities(text):
    """Извлекает сущности из текста."""
    entities = set()
    for term in TECH_TERMS:
        if term.lower() in text.lower():
            entities.add(term)
    for name in PERSON_NAMES:
        if name in text:
            entities.add(name)
    return list(entities)


def main():
    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASS))
    
    # Читаем Hermes память
    entries = parse_memory_file()
    if not entries:
        print("Нет записей для синхронизации")
        # Пробуем тестовые
        entries = [{"content": "Тестовая запись", "hash": "test"}]
    
    print(f"Найдено записей в Hermes: {len(entries)}")
    
    # Читаем состояние последней синхронизации
    synced_hashes = set()
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            synced_hashes = set(json.load(f).get("hashes", []))
    
    # Новые записи (ещё не синхронизированы)
    new_entries = [e for e in entries if e["hash"] not in synced_hashes]
    print(f"Новых записей для синхронизации: {len(new_entries)}")
    
    if not new_entries:
        print("Всё уже синхронизировано")
        driver.close()
        return
    
    with driver.session() as session:
        # Убеждаемся что категории существуют
        for cid, cname in CATEGORIES.items():
            session.run("MERGE (c:Category {id: $id}) SET c.name = $name", id=cid, name=cname)
        
        added = 0
        for entry in new_entries:
            cat = categorize(entry["content"])
            entities = extract_entities(entry["content"])
            
            # Создаём узел памяти
            session.run(
                "CREATE (m:Memory {id: $id, content: $content, hash: $hash, "
                "category: $cat, created: $time})",
                id=f"mem_{entry['hash']}", content=entry["content"],
                hash=entry["hash"], cat=cat,
                time=datetime.now(timezone.utc).isoformat()
            )
            
            # Связываем с категорией
            session.run(
                "MATCH (m:Memory {id: $mid}), (c:Category {id: $cid}) "
                "CREATE (m)-[:BELONGS_TO]->(c)",
                mid=f"mem_{entry['hash']}", cid=cat
            )
            
            # Связываем с сущностями
            for entity in entities[:5]:
                session.run(
                    "MERGE (e:Entity {name: $name}) "
                    "ON CREATE SET e.created = $time",
                    name=entity, time=datetime.now(timezone.utc).isoformat()
                )
                session.run(
                    "MATCH (m:Memory {id: $mid}), (e:Entity {name: $ename}) "
                    "CREATE (m)-[:MENTIONS]->(e)",
                    mid=f"mem_{entry['hash']}", ename=entity
                )
            added += 1
        
        # Статистика
        total = session.run("MATCH (n) RETURN count(n) as c").single()["c"]
        rels = session.run("MATCH ()-[r]->() RETURN count(r) as c").single()["c"]
        print(f"Добавлено: {added}, Всего узлов: {total}, Связей: {rels}")
    
    # Сохраняем состояние
    all_hashes = {e["hash"] for e in entries}
    with open(STATE_FILE, 'w') as f:
        json.dump({"hashes": list(all_hashes), "updated": str(datetime.now(timezone.utc))}, f)
    
    driver.close()


if __name__ == "__main__":
    main()
