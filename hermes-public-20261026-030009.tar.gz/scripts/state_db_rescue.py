#!/usr/bin/env python3
"""Rescue state.db.old -> state.db.recovered2: copy intact tables, page through damaged ones."""
import sqlite3, sys, time, os

SRC = "/root/.hermes/state.db.old"
DST = "/root/.hermes/state.db.recovered2"
os.path.exists(DST) and os.remove(DST)

src = sqlite3.connect(f"file:{SRC}?mode=ro", uri=True)
src.execute("PRAGMA query_only=ON")
dst = sqlite3.connect(DST)
dst.execute("PRAGMA journal_mode=OFF")
dst.execute("PRAGMA synchronous=OFF")

# --- 1. schema (non-FTS) from source ---
schema_sql = src.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'messages_fts%' AND name NOT LIKE 'sqlite_%'").fetchall()
for (sql,) in schema_sql:
    try:
        dst.execute(sql)
    except sqlite3.Error as e:
        print(f"SKIP schema: {sql[:60]}... -> {e}")

# --- 2. copy whole tables page-by-page, catching corrupt pages ---
def copy_table(name, page=500):
    cols = [r[1] for r in src.execute(f"PRAGMA table_info({name})")]
    if not cols:
        print(f"{name}: no columns, skip"); return 0
    colsql = ",".join(cols)
    placeholders = ",".join("?" * len(cols))
    copied = 0
    lo, hi = 0, page
    while True:
        rows = []
        try:
            rows = src.execute(f"SELECT {colsql} FROM {name} WHERE rowid > ? AND rowid <= ?", (lo, hi)).fetchall()
        except sqlite3.Error as e:
            print(f"  {name}: page error at rowid {lo}-{hi}: {e}")
        if rows:
            try:
                dst.executemany(f"INSERT INTO {name} ({colsql}) VALUES ({placeholders})", rows)
            except sqlite3.Error as e:
                print(f"  {name}: INSERT error {lo}-{hi}: {e}")
            copied += len(rows)
        if len(rows) < page:
            break
        lo = hi
        hi += page
    print(f"{name}: copied {copied}")
    return copied

print("=== full tables ===")
for t in ["sessions","session_model_usage","system_prompts","async_delegations","gateway_routing","state_meta","schema_version","session_turn_leases","gateway_hygiene_state","compression_locks"]:
    try:
        copy_table(t)
    except sqlite3.Error as e:
        print(f"{t}: FAILED {e}")

print("=== damaged tables ===")
copy_table("messages", page=2000)
copy_table("delivery_obligations", page=200)

dst.commit()
dst.execute("PRAGMA journal_mode=DELETE")
dst.execute("VACUUM")
dst.commit()
print("=== dst integrity ===")
try:
    print(dst.execute("PRAGMA integrity_check").fetchall()[:5])
except sqlite3.Error as e:
    print("integrity error:", e)
print("=== dst counts ===")
for t in ["sessions","messages","session_model_usage","system_prompts","delivery_obligations","async_delegations"]:
    try:
        print(t, dst.execute(f"SELECT count(*) FROM {t}").fetchone()[0])
    except sqlite3.Error as e:
        print(t, "ERR", e)
dst.close(); src.close()
