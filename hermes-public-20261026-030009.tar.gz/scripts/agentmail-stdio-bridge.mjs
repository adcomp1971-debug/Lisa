#!/usr/bin/env node
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { ListToolsRequestSchema, CallToolRequestSchema } from '@modelcontextprotocol/sdk/types.js';

const ENDPOINT = new URL('https://mcp.agentmail.to/mcp');

async function main() {
  const apiKey = process.env.AGENTMAIL_API_KEY;
  if (!apiKey) { console.error('AGENTMAIL_API_KEY required'); process.exit(1); }

  const remote = new StreamableHTTPClientTransport(ENDPOINT, {
    requestInit: {
      headers: {
        'x-api-key': apiKey,
        'X-AgentMail-MCP-Bridge': 'hermes/1.0.0',
      },
    },
  });

  const client = new Client({ name: 'hermes-agentmail', version: '1.0.0' });
  const server = new Server(
    { name: 'agentmail', version: '1.0.0' },
    { capabilities: { tools: {} } }
  );

  server.setRequestHandler(ListToolsRequestSchema, () => client.listTools());
  server.setRequestHandler(CallToolRequestSchema, (req) => client.callTool(req.params));

  await client.connect(remote);
  await server.connect(new StdioServerTransport());
}
main().catch(e => { console.error(e.message); process.exit(1); });
