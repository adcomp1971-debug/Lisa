#!/usr/bin/env python3
"""Построение векторного индекса суперсети «Герметист».
Чанкинг → эмбеддинги (nomic-embed-text через Ollama) → numpy + метаданные.
"""
import os, json, time, glob, sys, hashlib
import numpy as np
import urllib.request

DOC_DIRS = [
    '/root/hermes-box/documents/sefaria',
    '/root/hermes-box/documents/wars',
    '/root/hermes-box/documents/classics',
    '/root/hermes-box/documents/traditio',
    '/root/hermes-box/documents/traditio_ru',
    '/root/hermes-box/documents/philosophy',
    '/root/hermes-box/documents/hermetica',
]
INDEX_DIR = '/root/hermes-box/index'
os.makedirs(INDEX_DIR, exist_ok=True)

CHUNK_SIZE = 1200
CHUNK_OVERLAP = 150
OLLAMA_URL = 'http://127.0.0.1:11434'
EMBED_MODEL = 'nomic-embed-text'

def chunk_text(text, size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    chunks = []
    i = 0
    while i < len(text):
        chunks.append(text[i:i+size])
        i += size - overlap
    return chunks

def embed(text, attempts=3):
    last = None
    for i in range(attempts):
        try:
            req = urllib.request.Request(
                f'{OLLAMA_URL}/api/embeddings',
                data=json.dumps({'model': EMBED_MODEL, 'prompt': text}).encode(),
                headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=180) as resp:
                d = json.loads(resp.read())
                return np.array(d['embedding'], dtype=np.float32)
        except Exception as e:
            last = e
            time.sleep(2 * (i + 1))
    raise last if last is not None else RuntimeError('embed failed')

def main():
    # Собираем все файлы
    files = []
    for d in DOC_DIRS:
        files.extend(glob.glob(os.path.join(d, '*.txt')))
    print(f"Файлов: {len(files)}", flush=True)

    # Ограничиваем себя одним CPU через os.sched_setaffinity (если доступно)
    try:
        os.sched_setaffinity(0, {0})  # только ядро 0
        print("CPU affinity: только ядро 0 (не душим сервер)", flush=True)
    except Exception as e:
        print(f"affinity не удалось: {e}", flush=True)

    # Проверяем уже обработанные (по метаданным)
    # ВАЖНО: meta.json — СПИСОК записей (по одной на чанк), НЕ словарь по имени файла!
    # Словарь {file: entry} оставлял 1 чанк на файл и терял ~118k записей (баг 2026-09-12).
    meta_path = os.path.join(INDEX_DIR, 'meta.json')
    existing_meta = []
    if os.path.exists(meta_path):
        with open(meta_path) as f:
            existing_meta = json.load(f)
        if not isinstance(existing_meta, list):
            raise SystemExit('meta.json повреждён: ожидался список записей')
        print(f"Уже проиндексировано записей: {len(existing_meta)}", flush=True)

    all_embeddings = []
    all_meta = []

    # Сначала загружаем существующие
    if os.path.exists(os.path.join(INDEX_DIR, 'embeddings.npy')):
        all_embeddings = list(np.load(os.path.join(INDEX_DIR, 'embeddings.npy')))
        all_meta = list(existing_meta)
        if len(all_embeddings) != len(all_meta):
            raise SystemExit(f'РАСХОЖДЕНИЕ: embeddings={len(all_embeddings)} meta={len(all_meta)} — НЕ индексировать, чинить вручную')
        print(f"Загружено из файла: {len(all_embeddings)}", flush=True)

    indexed_files = {e.get('file') for e in all_meta}

    done = 0
    for fi, fpath in enumerate(files):
        try:
            size = os.path.getsize(fpath)
            if size > 30_000_000:  # пропуск гигантов > 30MB
                continue
            with open(fpath, encoding='utf-8', errors='ignore') as f:
                content = f.read()
            if len(content) < 200:
                continue

            # Хэш для дедупа
            h = hashlib.md5(content[:10000].encode()).hexdigest()
            rel = fpath.replace('/root/hermes-box/documents/', '')
            if rel in indexed_files:
                continue

            chunks = chunk_text(content)
            for ci, chunk in enumerate(chunks):
                emb = embed(chunk)
                all_embeddings.append(emb)
                all_meta.append({
                    'file': rel,
                    'chunk': ci,
                    'hash': h,
                    'size': size,
                })
            done += 1
            if done % 20 == 0:
                print(f"[{fi+1}/{len(files)}] файлов: {done}, чанков: {len(all_embeddings)}", flush=True)
                # Периодическое сохранение
                np.save(os.path.join(INDEX_DIR, 'embeddings.npy'), np.array(all_embeddings))
                with open(meta_path, 'w') as f:
                    json.dump(all_meta, f)
        except Exception as e:
            print(f"ERR {fpath}: {str(e)[:80]}", flush=True)

    # Финальное сохранение
    np.save(os.path.join(INDEX_DIR, 'embeddings.npy'), np.array(all_embeddings))
    with open(meta_path, 'w') as f:
        json.dump(all_meta, f)
    print(f"\nГОТОВО: файлов={done}, чанков={len(all_embeddings)}", flush=True)
    print(f"Размер индекса: {os.path.getsize(os.path.join(INDEX_DIR, 'embeddings.npy'))/1048576:.0f} MB", flush=True)

if __name__ == '__main__':
    main()
