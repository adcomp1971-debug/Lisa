#!/usr/bin/env python3
"""
YouTube Scout Collector — no_agent скрипт.
Собирает новые видео с AI-каналов через Invidious API.
Запуск: python3 ~/.hermes/scripts/youtube-scout-collector.py
Выхлоп: новые видео (если есть) или "Новых видео нет"
"""
import sqlite3
import json, os, sys, time
from urllib.request import urlopen, Request
from datetime import datetime, timezone

DB_PATH = os.path.expanduser("~/.hermes/youtube_scout.db")

# AI-каналы: (channel_id, name) — YouTube ID
CHANNELS = [
    ("UCg1aUKk6w2QlG3Dq0P0vPvA", "Karpathy"),
    ("UCsBjURrPoezykLs9EqgamOA", "AI Explained"),  # corrected ID
    ("UCbfYPyITQ-7l4upoX8nvctg", "Two Minute Papers"),
    ("UCfY1CYf4j3_D0G_OJ2HIIXQ", "Yannic Kilcher"),
    ("UCLLw7jmQD1KMD4-6VwKjJ2A", "Stanford MLSys"),
    ("UCcIv0dLpEeNcJQz3y0H0z0A", "Deep Learning AI"),
    ("UC6L9Y3N4T0oFQn4E5w0G0fQ", "NVIDIA Developer"),
    ("UCdN9LMNkQKfGtHKJnJOeOjg", "Umar Jamil"),
    ("UCiJ0q0z9Z9w0i5z9az0i0iQ", "Wes Roth"),
]

INVIDIOUS_INSTANCES = ["https://inv.nadeko.net", "https://yewtu.be"]

def get_conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS channels (
            channel_id TEXT PRIMARY KEY,
            name TEXT,
            last_checked TEXT
        );
        CREATE TABLE IF NOT EXISTS videos (
            video_id TEXT PRIMARY KEY,
            channel_id TEXT,
            title TEXT,
            url TEXT,
            published TEXT,
            detected_at TEXT,
            summarized INTEGER DEFAULT 0
        );
    """)
    for cid, name in CHANNELS:
        conn.execute("INSERT OR IGNORE INTO channels (channel_id, name) VALUES (?, ?)", (cid, name))
    conn.commit()
    return conn

def fetch_channel_videos(channel_id):
    """Try Invidious instances, return list of video dicts."""
    for base in INVIDIOUS_INSTANCES:
        url = f"{base}/api/v1/channels/{channel_id}"
        try:
            req = Request(url, headers={"User-Agent": "Hermes/1.0"})
            with urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                return data.get("latestVideos", [])
        except Exception:
            continue
    return []

def main():
    conn = get_conn()
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    total_new = 0
    new_videos = []

    for channel_id, channel_name in CHANNELS:
        videos = fetch_channel_videos(channel_id)
        if not videos:
            print(f"⚠ {channel_name}: недоступен", file=sys.stderr)
            continue

        for v in videos:
            vid = v.get("videoId")
            title = v.get("title", "")
            if not vid:
                continue
            url = f"https://youtube.com/watch?v={vid}"
            published = v.get("published", "")

            existing = conn.execute("SELECT video_id FROM videos WHERE video_id=?", (vid,)).fetchone()
            if not existing:
                conn.execute(
                    "INSERT INTO videos (video_id, channel_id, title, url, published, detected_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (vid, channel_id, title, url, published, now)
                )
                total_new += 1
                new_videos.append((channel_name, title, url))

        conn.execute("UPDATE channels SET last_checked=? WHERE channel_id=?", (now, channel_id))

    conn.commit()
    conn.close()

    if total_new == 0:
        print("Новых видео нет")
    else:
        print(f"# 🎬 YouTube Scout: {total_new} новых видео")
        print()
        for ch, title, url in new_videos:
            print(f"**[{ch}]** {title[:100]}")
            print(f"  {url}")
            print()

    return 0

if __name__ == "__main__":
    sys.exit(main())
