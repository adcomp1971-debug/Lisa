#!/usr/bin/env python3
# make_pdf.py <title> <input_md> <output_name>
# Converts markdown to PDF via weasyprint.
# Input: markdown with ## sections and - bullets.
import sys, os, datetime
from weasyprint import HTML

title = sys.argv[1]
infile = sys.argv[2]
outname = sys.argv[3]
OUTDIR = "/var/www/gatebox/files"

date_str = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

# Build HTML body from markdown-like input
body_parts = []
for raw in open(infile, encoding="utf-8"):
    line = raw.rstrip("\n")
    if not line.strip():
        continue
    if line.startswith("## "):
        body_parts.append(f"<h2>{line[3:]}</h2>")
    elif line.startswith("- "):
        cls = ' class="warn"' if line.startswith("- !! ") else ''
        text = line[2:] if not line.startswith("- !! ") else line[5:]
        body_parts.append(f"<li{cls}>{text}</li>")
    else:
        body_parts.append(f"<p>{line}</p>")

body = "\n".join(body_parts)
# Wrap consecutive <li> in <ul>
import re
body = re.sub(r'(<li[^>]*>.*?</li>\n?)+', lambda m: f"<ul>\n{m.group(0)}</ul>\n", body)

html = f"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<style>
  @page {{ size: A4; margin: 18mm 18mm 20mm 18mm; }}
  body {{ font-family: 'DejaVu Sans', sans-serif; font-size: 10pt; line-height: 1.5; color: #1a1a1a; }}
  h1 {{ font-size: 16pt; margin: 0 0 2mm 0; }}
  .date {{ font-size: 8pt; color: #888; margin-bottom: 6mm; }}
  h2 {{ font-size: 12pt; margin: 5mm 0 2mm 0; border-bottom: 1px solid #ddd; padding-bottom: 1mm; }}
  ul {{ margin: 0 0 3mm 0; padding-left: 5mm; }}
  li {{ margin-bottom: 1mm; }}
  p {{ margin: 0 0 2mm 0; }}
  .warn {{ color: #c00; font-weight: bold; }}
</style>
</head>
<body>
<h1>{title}</h1>
<div class="date">{date_str}</div>
{body}
</body>
</html>"""

out = os.path.join(OUTDIR, outname + ".pdf")
HTML(string=html).write_pdf(out)
print(out)
