#!/bin/bash
# Утренний целевой прогон vision A/B после сброса квоты Gemini (07:00 UTC).
# Печатает: построчный ход + блок СВОДКА.
cd /root/.hermes/cache/scratch || exit 1
exec python3 vision_ab.py gemini-3.8-flash gemini-3.6-flash 2>&1
