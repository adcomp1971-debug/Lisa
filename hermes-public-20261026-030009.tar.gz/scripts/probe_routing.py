import re, json, ssl, urllib.request, time, yaml

cfg = yaml.safe_load(open('/root/.hermes/config.yaml'))
env = {}
for line in open('/root/.hermes/.env'):
    line = line.strip()
    if '=' in line and not line.startswith('#'):
        k, v = line.split('=', 1); env[k] = v.strip().strip('"').strip("'")

ENDPOINTS = {
    'deepseek': 'https://api.deepseek.com/v1/chat/completions',
    'xai': 'https://api.x.ai/v1/chat/completions',
    'google': 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
    'openai': 'https://api.openai.com/v1/chat/completions',
    'moonshot': 'https://api.moonshot.ai/v1/chat/completions',
    'longcat': 'https://api.longcat.chat/openai/v1/chat/completions',
    'glm': 'https://api.z.ai/api/paas/v4/chat/completions',
}
KEYS = {'deepseek':'DEEPSEEK_API_KEY','xai':'XAI_API_KEY','google':'GEMINI_API_KEY',
        'openai':'OPENAI_API_KEY','moonshot':'KIMI_API_KEY','longcat':'LONGCAT_API_KEY','glm':'GLM_API_KEY'}

def probe(provider, model, reasoning=False):
    key = env.get(KEYS.get(provider, ''), '')
    if not key:
        return 'нет ключа'
    payload = {"model": model, "messages": [{"role": "user", "content": "2+2? Одним словом."}]}
    payload["max_tokens" if provider != 'openai' else "max_completion_tokens"] = 900
    t0 = time.time()
    try:
        req = urllib.request.Request(ENDPOINTS[provider], data=json.dumps(payload).encode(),
            headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=90) as r:
            d = json.loads(r.read())
        txt = (d['choices'][0]['message'].get('content') or '').strip()
        return f"✅ {txt[:25]!r} {time.time()-t0:.1f}s" if txt else f"⚠️ пусто {time.time()-t0:.1f}s"
    except Exception as e:
        body = getattr(e, 'read', lambda: b'')()
        return f"❌ {str(e)[:38]} {body.decode()[:60]}"

print("╔══════════════════════════════════════════════════════════════════╗")
print("║                    ЦЕПОЧКА HERMES (LIVE)                        ║")
print("╚══════════════════════════════════════════════════════════════════╝\n")

print("【1】 MAIN — основной ответчик")
m = cfg['model']
print(f"     {m['default']}  ({m['provider']})")
print(f"     └─ {probe(m['provider'], m['default'])}\n")

print("【2】 FALLBACK — при отказе main (по порядку)")
for i, f in enumerate(cfg['fallback_providers'], 1):
    print(f"     {i}. {f['model']:26s} ({f['provider']})")
    print(f"        └─ {probe(f['provider'], f['model'])}")
print()

print("【3】 VISION — изображения от пользователя")
v = cfg['auxiliary']['vision']
print(f"     {v['model']} ({v['provider']})")
print(f"     └─ {probe(v['provider'], v['model'])}\n")

print("【4】 COMPRESSION — сжатие контекста")
c = cfg['compression']
print(f"     {c['model']} (порог {c['threshold']}, ratio {c['target_ratio']})\n")

print("【5】 DELEGATION — субагенты для сложных задач")
d = cfg['delegation']
print(f"     {d['model']} ({d['provider']}, effort={d['reasoning_effort']}, timeout={d['child_timeout_seconds']}s)")
print(f"     └─ {probe(d['provider'], d['model'])}\n")

print("【6】 LOCAL RELAYS — Claude Code / Codex CLI")
# ВАЖНО: у каждого релея своя модель — с чужим именем он отдаёт 400/404 (это НЕ поломка).
# stunnel-порты говорят по TLS, поэтому scheme='https' (plain HTTP рвёт соединение).
_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode = ssl.CERT_NONE
RELAYS = [
    (4455, 'codex-grok',      'http',  '/v1/responses', {"model": "grok-4.7", "input": "ping", "max_output_tokens": 16}),
    (4448, 'codex-kimi',      'http',  '/v1/responses', {"model": "kimi-k3", "input": "ping", "max_output_tokens": 16}),
    (4446, 'codex-ds',        'http',  '/v1/responses', {"model": "deepseek-flash", "input": "ping", "max_output_tokens": 16}),
    (4454, 'claude-grok',     'http',  '/v1/messages',  {"model": "grok-4.7", "max_tokens": 16, "messages": [{"role": "user", "content": "ping"}]}),
    (4451, 'stunnel→longcat', 'https', '/v1/messages',  {"model": "longcat-2.0", "max_tokens": 16, "messages": [{"role": "user", "content": "ping"}]}),
    (4452, 'stunnel→kimi',    'https', '/v1/messages',  {"model": "kimi-k3", "max_tokens": 16, "messages": [{"role": "user", "content": "ping"}]}),
]
for port, name, scheme, path, payload in RELAYS:
    try:
        t0 = time.time()
        req = urllib.request.Request(f'{scheme}://127.0.0.1:{port}{path}',
            data=json.dumps(payload).encode(),
            headers={'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=30,
                                    context=_ssl_ctx if scheme == 'https' else None) as r:
            body = r.read(400).decode('utf-8', 'replace')
            status = r.status
        bad = '"error"' in body or status != 200
        print(f"     :{port} {name:14s} "
              f"{'⚠️ HTTP ' + str(status) + ' — релей ответил ошибкой' if bad else '✅ HTTP 200'} "
              f"({time.time()-t0:.1f}s)")
    except Exception as e:
        code = getattr(e, 'code', None)
        print(f"     :{port} {name:14s} {'⚠️ HTTP '+str(code) if code else '❌ ' + str(e)[:35]}")
