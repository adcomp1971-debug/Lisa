#!/usr/bin/env python3
"""Telegram daily digest — fetches latest posts from subscribed channels and outputs a summary.

Usage:
    python3 tg_digest.py           # Today's posts from all channels
    python3 tg_digest.py --hours 6  # Posts from last 6 hours
    python3 tg_digest.py --search "орешник"  # Search specific topic
"""

import asyncio
import sys
import argparse
from datetime import datetime, timezone, timedelta
from telethon import TelegramClient

API_ID = 36633463
API_HASH = "6227801e5ea910daccde171aeec5b7da"
SESSION_FILE = "/root/.hermes/telegram_session"

# Alex's channel list
CHANNELS = {
    # Personal
    "Анатолий Шарий": "@ASupersharij",
    "Фронтовая птичка": "@frontbird",
    "Win-Win": "@victorstepanych",
    "Dambiev": "@ChDambiev",
    "Мир в Моменте": "@MIrvMomente",
    # News
    "BB Breaking": "@bbbreaking",
    "РИА Новости": "@rian_ru",
    "Военный Осведомитель": "@milinfolive",
    "RT на русском": "@rt_russian",
    "ТАСС": "@tass_agency",
}

TOPICS = [
    "Украина", "Россия", "СВО", "Орешник", "переговоры",
    "США", "Иран", "Китай", "ЕС", "НАТО",
    "Белгород", "Курск", "Донбасс", "Крым",
]

MIN_POST_LENGTH = 80  # Skip short/templated posts


async def fetch_digest(hours: int = 24, search: str = None, max_per_channel: int = 5):
    """Fetch posts from all channels, optionally filtering by time/search."""
    client = TelegramClient(SESSION_FILE, API_ID, API_HASH)
    await client.start()

    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    all_posts = []

    for name, uname in CHANNELS.items():
        try:
            entity = await client.get_entity(uname)
            messages = await client.get_messages(entity, limit=50)
            posts = []
            for msg in messages:
                if not msg.text or len(msg.text) < MIN_POST_LENGTH:
                    continue
                if msg.date and msg.date < cutoff:
                    continue
                if search and search.lower() not in msg.text.lower():
                    continue
                posts.append({
                    "channel": name,
                    "username": uname,
                    "date": msg.date.isoformat() if msg.date else "",
                    "text": msg.text[:400],
                    "views": getattr(msg, 'views', 0) or 0,
                })
            posts = posts[:max_per_channel]
            all_posts.extend(posts)
        except Exception as e:
            print(f"  ✗ {name}: {e}", file=sys.stderr)

    all_posts.sort(key=lambda p: p["date"], reverse=True)

    # Output
    search_tag = f' по теме "{search}"' if search else ""
    print(f"**Дайджест Telegram-каналов** — последние {hours}ч{search_tag}")
    print(f"_{datetime.now().strftime('%d.%m.%Y %H:%M')} UTC_")
    print()

    current_channel = None
    for p in all_posts:
        if p["channel"] != current_channel:
            current_channel = p["channel"]
            print(f"### {p['channel']} ({p['username']})")
            print()

        dt = datetime.fromisoformat(p["date"]).strftime("%H:%M") if p["date"] else ""
        text = p["text"].replace("\n", "\n> ")
        print(f"**{dt}** — {text}")
        print()

    print(f"── {len(all_posts)} постов из {len(set(p['channel'] for p in all_posts))} каналов")

    await client.disconnect()


def main():
    parser = argparse.ArgumentParser(description="Telegram digest")
    parser.add_argument("--hours", type=int, default=24, help="Hours back to fetch")
    parser.add_argument("--search", help="Filter by keyword")
    parser.add_argument("--max", type=int, default=5, help="Max posts per channel")
    args = parser.parse_args()
    asyncio.run(fetch_digest(args.hours, args.search, args.max))


if __name__ == "__main__":
    main()
