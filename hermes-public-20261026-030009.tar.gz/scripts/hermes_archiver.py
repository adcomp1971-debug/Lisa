#!/usr/bin/env python3
"""
Hermes Archiver — гибридная сеть знаний.
Каскад: локальная база → Sefaria API → Source Library MCP/API → Internet Archive → веб.

Каждый ответ возвращается с указанием источника и ссылкой.
"""
import json, os, re, urllib.request, urllib.parse, urllib.error, time, sys
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed

# ===== Конфигурация =====
SEFARIA_API = 'https://www.sefaria.org/api'
SOURCE_LIB_API = 'https://sourcelibrary.org/api'
SOURCE_LIB_KEY = os.environ.get('SOURCE_LIBRARY_API_KEY', '')
if not SOURCE_LIB_KEY:
    try:
        with open('/root/.hermes/.env') as _ef:
            for _ln in _ef:
                if _ln.startswith('SOURCE_LIBRARY_API_KEY='):
                    SOURCE_LIB_KEY = _ln.split('=', 1)[1].strip().strip('"').strip("'")
                    break
    except Exception:
        pass

# Академический порядок: герметика/философия/классика раньше traditio (Эвола не должна быть первой).
LOCAL_DIRS = [
    '/root/hermes-box/documents/hermetica',
    '/root/hermes-box/documents/philosophy',
    '/root/hermes-box/documents/classics',
    '/root/hermes-box/documents/rus_history',
    '/root/hermes-box/documents/wars',
    '/root/hermes-box/documents/sefaria',
    '/root/hermes-box/documents/traditio',
    '/root/hermes-box/documents/traditio_ru',
]
_TRADITIO_OK = (
    'эвола', 'эвол', 'evola', 'генон', 'guenon', 'головин', 'дугин', 'dugin',
    'шуон', 'шаон', 'schuon', 'традиционал', 'юга', 'юге', 'юги', 'yuga', 'kali', 'кали',
    'дхарма', 'дхарм', 'dharma', 'карма', 'карм', 'karma', 'тантра', 'тантр', 'tantra',
    'нирвана', 'нирван', 'nirvana', 'йога', 'йоге', 'yoga',
    'мамай', 'куликов',
    # герметика / практики (2026-09-12) — иначе папка traditio не сканируется
    'практик', 'practice', 'practices', 'герметич', 'hermetic', 'hermeticism',
    'теург', 'theurgy', 'алхим', 'alchemy', 'alchemical',
    'парацельс', 'paracelsus', 'поймандр', 'поимандр', 'poimandres', 'pymander',
    'асклепий', 'asclepius', 'аскез', 'ascetic', 'созерцани', 'contemplation',
    'спагир', 'spagyric', 'магия', 'magic', 'magus', 'ритуал', 'ritual',
    'посвящени', 'initiation', 'гермес', 'hermes', 'трисмегист', 'trismegistus',
    'камень', 'philosopher', 'киновар', 'cinnabar', 'мистери', 'mystery',
)
_JUNK_TITLE = (
    'гарри поттер', 'harry potter', 'isbn', 'cataloging-in-publication',
    'library of congress', 'kindle', 'fanfic', 'wikipedia', 'википеди',
    'poissons', 'prosopography', 'milch-cow', 'ganong', 'ganung',
    'william augustus guenon',
)
# Имена/якоря: если они в запросе — должны быть в названии/авторе, не только в сниппете
# (иначе «guenon» = фр. «мартышка» → книги про рыб / просопография).
_NAME_ANCHORS = (
    ('guenon', 'guénon', 'guéon', 'генон'),
    ('evola', 'эвола'),
    ('schuon', 'шуон', 'шаон'),
    ('guénon',),
)
# Тематические якоря: обязаны быть в title/author (не случайно в сниппете)
_TOPIC_TITLE_ANCHORS = (
    ('jerusalem', 'иерусалим', 'hierusalem', 'ierosolyma', 'yerushalayim'),
    ('stalingrad', 'сталинград'),
    ('nevsky', 'невск', 'ledovoe', 'ледов', 'livonia', 'livon', 'peipus', 'чудск'),
)

# ===== Уровень 1: локальная база (полнотекстовый поиск) =====
def search_local(query, limit=5, dirs=None):
    """Простой полнотекстовый поиск по локальным файлам.
    Требуем совпадения МИНИМУМ 2 слов запроса (не считая стоп-слов), иначе результат слабый."""
    STOP = {'что','как','такое','это','кто','где','почему','зачем','когда','какой','какая','какие','такой','такая','такие','по','о','и','в','на','не','мне','с','у','для','про','about','the','and','what','who','why','how','does','is','are','of','to','in','a','an',
            'пишет','пишут','написал','говорит','сказал','говорил','написано','есть','был','была','были','быть','стал','стала'}
    ALIAS = {
        'куликовская': ['kulikovo', 'kulikovskaya'],
        'куликовской': ['kulikovo', 'kulikovskaya'],
        'битва': ['bitva'],
        'летопись': ['letopis'],
        'мамай': ['mamai'],
        'сефирот': ['sephirot', 'sefirot', 'sephiroth'],
        'кали': ['kali'],
        'юга': ['yuga'],
        'юге': ['yuga'],
        'юги': ['yuga'],
        'шаон': ['schuon', 'шуон'],
        'шуон': ['schuon', 'шаон'],
        'меркава': ['merkavah', 'merkaba'],
        'меркавы': ['merkavah', 'merkaba'],
        'меркав': ['merkavah', 'merkaba'],
        'каббала': ['kabbalah', 'qabbalah', 'cabala'],
        'каббале': ['kabbalah', 'qabbalah', 'cabala'],
        'дхарма': ['dharma'],
        'дхарме': ['dharma'],
        'дхармы': ['dharma'],
        'дхарм': ['dharma'],
        'карма': ['karma'],
        'карме': ['karma'],
        'кармы': ['karma'],
        'карм': ['karma'],
        'тантра': ['tantra'],
        'тантре': ['tantra'],
        'тантр': ['tantra'],
        'нирвана': ['nirvana'],
        'нирване': ['nirvana'],
        'нирван': ['nirvana'],
        'йога': ['yoga'],
        'йоге': ['yoga'],
        'эвола': ['evola'],
        'эволе': ['evola'],
        'эволы': ['evola'],
        'эвол': ['evola'],
        'генон': ['guenon'],
        'геноне': ['guenon'],
        'генона': ['guenon'],
        'геноном': ['guenon'],
        'талмуд': ['talmud'],
        'талмуде': ['talmud'],
        'мишна': ['mishnah', 'mishna'],
        'мишне': ['mishnah', 'mishna'],
        'тора': ['torah'],
        'торе': ['torah'],
        'зоар': ['zohar'],
        'зоаре': ['zohar'],
        'танах': ['tanakh'],
        'мидраш': ['midrash'],
        'гемара': ['gemara'],
        'шаббат': ['shabbat'],
        'канон': ['canon'],
        'сефард': ['sefard'],
        'хасид': ['hasid', 'chasid'],
        'раввин': ['rabbi', 'rabbinic'],
        'иудей': ['jewish', 'judaism'],
        # герметика: практики (2026-09-12) — без этого русские запросы давали 0
        'практика': ['practice', 'practices', 'practical'],
        'практики': ['practice', 'practices', 'practical'],
        'практике': ['practice', 'practices', 'practical'],
        'практику': ['practice', 'practices'],
        'практик': ['practice', 'practices', 'practical'],
        'теургия': ['theurgy', 'theurgic'],
        'теургии': ['theurgy'],
        'теургию': ['theurgy'],
        'алхимия': ['alchemy', 'alchemical'],
        'алхимии': ['alchemy', 'alchemical'],
        'алхимию': ['alchemy'],
        'аскеза': ['asceticism', 'ascetic'],
        'аскетизм': ['asceticism', 'ascetic'],
        'созерцание': ['contemplation', 'contemplative'],
        'спагирия': ['spagyria', 'spagyric'],
        'спагирика': ['spagyria', 'spagyric'],
        'парацельс': ['paracelsus'],
        'парацельса': ['paracelsus'],
        'поймандр': ['poimandres', 'pymander'],
        'поимандр': ['poimandres', 'pymander'],
        'герметизм': ['hermeticism', 'hermetic'],
        'герметическая': ['hermetic'],
        'герметические': ['hermetic'],
        'герметической': ['hermetic'],
        'герметическую': ['hermetic'],
        'молитва': ['prayer'],
        'молитвы': ['prayer'],
        'гимн': ['hymn'],
        'ритуал': ['ritual', 'initiatory'],
        'посвящение': ['initiation'],
        'возрождение': ['rebirth', 'regeneration'],
        'асклепий': ['asclepius'],
        'гермес': ['hermes', 'trismegistus'],
    }
    orig_words = [w.lower() for w in query.replace('-', ' ').split() if len(w) >= 3 and w.lower() not in STOP]
    if not orig_words:
        return []
    results = []
    ql = query.lower()
    trad_ok = any(t in ql for t in _TRADITIO_OK)
    scan = LOCAL_DIRS
    if dirs is not None:
        if not dirs:
            return []
        want = tuple(dirs)
        scan = [d for d in LOCAL_DIRS if any(w in d for w in want)]
    for d in scan:
        if not os.path.isdir(d):
            continue
        if ('traditio' in d) and not trad_ok and (not dirs or 'traditio' not in ''.join(dirs)):
            continue
        for fname in os.listdir(d):
            if not fname.endswith('.txt'):
                continue
            fpath = os.path.join(d, fname)
            try:
                size = os.path.getsize(fpath)
                if size > 20_000_000:
                    continue
                with open(fpath, encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                low = content.lower()
                fname_low = fname.lower().replace('_', ' ').replace('-', ' ')
                blob = low + ' ' + fname_low
                matched_orig = []
                for w in orig_words:
                    alts = [w] + ALIAS.get(w, [])
                    if any(a in blob for a in alts):
                        matched_orig.append(w)
                # ≥2 разных слов запроса; одно слово — только если оно в ИМЕНИ файла
                name_hit = False
                for w in orig_words:
                    alts = [w] + ALIAS.get(w, [])
                    if any(a in fname_low for a in alts):
                        name_hit = True
                        break
                known = any(
                    any(t in w or w in t for t in _TRADITIO_OK) or w in ALIAS
                    for w in orig_words
                )
                single_known = known and bool(matched_orig) and (
                    len(orig_words) == 1 or name_hit or any(
                        any(t in m or m in t for t in _TRADITIO_OK) or m in ALIAS
                        for m in matched_orig
                    )
                )
                if len(matched_orig) >= 2 or name_hit or (len(orig_words) == 1 and matched_orig) or single_known:
                    score = sum(blob.count(a) for w in matched_orig for a in ([w]+ALIAS.get(w,[])))
                    if name_hit:
                        score += 50
                    # Бонус +10000 для rus_history УБРАН (аудит Astra, правка A).
                    # Он давал ПВЛ безусловное первое место на любом русском запросе
                    # (score ~10003 при реальных совпадениях 2-3), из-за чего летопись
                    # вытесняла релевантные источники. Русские документы должны
                    # выигрывать честным счётом вхождений, а совпадение названия/автора
                    # уже учтено в name_hit (+50).
                    if '/sefaria/' in fpath and not (dirs and 'sefaria' in dirs):
                        score -= 100
                    results.append({
                        'source': 'local',
                        'book': fname.replace('.txt','').replace('_',' ')[:60],
                        'score': score,
                        'snippet': _snippet(content, orig_words + [a for w in orig_words for a in ALIAS.get(w,[])]),
                        'file': fpath,
                        'matched': matched_orig,
                    })
            except Exception:
                continue
    results.sort(key=lambda x: -x['score'])
    return results[:limit]

def _snippet(content, words, width=400):
    low = content.lower()
    best_pos = -1
    best_score = 0
    for w in words:
        pos = low.find(w)
        if pos != -1:
            # считаем сколько слов рядом
            score = 1
            for w2 in words:
                p2 = low.find(w2, max(0, pos-500), pos+500)
                if p2 != -1:
                    score += 1
            if score > best_score:
                best_score = score
                best_pos = pos
    if best_pos == -1:
        return content[:width]
    start = max(0, best_pos - width//2)
    return '...' + content[start:start+width] + '...'

# ===== Уровень 2: Sefaria API =====
def search_sefaria(query, limit=3):
    """Поиск по иудаике через Sefaria API."""
    try:
        url = f'{SEFARIA_API}/search/{urllib.parse.quote(query)}?size={limit}'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            d = json.loads(resp.read())
        results = []
        for hit in d.get('hits', [])[:limit]:
            results.append({
                'source': 'sefaria',
                'book': hit.get('title', ''),
                'score': hit.get('score', 0),
                'snippet': hit.get('excerpt', '')[:400],
                'url': f"https://www.sefaria.org/{urllib.parse.quote(hit.get('ref',''))}",
            })
        return results
    except Exception as e:
        return [{'source': 'sefaria', 'error': str(e)[:100]}]

# ===== Уровень 3: Source Library API =====
def _sl_get(path, timeout=12):
    headers = {'User-Agent': 'Hermetist/1.0', 'Accept': 'application/json'}
    if SOURCE_LIB_KEY:
        headers['Authorization'] = f'Bearer {SOURCE_LIB_KEY}'
    req = urllib.request.Request(SOURCE_LIB_API + path, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())

def _sl_mcp(tool, arguments, timeout=25):
    """JSON-RPC tools/call на sourcelibrary.org/api/mcp — пассажи, не каталог.
    Ретраи на 429/5xx с паузами (rate limit ~1.2с+)."""
    payload = {
        "jsonrpc": "2.0", "id": 1,
        "method": "tools/call",
        "params": {"name": tool, "arguments": arguments},
    }
    headers = {
        "User-Agent": "Mozilla/5.0 Hermetist",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if SOURCE_LIB_KEY:
        headers["Authorization"] = f"Bearer {SOURCE_LIB_KEY}"
    last_err = None
    for attempt in range(3):
        if attempt:
            time.sleep(1.2 * attempt)
        try:
            req = urllib.request.Request(
                "https://sourcelibrary.org/api/mcp",
                data=json.dumps(payload).encode(),
                headers=headers,
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                d = json.loads(resp.read())
            if d.get("error"):
                raise RuntimeError(str(d["error"])[:120])
            content = ((d.get("result") or {}).get("content") or [])
            text = ""
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    text = part.get("text") or ""
                    break
            if not text and isinstance(d.get("result"), dict) and "passages" in (d.get("result") or {}):
                return d["result"]
            if not text:
                return {}
            try:
                return json.loads(text)
            except Exception:
                return {"raw": text[:200]}
        except urllib.error.HTTPError as e:
            last_err = f"HTTP {e.code}"
            if e.code in (429, 500, 502, 503):
                time.sleep(2 * (attempt + 1))
                continue
            raise
        except Exception as e:
            last_err = str(e)[:100]
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(last_err or "SL fail")

def search_sourcelib(query, limit=6):
    """Пассажи Source Library: search_translations, затем search_concept. Не каталог GET /search."""
    junk = (
        "ленин", "lenin", "гоголь", "gogol", "салтыков", "крылов", "krylov",
        "горький", "капитализм", "blavatsky", "isis unveiled",
    )
    ql = (query or "").lower()
    templar_q = "templar" in ql or "тампли" in ql
    rus_q = any(x in ql for x in ("nevsky", "battle of the ice", "karamzin", "chronicle", "летопис", "ледов",
                                  "vladimir", "baptism", "troubles", "dmitry", "oprichnina", "russia", "russian",
                                  "lomonosov", "нестор", "русск", "москов", "смут", "опричнин"))
    mil_q = any(x in ql for x in ("brusilov", "offensive", "1916", "верден", "сомм", "ww1",
                                  "stalingrad", "borodino", "napoleon", "verdun", "constantinople", "ottoman",
                                  "world war", "siege", "битв", "сражен", "войн", "осад"))
    try:
        data = _sl_mcp("search_translations", {"query": query, "limit": max(limit, 12)})
        passages = list(data.get("passages") or [])
        try:
            c = _sl_mcp("search_concept", {"query": query, "limit": 10})
            passages.extend(c.get("passages") or c.get("results") or [])
        except Exception:
            pass
        results, seen, per_book = [], set(), {}
        for p in passages:
            st = (p.get("snippet_type") or "").lower()
            if st and st not in ("translation", "ocr", ""):
                continue
            title = p.get("title") or ""
            author = p.get("author") or ""
            snippet = re.sub(r"<[^>]+>", " ", p.get("snippet") or "")
            snippet = re.sub(r"\s+", " ", snippet).strip()
            if len(snippet) < 40:
                continue
            blob = (title + " " + author + " " + snippet).lower()
            if any(j in blob for j in junk):
                continue
            if rus_q:
                occult = ("blavatsky", "paracelsus", "alchemi", "yuga", "evola", "guenon", "isis unveiled")
                if any(x in blob for x in occult):
                    continue
                if not any(x in blob for x in ("nevsky", "novgorod", "livon", "teuton", "peipus", "ice", "karamzin",
                                               "chronicle", "летопис", "чудск", "ледов", "vladimir", "baptism",
                                               "troubles", "dmitry", "oprichnina", "russia", "russian", "rus ",
                                               "lomonosov", "нестор", "русск", "москов", "смут", "опричнин")):
                    continue
            if mil_q:
                drop = (
                    "berdiaev", "berdyaev", "бердяев", "mysticism", "magic", "маги",
                    "zoroaster", "dinkard", "philosophy of freedom", "haunted",
                    "hawaiian", "volcano", "philodemus", "leucippe", "hindoe",
                    "oxyrhynchus", "papyri", "sermon", "theology", "gospel",
                    "inanna", "netherworld", "hercules", "odyssey", "thesaurus",
                    "witches", "demon-mania", "gallic", "caesar", "siddhanta",
                    "new thought", "panchangamu",
                )
                if any(x in blob for x in drop):
                    continue
                # Якорный фильтр: если запрос содержит известное военное ключевое слово,
                # результат обязан содержать уникальное якорное слово (не год), иначе мусор.
                anchors = []
                if "stalingrad" in ql or "сталинград" in ql:
                    anchors.append(("stalingrad", "сталинград"))
                if "verdun" in ql or "верден" in ql:
                    anchors.append(("verdun", "верден"))
                if "borodino" in ql or "бородин" in ql:
                    anchors.append(("borodino", "бородин", "napoleon", "наполеон"))
                if "world war" in ql or "мировой войны" in ql or "первой миров" in ql:
                    anchors.append(("world war", "ww1", "war of 1914", "war of the", "первой мировой", "мировой войны"))
                if "constantinople" in ql or "константинопол" in ql:
                    anchors.append(("constantinople", "konstantinopel", "константинопол", "byzant"))
                if "brusilov" in ql:
                    anchors.append(("brusilov", "брусилов", "offensive"))
                if "kulikovo" in ql or "куликов" in ql:
                    anchors.append(("kulikovo", "куликов", "mamai", "мамай"))
                if "battle of the ice" in ql or "ледов" in ql:
                    anchors.append(("nevsky", "пеипус", "peipus", "чудск", "livon", "teuton"))
                if "siege" in ql or "осад" in ql:
                    anchors.append(("siege", "осад", "constantinople", "константинопол"))
                if anchors:
                    if not any(a in blob for grp in anchors for a in grp):
                        continue
            if templar_q:
                occult = ("blavatsky", "isis", "waite", "sorcery", "magic", "kabbalah", "alchemi")
                ok = any(x in blob for x in ("templar", "templari", "templier", "tempelherr", "ritter"))
                if any(x in blob for x in occult) and not ok:
                    continue
                if not ok:
                    continue
            page = p.get("page")
            url = p.get("short_url") or p.get("url") or ""
            key = (title[:80], page)
            if key in seen:
                continue
            seen.add(key)
            bk = (title or "")[:80]
            if per_book.get(bk, 0) >= 1:
                continue
            per_book[bk] = per_book.get(bk, 0) + 1
            book = f"{title} — {author}".strip(" —")
            if page:
                book += f" (с. {page})"
            results.append({
                "source": "sourcelibrary",
                "book": book,
                "author": author,
                "score": 2,
                "snippet": snippet[:600],
                "url": url,
            })
            if len(results) >= limit:
                break
        if not results:
            return [{"source": "sourcelibrary", "error": "нет пассажи в MCP"}]
        return results
    except Exception as e:
        return [{"source": "sourcelibrary", "error": str(e)[:120]}]

# ===== Уровень 4: Internet Archive =====
# Специфичные слова — по ним проверяем релевантность книги (не по "battle"/"war")
_IA_SPECIFIC = ('stalingrad', 'сталинград', 'verdun', 'верден', 'borodino', 'бородин',
                'kulikovo', 'куликов', 'mamai', 'мамай', 'constantinople', 'константинопол',
                'nevsky', 'невск', 'oprichnina', 'опричнин', 'troubles', 'смут', 'lomonosov',
                'stalin', 'сталин', 'napoleon', 'наполеон', 'hitler', 'гитлер', 'wehrmacht',
                'vermaht', 'вермахт', 'brusilov', 'брусилов', 'ottoman', 'оттоман', 'byzant',
                'кали', 'kali', 'yuga', 'юга', 'schuon', 'шуон', 'шаон', 'guenon', 'генон',
                'evola', 'эвола', 'dharma', 'дхарм', 'kabbalah', 'каббал', 'merkavah', 'меркав',
                'talmud', 'талмуд', 'zohar', 'зоар', 'quran', 'коран', 'sufi', 'суфи', 'arab',
                'араб', 'hermes', 'гермес', 'paracelsus', 'парацельс', 'poimandr', 'поймандр',
                'templar', 'тампли', 'philosopher', 'алхим',
                'jerusalem', 'иерусалим', 'иерусалима')

_IA_GENERIC = ('battle', 'битв', 'war', 'войн', 'book', 'books', 'книг', 'world', 'мир',
               'history', 'истор', 'army', 'арми', 'front', 'фронт', 'offensive', 'наступ',
               'defense', 'оборон', 'campaign', 'поход', 'siege', 'осад', 'russia', 'росси',
               'soviet', 'совет', 'german', 'герман', '1941', '1942', '1943', '1944', '1945',
               'chronicle', 'летопис', 'text', 'текст', 'volume', 'том', 'part', 'часть',
               'alexander', 'alexandr', 'victory', 'побед', 'great', 'велик', 'ivan', 'иван')

def _ia_specific_words(words):
    """Из списка слов выбираем специфичные (не общие типа battle/war/book/год).
    Плюс русские корни: 'сталинградская' → 'сталин' (покрывает кириллические названия)."""
    spec = [w for w in words if (w in _IA_SPECIFIC or (len(w) >= 6 and w not in _IA_GENERIC))]
    for w in words:
        if re.search(r'[а-яё]', w) and len(w) > 6:
            root = w[:6]
            if root in _IA_SPECIFIC or (len(root) >= 5 and root not in _IA_GENERIC):
                spec.append(root)
    # дедупликация, сохраняя порядок
    return list(dict.fromkeys(spec)) or words

def _ia_real_snippet(ident, words, max_chars=600):
    """Скачать djvu.txt открытой книги IA и вытащить сниппет с реальным текстом.
    Возвращает (текст_сниппета, url_plaintext) или (None, None)."""
    try:
        with urllib.request.urlopen(urllib.request.Request(
                f'https://archive.org/metadata/{ident}', headers={'User-Agent': 'Mozilla/5.0'}), timeout=10) as r:
            md = json.loads(r.read())
        server = md.get('server') or ''
        dirp = md.get('dir') or ''
        txt_name = None
        for f in (md.get('files') or []):
            n = f.get('name') or ''
            if n.endswith('_djvu.txt'):
                txt_name = n
                break
        if not txt_name:
            return None, None
        url = f'https://{server}{dirp}/{urllib.parse.quote(txt_name)}'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        # Ограничение размера: не тащим гигабайты. Скачиваем, но обрезаем после ~1MB.
        with urllib.request.urlopen(req, timeout=12) as r:
            data = r.read(1_200_000)
        text = data.decode('utf-8', errors='ignore')
        low = text.lower()
        # ищем вхождение СПЕЦИФИЧНОГО слова (не "battle"/"war" — иначе сборник стихов проходит)
        words_for_find = _ia_specific_words(words)
        pos = -1
        for w in words_for_find:
            p = low.find(w)
            if p != -1 and (pos == -1 or p < pos):
                pos = p
        if pos == -1:
            return None, url
        start = max(0, pos - 150)
        snip = text[start:start + max_chars]
        snip = re.sub(r'\s+', ' ', snip).strip()
        return snip, url
    except Exception:
        return None, None


def search_internet_archive(query, limit=5):
    """Поиск книг/документов в Internet Archive (20M+). Только открытые книги (не lending),
    сниппеты — реальный текст из djvu.txt, не каталоговое описание."""
    try:
        # Чистим стоп-слова: русские + английские (через _en_query) слова
        ru_words = [w.lower() for w in query.replace('-', ' ').split() if w.lower() not in _STOP and len(w) > 2]
        en_words = [w for w in _en_query(query).split() if w.lower() not in _STOP and len(w) > 2]
        has_cyr = any('\u0400' <= c <= '\u04FF' for c in query)
        # ВАЖНО: если в запросе кириллица — русские слова ПЕРВЫМИ (русские книги в IA
        # имеют кириллические метаданные, англ. запрос даёт англ. мусор)
        words = list(dict.fromkeys((ru_words if has_cyr else en_words) + (en_words if has_cyr else ru_words)))
        if not words:
            words = [w for w in query.split() if len(w) > 2][:3]
        # ПРАВКА C (аудит Astra): результаты разных попыток НАКАПЛИВАЮТСЯ по identifier.
        # Было: docs = результат ПОСЛЕДНЕЙ попытки — точный AND-поиск перезаписывался менее
        # точным OR, из-за чего в выдачу лез мусор вроде «The O9A And The Longusian Esoteric
        # Tradition». Стало: AND-попытки идут первыми и остаются в пуле, OR только ДОБАВЛЯЕТ.
        docs_by_id = {}
        attempts = []
        if len(words) >= 2:
            attempts.append(f'"{words[0]}" AND "{words[1]}"')
        if has_cyr and en_words and len(en_words) >= 2:
            attempts.append(f'"{en_words[0]}" AND "{en_words[1]}"')
        elif len(words) >= 2:
            attempts.append(' AND '.join(f'"{w}"' for w in words[:2]))
        if len(words) >= 3:
            attempts.append(' OR '.join(f'"{w}"' for w in words[:3]))
        if len(words) > 3:
            attempts.append(' OR '.join(f'"{w}"' for w in words))
        for q in attempts[:2]:
            if len(docs_by_id) >= limit + 4:
                break
            url = (
                'https://archive.org/advancedsearch.php?q=' + urllib.parse.quote(q)
                + '+AND+mediatype:texts+AND+!access-restricted-item:true'
                + '&fl[]=identifier&fl[]=title&fl[]=description&fl[]=creator&fl[]=date&fl[]=language'
                + '&rows=' + str(limit + 3) + '&output=json'
            )
            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=7) as resp:
                    d = json.loads(resp.read())
            except Exception:
                continue  # одна неудачная попытка не должна ронять весь поиск
            for doc in d.get('response', {}).get('docs', []) or []:
                ident = doc.get('identifier')
                if ident and ident not in docs_by_id:
                    docs_by_id[ident] = doc
        docs = list(docs_by_id.values())
        results = []
        for doc in docs[:limit + 4]:
            title = doc.get('title', '') or ''
            if any(j in title.lower() for j in _JUNK_TITLE):
                continue
            # Периодика: газеты/журналы (China Mail 1947-09-15, Combat Aircraft) — НЕ книги
            tl = title.lower()
            if re.search(r'\b\d{4}[-/]\d{2}[-/]\d{2}\b|\b\d{2}[-/]\d{2}[-/]\d{4}\b', title):
                continue
            if any(x in tl for x in (' mail ', ' times ', ' herald ', ' gazette ', ' weekly ',
                                     ' monthly ', ' daily ', ' journal of commerce', ' combat aircraft',
                                     ' photo book', ' tanks & fighting', ' magazine')):
                continue
            ident = doc.get('identifier', '')
            snippet, txt_url = _ia_real_snippet(ident, words[:3])
            if snippet:
                book = title[:80]
                results.append({
                    'source': 'archive.org',
                    'book': book,
                    'score': 2,
                    'snippet': snippet[:600],
                    'url': f'https://archive.org/details/{ident}',
                    'txt_url': txt_url,
                })
                if len(results) >= limit:
                    break
        if not results:
            # Фолбэк: хотя бы каталог, но помечаем что текст недоступен
            for doc in docs[:limit + 4]:
                title = doc.get('title', '') or ''
                # Периодика в фолбэке тоже отсекаем
                tl = title.lower()
                if re.search(r'\b\d{4}[-/]\d{2}[-/]\d{2}\b|\b\d{2}[-/]\d{2}[-/]\d{4}\b', title):
                    continue
                if any(x in tl for x in (' mail ', ' times ', ' herald ', ' gazette ', ' weekly ',
                                         ' monthly ', ' daily ', ' magazine', ' tribune', ' review-advertiser',
                                         ' gateway (')):
                    continue
                desc = doc.get('description') or ''
                if isinstance(desc, list):
                    desc = ' '.join(str(x) for x in desc)
                ident = doc.get('identifier', '')
                results.append({
                    'source': 'archive.org',
                    'book': (title or '')[:80],
                    'score': 1,
                    'snippet': (str(desc).strip() or title)[:400],
                    'url': f'https://archive.org/details/{ident}',
                })
                if len(results) >= limit:
                    break
        if not results:
            return [{'source': 'archive.org', 'error': 'нет открытых книг'}]
        return results
    except Exception as e:
        return [{'source': 'archive.org', 'error': str(e)[:100]}]

# ===== Уровень 5: Gutenberg (gutendex API) =====
def search_gutenberg(query, limit=3):
    """Поиск книг в Project Gutenberg (75k+ книг) через Gutendex.

    ПРАВКА D (аудит Astra): Gutendex ищет ТОЛЬКО по метаданным (название/автор), поэтому
    Поиск по всей фразе («hermetic tradition theurgy») давал ровно 0 результатов. Теперь
    пробуем по значимым словам по одному, от длинных к коротким: «hermetic» находит
    «The Hermetic Museum» и т.п.
    """
    try:
        words = [w for w in _en_query(query).split()
                 if w.lower() not in _STOP and len(w) > 3]
        if not words:
            words = [w for w in query.split() if len(w) > 3]
        if not words:
            return []
        words = sorted(dict.fromkeys(words), key=len, reverse=True)

        results, seen = [], set()
        for w in words[:4]:
            if len(results) >= limit:
                break
            try:
                url = f'https://gutendex.com/books?search={urllib.parse.quote(w)}'
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=8) as resp:
                    d = json.loads(resp.read())
            except Exception:
                continue
            for b in d.get('results', [])[:limit]:
                gid = b.get('id', '')
                title = b.get('title', '')
                if not gid or gid in seen:
                    continue
                # Проверяем, что слово реально есть в названии/авторе (Gutendex любит
                # отдавать близкие совпадения).
                authors = ', '.join(a.get('name', '') for a in b.get('authors', []))
                if w.lower() not in (title + ' ' + authors).lower():
                    continue
                seen.add(gid)
                results.append({
                    'source': 'gutenberg',
                    'book': f"{title} — {authors}",
                    'author': authors,
                    'score': 1,
                    'snippet': f"https://www.gutenberg.org/ebooks/{gid}",
                    'url': f"https://www.gutenberg.org/cache/epub/{gid}/pg{gid}.txt",
                    'source_id': str(gid),
                    'kind': 'catalog_record',
                })
                if len(results) >= limit:
                    break
        return results
    except Exception as e:
        return [{'source': 'gutenberg', 'error': str(e)[:100]}]

# ===== Уровень 6: Perseus/Scaife =====
def search_perseus(query, limit=3):
    """Поиск классических текстов в Perseus/Scaife.

    ПРАВКА E (аудит Astra): раньше функция возвращала строку «Perseus Digital Library
    (поиск по классике)» со ссылкой на поиск — и она попадала в выдачу как найденная
    книга, хотя поиска не было. Scaife — SPA: полнотекстовые результаты через HTML
    не отдаются. Реальный путь — импорт TEI-коллекций PerseusDL (canonical-greekLit,
    canonical-latinLit) в корпус; до него уровень честно сообщает, что не поддерживается.
    """
    return [{
        'source': 'perseus',
        'status': 'unsupported',
        'error': 'Scaife не отдаёт полнотекстовый поиск; нужен импорт TEI PerseusDL в корпус',
    }]

# ===== Уровень 7: Harvard LibraryCloud (1M+ public domain) =====
def search_harvard(query, limit=3):
    """Поиск в Harvard LibraryCloud API (1M+ книг)."""
    try:
        url = f'https://api.lib.harvard.edu/v2/items.json?q={urllib.parse.quote(query)}&limit={limit}'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            d = json.loads(resp.read())
        results = []
        items = d.get('items', {}).get('mods', []) or d.get('items', {}).get('item', [])
        for item in items[:limit]:
            title = ''
            for tinfo in item.get('titleInfo', []):
                if isinstance(tinfo, dict):
                    title = tinfo.get('title', '') or ''
                    break
            results.append({
                'source': 'harvard',
                'book': title[:80],
                'score': 1,
                'snippet': f"Harvard LibraryCloud: {query}",
                'url': 'https://library.harvard.edu/',
            })
        if not results:
            return [{'source': 'harvard', 'error': 'нет результатов'}]
        return results
    except Exception as e:
        return [{'source': 'harvard', 'error': str(e)[:100]}]

# ===== Уровень 8: Bodleian/Oxford =====
def search_bodleian(query, limit=3):
    """Bodleian Libraries (Oxford).

    ПРАВКА E: раньше отдавала строку «Bodleian Libraries — поиск по манускриптам» как
    найденную книгу. IIIF отдаёт страницы и метаданные, но НЕ полнотекстовый поиск.
    Конкретный endpoint подключать только после сохранения успешной тестовой фикстуры.
    """
    return [{
        'source': 'bodleian',
        'status': 'unsupported',
        'error': 'каталог/IIIF не даёт полнотекстового поиска — нужна фикстура endpoint',
    }]

# ===== Уровень 9: РГБ (библиотека Ленина) — ALEPH каталог =====
def search_rsl(query, limit=5):
    """Поиск в Российской государственной библиотеке (РГБ, библиотека Ленина).
    Парсит таблицу short-a-body: автор / заглавие / выходные данные."""
    try:
        url = f'http://aleph.rsl.ru/F?func=find-b&find_code=WRD&request={urllib.parse.quote(query)}'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            html = resp.read().decode('utf-8', errors='ignore')
        qwords = [w.lower() for w in query.split() if len(w) > 2]
        results, seen = [], set()
        rows = re.split(r'<tr valign=baseline>', html, flags=re.I)
        for row in rows[1:]:
            tds = re.findall(r'<td class=td1[^>]*>(.*?)</td>', row, flags=re.S | re.I)
            if len(tds) < 4:
                continue
            def _clean(x):
                x = re.sub(r'<[^>]+>', ' ', x)
                x = re.sub(r'&nbsp;|&amp;|&lt;|&gt;|&quot;|&#\d+;', ' ', x)
                return re.sub(r'\s+', ' ', x).strip()
            author = _clean(tds[3]) if len(tds) > 3 else ''
            title = _clean(tds[4]) if len(tds) > 4 else ''
            pub = _clean(tds[5]) if len(tds) > 5 else ''
            if not title or len(title) < 8:
                continue
            year = re.search(r'(1[89]\d\d|20\d\d)', pub)
            full = f"{author} {title} {pub}".strip()
            if len(full) < 24 or full in seen:
                continue
            if qwords and not any(w in full.lower() for w in qwords):
                continue
            seen.add(full)
            book = f"{author} — {title}" if author else title
            results.append({
                'source': 'rsl',
                'book': book[:110],
                'score': 1,
                'snippet': f"{title[:150]} ({pub[:60]})",
                'url': url,
                'year': year.group(1) if year else '',
            })
            if len(results) >= limit:
                break
        if not results:
            return [{'source': 'rsl', 'error': 'нет результатов'}]
        return results
    except Exception as e:
        return [{'source': 'rsl', 'error': str(e)[:100]}]

# ===== Уровень 10: Восточная литература (vostlit) =====
def search_vostlit(query, limit=3):
    """Восточная литература (vostlit.info).

    ПРАВКА E: раньше отдавала строку-заглушку «Восточная литература (vostlit.info)» как
    найденный источник. Контракт /Search/?q= не подтверждён. Правильный путь по аудиту —
    обновляемый каталог ссылок с оглавлений сайта + FTS по нему; до него — честный статус.
    """
    return [{
        'source': 'vostlit',
        'status': 'unsupported',
        'error': 'контракт /Search/ не подтверждён; нужен каталог с оглавлений + FTS',
    }]
def search_quran(query, limit=3):
    """Поиск по Корану — РЕАЛЬНЫЙ поиск по аятам.

    ПРАВКА E (аудит Astra): раньше брала название издания и возвращала ссылку на
    quran.com/search — то есть выдавала себя за найденный текст. Теперь настоящий
    поиск по аятам через alquran.cloud (/v1/search/{слово}/all/{перевод}) с указанием
    суры, номера аята и канонического локатора.
    """
    try:
        words = [w for w in query.replace('-', ' ').split() if len(w) > 2][:3]
        if not words:
            return []
        results, seen = [], set()
        for w in words:
            if len(results) >= limit:
                break
            try:
                u = f'https://api.alquran.cloud/v1/search/{urllib.parse.quote(w)}/all/ru.kuliev'
                rq = urllib.request.Request(u, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(rq, timeout=10) as resp:
                    d = json.loads(resp.read())
            except Exception:
                continue
            for m in ((d.get('data') or {}).get('matches') or [])[:limit]:
                surah = m.get('surah') or {}
                num = m.get('numberInSurah')
                key = (surah.get('number'), num)
                if not num or key in seen:
                    continue
                seen.add(key)
                results.append({
                    'source': 'quran',
                    'book': f"Коран {surah.get('number')}:{num} (сура «{surah.get('name')}»)",
                    'score': 1,
                    'snippet': (m.get('text') or '')[:600],
                    'locator': f"{surah.get('number')}:{num}",
                    'url': f"https://quran.com/{surah.get('number')}/{num}",
                    'kind': 'text_passage',
                    'source_id': f"{surah.get('number')}:{num}",
                })
                if len(results) >= limit:
                    break
        return results
    except Exception as e:
        return [{'source': 'quran', 'error': str(e)[:100]}]

# ===== Уровень 10: Islamic corpus (corpus.quran.com + IA ислам) =====
def search_islamic(query, limit=3):
    """Исламские тексты: хадисы, суфизм, философия — через Internet Archive."""
    try:
        q = ' AND '.join(f'"{w}"' for w in query.split()[:3])
        url = f'https://archive.org/advancedsearch.php?q={urllib.parse.quote(q)}+AND+mediatype:texts&fl[]=identifier&fl[]=title&rows={limit}&output=json'
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            d = json.loads(resp.read())
        results = []
        for doc in d.get('response', {}).get('docs', [])[:limit]:
            results.append({
                'source': 'islamic',
                'book': doc.get('title', ''),
                'score': 1,
                'snippet': f"https://archive.org/details/{doc.get('identifier','')}",
                'url': f"https://archive.org/details/{doc.get('identifier','')}",
            })
        if not results:
            return [{'source': 'islamic', 'error': 'нет результатов'}]
        return results
    except Exception as e:
        return [{'source': 'islamic', 'error': str(e)[:100]}]

# ===== Семантический уровень: nomic-embed-text (ollama) + numpy-косинус =====
_EMB_CACHE = {}
_EMB_META = None
_EMB_NORM = None

def _ollama_embed(text):
    if text in _EMB_CACHE:
        return _EMB_CACHE[text]
    try:
        req = urllib.request.Request(
            'http://127.0.0.1:11434/api/embeddings',
            data=json.dumps({'model': 'nomic-embed-text', 'prompt': text}).encode(),
            headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=30) as r:
            d = json.loads(r.read())
        v = np.array(d.get('embedding') or [], dtype=np.float32)
        _EMB_CACHE[text] = v
        return v
    except Exception:
        return None

def semantic_search(query, limit=6):
    """Векторный поиск: русский запрос → _en_query перевод → nomic эмбеддинг →
    косинус с индексом (122k чанков). Только релевантные по порогу."""
    try:
        global _EMB_META, _EMB_NORM
        idx_path = '/root/hermes-box/index/embeddings.npy'
        meta_path = '/root/hermes-box/index/meta.json'
        if not os.path.exists(idx_path):
            return []
        if _EMB_META is None:
            _EMB_META = json.load(open(meta_path))
            emb = np.load(idx_path, mmap_mode='r')
            norms = np.linalg.norm(emb, axis=1)
            norms[norms == 0] = 1
            _EMB_NORM = emb / norms[:, None]
        en_q = _en_query(query)
        # Защита: nomic-embed-text НЕ понимает русский. Мало проверить наличие латиницы —
        # _en_query оставляет русские обрубки тех слов, которых нет в словаре перевода
        # («книги относятся ... ескому корпусу»). На таком векторе семантика вытаскивала
        # ПВЛ, Судебник 1497, Головина и Дугина с косинусом 0.73 на запрос про
        # герметический корпус — то есть ровно тот мусор, на который жалуется владелец.
        # Эмбеддим ТОЛЬКО латинские слова; если их не осталось — семантику не запускаем.
        en_q = ' '.join(w for w in en_q.split() if w.isascii() and w.isalpha())
        if not en_q:
            return []
        qv = _ollama_embed(en_q)
        if qv is None or _EMB_NORM is None or len(qv) != _EMB_NORM.shape[1]:
            return []
        qn = qv / np.linalg.norm(qv)
        scores = _EMB_NORM @ qn
        top = np.argsort(-scores)[:limit * 3]
        out = []
        seen_files = set()
        for i in top:
            if scores[i] < 0.68:   # порог поднят с 0.63 (2026-09-21): на 0.63 проходил мусор (Luciferianism/Freemasonry, технические имена dli.ernet/69c4ec) — семантика цепляла их к герметике
                continue
            c = _EMB_META[i]
            fpath = os.path.join('/root/hermes-box/documents/', c.get('file', ''))
            fname = os.path.basename(c.get('file', ''))
            key = c.get('file', '')[:60]
            if key in seen_files:
                continue
            seen_files.add(key)
            snippet = ''
            try:
                if os.path.exists(fpath):
                    with open(fpath, encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    # build_index.py: CHUNK_SIZE=1200, OVERLAP=150 → шаг 1050
                    step = 1200 - 150
                    start = (c.get('chunk', 0) or 0) * step
                    snippet = content[start:start + 1200][:900]
            except Exception:
                pass
            out.append({
                'source': 'semantic',
                'book': fname.replace('.txt', '').replace('_', ' ')[:70],
                'score': round(float(scores[i]), 3),
                'snippet': snippet,
                'file': fpath,
                'url': f'https://archive.org/search?q={urllib.parse.quote(query)}',
            })
            if len(out) >= limit:
                break
        return out
    except Exception:
        return []
_STOP = {'что','как','такое','это','кто','где','почему','зачем','когда','какой','какая','какие','такой','такая','такие','по','о','и','в','на','не','мне','с','у','для','про','about','the','and','what','who','why','how','does','is','are','of','to','in','a','an',
         'пишет','пишут','написал','говорит','сказал','говорил','написано','есть','был','была','были','быть','стал','стала'}

def _query_words(query):
    words = [w.lower() for w in query.replace('-', ' ').split() if len(w) >= 3 and w.lower() not in _STOP]
    extra = []
    ALIAS = {
        'куликовская': ['kulikovo', 'kulikovskaya'],
        'куликовской': ['kulikovo', 'kulikovskaya'],
        'битва': ['bitva'],
        'летопись': ['letopis'],
        'мамай': ['mamai'],
        'сефирот': ['sephirot', 'sefirot', 'sephiroth'],
        'кали': ['kali'],
        'юга': ['yuga'],
        'юге': ['yuga'],
        'юги': ['yuga'],
        'шаон': ['schuon', 'шуон'],
        'шуон': ['schuon', 'шаон'],
        'меркава': ['merkavah', 'merkaba'],
        'меркавы': ['merkavah', 'merkaba'],
        'меркав': ['merkavah', 'merkaba'],
        'каббала': ['kabbalah', 'qabbalah', 'cabala'],
        'каббале': ['kabbalah', 'qabbalah', 'cabala'],
        'дхарма': ['dharma'],
        'дхарме': ['dharma'],
        'дхармы': ['dharma'],
        'дхарм': ['dharma'],
        'карма': ['karma'],
        'карме': ['karma'],
        'кармы': ['karma'],
        'карм': ['karma'],
        'тантра': ['tantra'],
        'тантре': ['tantra'],
        'тантр': ['tantra'],
        'нирвана': ['nirvana'],
        'нирване': ['nirvana'],
        'нирван': ['nirvana'],
        'йога': ['yoga'],
        'йоге': ['yoga'],
        'эвола': ['evola'],
        'эволе': ['evola'],
        'эволы': ['evola'],
        'эвол': ['evola'],
        'генон': ['guenon'],
        'геноне': ['guenon'],
        'генона': ['guenon'],
        'геноном': ['guenon'],
        'талмуд': ['talmud'],
        'талмуде': ['talmud'],
        'мишна': ['mishnah', 'mishna'],
        'мишне': ['mishnah', 'mishna'],
        'тора': ['torah'],
        'торе': ['torah'],
        'зоар': ['zohar'],
        'зоаре': ['zohar'],
        'танах': ['tanakh'],
        'мидраш': ['midrash'],
        'гемара': ['gemara'],
        'шаббат': ['shabbat'],
        'хасид': ['hasid', 'chasid'],
        'раввин': ['rabbi', 'rabbinic'],
        'иудей': ['jewish', 'judaism'],
        'шуон': ['schuon'],
        'шаон': ['schuon'],
        'алхимии': ['алхимия', 'alchemy'],
        'алхимия': ['alchemy'],
        'делание': ['opus'],
        'герметизм': ['hermeticism', 'hermetic'],
        'философский': ['philosopher'],
    }
    for w in list(words):
        extra.extend(ALIAS.get(w, []))
    return list(dict.fromkeys(words + extra))

def _en_query(query):
    TRANSLIT = {
        'кали юга': 'kali yuga', 'кали-юга': 'kali yuga', 'кали юге': 'kali yuga',
        'кали югу': 'kali yuga', 'кали юги': 'kali yuga',
        'юга': 'yuga', 'юге': 'yuga', 'юги': 'yuga', 'югу': 'yuga',
        'шуон': 'schuon', 'шаон': 'schuon',
        'генон': 'guenon', 'геноне': 'guenon', 'генона': 'guenon', 'геноном': 'guenon',
        'эвола': 'evola', 'эволе': 'evola', 'эволы': 'evola',
        'меркава': 'merkavah merkaba', 'меркавы': 'merkavah merkaba',
        'талмуд': 'talmud', 'талмуде': 'talmud', 'мишна': 'mishnah', 'мишне': 'mishnah',
        'тора': 'torah', 'торе': 'torah', 'зоар': 'zohar', 'зоаре': 'zohar',
        'танах': 'tanakh', 'мидраш': 'midrash', 'гемара': 'gemara', 'шаббат': 'shabbat',
        'хасид': 'hasid', 'раввин': 'rabbi', 'иудей': 'jewish', 'иудеи': 'jews',
        'иерусалим': 'jerusalem', 'иерусалима': 'jerusalem', 'иерусалиме': 'jerusalem',
        'енох': 'enoch', 'енoxa': 'enoch', 'ханох': 'chanoch', 'метатрон': 'metatron',
        'юбилеев': 'jubilees', 'апокриф': 'apocrypha', 'апокрифич': 'apocrypha',
        'израиль': 'israel', 'израиля': 'israel', 'еврей': 'jewish', 'евреи': 'jews',
        'сион': 'zion', 'соломон': 'solomon temple', 'храм': 'temple jerusalem',
        'дхарма': 'dharma', 'карма': 'karma', 'карме': 'karma',
        'тантра': 'tantra', 'нирвана': 'nirvana', 'йога': 'yoga',
        'сансара': 'samsara', 'веданта': 'vedanta', 'адвайта': 'advaita',
        'упанишад': 'upanishad',
        'философский камень': 'philosopher stone', 'герметизм': 'hermeticism',
        # герметика: практики (иначе 'практики' остаётся русским и фильтр режет Эволу)
        'герметич': 'hermetic hermeticism', 'герметизм': 'hermeticism hermetic',
        'практик': 'practice practices practical', 'практика': 'practice',
        'теурги': 'theurgy theurgic', 'теургия': 'theurgy',
        'алхими': 'alchemy alchemical', 'алхимия': 'alchemy',
        'созерцани': 'contemplation contemplation', 'аскез': 'asceticism ascetic',
        'молитв': 'prayer', 'гимн': 'hymn', 'ритуал': 'ritual initiation initiatory',
        'возрождени': 'rebirth regeneration', 'посвящени': 'initiation',
        'спагирик': 'spagyria spagyric', 'сигнатур': 'signature',
        'парацельс': 'paracelsus', 'поймандр': 'poimandres pymander',
        'асклепий': 'asclepius', 'гермес': 'hermes trismegistus',
        'каббала': 'kabbalah sephiroth', 'сефирот': 'sephiroth sefirot kabbalah',
        'зоар': 'zohar', 'талмуд': 'talmud', 'иудаизм': 'judaism kabbalah',
        'ибн араби': 'ibn arabi fusus bezels', 'суфизм': 'sufism ibn arabi',
        'коран': 'quran koran', 'хадис': 'hadith',
        'ледовое побоище': 'battle of the ice nevsky peipus 1242',
        'ледовом побоище': 'battle of the ice nevsky peipus',
        'ледовое': 'battle of the ice nevsky peipus',
        'ледовом': 'battle of the ice nevsky peipus',
        'куликовская битва': 'battle of kulikovo mamai 1380',
        'куликовской битве': 'battle of kulikovo mamai 1380',
        'куликовск': 'battle of kulikovo mamai 1380',
        'мамай': 'mamai kulikovo 1380',
        'крещение руси': 'baptism of rus vladimir 988 chronicle',
        'крещени': 'baptism of rus vladimir 988',
        'владимир': 'vladimir grand prince of kiev rus',
        'смутн': 'time of troubles russia false dmitry',
        'лжедмитрий': 'false dmitry time of troubles',
        'опричнин': 'oprichnina ivan the terrible',
        'иван грозн': 'ivan the terrible oprichnina',
        'сталинград': 'battle of stalingrad 1942',
        'сталинградск': 'battle of stalingrad 1942',
        'бородин': 'battle of borodino 1812 napoleon',
        'верден': 'battle of verdun 1916',
        'верденск': 'battle of verdun 1916',
        'константинопол': 'siege of constantinople 1453 ottoman',
        'осад': 'siege fortress',
        'первая миров': 'world war i 1914 1918',
        'первой миров': 'world war i 1914 1918',
        'мировая война': 'world war',
        'шариат': 'sharia islamic law',
        'поймандр': 'poimandres corpus hermeticum',
        'гермес': 'hermes trismegistus corpus hermeticum',
        'суфизм': 'sufism tasawwuf ibn arabi',
        'суфий': 'sufism sufi tasawwuf',
        'брусиловский прорыв': 'brusilov offensive 1916',
        'брусиловском прорыве': 'brusilov offensive 1916',
        'брусилов': 'brusilov offensive 1916',
        'тамплиер': 'templar templars knights temple',
        'тамплиеры': 'templars knights templar',
        'храмовник': 'templar knights temple',
        'тувал': 'tubal tubal-cain',
        'туваль': 'tuval tubal tubal-cain',
        'туваля': 'tuval tubal tubal-cain',
    }
    ql = ' ' + query.lower() + ' '
    for ru, en in sorted(TRANSLIT.items(), key=lambda x: -len(x[0])):
        if ru in ql:
            ql = ql.replace(ru, ' ' + en + ' ')
    extra_stop = _STOP | {
        'чем', 'отличия', 'отличие', 'признаных', 'признанных', 'корифеев',
        'корифей', 'истории', 'история', 'этом', 'этой', 'быть', 'был',
    }
    out = []
    for w in re.findall(r'[a-z0-9\-]+|[а-яё]+', ql):
        if w in extra_stop or len(w) < 3:
            continue
        out.append(w)
    return ' '.join(dict.fromkeys(out)) or query

def _is_relevant(results, query):
    """Релевантно по словам запроса. Для Source Library — по английским ключам, не по русским стоп-словам."""
    orig = [w.lower() for w in query.split() if len(w) > 3 and w.lower() not in _STOP]
    en_words = [w for w in _en_query(query).split() if w not in _STOP and len(w) > 2]
    topic_w = {
        'judaism', 'kabbalah', 'islam', 'sufism', 'hermeticism', 'alchemy',
        'chronicle', 'templar', 'templars',
    }
    primary = [w for w in en_words if w not in topic_w]
    need = 2 if len(orig) >= 2 else 1
    words = list(dict.fromkeys(_query_words(query) + en_words))
    if not words and not orig:
        return []
    junk = ('ленин', 'lenin', 'гоголь', 'gogol', 'салтыков', 'крылов', 'krylov', 'горький', 'капитализм')
    out = []
    for r in results or []:
        if r.get('error'):
            continue
        blob = (r.get('book','') + ' ' + r.get('author','') + ' ' + r.get('snippet','') + ' ' + r.get('file','')).lower()
        if any(j in blob for j in junk):
            continue
        if r.get('source') == 'sourcelibrary':
            keys = primary or en_words
            title_auth = (r.get('book', '') + ' ' + r.get('author', '')).lower()
            ql = (query or '').lower()
            # Имя из запроса — только в title/author (не «Guenon de mer» в книге про рыб)
            name_miss = False
            for grp in _NAME_ANCHORS:
                if any(a in ql or a in (primary or []) or a in en_words for a in grp):
                    if not any(a in title_auth for a in grp):
                        name_miss = True
                        break
            if name_miss:
                continue
            for grp in _TOPIC_TITLE_ANCHORS:
                if any(a in ql or a in (primary or []) or a in en_words for a in grp):
                    if not any(a in title_auth for a in grp):
                        name_miss = True
                        break
            if name_miss:
                continue
            # Требуем ≥2 ключей в blob (одно "kali" в Codex Zographensis — филологический мусор)
            if keys:
                hits = sum(1 for k in keys if k in blob)
                need_sl = 2 if len(keys) >= 2 else 1
                if any(a in title_auth for grp in _NAME_ANCHORS for a in grp):
                    need_sl = 1
                if any(a in title_auth for grp in _TOPIC_TITLE_ANCHORS for a in grp):
                    need_sl = 1
                if hits >= need_sl:
                    out.append(r)
            continue
        if r.get('source') == 'archive.org':
            spec = _ia_specific_words(list(dict.fromkeys((primary or []) + (en_words or []) + (orig or []))))
            title_low = (r.get('book') or '').lower()
            snip_low = (r.get('snippet') or '').lower()
            ql = (query or '').lower()
            topic_miss = False
            for grp in _TOPIC_TITLE_ANCHORS:
                if any(a in ql or a in (primary or []) or a in en_words for a in grp):
                    if not any(a in title_low for a in grp):
                        topic_miss = True
                        break
            if topic_miss:
                continue
            if spec:
                # Специфичное слово в НАЗВАНИИ книги — железно релевантно
                if any(s in title_low for s in spec):
                    out.append(r)
                # Или 2+ специфичных слова в сниппете (книга «обо всём», но абзац по теме)
                elif sum(1 for s in spec if s in snip_low) >= 2:
                    out.append(r)
            elif any(k in blob for k in (primary or en_words)):
                out.append(r)
            continue
        if r.get('source') == 'local':
            matched = r.get('matched') or []
            blob_id = (r.get('book','') + ' ' + (r.get('file') or '')).lower()
            name_ok = any(w in blob_id for w in words if len(w) >= 3)
            known_hit = any(
                any(t in m or m in t for t in _TRADITIO_OK)
                for m in matched
            )
            if len(matched) >= need or name_ok or known_hit:
                out.append(r)
            continue
        hit = 0
        for w in orig or words:
            alts = [w] + [a for a in _query_words(w) if a != w]
            if any(a in blob for a in alts):
                hit += 1
        if hit < need:
            hit = sum(1 for w in words if w in blob)
            need2 = 1 if need == 1 else min(need, 2)
            if hit < need2:
                continue
            hit = need
        if hit >= need:
            out.append(r)
    return out

# ===== Library of Congress (170M записей, без ключа) =====
def search_loc(query, limit=5):
    """Поиск в Library of Congress. Фильтры fa дают 403 — фильтруем на своей стороне:
    отбрасываем газеты (title с датами), оставляем книги."""
    try:
        import requests
        q_use = _en_query(query) if any('\u0400' <= c <= '\u04FF' for c in query) else query
        params = {'q': q_use, 'fo': 'json', 'c': 30}
        resp = requests.get('https://www.loc.gov/search/', params=params, timeout=15,
                            headers={'User-Agent': 'Mozilla/5.0 Hermetist'})
        resp.raise_for_status()
        d = resp.json()
        qwords = [w.lower() for w in query.replace('-', ' ').split() if len(w) >= 3 and w.lower() not in _STOP]
        en_words = [w for w in _en_query(query).split() if len(w) > 2 and w.lower() not in _STOP]
        results = []
        for item in (d.get('results') or [])[:30]:
            title = (item.get('title') or '').strip()
            if not title or len(title) < 10:
                continue
            # Газета? title вида "The Independent (Honolulu, H.I.), March 25, 1897"
            if re.search(r'\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}\b', title):
                continue
            if re.search(r'\d{4}-\d{2}-\d{2}', title):
                continue
            blob = (title + ' ' + ' '.join(str(x) for x in (item.get('subject') or []))).lower()
            hit = sum(1 for w in (qwords + en_words) if w in blob)
            if qwords and hit == 0:
                continue
            # Ложные «Guenon»: генеалогия Flushing, дойные коровы, William Augustus
            tl = title.lower()
            if any(j in tl for j in _JUNK_TITLE):
                continue
            ql = (query or '').lower()
            for grp in _NAME_ANCHORS:
                if any(a in ql or a in en_words for a in grp):
                    if not any(a in tl for a in grp):
                        hit = 0
                        break
                    # René / traditionalist, не однофамильцы
                    if 'guenon' in grp or 'генон' in grp:
                        if not any(x in tl for x in ('rene', 'rené', 'gué', 'tradition', 'crisis', 'east', 'west', 'quantity', 'vedanta', 'symbol')):
                            if 'jean guenon' in tl or 'augustus' in tl or 'genealogy' in tl or 'milch' in tl or 'dairy' in tl:
                                hit = 0
                                break
            if hit == 0 and qwords:
                continue
            url = item.get('url') or ''
            if url.startswith('//'):
                url = 'https:' + url
            results.append({
                'source': 'loc',
                'book': title[:110],
                'score': hit + 1,
                'snippet': (title[:150] + ' — Library of Congress, ' + (item.get('date') or 'дата неизв.')),
                'url': url,
            })
            if len(results) >= limit:
                break
        if not results:
            return [{'source': 'loc', 'error': 'нет результатов'}]
        return results
    except Exception as e:
        return [{'source': 'loc', 'error': str(e)[:100]}]

def _norm_book_key(r):
    """Дедуп: одна книга с разной страницей / обрезкой не должна дублироваться."""
    f = (r.get('file') or '').strip()
    if f:
        import os
        stem = os.path.basename(f).lower()
        stem = re.sub(r'\.(txt|pdf|djvu)$', '', stem)
        stem = re.sub(r'[-_]?\d{6,}[-_]?', ' ', stem)
        stem = re.sub(r'(pdfdrive|collected-works-of-rene-gueno.*)', '', stem)
        # общее ядро «revolt-against-the-modern-world»
        m = re.search(r'(revolt[-_]against[-_]the[-_]modern[-_]world)', stem)
        if m:
            return ('filecore', m.group(1))
        m = re.search(r'(crisis[-_]of[-_]the[-_]modern[-_]world)', stem)
        if m:
            return ('filecore', m.group(1))
        return ('file', re.sub(r'\s+', ' ', stem)[:90])
    book = (r.get('book') or '').lower()
    book = re.sub(r'\s*\(с\.\s*\d+\)\s*', '', book)
    book = re.sub(r'\s+', ' ', book).strip()[:90]
    return (r.get('source') or '', book)


# ===== Каскадный поиск =====
def cascade(query, verbose=False):
    """Роутер по теме → только нужные архивы. РГБ для русской истории, Sefaria для иудаики, SL по ключу для герметики."""
    from germetist_router import route
    report = []
    collected = []
    last_level = 1
    rt = route(query)
    report.append(f"🧭 тема: {rt['topic']} → local={','.join(rt['local'])} net={','.join(rt['net'])}")

    # ПРАВКА B (аудит Astra): локальный поток сохраняется ЦЕЛИКОМ, без ранней
    # отсечки _is_relevant / предпочтения заголовков / лимита 3 книги. Раньше именно
    # здесь гибли Генон и Эвола: они находились поиском, но не доходили до ответа.
    local = search_local(query, limit=30, dirs=rt['local'])
    if local:
        for r in local:
            collected.append({**r, '_stream': (query, 'local')})
        report.append('✅ Локальная база: %d кандидатов до общей оценки' % len(local))
    else:
        report.append("❌ Локальная база: пусто")

    NET = {
        'sourcelib': (3, 'Source Library', search_sourcelib),
        'archive.org': (4, 'Internet Archive', search_internet_archive),
        'loc': (6, 'Library of Congress', search_loc),
        'gutenberg': (5, 'Gutenberg', search_gutenberg),
        'sefaria': (2, 'Sefaria', search_sefaria),
        'rsl': (10, 'РГБ', search_rsl),
        'vostlit': (11, 'Востлит', search_vostlit),
    }
    levels = [NET[n] for n in rt['net'] if n in NET]

    seen = {_norm_book_key(r) for r in collected}
    q_en = _en_query(query)
    topic_pad = {
        'judaism', 'kabbalah', 'islam', 'sufism', 'hermeticism', 'alchemy',
        'chronicle', 'templar', 'templars', 'knights', 'temple',
    }
    core = [w for w in q_en.split() if w not in topic_pad]
    if core:
        q_en = ' '.join(core)

    def _run(item):
        level, name, fn = item
        q_use = query if name in ('РГБ', 'Востлит', 'Internet Archive', 'Library of Congress') else q_en
        try:
            got = fn(q_use)
            return level, name, got, None
        except Exception as e:
            return level, name, None, str(e)[:80]

    with ThreadPoolExecutor(max_workers=5) as ex:
        futs = [ex.submit(_run, it) for it in levels]
        try:
            for fut in as_completed(futs, timeout=25):
                try:
                    level, name, got, err = fut.result()
                except Exception as e:
                    report.append(f"❌ архив: {str(e)[:80]}")
                    continue
                last_level = max(last_level, level)
                if err:
                    report.append(f"❌ {name}: {err}")
                    continue
                if not got or got[0].get('error'):
                    err2 = (got[0].get('error') if got else 'пусто') or 'пусто'
                    report.append(f"❌ {name}: {err2}")
                    continue
                # ПРАВКА B: внешний поток тоже сохраняется целиком — фильтрация
                # и дедупликация переехали в общую оценку (RRF), чтобы не терять
                # кандидатов раньше, чем их увидит ранжирование.
                added = 0
                for r in got:
                    if r.get('error'):
                        continue
                    collected.append({**r, '_stream': (query, name)})
                    added += 1
                report.append(f"✅ {name}: {added} кандидатов до общей оценки")
        except TimeoutError:
            report.append("⚠️ Таймаут части архивов — берём что успели")

    # ПРАВКА B: отсечение [:12] убрано — лимит теперь один, на выходе app.py.
    return {'results': collected, 'level': last_level, 'report': report}

if __name__ == '__main__':
    q = ' '.join(sys.argv[1:]) or 'philosopher stone Paracelsus'
    print(f"Запрос: {q}\n")
    t0 = time.time()
    res = cascade(q)
    print(f"Время: {time.time()-t0:.1f}s")
    for line in res['report']:
        print(line)
    print()
    for r in res['results']:
        print(f"  [{r.get('source')}] {r.get('book','')[:60]}")
        print(f"    {r.get('snippet','')[:200]}")
        print(f"    {r.get('url','')}")
