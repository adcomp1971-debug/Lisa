#!/usr/bin/env python3
"""
YouTube Scout Digest — детекция новых видео + извлечение контента через Playwright.

Выход: структурированный текст с полным описанием для LLM-конспектирования.
Использование: python3 youtube-scout-digest.py [--since HOURS]
"""
import sys, os, json, sqlite3, time, re
import urllib.request, xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta

DB_PATH = os.path.expanduser("~/.hermes/youtube_scout.db")

CHANNELS = [
    {"id": "UCXUPKJO5MZQN11PqgIvyuvQ", "name": "Andrej Karpathy"},
    {"id": "UCNJ1Ymd5yFuUPtn21xtRbbw", "name": "AI Explained"},
    {"id": "UCbfYPyITQ-7l4upoX8nvctg", "name": "Two Minute Papers"},
    {"id": "UCZHmQk67mSJgfCCTn7xBfew", "name": "Yannic Kilcher"},
    {"id": "UCzz6ructab1U44QPI3HpZEQ", "name": "Stanford MLSys Seminars"},
    {"id": "UCcIXc5mJsHVYTZR1maL5l9w", "name": "DeepLearningAI"},
    {"id": "UCBHcMCGaiJhv-ESTcWGJPcw", "name": "NVIDIA Developer"},
    {"id": "UCtAcpQcYerN8xxZJYTfWBMw", "name": "Umar Jamil"},
    {"id": "UCqcbQf6yw5KzRoDDcZ_wBSw", "name": "Wes Roth"},
]

SINCE_HOURS = 48

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS videos (
            video_id TEXT PRIMARY KEY,
            channel_id TEXT, channel_name TEXT,
            title TEXT, url TEXT, description TEXT,
            published TEXT, detected_at TEXT,
            transcript_status TEXT DEFAULT 'pending', tags TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS digests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT, new_count INTEGER, content TEXT
        )
    """)
    conn.commit()
    return conn

def fetch_rss(channel):
    entries = []
    url = f"https://www.youtube.com/feeds/videos.xml?channel_id={channel['id']}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        resp = urllib.request.urlopen(req, timeout=15)
        root = ET.fromstring(resp.read())
        ns = {"atom": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015", "media": "http://search.yahoo.com/mrss/"}
        for entry in root.findall("atom:entry", ns):
            vid = entry.findtext("yt:videoId", "", ns)
            title = entry.findtext("atom:title", "", ns)
            pub = entry.findtext("atom:published", "", ns)
            desc_el = entry.find("media:group/media:description", ns)
            desc = desc_el.text.strip() if desc_el is not None and desc_el.text else ""
            link = entry.find("atom:link", ns)
            url_v = link.get("href", f"https://youtube.com/watch?v={vid}") if link is not None else f"https://youtube.com/watch?v={vid}"
            entries.append({"video_id": vid, "channel_id": channel["id"], "channel_name": channel["name"], "title": title, "url": url_v, "description": desc[:2000], "published": pub})
    except Exception as e:
        print(f"[WARN] RSS failed {channel['name']}: {e}", file=sys.stderr)
    return entries

def get_video_page_content(video_id):
    """Извлечь расширенное описание из YouTube страницы через playwright."""
    import subprocess
    script = f"""
const {{{{ page }}}} = require('playwright');
(async () => {{
    const browser = await chromium.launch();
    const page = await browser.newPage();
    await page.goto('https://www.youtube.com/watch?v={video_id}', {{ waitUntil: 'networkidle', timeout: 15000 }});
    await page.waitForTimeout(2000);
    const data = await page.evaluate(() => {{
        // Пытаемся получить полное описание
        let desc = '';
        try {{
            // Раскрываем "more"
            const moreBtn = document.querySelector('#expand');
            if (moreBtn) moreBtn.click();
        }} catch(e) {{}}
        try {{
            desc = document.querySelector('#description-inline-expander span')?.innerText || '';
        }} catch(e) {{}}
        // Chapters
        let chapters = [];
        try {{
            const chEls = document.querySelectorAll('ytd-macro-markers-list-item-renderer');
            chEls.forEach(el => {{
                const time = el.querySelector('#time')?.innerText || '';
                const title = el.querySelector('#title')?.innerText || '';
                if (time) chapters.push({{time, title}});
            }});
        }} catch(e) {{}}
        // Title
        const title = document.querySelector('h1 yt-formatted-string')?.innerText || '';
        return {{ title, description: desc.slice(0, 5000), chapters }};
    }});
    console.log(JSON.stringify(data));
    await browser.close();
}})();
"""
    # Пробуем через node playwright
    try:
        result = subprocess.run(
            ["node", "-e", script.replace("chromium", "chromium")],
            capture_output=True, text=True, timeout=30,
            env={**os.environ, "PLAYWRIGHT_CHROMIUM_PATH": os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux64/chrome")}
        )
        if result.stdout:
            data = json.loads(result.stdout.strip())
            return data
    except:
        pass
    return None

def do_digest(since_hours=SINCE_HOURS):
    conn = init_db()
    cursor = conn.cursor()
    cutoff = datetime.now(timezone.utc) - timedelta(hours=since_hours) if since_hours else None
    
    new_videos = []
    for ch in CHANNELS:
        entries = fetch_rss(ch)
        for entry in entries:
            if cutoff:
                try:
                    pub = datetime.fromisoformat(entry["published"].replace("Z", "+00:00"))
                    if pub < cutoff: continue
                except: pass
            cursor.execute("SELECT video_id FROM videos WHERE video_id = ?", (entry["video_id"],))
            if cursor.fetchone(): continue
            cursor.execute("INSERT OR IGNORE INTO videos (video_id, channel_id, channel_name, title, url, description, published, detected_at) VALUES (?,?,?,?,?,?,?,?)",
                (entry["video_id"], entry["channel_id"], entry["channel_name"], entry["title"], entry["url"], entry["description"][:2000], entry["published"], datetime.now(timezone.utc).isoformat()))
            new_videos.append(entry)
        time.sleep(0.3)
    conn.commit()
    
    if not new_videos:
        print("📡 YouTube Scout — новых видео нет")
        conn.close()
        return
    
    new_videos.sort(key=lambda e: e["published"], reverse=True)
    
    print(f"📡 YouTube Scout — {len(new_videos)} новых видео\n")
    print("─── КОНТЕНТ ДЛЯ КОНСПЕКТИРОВАНИЯ ───\n")
    
    for v in new_videos:
        try:
            dt = datetime.fromisoformat(v["published"].replace("Z", "+00:00"))
            pub_str = dt.strftime("%d %b %Y, %H:%M")
        except:
            pub_str = v["published"][:10]
        
        print(f"=== {v['title']}")
        print(f"Канал: {v['channel_name']} · {pub_str}")
        print(f"Ссылка: {v['url']}")
        print(f"ID видео: {v['video_id']}")
        print(f"\nОписание из RSS:")
        print(v["description"][:1000])
        print()
    
    print("─── КОНЕЦ ДАЙДЖЕСТА ───")
    
    digest_content = f"Найдено {len(new_videos)} новых видео"
    conn.execute("INSERT INTO digests (created_at, new_count, content) VALUES (?, ?, ?)",
        (datetime.now(timezone.utc).isoformat(), len(new_videos), digest_content))
    conn.commit()
    conn.close()

if __name__ == "__main__":
    hours = SINCE_HOURS
    if len(sys.argv) > 2 and sys.argv[1] == "--since":
        hours = int(sys.argv[2])
    do_digest(hours)
