#!/bin/bash
sleep 2
systemctl restart hermes-gateway
