#!/usr/bin/env python3
"""
NVIDIA-Agent Telegram Polling Bot (v2 — timeout-protected)
"""
import asyncio
import os
import sys
import signal
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Load env
env_path = Path("/root/.hermes/profiles/nvidia/.env")
if env_path.exists():
    for line in env_path.read_text().splitlines():
        if line.strip() and not line.startswith("#"):
            key, _, value = line.partition("=")
            os.environ.setdefault(key.strip(), value.strip())

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
if not BOT_TOKEN or not BOT_TOKEN.startswith("8"):
    print("ERROR: TELEGRAM_BOT_TOKEN not set")
    sys.exit(1)

HERMES = "/usr/local/lib/hermes-agent/venv/bin/hermes"
ALLOWED = 420839805
TIMEOUT = 60  # max seconds for simple replies
DEEP_TIMEOUT = 180  # max seconds for explicitly deep/technical replies
STYLE_PREFIX = (
    "Отвечай только по-русски. У тебя 2 режима ответа. По умолчанию отвечай очень просто, коротко и по-человечески, как нормальный технарь в Telegram: обычно 2-5 коротких предложений, сначала прямой ответ простыми словами, без перегруза деталями. "
    "Если пользователь сам просит подробнее, глубже, технично, сравнить, разобрать архитектуру, показать команды, плюсы и минусы или что-то 'под капотом' — переключайся в глубокий режим и отвечай более технично, но всё равно кратко и по существу (примерно 4-6 предложений или короткий список). "
    "Всегда без маркетинга, без воды, без смешения языков. Жаргон сразу расшифровывай простыми словами.\n\n"
)


async def hermes_chat(prompt: str) -> str:
    """Run hermes -p nvidia chat with timeout. Returns response or error text."""
    raw_prompt = prompt.strip()
    prompt = STYLE_PREFIX + raw_prompt
    lowered = raw_prompt.lower()
    deep_markers = [
        'подробно', 'глубже', 'технично', 'сравни', 'архитектур', 'плюсы и минусы',
        'под капотом', 'пошагово', 'с примерами', 'с командами'
    ]
    timeout = DEEP_TIMEOUT if any(m in lowered for m in deep_markers) else TIMEOUT
    try:
        proc = await asyncio.create_subprocess_exec(
            HERMES, "-p", "nvidia", "chat", "-q", prompt, "--quiet",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        if timeout > TIMEOUT:
            return f"❌ Глубокий ответ занял больше {timeout} секунд. Попробуй сузить вопрос."
        return f"❌ Ответ занял больше {timeout} секунд — NVIDIA API перегружен или модель зависла. Попробуй короче."

    output = stdout.decode("utf-8", errors="replace").strip()
    err = stderr.decode("utf-8", errors="replace").strip()

    if proc.returncode != 0:
        return err or output or "⚠️ Hermes завершился с ошибкой"

    lines = [line for line in output.splitlines() if line.strip()]
    if lines and lines[0].startswith("session_id:"):
        lines = lines[1:]

    cleaned = "\n".join(lines).strip()
    return cleaned or "⚠️ Пустой ответ от Hermes"


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ALLOWED:
        return
    await update.message.reply_text(
        "🟢 NVIDIA-Agent v2 (Nemotron Super, isolated profile)\n"
        "/status /bench /memory /skills /help"
    )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ALLOWED:
        return
    r = await hermes_chat("Ты кто и на какой модели? Ответь коротко.")
    await update.message.reply_text(r)


async def bench(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ALLOWED:
        return
    await update.message.reply_text("⏳ Бенчмарк...")
    r = await hermes_chat("Ответь коротко: 2+2, столица Франции, что такое NIM")
    await update.message.reply_text(r)


async def mem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ALLOWED:
        return
    r = await hermes_chat("Что в памяти? Покажи.")
    await update.message.reply_text(r)


async def skills(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ALLOWED:
        return
    r = await hermes_chat("Какие NVIDIA-скиллы доступны?")
    await update.message.reply_text(r)


async def handle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ALLOWED:
        return
    text = update.message.text
    if not text:
        return

    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")
    response = await hermes_chat(text)

    # Split if too long
    max_len = 4000
    for i in range(0, len(response), max_len):
        chunk = response[i:i + max_len]
        try:
            await update.message.reply_text(chunk)
        except Exception:
            await update.message.reply_text(chunk[:4096])


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    print(f"[ERROR] {context.error}", flush=True)
    if update and hasattr(update, 'effective_chat') and update.effective_chat:
        try:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text="⚠️ Ошибка. Попробуй ещё раз."
            )
        except Exception:
            pass


def main():
    print(f"[{datetime.now()}] NVIDIA bot starting...", flush=True)
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("bench", bench))
    app.add_handler(CommandHandler("memory", mem))
    app.add_handler(CommandHandler("skills", skills))
    app.add_handler(CommandHandler("help", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle))
    app.add_error_handler(error_handler)
    print(f"[{datetime.now()}] Polling...", flush=True)
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped")
    except Exception as e:
        print(f"Fatal: {e}", flush=True)
        sys.exit(1)