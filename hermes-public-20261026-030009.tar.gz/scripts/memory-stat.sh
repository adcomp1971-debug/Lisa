#!/usr/bin/env bash
set -uo pipefail
MEM=/root/.hermes/memories
DB=/root/.hermes/state.db
LOG=/root/.hermes/logs/memory-stat.log
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)

SIZE=$(cat "$MEM/MEMORY.md" "$MEM/USER.md" 2>/dev/null | wc -c)

LAST=$(grep 'size=' "$LOG" 2>/dev/null | tail -1 | sed 's/.*size=\([0-9]*\).*/\1/')
if [ -n "${LAST:-}" ] && [ "$LAST" -gt 0 ]; then
  DELTA=$(awk "BEGIN{printf \"%+.1f\", ($SIZE-$LAST)/$LAST*100}")
else
  DELTA="n/a"
fi

read CR IN COST < <(sqlite3 "$DB" "SELECT COALESCE(SUM(cache_read_tokens),0), COALESCE(SUM(input_tokens),0), ROUND(COALESCE(SUM(actual_cost_usd), SUM(estimated_cost_usd),0),2) FROM sessions WHERE started_at >= strftime('%s','now','-7 days');" | tr '|' ' ')
if [ "$((CR+IN))" -gt 0 ]; then
  EFF=$(awk "BEGIN{printf \"%.1f\", $CR/($CR+$IN)*100}")
else
  EFF="n/a"
fi

HDR=$(grep -cE "^#{1,3} " "$MEM/MEMORY.md" 2>/dev/null || echo 0)
if [ "$SIZE" -gt 51200 ] && [ "$HDR" -gt 0 ]; then GUARD="🔼 пора структурировать"; else GUARD="рано"; fi

LINE="$TS size=$SIZE delta=$DELTA% cache_eff=$EFF% spend7d=\$$COST guardian=$GUARD"
echo "$LINE" >> "$LOG"
echo "$LINE"