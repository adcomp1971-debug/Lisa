#!/usr/bin/env python3
import sys, os, json, base64, urllib.request, urllib.error

if len(sys.argv) < 3:
    print("usage: gemini_vision.py <image_path_or_url> <question>"); sys.exit(1)

img = sys.argv[1]
question = sys.argv[2]
MODEL = "google/gemini-3-flash-preview"

key = None
envpath = "/root/.hermes/.env"
if os.path.exists(envpath):
    for line in open(envpath):
        if line.startswith("OPENROUTER_API_KEY="):
            key = line.split("=", 1)[1].strip().strip('"').strip("'")
            break
if not key:
    print("ERR: OPENROUTER_API_KEY не найден"); sys.exit(1)

if img.startswith("http://") or img.startswith("https://"):
    image_url = img
else:
    if not os.path.exists(img):
        print(f"ERR: файл не найден: {img}"); sys.exit(1)
    ext = os.path.splitext(img)[1].lower().lstrip(".") or "png"
    if ext == "jpg": ext = "jpeg"
    with open(img, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    image_url = f"data:image/{ext};base64,{b64}"

payload = {"model": MODEL, "messages": [{"role": "user", "content": [
    {"type": "text", "text": question},
    {"type": "image_url", "image_url": {"url": image_url}}]}]}

req = urllib.request.Request("https://openrouter.ai/api/v1/chat/completions",
    data=json.dumps(payload).encode(),
    headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, method="POST")
try:
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.loads(r.read().decode())
    print(data["choices"][0]["message"]["content"])
except urllib.error.HTTPError as e:
    print(f"ERR HTTP {e.code}: {e.read().decode()[:300]}"); sys.exit(1)
except Exception as e:
    print(f"ERR: {e}"); sys.exit(1)
