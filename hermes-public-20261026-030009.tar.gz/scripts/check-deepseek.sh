#!/bin/bash
# check-deepseek.sh — watchdog for DeepSeek credits
# Runs alongside openrouter-balance-watch, alerts if balance < $5

KEY=$(grep -v '^#' /root/.hermes/.env 2>/dev/null | grep DEEPSEEK_API_KEY | cut -d= -f2 | tr -d ' "')
if [ -z "$KEY" ]; then
    echo "DEEPSEEK_KEY_NOT_FOUND"
    exit 0
fi

RESPONSE=$(curl -s --max-time 10 "https://api.deepseek.com/user/balance" \
    -H "Authorization: Bearer $KEY" 2>/dev/null)

if [ -z "$RESPONSE" ]; then
    echo "API_UNREACHABLE"
    exit 1
fi

BALANCE=$(echo "$RESPONSE" | python3 -c "
import json,sys
d=json.load(sys.stdin)
infos=d.get('balance_infos',[])
total = sum(float(i.get('total_balance',0)) for i in infos)
print(f'{total:.2f}')
" 2>/dev/null)

if [ -z "$BALANCE" ] || [ "$BALANCE" = "0.00" ]; then
    # Try parsing alternative format
    BALANCE=$(echo "$RESPONSE" | python3 -c "
import json,sys
d=json.load(sys.stdin)
print(d.get('balance','0'))
" 2>/dev/null)
fi

if [ -z "$BALANCE" ]; then
    echo "COULD_NOT_PARSE"
    exit 1
fi

echo "BALANCE: \$$BALANCE"

# Alert if low
if (( $(echo "$BALANCE < 5" | bc -l) )); then
    echo "⚠️ LOW DEEPSEEK CREDITS: \$$BALANCE remaining"
    echo "ALERT::low_deepseek::$BALANCE"
    exit 2
fi

echo "OK"
