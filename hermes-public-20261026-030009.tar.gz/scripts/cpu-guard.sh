#!/usr/bin/env bash
# cpu-guard — аварийный тормоз для тяжёлых задач на 4-ядерном Hostinger.
#
# ИСПРАВЛЕНО 2026-09-20 (код-аудит Grok): раньше убивал БЕЗУСЛОВНО при каждом запуске
# (переменная LOAD считалась, но не использовалась) — из-за этого индексация RAG
# никогда не достраивалась, а pkill -9 рвал запись индекса → битый индекс.
#
# Теперь: убивает ТОЛЬКО при реальной перегрузке (load >= 6 на 4 ядра),
# сначала TERM (даёт шанс корректно завершиться), потом KILL; с блокировкой от наложений.
set -uo pipefail

LOG=/root/.hermes/logs/cpu-guard.log
LOCK=/run/cpu-guard.lock
LOAD_THRESHOLD=6          # 4 ядра × 1.5 — выше = система деградирует (Telegram отваливается)
GRACE_SECONDS=10          # сколько ждать после TERM перед KILL

# блокировка: не запускать дважды одновременно
exec 9>"$LOCK"
if ! flock -n 9; then
  echo "$(date -u '+%F %T') уже выполняется — выход" >> "$LOG"
  exit 0
fi

LOAD=$(awk '{printf "%.1f", $1}' /proc/loadavg)
LOAD_INT=${LOAD%.*}

log() { echo "$(date -u '+%F %T') $*" >> "$LOG"; }

# ---- ГЛАВНОЕ ИСПРАВЛЕНИЕ: проверка порога ----
if [ "${LOAD_INT:-0}" -lt "$LOAD_THRESHOLD" ]; then
  log "load=$LOAD < $LOAD_THRESHOLD — перегрузки нет, ничего не трогаю"
  exit 0
fi

log "load=$LOAD >= $LOAD_THRESHOLD — перегрузка, ищу виновников"

# Мягкое завершение: сначала TERM, дать время, потом KILL только если жив
kill_pat() {
  local pat="$1" pids
  pids=$(pgrep -f "$pat" 2>/dev/null | grep -v "^$$\$" || true)
  [ -z "$pids" ] && return 0

  for pid in $pids; do
    # не трогаем процессы моложе 60 секунд — возможно, это нужная работа в начале
    local age
    age=$(ps -o etimes= -p "$pid" 2>/dev/null | tr -d ' ')
    if [ -n "${age:-}" ] && [ "$age" -lt 60 ]; then
      log "  PID $pid ($pat) — моложе 60с, не трогаю"
      continue
    fi
    local cmd
    cmd=$(ps -o args= -p "$pid" 2>/dev/null | head -c 120)
    log "  TERM PID $pid: $cmd"
    kill -TERM "$pid" 2>/dev/null || true
  done

  sleep "$GRACE_SECONDS"

  for pid in $pids; do
    if kill -0 "$pid" 2>/dev/null; then
      log "  KILL PID $pid (не ответил на TERM)"
      kill -KILL "$pid" 2>/dev/null || true
    fi
  done
  return 0
}

# Только реально тяжёлые задачи (точные паттерны, не широкие)
kill_pat 'build_hermetica_index'
kill_pat 'ollama create'
kill_pat 'finetune_hermetica\.py'

# llama-server НЕ убиваем — если он постоянный сервис эмбеддингов, ему место в systemd
# с CPUQuota (см. AGENTS.md: cgroups-лимиты). Убивать его = ломать Герметист.
# kill_pat 'llama-server.*--embedding'

LOAD_AFTER=$(awk '{printf "%.1f", $1}' /proc/loadavg)
log "после обработки: load=$LOAD_AFTER (был $LOAD)"
