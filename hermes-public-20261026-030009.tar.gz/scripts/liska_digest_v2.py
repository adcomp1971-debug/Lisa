#!/usr/bin/env python3
"""
Утренний дайджест для Ани v2 — multi-source + Prism-style.
Запускается по крону в 09:00 МСК (06:00 UTC).
"""
import asyncio
import json
import os
import sys
import urllib.request
from datetime import date

sys.path.insert(0, '/root')

# ── cron-runtime guard (2026-09-28) ───────────────────────────────────────
# Cron запускает .py-скрипты интерпретатором шлюза (sys.executable). После
# смены runtime-поколения Hermes 25.09.2026 это managed-python БЕЗ
# site-packages, поэтому модули, стоящие в venv, скрипту не видны.
# Перезапускаемся на первом интерпретаторе, где нужные модули есть.
# См. скилл cron-reliability §12.
_NEEDED = ("telegram", "aiohttp", "faster_whisper")


def _ensure_runtime():
    import glob, os, subprocess, sys

    def _ok(exe):
        try:
            return subprocess.run(
                [exe, "-c", "import " + ", ".join(_NEEDED)],
                capture_output=True, timeout=30,
            ).returncode == 0
        except Exception:
            return False

    if _ok(sys.executable):
        return
    candidates = ["/usr/local/lib/hermes-agent/venv/bin/python"]
    candidates += sorted(glob.glob("/root/.hermes/installs/*/environments/*/venv/bin/python"))
    for exe in candidates:
        if (os.path.exists(exe)
                and os.path.realpath(exe) != os.path.realpath(sys.executable)
                and _ok(exe)):
            os.execv(exe, [exe, os.path.abspath(__file__)] + sys.argv[1:])
    raise SystemExit("cron-runtime guard: нет интерпретатора с %s" % (", ".join(_NEEDED),))


_ensure_runtime()

from liskaanka_bot import search_cmd, call_llm, log

ENV_PATH = os.path.expanduser("~/.hermes/.env")

def _get_env(key):
    with open(ENV_PATH) as f:
        for line in f:
            if line.startswith(f"{key}="):
                return line.strip().split("=", 1)[1]
    return None

TOKEN = _get_env("TELEGRAM_BOT_TOKEN_LISKA")
CHAT_ID = 347164465  # Anya

def _send_telegram(text: str):
    data = json.dumps({
        "chat_id": CHAT_ID,
        "text": text[:4000],
        "parse_mode": "HTML",
    }).encode()
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{TOKEN}/sendMessage",
        data=data,
        headers={"Content-Type": "application/json"},
    )
    resp = urllib.request.urlopen(req, timeout=15)
    return json.loads(resp.read())


# ─── Multi-query search ───
# Вместо одного запроса — 4 точечных, каждый со своей свежестью

QUERIES = {
    "msk": "Москва главные новости сегодня происшествия",
    "ru":  "Россия главные новости сегодня политика экономика",
    "world": "мир главные новости сегодня политика",
    "life": "погода природа происшествия культура сегодня",
}

async def search_all() -> dict:
    """Параллельный поиск по 4 темам, возвращает {тема: [результаты]}"""
    tasks = {
        topic: search_cmd(query, limit=6)
        for topic, query in QUERIES.items()
    }
    results = {}
    for topic, coro in tasks.items():
        try:
            text = await coro
            results[topic] = text
        except Exception as e:
            log.error(f"Search {topic} failed: {e}")
            results[topic] = ""
    return results


async def make_digest() -> str:
    """Собрать дайджест в 2 прохода: поиск → LLM → синтез"""
    
    # Фаза 1: поиск по 4 темам
    log.info("Phase 1: Searching 4 topics...")
    raw = await search_all()
    
    # Собираем всё в один контекст
    search_block = []
    for topic, text in raw.items():
        label = {"msk": "Москва", "ru": "Россия", "world": "Мир", "life": "Погода/Культура"}
        search_block.append(f"=== {label.get(topic, topic)} ===\n{text[:1500]}")
    
    full_context = "\n\n".join(search_block)
    
    # Фаза 2: LLM — не просто категоризация, а осмысленный обзор
    # Prompt engineered на структуру, которой пользуется Аня
    system_prompt = (
        "Ты — Лиска, дружелюбный помощник. Составь утренний обзор новостей на сегодня, "
        f"{date.today().strftime('%d %B %Y')}.\n\n"
        "Правила:\n"
        "1. Разбей на блоки в таком порядке: Москва → Россия → Мир → Погода/Происшествия → Культура/Спорт/Интересное\n"
        "2. В каждом блоке 1-3 главные новости. Только факты, без домыслов.\n"
        "3. Если новость трагическая (пожар, ДТП, гибель) — напиши мягко, без смакования.\n"
        "4. Убирай повторы — если одно событие попало из нескольких источников, оставь лучший.\n"
        "5. Если в блоке нет важного — пропусти блок.\n"
        "6. В конце добавь раздел \"☀️ Погода сегодня\" — если есть данные.\n"
        "7. Заверши пожеланием хорошего дня (тёплым, но не приторным).\n\n"
        "Формат: обычный текст, без маркдауна. Каждый блок начинается с эмодзи и заголовка."
        "Коротко — чтобы можно было прочитать за 3-4 минуты."
    )
    
    user_prompt = (
        f"Вот результаты поиска по 4 темам (Москва, Россия, Мир, Погода/Культура). "
        f"Сделай из них структурированный утренний обзор:\n\n{full_context[:6000]}"
    )
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
    
    digest = await call_llm(messages)
    if not digest:
        # Fallback — просто текст
        digest = (
            "☀️ Доброе утро! Вот что нашлось по новостям:\n\n"
            f"{full_context[:2500]}"
        )
    
    return digest


async def main():
    log.info("Liska digest v2: starting multi-source search...")
    digest = await make_digest()
    
    log.info(f"Liska digest v2: sending ({len(digest)} chars)")
    msg = _send_telegram(f"☀️ <b>Доброе утро!</b>\n\n{digest}")
    log.info(f"Sent: {msg.get('ok')}")
    
    log.info("Liska digest v2 done")


if __name__ == "__main__":
    asyncio.run(main())
