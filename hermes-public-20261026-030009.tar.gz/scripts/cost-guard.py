#!/usr/bin/env python3
"""cost-guard — сторож расходов LLM для Hermes.

WHY (инцидент 21.09.2026): $12.58/мес, из них 91% — одна 30-дневная telegram-сессия.
Причина: Hermes считает окно deepseek-flash = 1M токенов, compression.threshold 0.7 →
компрессия включалась только на 700k. Сессия доросла до 697k токенов и каждый вызов
перечитывал их заново (cache-read = 96% всех токенов). Старый cost-report.py этого
не видел вообще: он считал sessions.started_at, поэтому долгоживущая сессия
в суточное окно не попадала и отчёт показывал $0.05/день и «ок».

HOW: парсит реальные API-вызовы из логов (~/.hermes/logs/agent.log*), где по каждому
вызову известно model / in / out / cache_read / session. Окно — скользящие N часов.

OUTPUT: пустой stdout + exit 0 = тишина (норма). Непустой stdout = алерт, cron
(no_agent) доставит его в Telegram. Всегда exit 0, чтобы cron не считал job упавшим.

ENV: COST_WINDOW_HOURS=24, COST_WARN_USD=1.0, COST_HARD_USD=3.0, SESSION_CTX_WARN=100000
"""
from __future__ import annotations

import collections
import gzip
import hashlib
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone
from typing import Any, Dict

LOG_DIR = os.path.expanduser("~/.hermes/logs")
STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "state", "cost-guard-state.json")
STATE_FILE = os.path.normpath(STATE_FILE)
# Повтор ТОЧНО ТАКОГО ЖЕ алерта (та же сигнатура) — не чаще, чем раз в N часов,
# если суммарный расход не вырос заметно. Иначе один раздутый контекст спамит каждые 6ч.
REPEAT_HOURS = float(os.environ.get("COST_REPEAT_HOURS", "72"))
REPEAT_COST_GROWTH = float(os.environ.get("COST_REPEAT_GROWTH", "1.5"))
LOG_FILES = ["agent.log", "agent.log.1", "agent.log.2.gz", "agent.log.3.gz"]

WINDOW_HOURS = float(os.environ.get("COST_WINDOW_HOURS", "24"))
WARN_USD = float(os.environ.get("COST_WARN_USD", "1.0"))
HARD_USD = float(os.environ.get("COST_HARD_USD", "3.0"))
SESS_CTX_WARN = int(os.environ.get("SESSION_CTX_WARN", "100000"))

# $ за 1M токенов: (input_uncached, output, cache_read). DeepSeek peak (01-04 и 06-10 UTC,
# пн-пт) — ×2. Значения — оценка по прайсу провайдера; важна динамика, не копейки.
PRICES: Dict[str, tuple] = {
    "deepseek-flash": (0.15, 0.60, 0.028),
    "deepseek-v4-flash": (0.15, 0.60, 0.028),
    "deepseek-chat": (0.15, 0.60, 0.028),
    "deepseek-v4-pro": (0.66, 1.98, 0.13),
    "grok-4.6": (2.00, 6.00, 0.50),
    "grok-4.7": (2.00, 6.00, 0.50),
    "grok-4.20-reasoning": (1.25, 2.50, 0.20),
    "grok-4.3": (1.25, 2.50, 0.50),
    "glm-5.3": (1.40, 4.40, 0.26),
    "glm-5.3-flash": (0.15, 0.50, 0.03),
    "kimi-k3": (0.40, 1.60, 0.10),
    "gpt-5.6-luna": (0.30, 1.20, 0.06),
    "gpt-6-astra": (10.00, 50.00, 2.00),
    "gemini-3.7-flash": (0.05, 0.20, 0.01),
    "gemini-3.8-flash": (0.05, 0.20, 0.01),
    "hermes-agent": (0.0, 0.0, 0.0),
}
DEFAULT_PRICE = (0.20, 0.80, 0.04)

LINE_RE = re.compile(
    r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),\d+ \w+ \[(\S+)\] [\w.]+: API call #\d+: "
    r"model=(\S+) provider=(\S+) in=(\d+) out=(\d+) total=(\d+) latency=(\S+) cache=(\d+)/(\d+)"
)


def new_sess() -> Dict[str, Any]:
    return {
        "calls": 0,
        "in": 0,
        "out": 0,
        "cache": 0,
        "cost": 0.0,
        "models": collections.Counter(),
        "last": None,
        "max_ctx": 0,
    }


def is_peak(ts: datetime) -> bool:
    """DeepSeek peak: 01:00-04:00 и 06:00-10:00 UTC, пн-пт (в остальное время скидка 50%)."""
    if ts.weekday() >= 5:
        return False
    return (1 <= ts.hour < 4) or (6 <= ts.hour < 10)


def price_for(model: str, ts: datetime) -> tuple:
    p = PRICES.get(model, DEFAULT_PRICE)
    if model.startswith("deepseek") and is_peak(ts):
        p = tuple(x * 2 for x in p)
    return p


def main() -> int:
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    cutoff = now - timedelta(hours=WINDOW_HOURS)

    per_session: Dict[str, Dict[str, Any]] = {}
    calls = 0

    for name in LOG_FILES:
        path = os.path.join(LOG_DIR, name)
        if not os.path.exists(path):
            continue
        opener = gzip.open if path.endswith(".gz") else open
        try:
            with opener(path, "rt", errors="ignore") as fh:
                for line in fh:
                    if "API call #" not in line:
                        continue
                    m = LINE_RE.match(line)
                    if not m:
                        continue
                    ts_s, sess, model, _prov, tin, tout, _tot, _lat, cr, _ct = m.groups()
                    try:
                        ts = datetime.strptime(ts_s, "%Y-%m-%d %H:%M:%S")
                    except ValueError:
                        continue
                    if ts < cutoff:
                        continue
                    tin, tout, cr = int(tin), int(tout), int(cr)
                    uncached = max(tin - cr, 0)
                    pi, po, pc = price_for(model, ts)
                    cost = (uncached * pi + cr * pc + tout * po) / 1_000_000

                    s = per_session.get(sess)
                    if s is None:
                        s = per_session[sess] = new_sess()
                    s["calls"] += 1
                    s["in"] += tin
                    s["out"] += tout
                    s["cache"] += cr
                    s["cost"] += cost
                    s["models"][model] += 1
                    if s["last"] is None or ts > s["last"]:
                        s["last"] = ts
                    s["max_ctx"] = max(s["max_ctx"], tin)
                    calls += 1
        except Exception:
            continue

    if calls == 0:
        return 0  # нет данных — молчим

    total_cost = sum(s["cost"] for s in per_session.values())
    total_in = sum(s["in"] for s in per_session.values())
    total_out = sum(s["out"] for s in per_session.values())
    total_cache = sum(s["cache"] for s in per_session.values())

    fat = [
        (sid, s)
        for sid, s in per_session.items()
        if s["max_ctx"] >= SESS_CTX_WARN
        and s["last"] is not None
        and (now - s["last"]).total_seconds() < 6 * 3600
    ]

    alerts = []
    if total_cost >= HARD_USD:
        alerts.append(f"🔴 ЖЁСТКО: ${total_cost:.2f} за {WINDOW_HOURS:.0f}ч (порог ${HARD_USD:.2f})")
    elif total_cost >= WARN_USD:
        alerts.append(f"⚠️ ${total_cost:.2f} за {WINDOW_HOURS:.0f}ч (порог ${WARN_USD:.2f})")

    for sid, s in sorted(fat, key=lambda x: -x[1]["max_ctx"])[:3]:
        alerts.append(
            f"⚠️ раздутый контекст: {sid} — {s['max_ctx']:,} токенов, "
            f"{s['calls']} вызовов за окно, ${s['cost']:.2f} → начинай новый чат"
        )

    if not alerts:
        return 0

    # --- дедупликация: не повторять тот же алерт слишком часто ---
    sig = hashlib.sha1("|".join(alerts).encode()).hexdigest()[:16]
    prev = {}
    try:
        with open(STATE_FILE, "rt") as fh:
            prev = json.load(fh)
    except Exception:
        prev = {}

    if prev.get("sig") == sig:
        last_alert = prev.get("at")
        prev_cost = float(prev.get("cost") or 0.0)
        too_soon = True
        if last_alert:
            try:
                dt = datetime.fromisoformat(last_alert)
                too_soon = (now - dt) < timedelta(hours=REPEAT_HOURS)
            except Exception:
                too_soon = False
        grew = total_cost > prev_cost * REPEAT_COST_GROWTH if prev_cost else True
        if too_soon and not grew:
            return 0  # тот же алерт, ничего не изменилось — молчим

    print(f"💰 COST GUARD — окно {WINDOW_HOURS:.0f}ч, вызовов {calls}")
    for a in alerts:
        print(a)
    print(f"Токены: in {total_in:,} (cache {total_cache:,}), out {total_out:,}")
    print("Топ сессий по расходу:")
    for sid, s in sorted(per_session.items(), key=lambda x: -x[1]["cost"])[:5]:
        last = s["last"].strftime("%d.%m %H:%M") if s["last"] else "?"
        models = ",".join(name for name, _ in s["models"].most_common(2))
        print(
            f"  {sid} · {s['calls']} вызовов · ctx_max {s['max_ctx']:,} · "
            f"${s['cost']:.2f} · посл. {last} · {models}"
        )
    if prev.get("sig") == sig:
        print(f"↻ повтор предыдущего алерта (сигнатура та же)")

    try:
        os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
        with open(STATE_FILE, "wt") as fh:
            json.dump({"sig": sig, "at": now.isoformat(timespec="seconds"), "cost": round(total_cost, 4)}, fh)
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
