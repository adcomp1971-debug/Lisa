#!/bin/bash
# session-prune — чистка старых сессий без LLM
# Молчит если нечего чистить (no_agent: пустой stdout = тихо)

OUT=$(hermes sessions prune --older-than 30 --yes 2>&1)
EXIT=$?

if [ $EXIT -ne 0 ]; then
    echo "⚠️ session-prune: ошибка выполнения: $OUT"
    exit 0
fi

# Выводим только если что-то удалено
if echo "$OUT" | grep -qiE 'pruned|removed|deleted|[0-9]+ session'; then
    echo "🧹 session-prune: $OUT"
fi
