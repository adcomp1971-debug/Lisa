#!/usr/bin/env python3
import re

with open('/root/.hermes/.env', 'r') as f:
    content = f.read()

# Show current key prefix
m = re.search(r'^DEEPSEEK_API_KEY=(.*)$', content, re.MULTILINE)
if m:
    old_key = m.group(1).strip()
    print(f"Current key: {old_key[:12]}...{old_key[-4:]}")
else:
    print("No DEEPSEEK_API_KEY found!")
    exit(1)

# New key from user
new_key = "<ВСТАВЬТЕ_КЛЮЧ_ИЛИ_ЧИТАЙТЕ_ИЗ_ENV>"

# Replace
new_content = re.sub(
    r'^DEEPSEEK_API_KEY=.*$',
    f'DEEPSEEK_API_KEY={new_key}',
    content,
    count=1,
    flags=re.MULTILINE
)

with open('/root/.hermes/.env', 'w') as f:
    f.write(new_content)

# Verify
with open('/root/.hermes/.env', 'r') as f:
    v = f.read()
m2 = re.search(r'^DEEPSEEK_API_KEY=(.*)$', v, re.MULTILINE)
if m2:
    new = m2.group(1).strip()
    print(f"Written key: {new[:12]}...{new[-4:]}")
    if new_key in new:
        print("OK - key updated successfully")
    else:
        print("ERROR: key mismatch!")
        exit(1)
