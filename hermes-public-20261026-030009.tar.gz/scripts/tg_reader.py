#!/usr/bin/env python3
"""Telegram channel reader via Telethon — auth + search + read posts.

First run: authenticates with phone number and saves session.
Subsequent runs: uses saved session.

Usage:
    # Step 1: request code (no --code)
    python3 tg_reader.py --auth
    # Step 2: complete auth with received code
    python3 tg_reader.py --auth --code "9u4s0sJe6Ag"
    # Step 3: read channels
    python3 tg_reader.py --channel @bbbreaking
    python3 tg_reader.py --search "орешник"
    python3 tg_reader.py --globalsearch "Украина"
    python3 tg_reader.py --list
"""

import os
import sys
import json
import argparse
import asyncio
from datetime import datetime

from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError

# Credentials from Alex
API_ID = 36633463
API_HASH = "6227801e5ea910daccde171aeec5b7da"
PHONE = "+972536285227"
SESSION_FILE = os.path.expanduser("~/.hermes/telegram_session")

# Known channels to search
KNOWN_CHANNELS = [
    "@bbbreaking",
    "@rian_ru",
    "@milinfolive",
    "@rt_russian",
    "@tass_agency",
    "@vchkogpu",
    "@meduzaproject",
    "@russia_ukraine_war",
]


async def auth(code: str = None):
    """Authenticate and save session. Two-step: request code, then sign in."""
    client = TelegramClient(SESSION_FILE, API_ID, API_HASH)
    await client.connect()

    if code:
        # Step 2: sign in with code
        try:
            await client.sign_in(phone=PHONE, code=code)
            me = await client.get_me()
            print(f"\n✓ Authenticated as: {me.first_name} (@{me.username})")
            print(f"  Phone: {me.phone}")
            print(f"  Session saved: {SESSION_FILE}")
        except SessionPasswordNeededError:
            print("2FA enabled. Please provide password with --password")
        except Exception as e:
            print(f"✗ Sign in failed: {e}")
            # Try to request a fresh code
            try:
                await client.send_code_request(PHONE)
                print("Fresh code requested. Run again with --code NEW_CODE")
            except Exception:
                pass
    else:
        # Step 1: request code
        try:
            result = await client.send_code_request(PHONE)
            print(f"\n✓ Code sent to Telegram!")
            print(f"  Phone: {PHONE}")
            print(f"  Timeout: {result.timeout}s")
            print(f"\n  Now run: python3 tg_reader.py --auth --code \"YOUR_CODE\"")
        except Exception as e:
            print(f"✗ Failed to send code: {e}")

    await client.disconnect()


async def read_channel(channel_name: str, limit: int = 20):
    """Read last N posts from a channel."""
    client = TelegramClient(SESSION_FILE, API_ID, API_HASH)
    await client.start()

    try:
        entity = await client.get_entity(channel_name)
        title = getattr(entity, 'title', channel_name)
        print(f"\n=== {channel_name} — {title} ===")

        messages = await client.get_messages(entity, limit=limit)
        for msg in messages:
            if msg.text:
                dt = msg.date.strftime("%H:%M") if msg.date else "??:??"
                text = msg.text[:300].replace("\n", " | ")
                print(f"  [{dt}] {text}")
                print()

        print(f"── {len(messages)} posts")
    except Exception as e:
        print(f"✗ {channel_name}: {e}")

    await client.disconnect()


async def search_channels(query: str, channels: list[str] = None, limit: int = 5):
    """Search for query in known channels."""
    if channels is None:
        channels = KNOWN_CHANNELS

    client = TelegramClient(SESSION_FILE, API_ID, API_HASH)
    await client.start()

    query_lower = query.lower().split()
    all_hits = []

    for ch in channels:
        try:
            entity = await client.get_entity(ch)
            messages = await client.get_messages(entity, limit=200)
            hits = []
            for msg in messages:
                if msg.text and all(q in msg.text.lower() for q in query_lower):
                    hits.append({
                        "channel": ch,
                        "date": msg.date.isoformat() if msg.date else "",
                        "text": msg.text[:300],
                    })
            all_hits.extend(hits)
            if hits:
                print(f"\n=== {ch} ({len(hits)} hits) ===")
                for h in hits[:limit]:
                    print(f"  [{h['date'][:16]}] {h['text'][:250]}")
                    print()
        except Exception as e:
            print(f"  ✗ {ch}: {e}")

    print(f"\n── Total: {len(all_hits)} hits across {len(channels)} channels")
    await client.disconnect()


async def list_dialogs():
    """List available dialogs (channels, chats)."""
    client = TelegramClient(SESSION_FILE, API_ID, API_HASH)
    await client.start()

    print("\n=== Your dialogs (channels & chats) ===")
    async for dialog in client.iter_dialogs(limit=100):
        if dialog.is_channel:
            uname = getattr(dialog.entity, 'username', None)
            at = f" @{uname}" if uname else ""
            print(f"  [channel] {dialog.name}{at} — {dialog.entity.participants_count or '?'} участников")

    await client.disconnect()


async def search_direct(query: str, limit: int = 100):
    """Global Telegram search."""
    client = TelegramClient(SESSION_FILE, API_ID, API_HASH)
    await client.start()

    print(f"\n=== Global search: '{query}' ===")
    count = 0
    async for message in client.iter_messages(None, search=query, limit=limit):
        if message.text:
            dt = message.date.strftime("%d.%m %H:%M") if message.date else ""
            ch_name = ""
            try:
                chat = await message.get_chat()
                ch_name = getattr(chat, 'title', '') or getattr(chat, 'username', '')
            except Exception:
                pass
            print(f"  [{dt}] [{ch_name}] {message.text[:200]}")
            print()
            count += 1

    print(f"── {count} results")
    await client.disconnect()


def main():
    parser = argparse.ArgumentParser(description="Telegram reader via Telethon")
    parser.add_argument("--auth", action="store_true", help="Authenticate (with optional --code)")
    parser.add_argument("--code", help="Verification code from Telegram")
    parser.add_argument("--channel", help="Read last posts from channel (e.g. @bbbreaking)")
    parser.add_argument("--limit", type=int, default=20, help="Max posts per channel")
    parser.add_argument("--search", help="Search query across known channels")
    parser.add_argument("--globalsearch", help="Global Telegram search")
    parser.add_argument("--list", action="store_true", help="List accessible dialogs/channels")
    parser.add_argument("--json", action="store_true", help="Output JSON")
    args = parser.parse_args()

    if args.auth:
        asyncio.run(auth(code=args.code))
    elif args.channel:
        asyncio.run(read_channel(args.channel, args.limit))
    elif args.search:
        asyncio.run(search_channels(args.search, limit=args.limit))
    elif args.globalsearch:
        asyncio.run(search_direct(args.globalsearch, limit=args.limit))
    elif args.list:
        asyncio.run(list_dialogs())
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
