#!/usr/bin/env python3
"""
Stack Doctor — вечерний аудит инфраструктуры.
Проверяет: систему, сервисы, конфиги, обновления, бэкапы, память.
Запускать: python3 stack-doctor.py
"""
import subprocess, os, json, sqlite3
from datetime import datetime, timezone
from pathlib import Path

HOME = os.path.expanduser("~")
HERMES_HOME = os.path.join(HOME, ".hermes")
NOW = datetime.now(timezone.utc)

def run(cmd, timeout=15):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip(), r.returncode
    except subprocess.TimeoutExpired:
        return "TIMEOUT", -1
    except Exception as e:
        return f"ERROR: {e}", -1

def fmt_size(b):
    if not b: return "0 B"
    for unit in ("B","KB","MB","GB","TB"):
        if b < 1024: return f"{b:.1f} {unit}"
        b /= 1024
    return f"{b:.1f} PB"

def check_system():
    issues = []
    # Disk
    out, _ = run("df -h / /var/log /root 2>/dev/null")
    disk_info = out
    for line in out.split("\n")[1:]:
        parts = line.split()
        if len(parts) >= 5:
            mount = parts[-1]
            pct = parts[-2].replace("%","")
            if pct and int(pct) > 85:
                issues.append(f"⚠️ Диск {mount} заполнен на {pct}%")
    
    # Memory
    out, _ = run("free -h")
    mem_info = out
    try:
        mem_line = out.split("\n")[1]
        parts = mem_line.split()
        total = parts[1]
        used = parts[2]
        avail = parts[-1]
    except: total = used = avail = "?"
    
    # Uptime
    out, _ = run("uptime -p")
    uptime = out.replace("up ", "") if out else "?"
    
    # Load
    out, _ = run("cat /proc/loadavg 2>/dev/null | cut -d' ' -f1-3")
    load = out
    
    # Zram / swap
    out, _ = run("swapon --show 2>/dev/null | tail -1")
    swap_info = out
    
    return {
        "disk": disk_info,
        "mem_total": total,
        "mem_used": used,
        "mem_avail": avail,
        "uptime": uptime,
        "load": load,
        "swap": swap_info,
        "issues": issues
    }

def check_services():
    # guardrails здесь намеренно НЕТ: это мёртвый oneshot-заглушка (/bin/true), вычищенный
    # ещё 13.06 после restart-loop. Пока он был в списке, доктор каждый вечер показывал
    # «⚠️ guardrails: inactive» как проблему — ложный алерт.
    services = {
        "nginx": "systemctl is-active nginx",
        "tailscale": "systemctl is-active tailscaled",
        "hermes-gateway": "systemctl is-active hermes-gateway 2>/dev/null || echo inactive",
        "hermes-dashboard": "systemctl is-active hermes-dashboard 2>/dev/null || echo inactive",
        "x-ui": "systemctl is-active x-ui 2>/dev/null || echo inactive",
        "awg0": "systemctl is-active awg-quick@awg0 2>/dev/null || echo inactive",
    }
    results = {}
    for name, cmd in services.items():
        out, _ = run(cmd, timeout=5)
        results[name] = out
    return results

def check_updates():
    updates = []
    # Apt updates
    out, code = run("apt list --upgradable 2>/dev/null | grep -v 'Listing...' | wc -l")
    try:
        n = int(out.strip())
        if n > 0:
            updates.append(f"{n} apt-пакетов доступно для обновления")
    except:
        pass
    
    # Hermes version
    out, _ = run("cd /root/.hermes && git log --oneline -1 2>/dev/null")
    hermes_local = out[:40] if out else "?"
    out, _ = run("cd /root/.hermes && git remote update 2>/dev/null; git rev-list --count HEAD..origin/main 2>/dev/null")
    try:
        behind = int(out.strip())
        if behind > 0:
            updates.append(f"Hermes на {behind} коммитов позади main")
    except:
        pass
    
    # Reboot / ядро
    out, _ = run("test -f /var/run/reboot-required && echo yes || echo no")
    if out.strip() == "yes":
        run_k, _ = run("uname -r")
        inst, _ = run("dpkg-query -W -f='${Version}' linux-image-virtual 2>/dev/null")
        pkgs, _ = run("cat /var/run/reboot-required.pkgs 2>/dev/null | sort -u | tr '\\n' ' '")
        updates.append(f"ТРЕБУЕТСЯ ПЕРЕЗАГРУЗКА (ядро в работе {run_k}, установлено {inst}; {pkgs.strip()})")

    return {"hermes_local": hermes_local, "updates": updates}

OFFSITE_REPO = "/root/backups/offsite"

def check_backups():
    """Проверяет РЕАЛЬНОЕ offsite-репо (remote = GitHub), а не /root/.hermes.

    /root/.hermes — локальный репо БЕЗ remote (последний коммит 30.05.2026); раньше доктор
    смотрел именно его и каждый вечер ложно докладывал «нет коммитов за 7 дней», хотя
    offsite-пуш отрабатывал штатно. Показывать свежесть надо по /root/backups/offsite.
    """
    info = {"last_commit": "?", "recent_commit_7d": "нет коммитов за 7 дней",
            "recent_backup": "", "sync": "?"}
    if not os.path.isdir(os.path.join(OFFSITE_REPO, ".git")):
        info["sync"] = "НЕТ РЕПО"
        return info

    run(f"git -C {OFFSITE_REPO} fetch --quiet origin 2>/dev/null", timeout=30)
    out, _ = run(f"git -C {OFFSITE_REPO} log -1 --format='%h %cd %s' --date='format:%d.%m %H:%M'")
    if out:
        info["last_commit"] = out[:80]
    out, _ = run(f"git -C {OFFSITE_REPO} log -1 --since='7 days ago' --format='%h'")
    info["recent_commit_7d"] = "есть" if out else "нет коммитов за 7 дней"

    local, _ = run(f"git -C {OFFSITE_REPO} rev-parse HEAD")
    remote, _ = run(f"git -C {OFFSITE_REPO} ls-remote origin main 2>/dev/null | cut -f1", timeout=30)
    local, remote = local.strip(), remote.strip()
    if local and remote and local == remote:
        info["sync"] = "✅ локальный HEAD == GitHub"
    elif local and remote:
        info["sync"] = f"⚠️ расхождение: локально {local[:7]} / GitHub {remote[:7]}"
    else:
        info["sync"] = "⚠️ GitHub недоступен — пуш проверить вручную"

    out, _ = run(f"ls -lt {OFFSITE_REPO}/*.tar.gz* 2>/dev/null | head -3")
    info["recent_backup"] = out[:400]
    return info

def check_logs():
    # Hermes log errors (сетевой шум Telegram вынесен отдельно — он не ошибка, а флап маршрута)
    out, _ = run("grep -iE 'error|traceback|exception' /root/.hermes/logs/*.log 2>/dev/null | grep -v telegram_network | tail -10")
    errors = out[:1000]
    
    # Log sizes
    out, _ = run("du -sh /root/.hermes/logs/ 2>/dev/null")
    log_size = out
    
    # Сетевой шум Telegram за сутки: это WARNING'и sticky-пути, шлюз сам переключается за ~10 c.
    # До 30/сутки — норма (наблюдения 29.09–05.10: 0–17). Больше — смотреть маршрут до Telegram.
    out, _ = run("journalctl -u hermes-gateway --since '24 hours ago' 2>/dev/null | grep -c telegram_network")
    tg_noise = out.strip() or "0"
    try:
        tg_noise_n = int(tg_noise)
    except ValueError:
        tg_noise_n = -1
    
    # Cron jobs (jobs.json, а не снесённый cron.db)
    cron_list = check_cron()
    
    return {"errors": errors, "log_size": log_size, "cron_list": cron_list, "tg_noise": tg_noise_n}


def check_cron():
    jobs_file = os.path.join(HERMES_HOME, "cron", "jobs.json")
    try:
        with open(jobs_file, encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as exc:
        return f"ERROR: {exc}"
    jobs = data if isinstance(data, list) else data.get("jobs", [])
    if isinstance(jobs, dict):
        jobs = list(jobs.values())
    rows = []
    for j in jobs:
        sched = j.get("schedule") or {}
        if isinstance(sched, dict):
            sched = sched.get("display") or sched.get("cron") or sched.get("expr") or "?"
        rows.append(f"{j.get('name', '?')}|{1 if j.get('enabled') else 0}|{sched}")
    return "\n".join(rows)

def check_memory_db():
    """Память Hermes живёт в /root/.hermes/memories/*.md (не в sqlite).

    Старая версия читала memory.db/user_profile.db — их нет, отсюда вечное «? записей · 0 B».
    Показываем размер и заполненность относительно лимитов (MEMORY 20000, USER 2000 символов).
    """
    out = {}
    for label, fname, limit in (("memory", "MEMORY.md", 20000), ("profile", "USER.md", 2000)):
        path = os.path.join(HERMES_HOME, "memories", fname)
        if not os.path.exists(path):
            out[label] = "файл не найден"
            continue
        try:
            with open(path, encoding="utf-8") as fh:
                n = len(fh.read())
        except Exception as exc:
            out[label] = f"ошибка чтения: {exc}"
            continue
        out[label] = f"{n}/{limit} симв. ({100 * n // limit}%)"
    return out

def check_nginx():
    out, _ = run("nginx -t 2>&1")
    cfg_ok = "syntax is ok" in out
    out, _ = run("ls -la /etc/nginx/sites-enabled/ 2>/dev/null")
    enabled = out[:500]
    return {"config_ok": cfg_ok, "sites_enabled": enabled}

def check_tailscale():
    out, _ = run("tailscale status 2>/dev/null | head -10")
    return out[:500]

def main():
    print(f"🏥 Stack Doctor — {NOW.strftime('%d %b %Y %H:%M UTC')}\n")
    
    # 1. Система
    sys = check_system()
    print("## 💻 Система")
    print(f"  Uptime: {sys['uptime']}")
    print(f"  Load: {sys['load']}")
    print(f"  RAM: {sys['mem_used']} / {sys['mem_total']} (доступно {sys['mem_avail']})")
    if sys['swap']:
        print(f"  Swap: {sys['swap']}")
    for i in sys['issues']:
        print(f"  {i}")
    print()
    
    # 2. Сервисы
    svc = check_services()
    print("## 🔧 Сервисы")
    for name, status in svc.items():
        icon = "✅" if status == "active" or status == "active\n" else "⚠️" if "inactive" in status else "❌"
        print(f"  {icon} {name}: {status.strip()}")
    print()
    
    # 3. Nginx
    nginx = check_nginx()
    print("## 🌐 Nginx")
    print(f"  Config: {'✅ OK' if nginx['config_ok'] else '❌ ERROR'}")
    print()
    
    # 4. Tailscale
    ts = check_tailscale()
    print("## 🔗 Tailscale")
    print(f"  {ts[:300]}")
    print()
    
    # 5. Обновления
    upd = check_updates()
    print("## 📦 Обновления")
    print(f"  Hermes: {upd['hermes_local'][:15]}...")
    for u in upd['updates']:
        print(f"  📢 {u}")
    if not upd['updates']:
        print("  ✅ Всё актуально")
    print()
    
    # 6. Бэкапы
    bak = check_backups()
    print("## 💾 Бэкапы")
    print(f"  Последний коммит: {bak['last_commit'][:50]}")
    print(f"  Коммит за 7 дней: {bak['recent_commit_7d']}")
    print(f"  Синхронизация: {bak['sync']}")
    if bak['recent_backup']:
        print(f"  Архив: {bak['recent_backup'][:200]}")
    print()
    
    # 7. Память
    mem = check_memory_db()
    print("## 🧠 Память Hermes")
    print(f"  MEMORY.md: {mem['memory']}")
    print(f"  USER.md:   {mem['profile']}")
    print()
    
    # 8. Логи
    logs = check_logs()
    print("## 📋 Логи & Кроны")
    print(f"  Размер логов: {logs['log_size']}")
    noise = logs['tg_noise']
    if noise < 0:
        print("  Telegram-сеть: не удалось посчитать")
    elif noise <= 30:
        print(f"  Telegram-сеть: {noise} флапов/24 ч — норма (шлюз сам переключает путь за ~10 с, потери не фиксировались)")
    else:
        print(f"  ⚠️ Telegram-сеть: {noise} флапов/24 ч — выше нормы (30), смотреть маршрут до api.telegram.org")
    if logs['errors']:
        print(f"  ⚠️ Последние ошибки:")
        for line in logs['errors'].split("\n")[-5:]:
            if line.strip(): print(f"    {line.strip()[:120]}")
    print()
    
    # 9. Cron jobs
    print("## ⏰ Активные кроны")
    if logs['cron_list']:
        for line in logs['cron_list'].split("\n"):
            if line.strip():
                parts = line.split("|")
                if len(parts) >= 3:
                    name = parts[0].strip()
                    enabled = parts[1].strip()
                    sched = parts[2].strip()
                    e = "✅" if enabled == "1" else "⏸️"
                    print(f"  {e} {name} · {sched}")
    print()
    
    # Итоговые рекомендации
    print("## 📋 Рекомендации")
    recs = []
    
    if sys['issues']:
        recs.extend(sys['issues'])
    
    for name, st in svc.items():
        if st != "active":
            recs.append(f"Сервис {name} не активен")

    if not bak['sync'].startswith("✅"):
        recs.append(f"Бэкап-репо: {bak['sync']}")
    
    for u in upd['updates']:
        recs.append(f"🔧 {u}")
    
    if nginx['config_ok'] == False:
        recs.append("Nginx config битый!")
    
    if recs:
        for r in recs:
            print(f"  • {r}")
    else:
        print("  ✅ Стек здоров. Всё в порядке.")
    print()
    
    print(f"---\n🏥 Stack Doctor завершил обход.")

if __name__ == "__main__":
    main()
