#!/usr/bin/env python3
"""Generate /var/www/gatebox/files/index.json for Lemmy's Vault."""
import json, os, time

FILES_DIR = "/var/www/gatebox/files"
OUTPUT = os.path.join(FILES_DIR, "index.json")

files = []
for name in sorted(os.listdir(FILES_DIR)):
    path = os.path.join(FILES_DIR, name)
    if name in ('index.html', 'index.json') or name.startswith('.'):
        continue
    if os.path.isfile(path):
        st = os.stat(path)
        files.append({
            "name": name,
            "size": st.st_size,
            "mtime": int(st.st_mtime),
        })

with open(OUTPUT, 'w') as f:
    json.dump(files, f)

print(f"index.json: {len(files)} files, {sum(f['size'] for f in files)} bytes")
