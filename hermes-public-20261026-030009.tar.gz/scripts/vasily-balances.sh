#!/usr/bin/env bash
# Василий — Финансовый надзиратель
# Проверяет балансы всех API и расходы. Пишет в лог, при падении ниже порога — выводит тревогу.
set -uo pipefail

ENV_FILE="$HOME/.hermes/.env"
LOG=/root/.hermes/logs/vasily-balances.log
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
ALERT=""

[ -f "$ENV_FILE" ] && source "$ENV_FILE" || { echo "$TS ERR: .env missing" >> "$LOG"; exit 1; }

# --- OpenRouter ---
if [ -n "${OPENROUTER_API_KEY:-}" ]; then
    OR_OUT=$(curl -sf --max-time 10 https://openrouter.ai/api/v1/auth/key \
      -H "Authorization: Bearer $OPENROUTER_API_KEY" 2>/dev/null) || OR_OUT=""
    OR_CREDITS=$(echo "$OR_OUT" | python3 -c '
import sys,json
try:
    d=json.load(sys.stdin)
    print(round(float(d.get("data",{}).get("credits",0)),2))
except: print("")
' 2>/dev/null) || OR_CREDITS=""
    echo "$TS openrouter=$OR_CREDITS" >> "$LOG"
    if [ -n "$OR_CREDITS" ] && [ "$(echo "$OR_CREDITS < 5" | bc -l 2>/dev/null)" = "1" ]; then
        ALERT="$ALERT⚠️ OpenRouter: \$$OR_CREDITS\n"
    fi
fi

# --- DeepSeek ---
if [ -n "${DEEPSEEK_API_KEY:-}" ]; then
    DS_OUT=$(curl -sf --max-time 10 https://api.deepseek.com/user/balance \
      -H "Authorization: Bearer $DEEPSEEK_API_KEY" 2>/dev/null) || DS_OUT=""
    DS_BAL=$(echo "$DS_OUT" | python3 -c '
import sys,json
try:
    d=json.load(sys.stdin)
    print(d["balance_infos"][0]["total_balance"])
except: print("")
' 2>/dev/null) || DS_BAL=""
    echo "$TS deepseek=$DS_BAL" >> "$LOG"
    if [ -n "$DS_BAL" ] && [ "$(echo "$DS_BAL < 5" | bc -l 2>/dev/null)" = "1" ]; then
        ALERT="$ALERT⚠️ DeepSeek: \$$DS_BAL\n"
    fi
fi

# --- OpenAI ---
if [ -n "${OPENAI_API_KEY:-}" ]; then
    curl -sf --max-time 10 https://api.openai.com/dashboard/billing/subscription \
      -H "Authorization: Bearer $OPENAI_API_KEY" 2>/dev/null >/dev/null
    echo "$TS openai=checked" >> "$LOG"
fi

# --- xAI ---
if [ -n "${XAI_API_KEY:-}" ]; then
    curl -sf --max-time 10 https://api.x.ai/v1/models \
      -H "Authorization: Bearer $XAI_API_KEY" 2>/dev/null >/dev/null
    echo "$TS xai=checked" >> "$LOG"
fi

# --- Vast.ai ---
if [ -n "${VAST_API_KEY:-}" ]; then
    VA_OUT=$(curl -sf --max-time 10 "https://vast.ai/api/v0/users/current/" \
      -H "Authorization: Bearer $VAST_API_KEY" 2>/dev/null) || VA_OUT=""
    VA_CREDITS=$(echo "$VA_OUT" | python3 -c '
import sys,json
try:
    d=json.load(sys.stdin)
    print(round(float(d.get("credit",0)),2))
except: print("")
' 2>/dev/null) || VA_CREDITS=""
    echo "$TS vastai=$VA_CREDITS" >> "$LOG"
    if [ -n "$VA_CREDITS" ] && [ "$(echo "$VA_CREDITS < 10" | bc -l 2>/dev/null)" = "1" ]; then
        ALERT="$ALERT⚠️ Vast.ai: \$$VA_CREDITS\n"
    fi
fi

if [ -n "$ALERT" ]; then echo -e "$ALERT"; fi
echo "$TS done" >> "$LOG"
