#!/bin/bash
sleep 10
systemctl restart hermes-gateway
systemctl restart hermes-gateway-buratino
