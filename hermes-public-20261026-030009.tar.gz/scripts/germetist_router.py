#!/usr/bin/env python3
"""Роутер Герметиста: вопрос → тема → архивы. Не искать везде сразу."""

TOPICS = {
    'rus_history': {
        'keys': (
            'летопис', 'карамзин', 'нестор', 'русь', 'руси ', 'русский', 'россий',
            'пвл', 'рюрик', 'ипатьев', 'лаврентьев', 'невск',
            'новгород', 'крещен', 'киев', 'москов', 'орда', 'татаро',
            'александр невск', 'дмитрий донск', 'пугачев', 'петр i', 'пётр i',
            'иван грозн', 'смут', 'бояр', 'лжедмитрий', 'опричнин',
            'судебник', 'минин', 'пожарск', 'аввакум', 'раскол',
        ),
        'local': ('rus_history',),
        'net': ('archive.org', 'rsl', 'vostlit', 'loc', 'sourcelib'),
        'lang': 'ru',
    },
    'judaism': {
        'keys': (
            'иудаизм', 'иудей', 'каббал', 'каббала', 'талмуд', 'тора', 'мишна',
            'зоар', 'зохар', 'сефир', 'сефирот', 'меркав', 'merkav', 'kabbalah',
            'talmud', 'torah', 'zohar', 'sefaria', 'мидраш', 'танах', 'tanakh',
            'хасид', 'гемария', 'гематрия', 'эйн соф', 'ein sof',
            'иерусалим', 'jerusalem', 'храм соломон', 'соломон', 'zion', 'сион',
            'израил', 'israel', 'еврей', 'jewish', 'евреи',
            'енох', 'enoch', 'ханох', 'chanoch', 'ханок', 'ангел', 'ангелы',
        ),
        'local': ('sefaria', 'rus_history', 'classics'),
        'net': ('sefaria', 'archive.org', 'loc', 'sourcelib', 'gutenberg'),
        'lang': 'en',
    },
    'islam': {
        'keys': (
            'коран', 'quran', 'суфи', 'sufi', 'ибн араби', 'ibn arabi', 'хадис',
            'ислам', 'islam', 'сунн', 'мухаммад', 'muhammad', 'аллах', 'allah',
            'тасаввуф', 'фусус', 'fusus', 'шариат', 'sharia',
        ),
        'local': ('philosophy',),
        'net': ('loc', 'sourcelib'),
        'lang': 'en',
    },
    'traditionalism': {
        'keys': (
            'генон', 'генона', 'геноне', 'guenon', 'эвола', 'эволы', 'эволе', 'evola',
            'юга', 'юге', 'юги', 'yuga', 'кали юга',
            'шуон', 'шаон', 'schuon', 'дугин', 'головин', 'традиционал',
            'дхарма', 'дхарме', 'dharma', 'карма', 'карме', 'karma', 'тантра', 'тантре', 'tantra',
            'нирвана', 'нирване', 'nirvana', 'йога', 'йоге', 'yoga', 'сансара', 'samsara',
            'веданта', 'vedanta', 'адвайта', 'advaita', 'упанишад', 'upanishad',
        ),
        'local': ('traditio', 'traditio_ru', 'hermetica', 'philosophy'),
        'net': ('loc', 'sourcelib'),
        'lang': 'en',
    },
    'hermetica': {
        'keys': (
            'гермес', 'герметизм', 'парацельс', 'paracelsus', 'алхим', 'alchemy',
            'философский камень', 'поймандр', 'poimandr', 'розенкрейц',
            'фладд', 'fludd', 'prima materia', 'азот',
        ),
        'local': ('traditio', 'hermetica', 'philosophy'),
        'net': ('loc', 'sourcelib'),
        'lang': 'en',
    },
    'military': {
        'keys': (
            'побоище', 'ледовое', 'ледов', 'чудск', 'куликов', 'мамай',
            'битв', 'сражен', 'войн', 'кампани', 'осад',
            'арми', 'флот', 'кавалери', 'пехот',
            'бородин', 'сталинград', 'курск', 'ватерлоо', 'канн',
            'teuton', 'ливон', 'livon',
            'брусилов', 'брусиловск', 'луцк',
            '1914', '1916', 'ww1', 'верден', 'сомм',
            'первая миров', 'первой миров', 'мировая война',
        ),
        'local': ('wars', 'rus_history'),
        'net': ('archive.org', 'rsl', 'vostlit', 'loc', 'sourcelib'),
        'lang': 'en',
    },
    'orders': {
        'keys': (
            'тамплиер', 'templar', 'храмовник', 'госпитальер', 'иоаннит',
            'мальтийск', 'крестонос', 'crusade', 'орден храма', 'knight templar',
        ),
        'local': ('wars', 'classics'),
        'net': ('loc', 'sourcelib'),
        'lang': 'en',
    },
    'classics': {
        'keys': (
            'платон', 'аристотель', 'гомер', 'plato', 'aristotle', 'homer',
            'плотин', 'plotinus', 'стоик',
        ),
        'local': ('classics', 'philosophy'),
        'net': ('sourcelib', 'gutenberg'),
        'lang': 'en',
    },
    'general': {
        'keys': (),
        'local': (),
        'net': ('loc', 'sourcelib'),
        'lang': 'en',
    },
}

_ORDER = ('judaism', 'islam', 'military', 'orders', 'rus_history', 'hermetica', 'traditionalism', 'classics')


# Каталоги для одиночных имён/терминов, если classify дал general.
_CATALOG_HINTS = (
    ('traditionalism', (
        'генон', 'guenon', 'эвола', 'evola', 'шуон', 'шаон', 'schuon',
        'дугин', 'головин', 'юга', 'yuga', 'кали', 'kali',
    )),
    ('judaism', (
        'каббал', 'зоар', 'зохар', 'сефир', 'меркав', 'талмуд', 'тора',
        'zohar', 'kabbalah',
    )),
    ('classics', ('платон', 'аристотель', 'гомер', 'плотин', 'plato', 'aristotle')),
    ('hermetica', ('гермес', 'парацельс', 'алхим', 'поймандр')),
)

_BIO_STOP = {
    'что', 'как', 'такое', 'это', 'кто', 'где', 'почему', 'зачем', 'когда',
    'какой', 'какая', 'какие', 'такой', 'такая', 'такие',
}


def classify(query):
    ql = (query or '').lower()
    for name in _ORDER:
        if any(k in ql for k in TOPICS[name]['keys']):
            return name
    return 'general'


def _significant_tokens(query):
    return [
        w for w in (query or '').lower().replace('-', ' ').split()
        if len(w) >= 3 and w not in _BIO_STOP
    ]


def route(query):
    topic = classify(query)
    spec = TOPICS[topic]
    local = spec['local']
    if topic == 'general':
        tokens = _significant_tokens(query)
        blob = ' '.join(tokens)
        for name, hints in _CATALOG_HINTS:
            if any(h in blob for h in hints):
                topic = name
                spec = TOPICS[name]
                local = spec['local']
                break
    return {
        'topic': topic,
        'local': local,
        'net': spec['net'],
        'lang': spec['lang'],
        'query': query,
    }
