#!/usr/bin/env python3
"""Recover Hermes state.db from corrupted state.db.old using LIMIT/OFFSET scans."""
import sqlite3
import sys
import os
import traceback
from datetime import datetime

SRC = "/root/.hermes/state.db.old"
BACKUP = "/root/.hermes/backups/hermes-20260826-020020/state.db"
DST = "/root/.hermes/state.db.recovered2"
LOG = "/root/.hermes/scripts/state_db_rescue2.log"

FTS_PREFIXES = ("messages_fts", "sqlite_")

SKIP_TABLES = {
    "messages_fts",
    "messages_fts_config",
    "messages_fts_content",
    "messages_fts_data",
    "messages_fts_docsize",
    "messages_fts_idx",
    "messages_fts_trigram",
    "messages_fts_trigram_config",
    "messages_fts_trigram_content",
    "messages_fts_trigram_data",
    "messages_fts_trigram_docsize",
    "messages_fts_trigram_idx",
}

# Tables copied with FK checks off; order: parents first
COPY_ORDER = [
    "schema_version",
    "state_meta",
    "system_prompts",
    "sessions",
    "session_model_usage",
    "async_delegations",
    "gateway_routing",
    "gateway_hygiene_state",
    "compression_locks",
    "session_turn_leases",
    "delivery_obligations",
    "messages",
]


def log(msg):
    line = f"{datetime.utcnow().isoformat()}Z {msg}"
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def open_ro(path):
    con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only=ON")
    con.execute("PRAGMA cache_size=-200000")
    return con


def fetch_page(con, table, limit, offset):
    cur = con.execute(f"SELECT * FROM {table} LIMIT ? OFFSET ?", (limit, offset))
    return [tuple(r) for r in cur.fetchall()]


def copy_table_paged(src, dst, table, page=50):
    """Copy via LIMIT/OFFSET; on error shrink page and skip bad slices."""
    copied = 0
    skipped = 0
    errors = []
    offset = 0
    cur_page = page
    consecutive_fail = 0
    max_offset_guess = 10_000_000

    # Get columns
    cols = [r[1] for r in src.execute(f"PRAGMA table_info({table})").fetchall()]
    placeholders = ",".join("?" * len(cols))
    insert_sql = f"INSERT OR IGNORE INTO {table} ({','.join(cols)}) VALUES ({placeholders})"

    while offset < max_offset_guess:
        try:
            rows = fetch_page(src, table, cur_page, offset)
            consecutive_fail = 0
            if not rows:
                break
            dst.executemany(insert_sql, rows)
            dst.commit()
            copied += len(rows)
            offset += len(rows)
            if copied % 500 == 0 or cur_page != page:
                log(f"  {table}: copied={copied} offset={offset} page={cur_page}")
            if len(rows) < cur_page:
                break
            # grow page back after success
            if cur_page < page:
                cur_page = min(page, cur_page * 2)
        except sqlite3.DatabaseError as e:
            consecutive_fail += 1
            msg = str(e)
            log(f"  {table} ERROR offset={offset} page={cur_page}: {msg}")
            errors.append((offset, cur_page, msg))
            if cur_page > 1:
                cur_page = max(1, cur_page // 2)
                continue
            # page=1 still fails: skip this offset
            skipped += 1
            offset += 1
            cur_page = 1
            if consecutive_fail > 200:
                log(f"  {table}: abort after 200 consecutive skips at offset={offset}")
                break
    return copied, skipped, errors


def copy_table_full(src, dst, table):
    cols = [r[1] for r in src.execute(f"PRAGMA table_info({table})").fetchall()]
    placeholders = ",".join("?" * len(cols))
    insert_sql = f"INSERT OR IGNORE INTO {table} ({','.join(cols)}) VALUES ({placeholders})"
    rows = [tuple(r) for r in src.execute(f"SELECT * FROM {table}").fetchall()]
    dst.executemany(insert_sql, rows)
    dst.commit()
    return len(rows)


def merge_from_backup(backup, dst, table):
    """Fill any missing PKs from intact backup."""
    cols = [r[1] for r in dst.execute(f"PRAGMA table_info({table})").fetchall()]
    placeholders = ",".join("?" * len(cols))
    insert_sql = f"INSERT OR IGNORE INTO {table} ({','.join(cols)}) VALUES ({placeholders})"
    before = dst.execute(f"SELECT count(*) FROM {table}").fetchone()[0]
    rows = [tuple(r) for r in backup.execute(f"SELECT * FROM {table}").fetchall()]
    dst.executemany(insert_sql, rows)
    dst.commit()
    after = dst.execute(f"SELECT count(*) FROM {table}").fetchone()[0]
    return after - before, len(rows)


def main():
    open(LOG, "w").close()
    log(f"SRC={SRC} DST={DST}")
    if os.path.exists(DST):
        os.remove(DST)

    src = open_ro(SRC)
    backup = open_ro(BACKUP)
    dst = sqlite3.connect(DST)
    dst.execute("PRAGMA journal_mode=WAL")
    dst.execute("PRAGMA synchronous=OFF")
    dst.execute("PRAGMA foreign_keys=OFF")

    # Recreate schema from sqlite_master (tables + indexes, skip FTS)
    masters = src.execute(
        "SELECT type, name, sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY CASE type WHEN 'table' THEN 0 ELSE 1 END, name"
    ).fetchall()
    created = []
    for typ, name, sql in masters:
        if name in SKIP_TABLES or name.startswith("messages_fts") or name.startswith("sqlite_"):
            continue
        if typ not in ("table", "index"):
            continue
        try:
            dst.execute(sql)
            created.append(name)
        except sqlite3.Error as e:
            log(f"schema skip {name}: {e}")
    dst.commit()
    log(f"created objects: {created}")

    stats = {}
    for table in COPY_ORDER:
        exists = src.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
        ).fetchone()
        if not exists:
            log(f"missing table {table}")
            continue
        log(f"copying {table} ...")
        try:
            n = copy_table_full(src, dst, table)
            stats[table] = {"copied": n, "skipped": 0, "method": "full", "errors": 0}
            log(f"  {table} full copy {n}")
        except sqlite3.DatabaseError as e:
            log(f"  {table} full failed ({e}), paging...")
            copied, skipped, errors = copy_table_paged(src, dst, table, page=20)
            stats[table] = {
                "copied": copied,
                "skipped": skipped,
                "method": "paged",
                "errors": len(errors),
            }
            log(f"  {table} paged copied={copied} skipped={skipped} errors={len(errors)}")

    # Merge missing from intact backup (INSERT OR IGNORE)
    log("merging from backup ...")
    for table in COPY_ORDER:
        try:
            added, bak_n = merge_from_backup(backup, dst, table)
            stats.setdefault(table, {})["from_backup"] = added
            stats[table]["backup_rows"] = bak_n
            log(f"  merge {table}: +{added} (backup had {bak_n})")
        except Exception as e:
            log(f"  merge {table} failed: {e}")
            stats.setdefault(table, {})["from_backup_error"] = str(e)

    dst.execute("PRAGMA foreign_keys=OFF")
    log("integrity_check ...")
    ic = dst.execute("PRAGMA integrity_check").fetchall()
    log(f"integrity: {ic}")
    log("VACUUM ...")
    dst.execute("VACUUM")
    ic2 = dst.execute("PRAGMA integrity_check").fetchall()
    log(f"integrity after vacuum: {ic2}")

    log("final counts:")
    tables = [r[0] for r in dst.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    counts = {}
    for t in tables:
        try:
            n = dst.execute(f"SELECT count(*) FROM {t}").fetchone()[0]
        except Exception as e:
            n = f"ERR {e}"
        counts[t] = n
        log(f"  {t}={n}")

    dst.close()
    src.close()
    backup.close()
    size = os.path.getsize(DST)
    log(f"DST size={size}")
    print("STATS", stats)
    print("COUNTS", counts)
    print("INTEGRITY", ic2)


if __name__ == "__main__":
    main()
