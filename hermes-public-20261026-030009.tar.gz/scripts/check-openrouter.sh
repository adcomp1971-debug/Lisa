#!/bin/bash
# check-openrouter-balance.sh — watchdog for OpenRouter credits
# Runs daily at noon, alerts if balance < $5

KEY=$(grep -v '^#' /root/.hermes/.env 2>/dev/null | grep OPENROUTER_API_KEY | cut -d= -f2 | tr -d ' "')
if [ -z "$KEY" ]; then
    # Try credential pools
    echo "OPENROUTER_KEY_NOT_FOUND"
    exit 0
fi

RESPONSE=$(curl -s --max-time 10 "https://openrouter.ai/api/v1/auth/key" \
    -H "Authorization: Bearer $KEY" 2>/dev/null)

if [ -z "$RESPONSE" ]; then
    echo "API_UNREACHABLE"
    exit 1
fi

CREDITS=$(echo "$RESPONSE" | python3 -c "
import json,sys
d=json.load(sys.stdin)
limit=d.get('data',{}).get('limit',0)
usage=d.get('data',{}).get('usage',0)
remaining = limit - usage
print(f'{remaining:.2f}')
" 2>/dev/null)

if [ -z "$CREDITS" ] || [ "$CREDITS" = "0.00" ]; then
    echo "COULD_NOT_PARSE"
    exit 1
fi

echo "BALANCE: \$$CREDITS"

# Alert if low
if (( $(echo "$CREDITS < 5" | bc -l) )); then
    echo "⚠️ LOW CREDITS: \$$CREDITS remaining on OpenRouter"
    echo "ALERT::low_credits::$CREDITS"
    exit 2
fi

echo "OK"

# Also check DeepSeek balance
echo ""
echo "=== DeepSeek ==="
bash /root/.hermes/scripts/check-deepseek.sh 2>/dev/null || true
