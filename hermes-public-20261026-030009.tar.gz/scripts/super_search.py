#!/usr/bin/env python3
"""Super Search — multi-source search aggregator for Telegram/X/Reddit/News.

Uses whatever backends are currently working. Returns aggregated results.
Fallback order: MCP web-search → browser → direct curl → cached.

Usage:
    python3 super_search.py "орешник украина" --sources tg,x,reddit,news
"""

import json
import sys
import subprocess
import argparse
import re
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

# ---------------------------------------------------------------------------
# Known public Telegram news channels (usernames without @)
# ---------------------------------------------------------------------------
TELEGRAM_NEWS_CHANNELS = [
    "bbbreaking",       # Breaking news
    "rian_ru",          # РИА Новости
    "milinfolive",      # Военный осведомитель
    "russia_ukraine_war", # Сводки
    "rt_russian",       # RT на русском
    "militarymaps",     # Military Maps
    "rusich_army",      # Русская армия
    "ukr_leaks",        # Ukrainian leaks
    "tass_agency",      # ТАСС
    "vchkogpu",         # ВЧК-ОГПУ
    "meduzaproject",    # Медуза
    "svobodnye",         # Свободные новости
]

# ---------------------------------------------------------------------------
# Search helpers
# ---------------------------------------------------------------------------

def search_telegram_via_web(query: str, max_results: int = 10) -> list[dict]:
    """Search Telegram posts via Google/Bing with site:t.me."""
    encoded = urllib.parse.quote(f"site:t.me {query}")
    results = []

    # Try DuckDuckGo HTML
    try:
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        out = subprocess.run(
            ["curl", "-sL", "--max-time", "15", url],
            capture_output=True, text=True
        )
        # Extract result snippets
        snippets = re.findall(
            r'class="result__snippet">(.*?)</a>',
            out.stdout,
            re.DOTALL
        )
        links = re.findall(
            r'class="result__url"[^>]*>(.*?)</a>',
            out.stdout
        )
        for snippet, link in zip(snippets, links):
            text = re.sub(r'<[^>]+>', '', snippet).strip()
            text = re.sub(r'\s+', ' ', text)
            if len(text) > 20:
                results.append({
                    "source": "telegram",
                    "text": text[:300],
                    "url": link.strip() if link else "",
                    "backend": "ddg"
                })
    except Exception:
        pass

    return results[:max_results]


def search_telegram_channels(query: str, max_results: int = 5) -> list[dict]:
    """Search within known Telegram channels via t.me/s/ web views."""
    results = []
    query_lower = query.lower().split()

    for channel in TELEGRAM_NEWS_CHANNELS[:6]:  # Limit parallel calls
        try:
            url = f"https://t.me/s/{channel}"
            out = subprocess.run(
                ["curl", "-sL", "--max-time", "10", url],
                capture_output=True, text=True
            )
            # Extract message text blocks
            msgs = re.findall(
                r'class="tgme_widget_message_text"[^>]*>(.*?)</div>',
                out.stdout,
                re.DOTALL
            )
            for msg in msgs:
                text = re.sub(r'<[^>]+>', ' ', msg).strip()
                text = re.sub(r'\s+', ' ', text)
                # Check if query matches
                if all(q in text.lower() for q in query_lower):
                    results.append({
                        "source": "telegram",
                        "channel": f"@{channel}",
                        "text": text[:300],
                        "backend": "t.me/s"
                    })
                    if len(results) >= max_results:
                        return results[:max_results]
        except Exception:
            continue

    return results[:max_results]


def search_news_sites(query: str, max_results: int = 10) -> list[dict]:
    """Search news sites directly."""
    encoded = urllib.parse.quote(query)
    results = []

    # Try Yandex News
    try:
        url = f"https://newssearch.yandex.ru/news/search?text={encoded}&rpt=nnews2&grhow=clutop"
        out = subprocess.run(
            ["curl", "-sL", "--max-time", "15",
             "-H", "User-Agent: Mozilla/5.0 (compatible; HermesBot/1.0)",
             url],
            capture_output=True, text=True
        )
        # Yandex News returns JSON
        if out.stdout.strip().startswith('{'):
            data = json.loads(out.stdout)
            for item in data.get("items", [])[:max_results]:
                results.append({
                    "source": "news",
                    "title": item.get("title", ""),
                    "text": item.get("text", "")[:300],
                    "url": item.get("url", ""),
                    "backend": "yandex-news"
                })
    except Exception:
        pass

    return results[:max_results]


def search_generic(query: str, max_results: int = 10) -> list[dict]:
    """Generic web search fallback."""
    results = []

    # Try SearXNG public instances
    searx_instances = [
        "https://search.bus-hit.me/search?format=json",
        "https://searx.be/search?format=json",
    ]
    encoded = urllib.parse.quote(query)

    for instance in searx_instances:
        try:
            url = f"{instance}&q={encoded}"
            out = subprocess.run(
                ["curl", "-sL", "--max-time", "15", url],
                capture_output=True, text=True
            )
            data = json.loads(out.stdout)
            for item in data.get("results", [])[:max_results]:
                results.append({
                    "source": "web",
                    "title": item.get("title", ""),
                    "text": (item.get("content", "") or item.get("snippet", ""))[:300],
                    "url": item.get("url", ""),
                    "backend": "searxng"
                })
        except Exception:
            continue

    return results[:max_results]


# ---------------------------------------------------------------------------
# Aggregator
# ---------------------------------------------------------------------------

def super_search(query: str, sources: list[str], max_per_source: int = 5) -> dict:
    """Run search across multiple sources in parallel."""
    searchers = {}

    if "tg" in sources:
        searchers["telegram_channels"] = lambda: search_telegram_channels(query, max_per_source)
        searchers["telegram_web"] = lambda: search_telegram_via_web(query, max_per_source)
    if "news" in sources:
        searchers["news"] = lambda: search_news_sites(query, max_per_source)
    if "web" in sources or "reddit" in sources or "x" in sources:
        # Generic web search covers all
        full_query = query
        if "reddit" in sources:
            full_query += " site:reddit.com"
        if "x" in sources:
            full_query += " site:x.com OR site:twitter.com"
        searchers["web"] = lambda: search_generic(full_query, max_per_source)

    all_results = {}
    with ThreadPoolExecutor(max_workers=4) as ex:
        futures = {ex.submit(fn): name for name, fn in searchers.items()}
        for fut in as_completed(futures):
            name = futures[fut]
            try:
                all_results[name] = fut.result(timeout=20)
            except Exception as e:
                all_results[name] = [{"error": str(e)}]

    return {
        "query": query,
        "sources": sources,
        "timestamp": datetime.utcnow().isoformat(),
        "results": all_results,
        "total_hits": sum(len(v) for v in all_results.values()),
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Super Search — multi-source aggregator")
    parser.add_argument("query", help="Search query")
    parser.add_argument(
        "--sources", default="tg,web",
        help="Comma-separated: tg,web,news,reddit,x (default: tg,web)"
    )
    parser.add_argument("--max", type=int, default=5, help="Max results per source")
    parser.add_argument("--json", action="store_true", help="Output JSON")
    args = parser.parse_args()

    sources = [s.strip().lower() for s in args.sources.split(",")]
    results = super_search(args.query, sources, args.max)

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        print(f"\n=== SUPER SEARCH: '{results['query']}' ===\n")
        for backend, items in results["results"].items():
            print(f"── {backend} ({len(items)} hits) ──")
            for i, item in enumerate(items[:5]):
                if "error" in item:
                    print(f"  [{i}] ERROR: {item['error']}")
                    continue
                text = item.get("text") or item.get("title", "")
                url = item.get("url", "")
                ch = item.get("channel", "")
                prefix = f"{ch} " if ch else ""
                print(f"  [{i}] {prefix}{text[:200]}")
                if url:
                    print(f"      {url}")
            print()
        print(f"Total: {results['total_hits']} results from {len(results['results'])} backends")

if __name__ == "__main__":
    main()
