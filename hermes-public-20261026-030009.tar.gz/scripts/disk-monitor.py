#!/usr/bin/env python3
"""Disk usage monitor — alerts when disk > 85% or grows fast"""
import shutil
import json
import os
import subprocess
import sys
from datetime import datetime

THRESHOLD_PCT = 85
THRESHOLD_FAST_PCT = 5  # рост >5% за сутки — алерт
STATE_FILE = os.path.expanduser("~/.hermes/disk-stat.json")

def get_usage():
    usage = shutil.disk_usage("/")
    pct = usage.used / usage.total * 100
    return {
        "total_gb": round(usage.total / 1e9, 1),
        "used_gb": round(usage.used / 1e9, 1),
        "free_gb": round(usage.free / 1e9, 1),
        "pct": round(pct, 1),
        "ts": datetime.now().isoformat(),
    }

def main():
    current = get_usage()
    
    alerts = []
    
    # Threshold check
    if current["pct"] >= THRESHOLD_PCT:
        alerts.append(f"⚠️ Диск {current['pct']}% — превышен порог {THRESHOLD_PCT}%")
    
    # Fast growth check
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            prev = json.load(f)
        growth = current["pct"] - prev["pct"]
        if growth >= THRESHOLD_FAST_PCT:
            alerts.append(f"⚠️ Диск вырос на {growth}% за сутки ({prev['pct']}% → {current['pct']}%)")
    
    # Save state
    with open(STATE_FILE, "w") as f:
        json.dump(current, f)
    
    if alerts:
        msg = "\n".join(alerts)
        msg += f"\n📊 Всего: {current['total_gb']}G, занято: {current['used_gb']}G, свободно: {current['free_gb']}G"
        print(msg)
    else:
        # Silent — всё ок
        sys.exit(0)

if __name__ == "__main__":
    main()
