#!/usr/bin/env python3
"""
YouTube Scout — мониторинг AI-каналов и поиск новых фич.

Режимы:
  --check     проверить RSS, найти новые видео, вывести дайджест (для cron no_agent)
  --digest    показать последний дайджест
  --update    обновить каналы (добавить/удалить)

Формат вывода (stdout) для no_agent cron:
  [NEW] Video Title
  Channel | URL
  ---
  Краткое описание из RSS
"""
import sqlite3
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
import json
import sys
import os
import time
from datetime import datetime, timezone, timedelta

DB_PATH = os.path.expanduser("~/.hermes/youtube_scout.db")

CHANNELS = [
    {
        "id": "UCXUPKJO5MZQN11PqgIvyuvQ",
        "name": "Andrej Karpathy",
        "tags": ["deep learning", "LLM", "neural nets"]
    },
    {
        "id": "UCNJ1Ymd5yFuUPtn21xtRbbw",
        "name": "AI Explained",
        "tags": ["AI breakthroughs", "LLM", "research"]
    },
    {
        "id": "UCbfYPyITQ-7l4upoX8nvctg",
        "name": "Two Minute Papers",
        "tags": ["research", "papers", "neural nets"]
    },
    {
        "id": "UCZHmQk67mSJgfCCTn7xBfew",
        "name": "Yannic Kilcher",
        "tags": ["deep learning", "ML research", "papers"]
    },
    {
        "id": "UCzz6ructab1U44QPI3HpZEQ",
        "name": "Stanford MLSys Seminars",
        "tags": ["ML systems", "research", "academia"]
    },
    {
        "id": "UCcIXc5mJsHVYTZR1maL5l9w",
        "name": "DeepLearningAI",
        "tags": ["deep learning", "education", "AI"]
    },
    {
        "id": "UCBHcMCGaiJhv-ESTcWGJPcw",
        "name": "NVIDIA Developer",
        "tags": ["GPU", "CUDA", "NVIDIA", "AI infra"]
    },
    {
        "id": "UCtAcpQcYerN8xxZJYTfWBMw",
        "name": "Umar Jamil",
        "tags": ["deep learning", "coding", "tutorials"]
    },
    {
        "id": "UCqcbQf6yw5KzRoDDcZ_wBSw",
        "name": "Wes Roth",
        "tags": ["AI news", "research", "LLM"]
    },
]


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS videos (
            video_id TEXT PRIMARY KEY,
            channel_id TEXT,
            channel_name TEXT,
            title TEXT,
            url TEXT,
            description TEXT,
            published TEXT,
            detected_at TEXT,
            transcript_status TEXT DEFAULT 'pending',
            tags TEXT,
            UNIQUE(video_id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS digests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT,
            new_count INTEGER,
            content TEXT
        )
    """)
    conn.commit()
    return conn


def fetch_rss(channel_id):
    """Получить RSS-ленту канала. Возвращает список entry dicts."""
    url = f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}"
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (compatible; HermesBot/1.0)"
        })
        resp = urllib.request.urlopen(req, timeout=15)
        xml_data = resp.read()
        root = ET.fromstring(xml_data)
        
        ns = {
            "atom": "http://www.w3.org/2005/Atom",
            "yt": "http://www.youtube.com/xml/schemas/2015",
            "media": "http://search.yahoo.com/mrss/"
        }
        
        entries = []
        channel_name = root.findtext("atom:title", "", ns)
        
        for entry in root.findall("atom:entry", ns):
            video_id = entry.findtext("yt:videoId", "", ns)
            title = entry.findtext("atom:title", "", ns)
            published = entry.findtext("atom:published", "", ns)
            desc = entry.findtext("media:group/media:description", "", ns) if entry.find("media:group", ns) is not None else ""
            link_el = entry.find("atom:link", ns)
            video_url = link_el.get("href", f"https://youtube.com/watch?v={video_id}") if link_el is not None else f"https://youtube.com/watch?v={video_id}"
            
            entries.append({
                "video_id": video_id,
                "channel_id": channel_id,
                "channel_name": channel_name,
                "title": title,
                "url": video_url,
                "description": desc.strip()[:2000],
                "published": published,
            })
        
        return entries
    except Exception as e:
        print(f"[WARN] RSS fetch failed for {channel_id}: {e}", file=sys.stderr)
        return []


def get_channel_tags(channel_id):
    for ch in CHANNELS:
        if ch["id"] == channel_id:
            return ", ".join(ch["tags"])
    return ""


def do_check(since_hours=None):
    """Проверить все каналы, найти новые видео, вывести дайджест."""
    conn = init_db()
    cursor = conn.cursor()
    
    cutoff = None
    if since_hours:
        cutoff = datetime.now(timezone.utc) - timedelta(hours=since_hours)
    
    all_new = []
    
    for ch in CHANNELS:
        entries = fetch_rss(ch["id"])
        for entry in entries:
            # фильтр по времени
            if cutoff:
                try:
                    pub = datetime.fromisoformat(entry["published"].replace("Z", "+00:00"))
                    if pub < cutoff:
                        continue
                except:
                    pass
            
            # проверяем, есть ли уже
            cursor.execute("SELECT video_id FROM videos WHERE video_id = ?", (entry["video_id"],))
            if cursor.fetchone():
                continue
            
            tags = get_channel_tags(ch["id"])
            
            cursor.execute("""
                INSERT OR IGNORE INTO videos
                (video_id, channel_id, channel_name, title, url, description, published, detected_at, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                entry["video_id"],
                entry["channel_id"],
                entry["channel_name"],
                entry["title"],
                entry["url"],
                entry["description"][:2000],
                entry["published"],
                datetime.now(timezone.utc).isoformat(),
                tags
            ))
            all_new.append(entry)
        
        # пауза между каналами
        time.sleep(0.5)
    
    conn.commit()
    
    if not all_new:
        print("📡 YouTube Scout — проверка завершена")
        print("Новых видео не найдено.")
        return
    
    # Сортируем по дате (новые сверху)
    all_new.sort(key=lambda e: e.get("published", ""), reverse=True)
    
    print(f"📡 YouTube Scout — {len(all_new)} новых видео\n")
    
    for entry in all_new:
        published = entry.get("published", "")
        try:
            dt = datetime.fromisoformat(published.replace("Z", "+00:00"))
            pub_str = dt.strftime("%d %b %Y, %H:%M")
        except:
            pub_str = published[:10]
        
        title = entry["title"]
        channel = entry["channel_name"]
        url = entry["url"]
        desc = entry["description"]
        
        print(f"▎{title}")
        print(f"  {channel} · {pub_str}")
        print(f"  {url}")
        
        if desc:
            # Берём первые 2-3 предложения
            short_desc = desc[:500]
            print(f"  {short_desc}")
        
        print()
    
    # Сохраняем дайджест в БД
    digest_content = f"Найдено {len(all_new)} новых видео"
    conn.execute("INSERT INTO digests (created_at, new_count, content) VALUES (?, ?, ?)",
                 (datetime.now(timezone.utc).isoformat(), len(all_new), digest_content))
    conn.commit()
    
    conn.close()


def show_digest():
    """Показать последний дайджест."""
    conn = init_db()
    cursor = conn.cursor()
    
    # Показываем последние непросмотренные видео
    cursor.execute("""
        SELECT title, channel_name, url, published, description
        FROM videos
        ORDER BY published DESC
        LIMIT 20
    """)
    
    rows = cursor.fetchall()
    if not rows:
        print("База пуста. Сначала запусти --check")
        conn.close()
        return
    
    print(f"📡 YouTube Scout — последние видео ({len(rows)})\n")
    for title, channel, url, published, desc in rows:
        try:
            dt = datetime.fromisoformat(published.replace("Z", "+00:00"))
            pub_str = dt.strftime("%d %b %Y, %H:%M")
        except:
            pub_str = str(published)[:10]
        
        print(f"▎{title}")
        print(f"  {channel} · {pub_str}")
        print(f"  {url}")
        if desc:
            print(f"  {desc[:300]}")
        print()
    
    conn.close()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "--check":
            since_hours = None
            if len(sys.argv) > 2 and sys.argv[2] == "--since":
                since_hours = int(sys.argv[3]) if len(sys.argv) > 3 else 48
            do_check(since_hours)
        elif cmd == "--digest":
            show_digest()
        else:
            print(f"Неизвестная команда: {cmd}")
            print("Использование: youtube-scout.py --check [--since HOURS] | --digest")
    else:
        do_check()
