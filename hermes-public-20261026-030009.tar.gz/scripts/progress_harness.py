#!/usr/bin/env python3
"""
Progress Harness — standalone tool for long-running AI agent sessions

Creates ~/.hermes/progress/<session-name>.json with checkpoints.
On resume — reads the file, continues from last checkpoint.
Integrates with Hermes checkpoints (complementary, not replacement).

Usage:
    progress_harness.py init "Task description" --session-id "1234_abcdef"
    progress_harness.py checkpoint "What was done" --state '{"key": "value"}'
    progress_harness.py status
    progress_harness.py resume
    progress_harness.py list
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DEFAULT_PROGRESS_DIR = Path.home() / ".hermes" / "progress"
HERMES_CONFIG_PATH = Path.home() / ".hermes" / "config.json"
CHECKPOINTS_SUBDIR = ".hermes/checkpoints"


class ProgressHarness:
    """Manage session progress across long-running AI conversations."""

    def __init__(self, progress_dir: Path | None = None, session_id: str | None = None):
        self.progress_dir = progress_dir or DEFAULT_PROGRESS_DIR
        self.progress_dir.mkdir(parents=True, exist_ok=True)
        self._session_id = session_id

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    def _current_session_file(self) -> Path | None:
        """Find the progress file for the active session."""
        if self._session_id:
            return self.progress_dir / f"{self._session_id}.json"

        # Try to infer from environment
        env_sid = os.environ.get("HERMES_SESSION_ID") or os.environ.get("SESSION_ID")
        if env_sid:
            return self.progress_dir / f"{env_sid}.json"

        # Fallback: most recently modified progress file
        files = sorted(self.progress_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        return files[0] if files else None

    def _all_session_files(self) -> list[Path]:
        return sorted(self.progress_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)

    @staticmethod
    def _now_iso() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    # ------------------------------------------------------------------ #
    # Core API
    # ------------------------------------------------------------------ #

    def init_session(self, task_description: str, session_id: str | None = None, *, force: bool = False) -> dict:
        """Create a new progress record."""
        sid = session_id or self._session_id or os.environ.get("HERMES_SESSION_ID") or os.environ.get("SESSION_ID") or f"session_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
        path = self.progress_dir / f"{sid}.json"

        if path.exists() and not force:
            return {"ok": False, "error": f"Session '{sid}' already exists. Use --force to overwrite.", "path": str(path)}

        progress = {
            "session_id": sid,
            "task_description": task_description,
            "status": "in_progress",
            "created_at": self._now_iso(),
            "updated_at": self._now_iso(),
            "checkpoints": [],
            "next_steps": [],
            "blockers": [],
            "metadata": {},
        }
        path.write_text(json.dumps(progress, indent=2, ensure_ascii=False))
        return {"ok": True, "session_id": sid, "path": str(path), "progress": progress}

    def save_checkpoint(self, action: str, state: dict | None = None, *, session_id: str | None = None) -> dict:
        """Append a checkpoint to the current session."""
        sid = session_id or self._session_id
        path = self.progress_dir / f"{sid}.json" if sid else self._current_session_file()

        if path is None or not path.exists():
            return {"ok": False, "error": "No active session. Run 'init' first or provide --session-id."}

        progress = json.loads(path.read_text())
        checkpoint = {
            "timestamp": self._now_iso(),
            "action": action,
            "state": state or {},
            "checkpoint_number": len(progress["checkpoints"]) + 1,
        }
        progress["checkpoints"].append(checkpoint)
        progress["updated_at"] = self._now_iso()
        progress["status"] = "in_progress"
        path.write_text(json.dumps(progress, indent=2, ensure_ascii=False))

        return {"ok": True, "checkpoint_number": checkpoint["checkpoint_number"], "session_id": progress["session_id"]}

    def load_progress(self, session_id: str | None = None) -> dict | None:
        """Read the current progress record."""
        if session_id:
            path = self.progress_dir / f"{session_id}.json"
        else:
            path = self._current_session_file()

        if path is None or not path.exists():
            return None
        return json.loads(path.read_text())

    def resume_last(self, session_id: str | None = None) -> dict:
        """Get the last checkpoint + next steps for resumption."""
        progress = self.load_progress(session_id)
        if progress is None:
            return {"ok": False, "error": "No progress record found."}

        last_cp = progress["checkpoints"][-1] if progress["checkpoints"] else None
        return {
            "ok": True,
            "session_id": progress["session_id"],
            "task_description": progress["task_description"],
            "status": progress["status"],
            "total_checkpoints": len(progress["checkpoints"]),
            "last_checkpoint": last_cp,
            "next_steps": progress["next_steps"],
            "blockers": progress["blockers"],
        }

    def set_next_steps(self, steps: list[str], session_id: str | None = None) -> dict:
        """Update the next_steps list."""
        return self._update_field("next_steps", steps, session_id)

    def set_blockers(self, blockers: list[str], session_id: str | None = None) -> dict:
        """Update the blockers list."""
        return self._update_field("blockers", blockers, session_id)

    def set_status(self, status: str, session_id: str | None = None) -> dict:
        """Change session status: in_progress | paused | completed."""
        if status not in ("in_progress", "paused", "completed"):
            return {"ok": False, "error": f"Invalid status '{status}'. Use: in_progress | paused | completed"}
        return self._update_field("status", status, session_id)

    def _update_field(self, field: str, value: Any, session_id: str | None = None) -> dict:
        sid = session_id or self._session_id
        if sid:
            path = self.progress_dir / f"{sid}.json"
        else:
            path = self._current_session_file()

        if path is None or not path.exists():
            return {"ok": False, "error": "No active session."}

        progress = json.loads(path.read_text())
        progress[field] = value
        progress["updated_at"] = self._now_iso()
        path.write_text(json.dumps(progress, indent=2, ensure_ascii=False))
        return {"ok": True, "session_id": progress["session_id"], field: value}

    # ------------------------------------------------------------------ #
    # Hermes checkpoint integration
    # ------------------------------------------------------------------ #

    def merge_with_hermes_checkpoints(self, session_id: str | None = None) -> dict:
        """
        Read Hermes checkpoint directory and merge checkpoint references
        into our progress record. This is complementary — we do NOT replace
        Hermes snapshots, we just annotate our progress with references.
        """
        progress = self.load_progress(session_id)
        if progress is None:
            return {"ok": False, "error": "No progress record to merge into."}

        checkpoints_dir = Path.home() / CHECKPOINTS_SUBDIR
        if not checkpoints_dir.exists():
            return {"ok": False, "error": f"Hermes checkpoints dir not found at {checkpoints_dir}"}

        # Find Hermes checkpoints that reference our session
        hermes_cps = []
        for cp_file in sorted(checkpoints_dir.glob("*.json")):
            try:
                cp = json.loads(cp_file.read_text())
            except (json.JSONDecodeError, OSError):
                continue
            # Link by session_id if available in Hermes checkpoint meta
            cp_session = cp.get("session_id") or cp.get("metadata", {}).get("session_id")
            if cp_session and cp_session == progress["session_id"]:
                hermes_cps.append({
                    "file": str(cp_file),
                    "timestamp": cp.get("timestamp") or cp.get("created_at"),
                    "label": cp.get("label") or cp.get("name") or cp_file.stem,
                })

        # Merge: annotate progress record with Hermes checkpoint refs
        if "metadata" not in progress:
            progress["metadata"] = {}
        progress["metadata"]["hermes_checkpoints"] = hermes_cps
        progress["metadata"]["hermes_checkpoints_count"] = len(hermes_cps)
        progress["updated_at"] = self._now_iso()

        sid = session_id or self._session_id or progress["session_id"]
        path = self.progress_dir / f"{sid}.json"
        path.write_text(json.dumps(progress, indent=2, ensure_ascii=False))

        return {
            "ok": True,
            "merged_checkpoints": len(hermes_cps),
            "session_id": progress["session_id"],
        }

    # ------------------------------------------------------------------ #
    # Listing
    # ------------------------------------------------------------------ #

    def list_sessions(self, *, limit: int = 20) -> list[dict]:
        """Return a summary of all known sessions."""
        results = []
        for p in self._all_session_files()[:limit]:
            try:
                data = json.loads(p.read_text())
                results.append({
                    "session_id": data.get("session_id"),
                    "task_description": data.get("task_description"),
                    "status": data.get("status"),
                    "checkpoints_count": len(data.get("checkpoints", [])),
                    "updated_at": data.get("updated_at"),
                })
            except (json.JSONDecodeError, OSError):
                continue
        return results


# ====================================================================== #
# CLI
# ====================================================================== #

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="progress_harness",
        description="Progress Harness — checkpoint manager for long AI sessions",
    )
    parser.add_argument("--session-id", help="Explicit session identifier")
    parser.add_argument("--progress-dir", type=Path, help="Override default progress directory")

    sub = parser.add_subparsers(dest="command", required=True)

    # init
    p_init = sub.add_parser("init", help="Start a new session")
    p_init.add_argument("task_description", help="Short description of the task")
    p_init.add_argument("--force", action="store_true", help="Overwrite existing session")

    # checkpoint
    p_cp = sub.add_parser("checkpoint", help="Record a checkpoint")
    p_cp.add_argument("action", help="What was accomplished")
    p_cp.add_argument("--state", default="{}", help="JSON dict of arbitrary state values")

    # status
    sub.add_parser("status", help="Show current session progress")

    # resume
    sub.add_parser("resume", help="Show last checkpoint + next steps")

    # next-steps
    p_ns = sub.add_parser("next-steps", help="Set next steps")
    p_ns.add_argument("steps", nargs="+", help="List of next steps")

    # blockers
    p_bl = sub.add_parser("blockers", help="Set blockers")
    p_bl.add_argument("blockers", nargs="+", help="List of blockers")

    # set-status
    p_st = sub.add_parser("set-status", help="Change session status")
    p_st.add_argument("status", choices=["in_progress", "paused", "completed"])

    # merge
    sub.add_parser("merge", help="Merge Hermes checkpoint references")

    # list
    sub.add_parser("list", help="List all sessions")

    return parser


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    h = ProgressHarness(progress_dir=args.progress_dir, session_id=args.session_id)

    if args.command == "init":
        state_json = "{}"
        result = h.init_session(args.task_description, session_id=args.session_id, force=args.force)
        if result["ok"]:
            print(f"✓ Session created: {result['session_id']}")
            print(f"  Path: {result['path']}")
        else:
            print(f"✗ {result['error']}")
            return 1

    elif args.command == "checkpoint":
        try:
            state = json.loads(args.state) if isinstance(args.state, str) else args.state
        except json.JSONDecodeError as e:
            print(f"✗ Invalid --state JSON: {e}")
            return 1
        result = h.save_checkpoint(args.action, state)
        if result["ok"]:
            print(f"✓ Checkpoint #{result['checkpoint_number']} saved ({result['session_id']})")
        else:
            print(f"✗ {result['error']}")
            return 1

    elif args.command == "status":
        progress = h.load_progress()
        if progress is None:
            print("No active session found.")
            return 1
        print(json.dumps(progress, indent=2, ensure_ascii=False))

    elif args.command == "resume":
        result = h.resume_last()
        if not result["ok"]:
            print(f"✗ {result['error']}")
            return 1
        print(f"Session: {result['session_id']}")
        print(f"Task:    {result['task_description']}")
        print(f"Status:  {result['status']}")
        print(f"Checkpoints: {result['total_checkpoints']}")
        if result["last_checkpoint"]:
            cp = result["last_checkpoint"]
            print(f"\nLast checkpoint (#{cp['checkpoint_number']}, {cp['timestamp']}):")
            print(f"  Action: {cp['action']}")
            if cp["state"]:
                print(f"  State:  {json.dumps(cp['state'], ensure_ascii=False)}")
        if result["next_steps"]:
            print(f"\nNext steps:")
            for i, s in enumerate(result["next_steps"], 1):
                print(f"  {i}. {s}")
        if result["blockers"]:
            print(f"\nBlockers:")
            for b in result["blockers"]:
                print(f"  ⚠ {b}")

    elif args.command == "next-steps":
        result = h.set_next_steps(args.steps)
        if result["ok"]:
            print(f"✓ Next steps updated for {result['session_id']}")
        else:
            print(f"✗ {result['error']}")
            return 1

    elif args.command == "blockers":
        result = h.set_blockers(args.blockers)
        if result["ok"]:
            print(f"✓ Blockers updated for {result['session_id']}")
        else:
            print(f"✗ {result['error']}")
            return 1

    elif args.command == "set-status":
        result = h.set_status(args.status)
        if result["ok"]:
            print(f"✓ Status → {args.status} ({result['session_id']})")
        else:
            print(f"✗ {result['error']}")
            return 1

    elif args.command == "merge":
        result = h.merge_with_hermes_checkpoints()
        if result["ok"]:
            print(f"✓ Merged {result['merged_checkpoints']} Hermes checkpoint references")
        else:
            print(f"✗ {result['error']}")
            return 1

    elif args.command == "list":
        sessions = h.list_sessions()
        if not sessions:
            print("No sessions found.")
            return 0
        for s in sessions:
            marker = {"in_progress": "▶", "paused": "⏸", "completed": "✓"}.get(s["status"], "?")
            print(f"  {marker} {s['session_id']}  [{s['status']}]  ({s['checkpoints_count']} cp)  {s.get('task_description','')[:60]}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
