#!/bin/bash
set -e
LOG=/root/.hermes/logs/update-$(date +%Y%m%d_%H%M%S).log
exec > "$LOG" 2>&1

echo "=== STOP GATEWAY ==="
systemctl stop hermes-gateway

sleep 5

echo "=== UPDATE HERMES ==="
cd /usr/local/lib/hermes-agent
hermes update --yes -q

echo "=== VERIFY ==="
hermes --version
hermes doctor --fix 2>&1 || true
hermes config check 2>&1 || true

echo "=== START GATEWAY ==="
systemctl start hermes-gateway

echo "=== DONE ==="
echo "Log: $LOG"
