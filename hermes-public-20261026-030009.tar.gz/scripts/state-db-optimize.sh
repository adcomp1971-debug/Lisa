#!/usr/bin/env bash
# state-db-optimize.sh — weekly state.db optimization (FTS5 merge + VACUUM)
set -euo pipefail

echo "=== state.db optimize $(date -u +%FT%TZ) ==="
hermes sessions optimize 2>&1
echo "=== done ==="
