#!/bin/bash
# Context Offload Watchdog — runs every 2 hours via no_agent cron
# Calls context_offload.py --compress and reports if anything was offloaded
set -euo pipefail

OUTPUT=$(python3 /root/.hermes/scripts/context_offload.py --check 2>&1) || true
EXIT_CODE=$?

if [ "$EXIT_CODE" -eq 99 ]; then
    echo "⚠️  CONTEXT OVERFLOW: $(echo "$OUTPUT" | head -3)"
    python3 /root/.hermes/scripts/context_offload.py --compress 2>&1 | tail -5
elif [ "$EXIT_CODE" -eq 80 ]; then
    echo "⚠️  Context at 80% — $(echo "$OUTPUT" | head -1)"
elif [ "$EXIT_CODE" -eq 1 ]; then
    echo "🔄 Offloaded $(echo "$OUTPUT" | grep -c 'offloaded') items"
    echo "$OUTPUT" | tail -10
elif [ "$EXIT_CODE" -eq 0 ]; then
    # Silent — nothing to report
    exit 0
fi
