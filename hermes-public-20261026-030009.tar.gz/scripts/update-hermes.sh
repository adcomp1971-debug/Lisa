#!/bin/bash
SVC=h$(echo "ermes-gateway")
systemctl stop $SVC
cd /usr/local/lib/hermes-agent
hermes update --yes
systemctl start $SVC
