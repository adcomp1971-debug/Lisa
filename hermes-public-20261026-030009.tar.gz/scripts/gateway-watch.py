#!/usr/bin/env python3
"""Gateway exit-code watchdog. Silent when clean, alerts on crashes."""
import subprocess, json, os
from datetime import datetime, timezone

SINCE = "24 hours ago"
THRESHOLD = 10  # alert if >10 exit-codes in 24h

result = subprocess.run(
    ["journalctl", "-u", "hermes-gateway", "--since", SINCE, "--no-pager", "-o", "json"],
    capture_output=True, text=True, timeout=30
)

if result.returncode != 0:
    msg = result.stderr.strip() or result.stdout.strip()[:100]
    print(f"⚠️ gateway-watch: journalctl failed ({msg})")
    exit(0)

exit_codes = 0
last_error = ""
for line in result.stdout.strip().split("\n"):
    if not line.strip():
        continue
    try:
        entry = json.loads(line)
        msg = entry.get("MESSAGE", "")
        if "exit-code" in msg or "Failed with result" in msg:
            exit_codes += 1
            last_error = msg
    except json.JSONDecodeError:
        continue

if exit_codes > THRESHOLD:
    print(f"🔴 Gateway crashed {exit_codes}x in last 24h (threshold={THRESHOLD})")
    print(f"Last: {last_error[:200]}")
    print("Check: systemctl status hermes-gateway, journalctl -u hermes-gateway -n 50")
elif exit_codes > 0:
    # below threshold — silent, not actionable
    pass
else:
    # silent — all good
    pass

exit(0)
