#!/usr/bin/env bash
# voice-cron.sh — обёртка: вывод cron-задачи → TTS голосовое сообщение
# Использование: voice-cron.sh "текст или файл"
# Если аргумент — путь к файлу, читает файл. Если текст — берёт как есть.
# Если <800 символов — отправляет голосом. Если больше — текстом.
set -euo pipefail

INPUT="${1:-}"
[ -z "$INPUT" ] && exit 0

TEXT=""
if [ -f "$INPUT" ]; then
    TEXT=$(cat "$INPUT")
else
    TEXT="$INPUT"
fi

LEN=$(echo -n "$TEXT" | wc -c)
if [ "$LEN" -gt 800 ]; then
    echo "$TEXT"
    exit 0
fi

# Оборачиваем в медиа-путь для доставки
OUTFILE=$(mktemp /tmp/voice-cron-XXXXXX.mp3)
python3 -c "
import sys
sys.path.insert(0, '/usr/local/lib/hermes-agent')
from agent.tts import text_to_speech_file
text_to_speech_file('''$TEXT''', '$OUTFILE')
" 2>/dev/null && echo "MEDIA:$OUTFILE" || echo "$TEXT"
