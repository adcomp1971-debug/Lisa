#!/usr/bin/env bash
# balance-voice.sh — сводка балансов провайдеров → голосом если <порога
set -euo pipefail

ENV_FILE="$HOME/.hermes/.env"
LOG=/root/.hermes/logs/balance-voice.log
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
THRESHOLD=5.00

[ -f "$ENV_FILE" ] && source "$ENV_FILE" || { echo "нет .env"; exit 1; }

MSG=""

# DeepSeek
DS=$(curl -sf --max-time 10 https://api.deepseek.com/user/balance \
    -H "Authorization: Bearer $DEEPSEEK_API_KEY" 2>/dev/null | \
    python3 -c "import sys,json;d=json.load(sys.stdin);print(d['balance_infos'][0]['total_balance'])" 2>/dev/null) || DS="ERR"
MSG+="DeepSeek: \$$DS. "

# OpenRouter
OR=$(curl -sf --max-time 10 https://openrouter.ai/api/v1/credits \
    -H "Authorization: Bearer $OPENROUTER_API_KEY" 2>/dev/null | \
    python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('data',{}).get('total_credits','ERR'))" 2>/dev/null) || OR="ERR"
MSG+="OpenRouter: \$$OR. "

# Anthropic
AN=$(curl -sf --max-time 10 https://api.anthropic.com/v1/account/credits \
    -H "x-api-key: $ANTHROPIC_API_KEY" -H "anthropic-version: 2023-06-01" 2>/dev/null | \
    python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('credits','ERR'))" 2>/dev/null) || AN="ERR"
MSG+="Anthropic: \$$AN."

echo "$TS $MSG" >> "$LOG"

URGENT=0
for bal in $(echo "$DS $OR $AN" | tr ' ' '\n'); do
    [ "$bal" = "ERR" ] && continue
    if [ "$(echo "$bal < $THRESHOLD" | bc -l 2>/dev/null)" = "1" ]; then
        URGENT=1
    fi
done

if [ "$URGENT" = "1" ]; then
    MSG="⚠️ Низкий баланс! $MSG"
fi

echo "$MSG"
