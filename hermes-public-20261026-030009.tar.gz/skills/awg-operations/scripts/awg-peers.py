#!/usr/bin/env python3
"""Инвентарь пиров AmneziaWG: живые/мёртвые, имена, возраст handshake.

Только stdlib — работает и под managed-python шлюза Hermes.
Ничего не меняет: read-only отчёт.

Usage:
  awg-peers.py                       # awg0, имена из живого конфига + бэкапов
  awg-peers.py awg2                  # другой интерфейс
  awg-peers.py awg0 --dead-keys      # только pubkey мёртвых (для awg set ... remove)
  awg-peers.py awg0 --conf /path/awg0.conf --names-from '/root/backups/awg0.conf.bak-*'

Колонки `awg show <iface> dump`: pubkey, psk, endpoint, allowed-ips,
latest-handshake, rx, tx, keepalive. hs=0 → рукопожатий не было никогда.
Имена матчатся ПО PublicKey, порядок блоков в файле и в dump разный.
"""
import argparse
import datetime
import glob
import re
import subprocess
import sys

CONF_TPL = '/etc/amnezia/amneziawg/{iface}.conf'
NAME_GLOBS = ('/root/backups/*{iface}*.conf*', '/root/*{iface}*.conf*',
              '/etc/amnezia/amneziawg/*{iface}*.conf.bak*')
SKIP_COMMENT = ('amnezia', 'privatekey', 'listenport', 'address', 'table',
                'mtu', 'dns', 'v6-peer', 'junk', 's1', 's2', 'h1', 'h2', 'h3', 'h4')


def parse_names(paths):
    """pubkey -> имя. Первый источник выигрывает, поэтому живой конфиг — первым."""
    names = {}
    for path in paths:
        cur = None
        try:
            fh = open(path, encoding='utf-8', errors='ignore')
        except OSError:
            continue
        with fh:
            for line in fh:
                s = line.strip()
                if s.startswith('#'):
                    cand = s.lstrip('#').strip()
                    low = cand.lower()
                    if cand and not any(low.startswith(p) for p in SKIP_COMMENT):
                        cur = cand
                    continue
                if s.startswith('[Peer]'):
                    continue
                m = re.match(r'^PublicKey\s*=\s*(\S+)', s)
                if m:
                    if cur:
                        names.setdefault(m.group(1), cur)
                    cur = None
    return names


def human(num):
    num = int(num or 0)
    for unit in ('B', 'KiB', 'MiB', 'GiB'):
        if num < 1024:
            return '%d %s' % (num, unit)
        num //= 1024
    return '%d TiB' % num


def dump(iface):
    res = subprocess.run(['awg', 'show', iface, 'dump'],
                         capture_output=True, text=True)
    if res.returncode != 0:
        sys.exit('awg show %s dump: %s' % (iface, (res.stderr or '').strip() or 'failed'))
    return res.stdout.splitlines()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('iface', nargs='?', default='awg0')
    ap.add_argument('--conf', default=None)
    ap.add_argument('--names-from', action='append', default=None,
                    help='glob с конфигами/бэкапами для восстановления имён (можно повторять)')
    ap.add_argument('--dead-keys', action='store_true', help='только pubkey мёртвых пиров')
    ap.add_argument('--all', action='store_true',
                    help='с --dead-keys: включить и тех, у кого есть трафик (бывшие клиенты)')
    args = ap.parse_args()

    conf = args.conf or CONF_TPL.format(iface=args.iface)
    sources = [conf] + sorted(glob.glob(conf + '.bak*'))
    if args.names_from:
        for pat in args.names_from:
            sources += sorted(glob.glob(pat))
    else:
        for pat in NAME_GLOBS:
            sources += sorted(glob.glob(pat.format(iface=args.iface)))
    names = parse_names(sources)

    now = datetime.datetime.now(datetime.timezone.utc)
    rows = []
    for line in dump(args.iface)[1:]:
        f = line.split('\t')
        if len(f) < 8:
            continue
        pub, allowed, hs, rx, tx = f[0], f[3], int(f[4] or 0), int(f[5] or 0), int(f[6] or 0)
        ip = allowed.split(',')[0].replace('/32', '').strip()
        rows.append(dict(pub=pub, ip=ip, hs=hs, rx=rx, tx=tx,
                         name=names.get(pub, '-')))

    dead = sorted([r for r in rows if r['hs'] == 0], key=lambda r: r['ip'])
    live = sorted([r for r in rows if r['hs'] > 0], key=lambda r: r['ip'])

    if args.dead_keys:
        for r in dead:
            if args.all or (r['rx'] == 0 and r['tx'] == 0):
                print(r['pub'])
        return

    print('iface %s: всего %d | живых %d | мёртвых %d' % (args.iface, len(rows), len(live), len(dead)))
    print('\n=== МЁРТВЫЕ (handshake никогда) ===')
    for i, r in enumerate(dead, 1):
        flag = '' if (r['rx'] or r['tx']) == 0 else '  <- был трафик, проверь вручную!'
        print('%2d) %-13s %-26s rx=%-9s tx=%-9s%s' % (i, r['ip'], r['name'], human(r['rx']), human(r['tx']), flag))
    print('\n=== ЖИВЫЕ (не трогать) ===')
    for i, r in enumerate(live, 1):
        when = datetime.datetime.fromtimestamp(r['hs'], datetime.timezone.utc)
        age = now - when
        age_s = int(age.total_seconds())
        ago = ('%d дн' % (age_s // 86400) if age_s >= 86400 else
               '%d ч' % (age_s // 3600) if age_s >= 3600 else '%d мин' % (age_s // 60))
        print('%2d) %-13s %-26s hs %s (%s назад) rx=%s tx=%s' % (
            i, r['ip'], r['name'], when.strftime('%Y-%m-%d %H:%M'), ago, human(r['rx']), human(r['tx'])))
    print('\nСнять мёртвых без разрыва живых:  for k in $(awg-peers.py %s --dead-keys); do awg set %s peer "$k" remove; done'
          % (args.iface, args.iface))


if __name__ == '__main__':
    main()
