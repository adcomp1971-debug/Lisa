# FaceTime / UDP-медиа фикс через AWG (серверная часть)

Диагностировал Kimi K3 (27 Jul 2026). Проблема: клиенты (iPhone) подключались к AWG, но FaceTime/Instagram видео не работали.

## Диагноз (3 причины)

1. **MTU слишком высокий** — WireGuard overhead ~60 байт. MTU 1420 → реально 1360 для данных. UDP медиа-пакеты (QUIC 1200+, RTP) фрагментировались или дропались. WireGuard НЕ фрагментирует — дропает.
2. **Нет MSS clamping** — TCP SYN не ограничивал MSS, сегменты не влезали в MTU после encapsulation.
3. **UDP/STUN/TURN не разрешены явно** — FaceTime использует STUN (UDP 3478), TURN (UDP 3478-5349), RTP (UDP 1024+).

## Фикс (4 шага)

```bash
# 1. MTU на лету (клиентские конфиги тоже: MTU = 1200)
ip link set dev awg0 mtu 1280   # затем в конфиге клиентов 1200

# 2. MSS clamping
iptables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu

# 3. FORWARD awg0→eth0
ufw route allow in on awg0 out on eth0

# 4. UDP через AWG
ufw allow out on awg0 proto udp
```

## Итоговый MTU
- Клиентский конфиг: `MTU = 1200` (проверено — при 1280/1350 медиа всё ещё падало)
- Сервер: 1280 достаточно для MSS clamp, но клиентам ставить 1200

## Проверка
- `iptables -t mangle -L FORWARD -n -v | grep TCPMSS` — должно показывать clamp to PMTU
- `ip link show awg0 | grep mtu` — mtu 1280 на сервере
- Клиент переподключается и FaceTime работает

## Связано
- `awg-client-provisioning` — MTU 1200 обязателен в клиентских конфигах
- `awg-operations` — диагностика «VPN не работает»
