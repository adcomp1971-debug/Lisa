#!/usr/bin/env python3
"""Diff the two latest cron run archives of one job.

Usage:  python3 cron-archive-diff.py <job_id> [answer_marker]

  job_id        hex id of the cron job (from `hermes cron list`)
  answer_marker literal string that starts the agent's real answer (e.g. the digest header
                line, or any unique phrase at the top of the delivered text). Optional but
                STRONGLY recommended — see the pitfall below.

What it prints:
  * whether each of the two newest archives contains the continuity injection
    ("Your previous run's output") and whether it was clipped;
  * the numbered items of both runs and their verbatim overlap.

PITFALL this script exists for: a run archive contains the WHOLE prompt, including the
loaded skill text and the continuity block. Grepping the file as a whole matches the skill's
own templates/examples (placeholder headings) and invents "repeats" between runs. The real
answer is taken from the LAST occurrence of the marker (rfind) — there is no `## Response`
heading in the archive.
"""
import glob
import os
import re
import sys

OUTPUT_DIR = os.path.expanduser("~/.hermes/cron/output")


def newest_archives(job_id, count=2):
    files = glob.glob(os.path.join(OUTPUT_DIR, job_id, "*.md"))
    return sorted(files, key=os.path.getmtime)[-count:]


def answer_text(path, marker):
    text = open(path, encoding="utf-8-sig").read()
    if not marker:
        return text
    idx = text.rfind(marker)  # last, not first: the prompt contains the previous run too
    if idx < 0:
        print(f"! marker {marker!r} not found in {os.path.basename(path)}", file=sys.stderr)
        return text[-6000:]
    return text[idx:]


def numbered_items(text):
    return [ln.strip() for ln in text.splitlines() if re.match(r"^\s*\d+\.\s+\S", ln)]


def norm(item):
    return re.sub(r"^\d+\.\s*", "", item).lower()[:55]


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    job_id = sys.argv[1]
    marker = sys.argv[2] if len(sys.argv) > 2 else None

    files = newest_archives(job_id)
    if len(files) < 2:
        sys.exit(f"need >=2 archives for job {job_id}, found {len(files)}")
    older, newer = files

    for path in (older, newer):
        raw = open(path, encoding="utf-8-sig").read()
        injected = "Your previous run's output" in raw
        clip = re.search(r"\[\.\.\. (\d+) chars omitted \.\.\.\]", raw)
        clip_note = f", clipped: {clip.group(1)} chars" if clip else ""
        state = "yes" if injected else "NO"
        print(f"{os.path.basename(path)}: previous-run injection={state}{clip_note}")

    old_items = numbered_items(answer_text(older, marker))
    new_items = numbered_items(answer_text(newer, marker))
    print(f"\nnumbered items: {len(old_items)} -> {len(new_items)}")

    duplicates = {norm(x) for x in old_items} & {norm(x) for x in new_items}
    print(f"verbatim heading repeats: {len(duplicates)}")
    for dup in sorted(duplicates):
        print("  REPEAT:", dup)
    for item in new_items[:8]:
        print("  -", item[:110])


if __name__ == "__main__":
    main()
