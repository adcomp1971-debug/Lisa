# External Memory Providers

Hermes ships 8 external memory providers. Built-in memory (MEMORY.md / USER.md) stays active — a provider is **additive**, never a replacement. Only **one** external provider can be active at a time.

Available: `honcho`, `openviking`, `mem0`, `hindsight`, `holographic`, `retaindb`, `byterover`, `supermemory`.

## Choosing one

- **Default on this server: `holographic`** — local SQLite, no API key, nothing leaves the host, FTS5 full-text plus HRR vectors, trust scoring.
- `honcho` / `mem0` / `supermemory` / `openviking` / `retaindb` / `byterover` / `hindsight` — cloud or API-key based, i.e. conversation content leaves the server. Only on an explicit user request.

## What enabling a provider actually buys

1. Provider context injected into the system prompt
2. Relevant memories **prefetched before each turn** (background, non-blocking) — the real gain over keyword lookup of MEMORY.md
3. Conversation turns synced after each response
4. Memories extracted at session end (provider-dependent)
5. Built-in memory writes mirrored to the provider
6. Provider-specific tools added

## Enabling holographic

1. Back up config (see hermes-config-ops SKILL.md §1 for the write path — never `hermes config set`, never `patch`/`write_file`)
2. Add `provider: holographic` under `memory:` and a `hermes-memory-store:` block under `plugins:` holding `auto_extract: true` and `db_path: /root/.hermes/memory_store.db`
3. Validate, and confirm nothing else drifted:
   `python3 -c "import yaml; d=yaml.safe_load(open('/root/.hermes/config.yaml')); print(d['memory'].get('provider'), d.get('plugins',{}).get('hermes-memory-store'), len(d.get('fallback_providers',[])))"`
4. `hermes memory status` must show `Provider: holographic`, `Plugin: installed`, `holographic (local) ← active`
5. Gateway restart (user action) before the bot uses it; CLI picks it up on the next invocation

## Holographic internals

- DB: `/root/.hermes/memory_store.db`
- Tables: `facts`, `entities`, `fact_entities`, `facts_fts*`, `memory_banks`
- `facts` columns: `fact_id`, `content`, `category`, `tags`, `trust_score`, `retrieval_count`, `helpful_count`, `created_at`, `updated_at`, `hrr_vector`. The key column is **`fact_id`, not `id`** — `SELECT id FROM facts` errors out.
- Tools: `fact_store` (add / search / probe / related / reason / contradict / update / remove / list) and `fact_feedback` (helpful +0.05, unhelpful −0.10 → trains trust scores)
- End-to-end smoke test that proves the wiring rather than the config: run `hermes chat -q` asking to store a fact, then confirm a new row in **both** `facts` and `facts_fts`

## Pitfalls

- `hermes memory setup` is interactive: it wants a TTY and cancels or hangs in cron and non-interactive tool calls. Configure through config.yaml instead.
- Never present the provider as a replacement for MEMORY.md/USER.md — both are injected, and MEMORY.md remains the authoritative always-loaded store.
- `auto_extract: true` spends model tokens at session end to distil facts; turn it off when cost matters more than recall.
- The provider reaches the bot only after a gateway restart; verifying in CLI and reporting success for the user is a lie.
