# state.db WAL Halt — Diagnose, Verify, Clean Up

Applies when the gateway log reports a live process holding a deleted `state.db-wal` inode, or aborts writes with `DeletedWalGenerationError` (typically after a checkpoint swap): writes halt and new transcript rows go to an on-disk fallback.

**This is a stale WAL generation, not corruption.** Frames committed by the retired generation sit in the retired copy until an operator decides whether they belong on top of the current file. Nothing is lost by waiting; nothing is gained by acting fast.

## Never, while the gateway is running

- open the live DB for write / checkpoint / `VACUUM` / `PRAGMA wal_checkpoint`
- run `hermes sessions recover` — it yields an empty DB; never swap it over the live file
- delete or overwrite the retired WAL copy

## Procedure

1. Gateway restart — performed by the user, never from inside the gateway. This is the actual fix.
2. Prove no data loss **before** touching anything. All read-only: connect with `file:/path?mode=ro` as a URI plus `PRAGMA query_only=1`.
   - `SELECT COUNT(*), MAX(id) FROM messages` on the live DB and on the retired copy
   - set-difference the `id`s: every id present in the retired copy must exist in the live DB. Difference of 0 = nothing lost, replay unnecessary
3. Read-only integrity check: `PRAGMA quick_check(1)` → `ok`
4. Confirm writes resumed: newest message timestamp is current, and any session reported unreadable returns its full message count

Declare the restart sufficient only when the id-difference is 0. Otherwise the retired copy must be inspected before it is archived or deleted.

## Live files vs dead leftovers

`lsof /root/.hermes/state.db*` — only files held by the running Hermes process are live (`state.db`, `state.db-shm`, `state.db-wal`). Anything else carrying a suffix (`-wal`, `-shm`, `.broken`, `.old`, `.pre-swap*`, `.recovered*`, `retired-wal-*`) is a leftover from an earlier incident and never part of the live set.

## Retention and cleanup order

1. Verify (steps 2–3 above)
2. Archive the retired snapshot: `tar -czf /root/.hermes/state-archives/retired-wal-<stamp>.tar.gz -C /root/.hermes <retired-dir>` — compresses roughly 2:1 (≈420 MB → ≈220 MB). Delete the source directory only after the archive is a plausible size
3. Then delete dead generations: `.broken` / `.old` / `.pre-swap*` / `.recovered*` copies, which accumulate to hundreds of MB each. Safe only once the live DB passes integrity and the id-difference is 0

Never reverse the order to free space first.

## Related

- Routine size control on a healthy DB (prune windows, VACUUM, FTS5 size expectations) is a separate topic — this file is only the halt/verify/cleanup path.
