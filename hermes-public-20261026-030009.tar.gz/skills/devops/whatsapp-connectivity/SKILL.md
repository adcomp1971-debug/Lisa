---
name: whatsapp-connectivity
description: "WhatsApp через VPN: Meta-баны, iOS-прокси, обход РКН."
category: devops
version: 1.0.0
author: Hermes Agent
---

# WhatsApp Connectivity через VPN/прокси

Класс задач: у клиента (iPhone/Android) в РФ WhatsApp не работает через самодельный VPN (AmneziaWG). Нужно понять, кто блокирует (РКН, Meta-бан IP, shadow-ban аккаунта, приложение) и что чинить.

## Диагностическая последовательность (проверено 2026-08-07)

### Шаг 1 — VPN жив?
```bash
awg show awg0 | grep -A4 "<client-ip>"
# handshake свежий + трафик идёт = VPN ок
```

### Шаг 2 — IP сервера в бане Meta? (не путать с анти-бот защитой API)
- `web.whatsapp.com` открывается с серверного IP и QR-код генерируется → IP **НЕ забанен** для веб-версии.
- `g.whatsapp.net` сбрасывает TLS (`Connection reset by peer`) со **ВСЕХ** дата-центров (проверить через check-host.net: DE/US/RU) — это **анти-бот защита API**, НЕ признак бана IP. curl-тест на g.whatsapp.net бесполезен для проверки бана.

### Шаг 3 — Ключевой тест: tcpdump на интерфейсе VPN
```bash
timeout 90 tcpdump -i awg0 -nn 'tcp port 5222 or tcp port 443' -c 30
```
Если у ДРУГОГО клиента (соседний пир) WhatsApp-трафик идёт напрямую к Meta (31.13.x.x:5222) — IP не банится, а проблема в аккаунте/приложении клиента. Спросить: «а у остальных работает?» — если ни у кого не работает → системный блок, если только у одного → shadow-ban аккаунта.

**⚠️ Питфолл (проверено 2026-08-07): tcpdump показывает TCP-соединения к Meta, но WhatsApp всё равно не работает у ВСЕХ клиентов.** Наблюдали: `10.9.0.101 → 31.13.72.175:5222` — handshake идёт, пакеты ходят, но и у этого клиента («Саша») сообщения «уже давно не работают». Вывод: TCP-соединение устанавливается, а блок происходит на уровне протокола Noise/приложения поверх TCP — дата-центровый IP режется Meta на прикладном уровне, не на TCP. Прокси (даже официальный `facebook/whatsapp_proxy`) это НЕ решает, если Meta режет весь трафик с дата-центра. В таком случае остаётся: смена IP на не-дата-центровый (residential), либо ожидание, либо другой канал. Не тратить время на переустановку приложения у одного клиента, если у всех одинаковый симптом — это системный блок.

### Шаг 4 — Симптомы и вердикт
- «Без VPN вообще не работает» → РКН, нужен VPN (это ожидаемо в 2026, WhatsApp душат на госуровне).
- «С VPN открывается, но сообщения не ходят» → либо Meta ограничивает аккаунт (shadow-ban за дата-центр), либо зависшее приложение. Прокси-обход часто не помогает, если забанен АККАУНТ, а не IP.
- «Приложение открывается, медиа грузится, сообщения нет» → мобильный API (g.whatsapp.net) режется, но IP не забанен для веба → аккаунт/приложение.

## WhatsApp iOS настройка прокси — критические факты (проверено 2026-08-07)

1. **Поле адреса принимает ТОЛЬКО хост/IP без порта.** Порт задаётся отдельно в «Порт чата» и «Порт медиа». Адрес вида `1.2.3.4:3128` в одном поле → кнопка «Сохранить» серая. Это НЕ баг — так устроен экран (секция «Настроить порты (необязательно)»).
2. **SOCKS5 прокси НЕ поддерживается** — WhatsApp iOS говорит с прокси сырым TCP (протокол Noise), НЕ HTTP CONNECT и НЕ SOCKS5. Обычный squid/dante не подойдут в принципе.
3. **Правильный прокси — официальный `facebook/whatsapp_proxy`** (HAProxy от Meta):
   ```bash
   docker run -d --name whatsapp-proxy --restart unless-stopped \
     -p 10.9.0.1:5222:5222 -p 10.9.0.1:587:587 \
     -p 10.9.0.1:7777:7777 -p 10.9.0.1:8199:8199 \
     facebook/whatsapp_proxy:latest
   ```
   Внутри: 5222 → g.whatsapp.net:5222 (чат), 587 → whatsapp.net:443 (медиа), 7777 резерв, 8199 stats. Сертификат генерируется сам при старте.
4. **Приватный IP (10.9.0.1) в прокси WhatsApp может не работать** — приложение/iOS не подключается к RFC1918 адресам в этом контексте. Публичный IP тоже не работает при Full Tunnel: iOS намеренно маршрутизирует IP самого VPN-сервера мимо туннеля (endpoint exclusion). Это тупик обоих вариантов — проверять реальным tcpdump, какой трафик реально идёт от клиента.
5. Проверка доходит ли трафик клиента до прокси: `docker logs whatsapp-proxy --tail 20` + `grep <client-ip> /var/log/squid/access.log` (для squid) или tcpdump на awg0.

## Shadow-ban аккаунта Meta
Если прокси работает, IP не забанен, а сообщения всё равно не ходят — вероятен shadow-ban аккаунта (Meta ограничивает аккаунты, подключающиеся с дата-центровых IP). Лечится: переустановка приложения (с бэкапом чатов), ожидание 1-7 дней, вход в WhatsApp Web для «прогрева». Прокси это НЕ решает.

## 🔴 СТОП-ПРАВИЛО: никаких изменений системы без явного подтверждения Алекса
(проверено 2026-08-07, Алекс в ярости)
- **НЕ разворачивать docker-контейнеры, не менять конфиги nginx/squid/xray, не открывать порты** — сначала план, потом ждать «да».
- **Делегированным субагентам (delegate_task) НЕ давать полномочий на изменения.** Субагент (Kimi) развернул `whatsapp-proxy` контейнер сам, без согласия — это грубое нарушение. В goal/context субагента явно писать: «только диагностика read-only, никаких изменений системы без отдельного подтверждения».
- Проверка порта 443/8443 (заняты XRay/nginx) — допустима как диагностика, но перенастройка — только с согласия.
- Если Алекс сказал «не смей» — немедленно остановиться, объяснить что уже сделано, предложить план и ждать.

## Cloudflare WARP как чистый выходной IP (для прокси на сервере)
```bash
# wgcf: регистрация + генерация wireguard-конфига Cloudflare WARP
wgcf register --accept-tos && wgcf generate
# warp0 поднимается с отдельной таблицей маршрутизации (НЕ default route!):
ip link add dev warp0 type wireguard && wg setconf warp0 /tmp/warp-setconf.conf
ip addr add 172.16.0.2/32 dev warp0 && ip link set warp0 up && ip link set dev warp0 mtu 1280
ip route replace default dev warp0 table 100
ip rule add from 172.16.0.2 lookup 100
# Выход через WARP: curl --interface warp0 https://icanhazip.com → 104.28.x.x (Cloudflare)
```
**Питфолы WARP:**
- endpoint по умолчанию IPv6 (`engage.cloudflareclient.com:2408`) — если на сервере IPv6 кривой, принудительно `wg set warp0 peer <pub> endpoint 162.159.192.1:2408`.
- `wg setconf` НЕ принимает `Address=` (это директива wg-quick) — выносить в `ip addr add`.
- WARP не пускает трафик к собственным Cloudflare-эндпоинтам (icanhazip.com, ipify, 1.1.1.1 через него молчат) — это норма, тестировать на example.com.
- Для squid привязка исходящего к WARP: `tcp_outgoing_address 172.16.0.2` + `acl to_ipv6 dst ::/0` + `http_access deny to_ipv6` + `dns_v4_first on`.

## Альтернативный канал — XRay VLESS (когда AWG-прокси не помог)

Если через AWG (AmneziaWG) + прокси WhatsApp не завёлся — пробуем дать клиенту второй туннель: XRay VLESS Reality (тот же сервер, другой протокол). Полезно для РФ: порт 443 (стандартный HTTPS) не режется провайдерами, SNI `www.icloud.com` — легитимный домен Apple, DPI не палит.

**Важно (проверено 2026-08-08):** смена канала AWG→XRay НЕ меняет выходной IP — оба выходят с `76.13.77.105`. Если Meta режет по IP дата-центра, XRay не поможет, только другой IP (residential). Но попробовать стоит — быстро и бесплатно, отсекает «проблема в протоколе/порту» от «проблема в IP».

Настройка порта 443 для VLESS через nginx SNI-роутинг (XRay на 8443, nginx stream на 443, сайты на 4443) и тест конфига локальным xray-клиентом — в `references/xray-vless-443-setup.md`.

## iOS-клиент VLESS Reality для российского App Store

Когда клиенту (iPhone) нужен XRay-туннель — многие VPN-клиенты удалены из РФ стора (Apple по требованию РКН). Проверено 2026-08-08:

**Лучший: v2RAGE** — бесплатный, 4.55★, явно поддерживает VLESS+REALITY (VMess, Hysteria, Hysteria2, TUIC, SOCKS), импорт через QR/буфер/вручную, без рекламы/трекинга. Ссылка: `https://apps.apple.com/ru/app/v2rage/id6761075402`.

НЕТ в РФ сторе (проверено через iTunes lookup): Streisand, V2Box, FoXray, v2RayTun, Happ. V2Ray Client+ (id6747379524) есть, но 3.4★ — сыроват.

**Метод проверки доступности приложения в региональном сторе** — web_extract на apps.apple.com/ru ненадёжен (SPA-заглушка «страница не найдена»). Надёжно через iTunes lookup API:
```bash
curl -s "https://itunes.apple.com/lookup?id=<APPLE_ID>&country=ru" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['results'][0]['trackName'] if d.get('resultCount') else 'НЕ НАЙДЕН')"
curl -s "https://itunes.apple.com/search?term=vless&country=ru&entity=software&limit=10"
```

Полный список и команды — в `references/ios-vless-clients-russia.md`.

## Ссылки
- `references/whatsapp-proxy-ios-session.md` — полный разбор сессии 2026-08-07 (все попытки и результаты)
- `references/xray-vless-443-setup.md` — настройка VLESS на порту 443 через nginx SNI + проверка конфига (2026-08-08)
- `references/ios-vless-clients-russia.md` — iOS-клиенты VLESS Reality для РФ стора + iTunes lookup API (2026-08-08)
