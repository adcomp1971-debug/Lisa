# Диагностика «Instagram не работает у клиента» — 2026-08-24

Симптом: Юля (AWG 10.9.0.108) — Instagram не работает. Алекс требует проверить AWG.

## Диагностика (порядок)

1. **VPN жив?** `awg show awg0 | grep -A4 10.9.0.108` → handshake свежий (секунды), transfer растёт = VPN ок.
2. **Серверные IG-эндпоинты доступны?**
   ```bash
   for h in i.instagram.com api.instagram.com upload.instagram.com graph.instagram.com; do
     ip=$(dig +short $h @8.8.8.8 | tail -1)
     curl -sk --interface eth0 --max-time 8 -o /dev/null -w "$h: %{http_code}\n" "https://$ip/"
   done
   # 404 = норм (соединение есть, нет пути). 000 = недоступно.
   ```
3. **Куда реально ходит клиент?** (КЛЮЧЕВОЙ ШАГ)
   ```bash
   timeout 60 tcpdump -i awg0 -nn 'src host 10.9.0.108 and tcp dst port 443' -c 20
   # Смотрим dst IP: 157.240.x/31.13.x = Meta (Instagram/WhatsApp);
   # 149.154.167.x = Telegram Amsterdam (НЕ Meta!).
   ```
4. **Чей IP?** whois RIPE-ERX даёт обобщённое («RIPE-ERX-149-154-0-0»). Точный владелец через ip-api:
   ```bash
   curl -s "http://ip-api.com/json/<IP>" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('org'), d.get('isp'))"
   ```

## Вывод из сессии

- Юля была подключена (handshake 25с, 1.45 GiB трафика), IG-эндпоинты с сервера отвечали 404 (ок), Meta-IP доступны.
- За 60с tcpdump Юля ходила ТОЛЬКО на 149.154.167.41/.35 — это **Telegram Messenger Amsterdam Network** (Нидерланды), НЕ Meta.
- Вывод: клиент вообще не обращается к Instagram → проблема на устройстве (залипший DNS/кэш после РКН), НЕ в VPN и НЕ в сервере.
- Рекомендация клиенту по порядку: перезапустить приложение → перезапустить VPN → перезагрузить телефон → переустановить Instagram.
- Не трогать сервер, не менять конфиги, не рестартить AWG.

## Питфолл: web-graph.instagram.com / b-graph.instagram.com не резолвятся

`dig +short web-graph.instagram.com` → пусто (и у 8.8.8.8, и у системного). Это НЕ поломка — такие хосты внутренние для приложения Meta, не публичные. Не чинить.

## Питфолл: `systemctl is-active` для AWG

`systemctl is-active awg-quick@awg0` = active (правильно). `wg-quick@awg0` = inactive (НЕ то имя, у нас amneziawg). Использовать `awg show awg0`, а не `wg show` (wg не установлен, показывает только warp0).
