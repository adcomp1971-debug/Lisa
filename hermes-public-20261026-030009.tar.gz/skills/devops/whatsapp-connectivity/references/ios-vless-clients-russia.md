# iOS-клиенты VLESS Reality для российского App Store (2026-08-08)

Когда клиенту (iPhone в РФ) нужен XRay VLESS-туннель — многие VPN-клиенты
удалены из российского App Store (Apple удаляет по требованию РКН). Это
список проверенных вариантов и метод проверки доступности.

## Лучший выбор: v2RAGE

- Бесплатный, 4.55★ (84 отзыва в РФ сторе), без подписок/рекламы/трекинга
- Явно поддерживает **VLESS (с REALITY)**, также VMess, Hysteria, Hysteria2, TUIC, SOCKS
- Импорт через QR-код, буфер обмена или вручную (вставляет vless:// ссылку)
- iPhone/iPad/Mac/Apple TV
- Ссылка: `https://apps.apple.com/ru/app/v2rage/id6761075402`

## Проверено 2026-08-08: НЕТ в российском сторе

| Приложение | Статус в РФ сторе |
|-----------|-------------------|
| Streisand (id6450534064) | «страница не найдена» — удалено |
| V2Box (id6446814690) | не найдено |
| FoXray (id6443714888) | не найдено |
| v2RayTun (id6477523893) | не найдено |
| Happ (id6504287215) | не найдено (сайт happ.su заявляет «Global, Rus», но lookup country=ru пуст) |
| V2Ray Client+ (id6747379524) | есть, 3.4★, 277 отзывов — работает, но сыроват |

## Метод проверки доступности приложения в региональном сторе

**web_extract на apps.apple.com/ru/... ненадёжен** — часто возвращает
«Запрашиваемая страница не найдена» даже для существующих приложений
(SPA-заглушка Apple). Надёжный способ — iTunes lookup/search API:

```bash
# доступность конкретного приложения:
curl -s "https://itunes.apple.com/lookup?id=<APPLE_ID>&country=ru" | \
  python3 -c "import json,sys; d=json.load(sys.stdin); print(d['results'][0]['trackName'] if d.get('resultCount') else 'НЕ НАЙДЕН')"

# поиск по термину с рейтингами:
curl -s "https://itunes.apple.com/search?term=vless&country=ru&entity=software&limit=10" | \
  python3 -c "import json,sys; [print(r['trackName'], r.get('trackId'), r.get('averageUserRating'), r.get('userRatingCount')) for r in json.load(sys.stdin).get('results',[])]"
```

country=ru — российский стор; можно менять на us/ge/kz и т.п.
Выбирать по `averageUserRating` + `userRatingCount` (больше отзывов = надёжнее).
