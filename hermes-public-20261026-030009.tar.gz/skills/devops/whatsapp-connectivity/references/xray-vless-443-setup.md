# XRay VLESS на порту 443 через nginx SNI-роутинг (2026-08-08)

Проблема: XRay (x-ui) слушает VLESS Reality на `76.13.77.105:8443`, но для клиентов из РФ порт 8443 (нестандартный) может резаться провайдером. Нужно раздавать клиентам порт **443** (стандартный HTTPS). Решение — nginx stream с SNI-роутингом: `www.icloud.com` → XRay, всё остальное → сайты nginx.

## Ключевые факты

- XRay слушает на **конкретном IP** `76.13.77.105:8443` (НЕ 127.0.0.1:8443!). В nginx stream upstream указывать `76.13.77.105:8443`.
- Базовый Ubuntu nginx (nginx-core) **НЕ имеет stream-модуля** → `unknown directive "stream"`. Нужен `nginx-full`.
- 443 занят nginx (сайты gatebox/dash/mivtzar) — их надо перевести на внутренний 4443.
- XUI веб-панель: порт 49624, работает по **HTTPS** с секретным basePath `/bSKXRhmWZZaWa2axfu/`. Прямая ссылка: `https://76.13.77.105:49624/bSKXRhmWZZaWa2axfu/`. nginx-локация `/xui/` проксирует на неё по HTTP → ломается («Unsupported HTTP version»). Для работы через nginx нужен `proxy_ssl` (https к бэкенду) или прямая ссылка на 49624.

## Шаги

### 1. Установить nginx-full (если stream-модуля нет)
```bash
nginx -V 2>&1 | tr ' ' '\n' | grep -c "^--with-stream"   # 0 = нет
apt-get install -y nginx-full
```

### 2. Перевести http-сайты с 443 на 4443
```bash
cp /etc/nginx/sites-available/gatebox /root/backups/nginx-gatebox.bak.$(date +%Y%m%d_%H%M%S)
sed -i 's/listen 443 ssl http2;/listen 4443 ssl http2;/' /etc/nginx/sites-enabled/gatebox
```

### 3. Добавить stream-блок в конец /etc/nginx/nginx.conf
```nginx
stream {
    map $ssl_preread_server_name $backend {
        www.icloud.com        76.13.77.105:8443;   # XRay VLESS Reality
        default               127.0.0.1:4443;      # nginx http (сайты)
    }
    server {
        listen 443;
        proxy_pass $backend;
        ssl_preread on;
    }
}
```

### 4. Применить и проверить
```bash
nginx -t && systemctl reload nginx
# Сайт жив через stream default:
curl -k -o /dev/null -w '%{http_code}' https://76.13.77.105/dash/    # 200
# VLESS SNI уходит на XRay (000/сброс от curl — НОРМА, это Reality не отвечает не-VLESS клиентам):
curl -k -m 8 -o /dev/null --resolve www.icloud.com:443:127.0.0.1 https://www.icloud.com/  # 000
```

### 5. Клиентский VLESS URL — порт 443 (не 8443!)
```
vless://<UUID>@76.13.77.105:443?type=tcp&security=reality&pbk=<PUBKEY>&fp=chrome&sni=www.icloud.com&sid=<SID>&spx=%2F&flow=xtls-rprx-vision#Имя-Клиента
```
Параметры (pubkey/sid/sni/spx) брать из `inbounds.stream_settings.realitySettings` в БД x-ui. Скрипт `add_client.py` может выдать порт 443 или 8443 — **всегда сверять с фактическим inbound** (`SELECT port FROM inbounds`).

## Проверка конфига — локальный xray-клиент

Поднять второй xray как клиент (SOCKS inbound) и прогнать curl:

```json
// /tmp/xray-test-client.json
{
  "log": {"loglevel": "warning"},
  "inbounds": [{"port": 18080, "listen": "127.0.0.1", "protocol": "socks", "settings": {"udp": true}}],
  "outbounds": [{
    "protocol": "vless",
    "settings": {"vnext": [{"address": "76.13.77.105", "port": 443, "users": [{"id": "<UUID>", "encryption": "none", "flow": "xtls-rprx-vision"}]}]},
    "streamSettings": {"network": "tcp", "security": "reality",
      "realitySettings": {"serverName": "www.icloud.com", "fingerprint": "chrome",
        "publicKey": "<PUBKEY>", "shortId": "<SID>", "spiderX": "/"}}
  }]
}
```

```bash
nohup /usr/local/x-ui/bin/xray-linux-amd64 run -c /tmp/xray-test-client.json > /tmp/xray-client.log 2>&1 &
sleep 3
curl -s -m 20 --socks5 127.0.0.1:18080 https://api.ipify.org   # ожидаем 76.13.77.105
```

Успех = ipify вернул IP сервера. Пусто/exit 35 → смотреть `/tmp/xray-client.log` и `/var/log/nginx/error.log` (там будет `connect() failed (111) ... upstream: "127.0.0.1:8443"` если забыли заменить на 76.13.77.105).

## Чистка мёртвых клиентов x-ui

Удаление `gatebox-*`/`test*` клиентов (0 трафика в client_traffics):
- Бэкап БД перед чисткой: `cp /etc/x-ui/x-ui.db /etc/x-ui/x-ui.db.bak.$(date +%Y%m%d_%H%M%S)`
- Скрипт: python3.12, читает `inbounds.settings.clients`, фильтрует по префиксу email, пишет обратно, чистит `client_traffics` (по `email`) и `inbound_client_ips` (по **`client_email`** — колонка называется так, не `email`).
- `add_client.py` из xray-add-client добавляет и в settings, и в client_traffics — при ручной правке синхронизировать обе таблицы.

## Опасное действие — только с согласия Алекса

- nginx stream, перенос сайтов на 4443, чистка клиентов — меняют работающую систему. Сначала план → «да» → действие.
- В делегированных задачах явно указывать субагенту: «только диагностика read-only, никаких изменений».
- Проверка (ss, nginx -t, curl) — можно без согласия.
