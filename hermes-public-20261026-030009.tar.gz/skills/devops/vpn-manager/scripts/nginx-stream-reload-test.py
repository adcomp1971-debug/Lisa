#!/usr/bin/env python3
"""Проверка, что `systemctl reload nginx` не рвёт живые соединения клиентов.

Держит скачивание через рабочий вход на 443 (VLESS/что угодно внутри) с ограничением
скорости, в середине делает reload nginx и проверяет, что файл доехал целиком.
Конфиг nginx НЕ меняется — проверяется только поведение reload.

Требуется локальный socks-клиент к рабочему входу (например xray с outbound на 127.0.0.1:443).

Использование:
  python3 nginx-stream-reload-test.py --socks 10812
  python3 nginx-stream-reload-test.py --socks 10812 --url https://proof.ovh.net/files/10Mb.dat \
      --expect-bytes 10485760 --rate 2M
"""
import argparse, os, subprocess, sys, time

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--socks", type=int, required=True, help="локальный socks-порт клиента")
    ap.add_argument("--url", default="https://proof.ovh.net/files/10Mb.dat")
    ap.add_argument("--expect-bytes", type=int, default=10 * 1024 * 1024)
    ap.add_argument("--rate", default="2M", help="--limit-rate, чтобы reload попал в середину")
    ap.add_argument("--delay", type=float, default=2.0, help="пауза до reload, сек")
    ap.add_argument("--out", default="/tmp/nginx-reload-test.bin")
    a = ap.parse_args()

    pre = subprocess.run(["systemctl", "is-active", "nginx"], capture_output=True, text=True).stdout.strip()
    if pre != "active":
        print(f"nginx не active ({pre}) — тест бессмысленен", file=sys.stderr)
        return 2

    if os.path.exists(a.out):
        os.remove(a.out)
    dl = subprocess.Popen([
        "curl", "-sL", "--limit-rate", a.rate, "-o", a.out, "--max-time", "180",
        "--socks5-hostname", f"127.0.0.1:{a.socks}", "-A", "Mozilla/5.0",
        "-w", "%{size_download} %{time_total}", a.url,
    ], stdout=subprocess.PIPE, text=True)
    try:
        time.sleep(a.delay)
        r = subprocess.run(["systemctl", "reload", "nginx"], capture_output=True, text=True)
        print(f"reload nginx: rc={r.returncode} {(r.stderr or '').strip()[:160]}")
        out, _ = dl.communicate(timeout=200)
        got = os.path.getsize(a.out) if os.path.exists(a.out) else 0
        size, dt = (out.split() + ["0", "0"])[:2]
        print(f"скачано {got} байт за {dt} с (ожидалось {a.expect_bytes})")
        ok = got == a.expect_bytes
        print("РЕЗУЛЬТАТ:", "reload НЕ рвёт соединение — файл целиком" if ok
              else "ОБРЫВ или неполный файл — reload порвал соединение")
        return 0 if ok else 1
    finally:
        if dl.poll() is None:
            dl.kill()
        post = subprocess.run(["systemctl", "is-active", "nginx"], capture_output=True, text=True).stdout.strip()
        print("nginx после теста:", post)
        if os.path.exists(a.out):
            os.remove(a.out)

if __name__ == "__main__":
    sys.exit(main())
