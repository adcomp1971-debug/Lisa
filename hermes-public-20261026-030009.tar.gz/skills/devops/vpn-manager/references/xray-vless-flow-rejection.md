# XRay VLESS Flow Rejection

**Xray 26.2.6+** (29 мая 2026) — поведение изменилось: клиенты без `flow` в VLESS-заголовке **reject'ятся**, а не просто триггерят warning.

## Симптомы

- Клиент подключается → сразу offline (меньше секунды)
- В дашборде x-ui: появляется зелёный → через мгновение offline
- Трафик стоит на месте (±байты, не гигабайты)

## Логи

```log
2026/05/29 18:57:43 DEBUG - XRAY: [3045518331] app/proxyman/inbound: connection ends > proxy/vless/inbound: account 4250dc23-9d32-4d01-9b03-d32fcff78379 is rejected since the client flow is empty. Note that the pure TLS proxy has certain TLS in TLS characters.
```

Лог-файл: `/var/log/x-ui/3xui.log`  
**Не** `journalctl -u x-ui` — там только логи веб-панели (login success/failure).

## Причина

Клиент подключается по VLESS **без указания `flow` в заголовке**. Сервер (даже если в БД flow прописан) отвергает соединение.

Это работает ТОЛЬКО если и сервер, и клиент согласованы по flow.

## Серверный workaround для legacy-клиентов

Если клиент не может обновиться (старый конфиг, не поддерживает flow) — снять требование flow в БД:

```bash
python3 -c "
import sqlite3, json
db = sqlite3.connect('/etc/x-ui/x-ui.db')
row = db.execute('SELECT id, settings FROM inbounds WHERE port=443').fetchone()
settings = json.loads(row[1])
for c in settings['clients']:
    if c['email'] == 'ИМЯ_КЛИЕНТА':
        c['flow'] = ''  # пустой flow = не требовать от клиента
        print(f'LEGACY MODE: {c[\"email\"]}')
db.execute('UPDATE inbounds SET settings=? WHERE id=?', (json.dumps(settings), row[0]))
db.commit()
"
systemctl restart x-ui
```

Проверить: `grep 'rejected.*flow.*empty' /var/log/x-ui/3xui.log` — должно быть пусто.

## Правильный фикс (клиент + сервер)

1. В БД сервера проставить `flow: xtls-rprx-vision` для клиента
2. Выдать клиенту новый конфиг/URL — чтобы клиент тоже слал flow. Генерация URL: `references/vless-url-generation.md`.
3. `systemctl restart x-ui`

## Связанные логи

- `/var/log/x-ui/3xui.log` — XRay connection debug
- `/var/log/x-ui/3xui.log` — не путать с `3xipl.log` (IP banning)
- `journalctl -u x-ui` — только x-ui web panel, не XRay
