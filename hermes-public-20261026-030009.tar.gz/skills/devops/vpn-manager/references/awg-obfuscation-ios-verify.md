# AmneziaWG obfuscation и проверка iOS

### AmneziaWG Obfuscation MUST Match Client-Server

**Без параметров обфускации (Jc, Jmin, Jmax, S1, S2, H1-H4) handshake НЕ пройдёт, даже если ключи правильные.** Проверено экспериментально: создали тестовый интерфейс с ключами Юли — без обфускации handshake не было. После `awg set <iface> jc 4 jmin 40 ...` — handshake появился мгновенно.

- Параметры обфускации ДОЛЖНЫ совпадать на клиенте и сервере
- Сервер всегда ставит их в `awg0.conf` и `awg show` показывает все 8 параметров
- Клиентский конфиг должен включать: `Jc = 4`, `Jmin = 40`, `Jmax = 70`, `S1 = 50`, `S2 = 100`, `H1 = 1106007595`, `H2 = 1284786334`, `H3 = 1463045443`, `H4 = 1537700372`
- vpn:// ссылка всегда включает обфускацию (бинарно кодируется в payload)
- При импорте текстового конфига через «Создать с нуля» на iOS параметры обфускации могут не подхватиться — предпочитай vpn://

**Диагностика:** если ключи правильные а handshake нет — проверить `awg show <iface>` на клиенте (если возможно) или перевыпустить конфиг с обфускацией.

### iOS AmneziaWG: vpn:// vs Text Import

**vpn:// ссылка надёжнее ручного импорта текста.** vpn:// кодирует ВСЕ параметры обфускации в бинарном формате, который приложение понимает нативно. При ручном импорте через «Создать с нуля» → вставить текст — параметры обфускации могут потеряться.

**Pitfall:** Telegram на iOS не делает vpn:// ссылки кликабельными. Решение: скопировать ссылку, открыть Safari, вставить в адресную строку, нажать Go. iOS сам предложит открыть в AmneziaWG.

**Проверка конфига перед отправкой клиенту:**
```bash
# 1. Все параметры обфускации присутствуют
grep -E '^(Jc|Jmin|Jmax|S1|S2|H1|H2|H3|H4) ' yulka.conf
# 2. Смоделировать подключение локально
ip link add test-awg type amneziawg
awg set test-awg private-key <(cat yulka.private.key)
awg set test-awg peer <server_pub> preshared-key <(cat yulka.psk.key) endpoint 76.13.77.105:51820 allowed-ips 0.0.0.0/0 persistent-keepalive 25
awg set test-awg jc 4 jmin 40 jmax 70 s1 50 s2 100 h1 1106007595 h2 1284786334 h3 1463045443 h4 1537700372
ip addr add 10.9.0.199/32 dev test-awg
ip link set up dev test-awg
sleep 10
awg show test-awg  # должен показать latest handshake
ip link delete test-awg  # очистка
```
