---
name: awg-client-reissue
description: "Перевыпуск офлайн AWG-клиента с сохранением IP, когда старый клиентский .conf утрачен или сломан."
---

# Перевыпуск офлайн AWG-клиента с сохранением IP

Использовать, когда:
- peer в `awg show` есть, но handshake долго отсутствует;
- серверный AWG исправен, другие клиенты handshakes делают;
- старый клиентский `.conf`/`.vpnlink` не найден или ему больше нельзя доверять;
- нужно выдать клиенту новый конфиг, не меняя его `AllowedIPs`.

## Перед действием
Это **опасная операция**: меняется peer на проде. Всегда через `vpn-safe`:
- показать план / риски / откат;
- запросить точное подтверждение `YES, DO IT`.

## Read-only вывод перед перевыпуском
1. Подтвердить, что проблема не в сервере:
   - `systemctl is-active awg-quick@awg0`
   - `awg show`
   - убедиться, что другие peer'ы handshakes делают.
2. Проверить, что проблемный peer не отвечает после мягкого рестарта awg0.
3. Попробовать установить имя клиента по старым бэкапам `awg0.conf.bak*` — по комментарию над `PublicKey`.
4. Проверить, сохранился ли старый клиентский `.conf` / `.vpnlink`. Если нет — перевыпуск.

## Процедура перевыпуска
Пример для клиента `yulka` с IP `10.9.0.9/32`:

1. Бэкап:
   - `cp /etc/amnezia/amneziawg/awg0.conf /etc/amnezia/amneziawg/awg0.conf.bak.$(date +%Y%m%d_%H%M%S)`
2. Сгенерировать новый комплект:
   - `yulka.private.key`
   - `yulka.public.key`
   - `yulka.psk.key`
3. Собрать новый `yulka.conf` с тем же IP и текущими параметрами Amnezia:
   - `Address = 10.9.0.9/32`
   - `Endpoint = 76.13.77.105:51820`
   - `PublicKey = <server_public.key>`
   - `PresharedKey = <new psk>`
   - `PersistentKeepalive = 25`
4. Сгенерировать `yulka.vpnlink` через `vpnlink_gen.py`.
5. В `awg0.conf` заменить **только** блок peer с `AllowedIPs = 10.9.0.9/32`, сохранив IP, но подставив новый `PublicKey` и `PresharedKey`.
6. Перезапустить `awg-quick@awg0`.
## Обязательная верификация перед отправкой клиенту

Нельзя отдавать конфиг без проверки. Минимум:

1. `systemctl is-active awg-quick@awg0` → `active`
2. `awg show` содержит новый peer на `AllowedIPs = 10.9.0.9/32`
3. Вычислить public key из нового client private key и сверить с peer на сервере
4. Сверить `PublicKey` в клиентском конфиге с `/etc/amnezia/amneziawg/server_public.key`
5. Проверить в клиентском конфиге:
   - `Address = <ожидаемый IP>/32`
   - `Endpoint = 76.13.77.105:51820`
   - `PresharedKey` присутствует

**Дополнительная верификация (рекомендуется):** локальная симуляция подключения с ключами клиента:
```bash
# Создать тестовый интерфейс
ip link add test-awg type amneziawg
awg set test-awg private-key <(cat yulka.private.key)
awg set test-awg peer <server_pub> preshared-key <(cat yulka.psk.key) endpoint 76.13.77.105:51820 allowed-ips 0.0.0.0/0 persistent-keepalive 25
awg set test-awg jc 4 jmin 40 jmax 70 s1 50 s2 100 h1 1106007595 h2 1284786334 h3 1463045443 h4 1537700372
ip addr add 10.9.0.199/32 dev test-awg
ip link set up dev test-awg
sleep 10
awg show test-awg  # должен показать latest handshake
ip link delete test-awg  # очистка
```
Это доказывает: серверный конфиг рабочий, handshake проходит, Amnezia-обфускация обязательна.

Если эти пункты не выполнены — конфиг клиенту не отправлять.

## Доставка пользователю
Лучше отправлять оба файла:
- `.conf`
- `.vpnlink`

И отдельно явно сказать:
- старый конфиг больше недействителен;
- нужно удалить/не использовать старый профиль;
- импортировать новый и включить туннель;
- если handshake не появится, проблема уже на стороне устройства/сети клиента.

## Отчёт после операции
Коротко:
- что заменено;
- какой IP сохранён;
- что проверено реально;
- появился ли handshake сразу или ожидается после переимпорта клиентом.
