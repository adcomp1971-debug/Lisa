# E2E-проверка клиентского AWG-профиля БЕЗ клиента

**Когда:** клиент говорит «не подключается» / «туннель есть, интернета нет», а профиль уже лежит в `/root/v10/*.conf`. Вместо ожидания клиента профиль проверяется на сервере за минуту.

**Идея:** поднять локальный amneziawg-интерфейс с ПРИВАТНЫМ ключом и PSK из проверяемого профиля, peer = узел, БЕЗ default route (Table=off), маршрут только к одному тестовому IP, затем curl. Если вернулся внешний IP узла — профиль рабочий, серверная сторона исправна, причина у клиента.

```bash
CONF=/root/v10/reissue-20261003/Client-awg2-51820-v2.conf
g(){ grep -i "^$1" "$CONF" | head -1 | awk '{print $3}'; }
PK=$(g PrivateKey); PSK=$(g PresharedKey); SPUB=$(g PublicKey); EP=$(g Endpoint)
ADDR=$(g Address | cut -d/ -f1); MTU=$(g MTU)
JC=$(g Jc); JMIN=$(g Jmin); JMAX=$(g Jmax); S1=$(g S1); S2=$(g S2)
H1=$(g H1); H2=$(g H2); H3=$(g H3); H4=$(g H4)
TGT=$(getent ahostsv4 api.ipify.org | awk 'NR==1{print $1}')
cleanup(){ ip route del "$TGT/32" dev awgtest 2>/dev/null; ip link del awgtest 2>/dev/null; rm -f /tmp/t.key /tmp/t.psk; }
trap cleanup EXIT
umask 077; printf '%s\n' "$PK" > /tmp/t.key; printf '%s\n' "$PSK" > /tmp/t.psk
ip link add awgtest type amneziawg || exit 1
awg set awgtest private-key /tmp/t.key
awg set awgtest jc "$JC" jmin "$JMIN" jmax "$JMAX" s1 "$S1" s2 "$S2" h1 "$H1" h2 "$H2" h3 "$H3" h4 "$H4"
awg set awgtest peer "$SPUB" preshared-key /tmp/t.psk allowed-ips 0.0.0.0/0 endpoint "$EP" persistent-keepalive 25
ip addr add "$ADDR/32" dev awgtest
ip link set mtu "$MTU" up dev awgtest
ip route add "$TGT/32" dev awgtest     # ТОЛЬКО /32, НИКОГДА 0.0.0.0/0 — иначе снесёт маршрутизацию сервера
sleep 4
awg show awgtest | grep -E 'latest handshake|transfer'
curl -s -m 12 --interface "$ADDR" https://api.ipify.org/   # ожидаем внешний IP узла
```

**Критерий успеха:** есть `latest handshake` + curl вернул внешний IP узла (HTTP 200).

## Питфоллы (все проверены на живом сервере)
- `awg set IF private-key <значение>` → `fopen: No such file or directory`. Ключ (и preshared-key) принимается ТОЛЬКО как путь к файлу.
- Без `preshared-key` handshake НЕ проходит: `0 B received, N B sent` — узел молча дропает. Все пиры awg2 выданы с PSK, профиль клиента обязан его содержать.
- `ping -I 10.11.0.3/32` → `SO_BINDTODEVICE ... No such device`: в `-I` адрес передавать БЕЗ маски.
- ICMP через узел не проходит (100% loss) — это не поломка; проверять TCP/HTTP (curl), не ping.
- Тест идёт через прод-маршрутизацию сервера: только `/32`-маршрут и `trap cleanup EXIT`, потом убедиться, что `ip link show awgtest` пусто и awg0/awg1 живы (`systemctl is-active`).

## Ограничение awg2: IPv6 внутри туннеля
- `ip -6 addr add fd00:11::1/64 dev awg2` → `RTNETLINK answers: Invalid argument`: ядро не даёт IPv6-адрес на интерфейс с MTU < 1280, а awg2 поднят с MTU 1200. Значит IPv6-адрес в `Address` серверного конфига фактически не применяется, и клиентам нельзя давать `::/0` (IPv6 уйдёт в туннель без выхода).
- Сам узел по IPv6 снаружи доступен (Endpoint по IPv6 для клиента возможен), но это отдельно от IPv6-адреса внутри туннеля.
