# AWG Client Config → Peer Matching

## Problem
When cleaning up AWG, you need to identify which `.conf` files correspond to which peers on the server. The server has peer public keys (`awg show`), while each client config has its own **private key**. The two don't directly appear together.

## Solution: Derive Public Key from Private Key

`awg pubkey` computes the Curve25519 public key from a private key. Use it to match client configs to server peers:

```bash
# For a single client:
priv=$(grep '^PrivateKey' /etc/amnezia/amneziawg/alex.conf | cut -d= -f2- | xargs)
pub=$(echo -n "$priv" | awg pubkey)
grep "$pub" /etc/amnezia/amneziawg/awg0.conf && echo "MATCH FOUND"
```

## Bulk Matching Script

```python
import subprocess, os

live_keys = [
    "+qkzzC+192yBs6Y48BOawy7Ux9mh51UpRxu6/Z1wonE=",
    # ... add all peer public keys from awg show or awg0.conf
]

conf_dir = "/etc/amnezia/amneziawg"
keep_files = ["awg0.conf"]

for f in sorted(os.listdir(conf_dir)):
    if not f.endswith(".conf") or f == "awg0.conf":
        continue
    fpath = os.path.join(conf_dir, f)
    with open(fpath) as fh:
        for line in fh:
            if line.startswith("PrivateKey"):
                priv = line.split("=", 1)[1].strip()
                if not priv:
                    continue
                try:
                    result = subprocess.run(
                        ["awg", "pubkey"],
                        input=priv.encode(),
                        capture_output=True,
                        timeout=5,
                    )
                    pub = result.stdout.decode().strip()
                    if pub in live_keys:
                        keep_files.append(f)
                except Exception:
                    pass
                break

# Now delete all confs not in keep_files
print(f"Keep: {keep_files}")
```

## AWG Cleanup Procedure

1. **Identify 5 live peers** from `awg show awg0` (any with `latest handshake`)
2. **Match client confs** by deriving pubkey from private key
3. **Remove dead peers from interface**:
   ```bash
   awg set awg0 peer "<public-key>" remove
   ```
4. **Backup and clean conf files**: keep only `awg0.conf` + matched client confs
5. **Regenerate awg0.conf from live interface**:
   ```bash
   awg showconf awg0 > /etc/amnezia/amneziawg/awg0.conf
   ```
6. **Verify**: `awg show awg0 | grep '^peer: '` should show only live peers

## Pitfalls

- **`awg pubkey` is strict about input format**: must be exactly the base64 key, no whitespace, no newlines except trailing newline. Use `echo -n "$priv" | awg pubkey` (not `echo "$priv"`).
- **grep substring matching**: `grep "10.9.0.10"` also matches `10.9.0.101`, `10.9.0.109`, etc. Always anchor matches or use exact comparison.
- **`.conf` files may be named with Unicode** (e.g. `Катерина.conf`). Shell globbing and Python handle this fine; just be aware when constructing grep/find commands.
- **Some alive peers may have no matching config** — their client conf was lost. Note this for the user.
- **Backup before mass delete**: `cp awg0.conf awg0.conf.bak-$(date +%Y%m%d)`
