# XRay + Tailscale Funnel: Port 443 Conflict

## Symptoms

- Dashboard shows XRay flashing between "running" and "stopped"
- `systemctl is-active x-ui` → `active`, but xray-core is crash-looping
- `journalctl -u x-ui -n 50` shows: `listen tcp 0.0.0.0:443: bind: address already in use`
- `ss -tlnp 'sport = :443'` shows tailscaled on `100.80.83.11:443`

## Root Cause

Tailscale Funnel binds to the Tailscale IP (`100.80.83.11:443`). XRay inbound is configured with `"listen": "0.0.0.0"` (all interfaces). Linux refuses the wildcard bind because port 443 is already taken on the Tailscale IP.

## Fix

Change XRay inbound `listen` from `0.0.0.0` to the server's **external IP** (e.g. `76.13.77.105`):

```bash
# CRITICAL: edit the SQLite database, NOT config.json
# x-ui regenerates config.json from DB on restart — direct edits get overwritten!

sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET listen='76.13.77.105' WHERE port=443;"
systemctl restart x-ui
```

## Verification

```bash
# Both should show LISTEN on different IPs:
ss -tlnp 'sport = :443'
# Expected:
#   76.13.77.105:443    → xray (clients)
#   100.80.83.11:443    → tailscaled (Funnel)

# Check for crash-loop errors:
journalctl -u x-ui -n 20 --no-pager | grep -c 'address already in use'
# Expected: 0
```

## Pitfall: x-ui config.json vs Database

**NEVER** edit `/usr/local/x-ui/bin/config.json` directly. 3x-ui manages configuration through its SQLite database (`/etc/x-ui/x-ui.db`). On service restart, x-ui regenerates `config.json` from the database — overwriting any manual edits.

Always use the database (or the x-ui REST API on port 2096) to change inbound settings:

```bash
# Read current inbounds:
sqlite3 /etc/x-ui/x-ui.db "SELECT id, port, listen, protocol, tag FROM inbounds;"

# Update listen address:
sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET listen='<IP>' WHERE port=<PORT>;"
```

## Related

- Tailscale Funnel uses the Tailscale IP, not 0.0.0.0 — they CAN coexist on the same port
- This works because Linux allows different IPs on the same port
- If `listen` is empty or NULL in the DB, x-ui defaults to `"0.0.0.0"` → will conflict
