# x-ui config.json vs SQLite и порт 443

### x-ui: config.json vs SQLite DB
**НИКОГДА не править /usr/local/x-ui/bin/config.json напрямую.** 3x-ui хранит конфигурацию в SQLite базе `/etc/x-ui/x-ui.db`. При рестарте сервиса x-ui **перезаписывает** config.json из БД — все ручные правки теряются. Всегда править через БД:
```bash
sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET listen='<IP>' WHERE port=443;"
```
См. `references/xray-tailscale-port-conflict.md`.

### XRay + Tailscale Funnel: порт 443
Если XRay падает с `bind: address already in use` на 443 — проверить `ss -tlnp 'sport = :443'`. tailscaled может держать `100.80.83.11:443` (Funnel). XRay с `0.0.0.0:443` не сможет подняться. 

**Два решения:**
1. **Привязать XRay к внешнему IP** (`76.13.77.105:443`) — через БД: `sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET listen='76.13.77.105' WHERE port=443;"`
2. **Перенести XRay на другой порт** (например 8443) — через БД: `sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET port=8443 WHERE port=443;"` + `systemctl restart x-ui`. После этого выдать клиентам новые VLESS URL с портом 8443.

Решение 2 применялось 07.07.2026 для освобождения порта 443 под MLflow через Tailscale Funnel.

См. `references/xray-tailscale-port-conflict.md`.
