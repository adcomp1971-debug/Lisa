# VLESS URL Generation from x-ui Database

Generate a proper VLESS Reality URL for any client directly from the x-ui SQLite database.
Use when a client needs a new config (flow fix, lost config, new device).

## One-liner (modify email)

```bash
python3 -c "
import sqlite3, json, urllib.parse, sys
db = sqlite3.connect('/etc/x-ui/x-ui.db')
row = db.execute('SELECT port, settings, stream_settings FROM inbounds WHERE port=443').fetchone()
settings = json.loads(row[1])
stream = json.loads(row[2])
rs = stream['realitySettings']
srv = rs['settings']

# Find target client
email = 'Valera 2'  # CHANGE THIS
client = next((c for c in settings['clients'] if c['email'] == email), None)
if not client:
    print(f'Client {email} not found')
    sys.exit(1)

uuid = client['id']
flow = client.get('flow', '')
server = '76.13.77.105'
port = row[0]

params = {
    'type': 'tcp',
    'security': 'reality',
    'pbk': srv['publicKey'],
    'fp': srv.get('fingerprint', 'chrome'),
    'sni': rs['serverNames'][0],
    'sid': rs['shortIds'][0],
    'spx': srv.get('spiderX', '/'),
}
if flow:
    params['flow'] = flow

query = '&'.join(f'{k}={urllib.parse.quote(str(v), safe=\"\")}' for k, v in params.items())
url = f'vless://{uuid}@{server}:{port}?{query}#{urllib.parse.quote(email)}'
print(url)
"
```

## Key parameters explained

| Param | Source | Example |
|-------|--------|---------|
| UUID | `clients[].id` | `cbc39236-...` |
| pbk | `realitySettings.settings.publicKey` | Reality public key |
| fp | `realitySettings.settings.fingerprint` | `chrome` |
| sni | `realitySettings.serverNames[0]` | `www.icloud.com` |
| sid | `realitySettings.shortIds[0]` | `1e` |
| spx | `realitySettings.settings.spiderX` | `/` |
| flow | `clients[].flow` | `xtls-rprx-vision` |

## Pitfalls

- `spx=/` must be URL-encoded as `%2F` in the URL query string
- Without `flow` in the URL, XRay 26.2.6+ rejects the connection (see `xray-vless-flow-rejection.md`)
- Server has 8 shortIds — use the first one (`shortIds[0]`)
- The `#NAME` fragment at the end makes the URL human-readable in most clients
