# vpnadd: ошибки в stdout, не stderr

### vpnadd: ошибки в stdout, не stderr

Shell-скрипт `vpnadd` писал сообщения об ошибках в stdout (`echo "текст"`), а бот читал только `result.stderr` — пользователь видел пустое «❌ Ошибка:». 

**Фикс в скрипте:** все `echo` при exit 1 должны идти в stderr: `echo "Сообщение" >&2`

**Фикс в боте:** при returncode != 0 читать stdout как fallback:
```python
err_msg = result.stderr[:200] or result.stdout[:200] or "Неизвестная ошибка"
```

Проверка: `vpnadd Имя 1>/dev/null` — ошибка должна показаться (идёт в stderr).
