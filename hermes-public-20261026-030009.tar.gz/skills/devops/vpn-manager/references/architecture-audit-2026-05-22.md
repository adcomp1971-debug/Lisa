# VPN Лиса architecture audit — 2026-05-22

Session type: read-only production architecture audit. No installs, deletes, restarts, config edits, or service changes.

## Key service names (gotchas)

- **AWG**: service is `awg-quick@awg0`, NOT `amneziawg`. `systemctl is-active amneziawg` returns "inactive" even when AWG is running.
- **XRay**: child process of `x-ui.service`, NOT a standalone `xray.service`.
- **3x-ui web panel**: port 49624 with obfuscated base path `/bSKXRhmWZZaWa2axfu/` (check `/etc/x-ui/x-ui.db` → settings table for current values). Port 2096 is an OLD port returning 404.

## Efficient audit probe set (parallel waves)

**Wave 1 — system + services:**
```bash
echo "=== HOST ===" && hostname && date && uptime && df -h / && free -h && swapon --show
echo "=== SERVICES ===" && for s in awg-quick@awg0 x-ui nginx tailscaled hermes-gateway; do echo -n "$s: "; systemctl is-active $s 2>/dev/null || echo "not found"; done
echo "=== PORTS ===" && ss -lntup
```

**Wave 2 — VPN + network:**
```bash
echo "=== AWG ===" && awg show
echo "=== IP ===" && ip -br addr && ip route | head -10
```

**Wave 3 — web + hermes:**
```bash
echo "=== AWG SERVICE ===" && systemctl list-units --type=service | grep -i "awg\|amnezia\|wireguard"
echo "=== X-UI PANEL ===" && sqlite3 /etc/x-ui/x-ui.db "SELECT key, value FROM settings WHERE key IN ('webPort','webBasePath');" && curl -sk -o /dev/null -w "HTTP %{http_code}" "https://localhost:$(sqlite3 /etc/x-ui/x-ui.db "SELECT value FROM settings WHERE key='webPort';")/$(sqlite3 /etc/x-ui/x-ui.db "SELECT value FROM settings WHERE key='webBasePath';")/"
echo "=== TAILSCALE ===" && tailscale funnel status && tailscale serve status
echo "=== NGINX ===" && sudo nginx -T 2>/dev/null | grep -E "server_name|listen|root|proxy_pass|location" | grep -v "#"
echo "=== HERMES ===" && hermes status --all | head -60
```

**Wave 4 — logs:**
```bash
echo "=== LOGS AWG ===" && journalctl -u awg-quick@awg0 --no-pager -n 10
echo "=== LOGS XRAY ===" && journalctl -u x-ui --no-pager -n 10 | tail -5
```

## Current state (2026-05-22, 20:36 UTC)

### System
- Host: srv1593922 (Hostinger VPS)
- Ubuntu 24.04, kernel 6.8.0-117-generic
- IP: 76.13.77.105 (eth0), Tailscale: 100.80.83.11
- Disk: 41G/193G (21%), RAM: 2.3G/15G, Swap: 0/4G
- Uptime: 4 days

### VPN
- **AmneziaWG**: `awg-quick@awg0`, interface `awg0`, UDP 51820, subnet `10.9.0.0/24`
  - 4 active peers (handshakes < 2 min), 13 inactive (old offline clients)
- **XRay / 3x-ui**: `x-ui.service` active
  - VLESS Reality on `0.0.0.0:443`
  - Web panel: port 49624, path `/bSKXRhmWZZaWa2axfu/`
  - Old port 2096 listening (404) — legacy, can be removed
- **Tailscale**: active, Funnel exposing GateBox publicly

### Web
- **nginx**: single site — GateBox (`gatebox.smd` + `gpu-qwen.tail0c8f2f.ts.net`), `default_server`
  - Root: `/var/www/gatebox/`
  - VPN Fox (vpnlisa) and hermes-dashboard sites removed from sites-enabled
- **GateBox**: live at https://gpu-qwen.tail0c8f2f.ts.net/

### Hermes
- Model: deepseek-v4-pro via DeepSeek
- Gateway: running (systemd, PID varies)
- Telegram: connected (420839805)
- Cron: 3 active jobs
- Nous Portal: auth expiring (checked 2026-05-22 20:36 — expiry at 20:52 same day)

### Risks
- **Nous Portal auth expires today** — needs refresh or services may degrade
- 13 inactive AWG peers — old clients, cleanup opportunity
- Port 2096 stale — remove from 3x-ui config
- All services run as root on production VPS (no sandbox isolation)
- XRay TLS handshake errors from scanner IPs (46.117.84.5) — normal internet noise, not a threat

### Changed since 2026-05-10
- VPN Fox landing page removed; GateBox is now the sole public web face
- Tailscale Funnel activated for public HTTPS access
- Hermes model switched from GPT-5.5 to DeepSeek V4 Pro
- GateBox assets moved from `/root/gatebox/` to `/var/www/gatebox/` (nginx permissions)
- Disk usage dropped from 72% to 21% (likely cleanup during GateBox migration)
