# Read-only architecture audit — процедура

## Read-only architecture audit

Если пользователь просит определить текущую архитектуру production VPN-сервера и явно запрещает изменения:
1. Работать только в read-only режиме; не использовать `systemctl restart/start/stop`, правку конфигов, install/remove, `awg set`, `wg-quick`, `iptables/nft/ufw` changes.
2. Сначала собрать inventory:
   - host/date/uptime/disk/memory/swap
   - `ss -lntup`
   - `systemctl is-active/status` для `x-ui`, `awg-quick@awg0`, `vpnbot`, `nginx`, `tailscaled`, `hermes-gateway`, `ollama`
   - `ip -br addr`, `ip route`
   - `awg show`
   - `nginx -T` только с редактированием/маскированием secrets в выводе
3. Разделить отчёт на зоны: production, ops, sandbox/AI.
4. Для AI/Hermes части проверить `hermes status --all`, `hermes tools list`, `hermes mcp list`, `hermes cron list`, `~/.hermes/config.yaml` summary, Claude/Codex version/auth presence без раскрытия tokens.
5. Для VPN части проверить XRay/3X-UI/AmneziaWG/Telegram bot установку и runtime, но не читать/печатать приватные ключи и tokens.
6. В конце дать ASCII diagram, LOW/MEDIUM/HIGH risk zones и production-safe recommended architecture.

См. также session-specific reference: `references/architecture-audit-2026-05-22.md` (latest audit).
