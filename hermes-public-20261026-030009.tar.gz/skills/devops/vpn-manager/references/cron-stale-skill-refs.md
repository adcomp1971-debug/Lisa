# Stale cron skill references после absorption

## Migration pitfall: stale cron skill references после absorption

Когда скилл поглощён в umbrella (как `vpn-auto-doctor` → `vpn-manager` 29.06.2026), существующие cron-джобы, загружавшие поглощённый скилл, продолжают ссылаться на него по имени. Это вызывает `WARNING cron.scheduler: Cron job '<name>': skill not found, skipping` в логах gateway каждые N минут.

**Проверка:**
```bash
hermes cron list 2>&1 | grep -B2 '<absorbed-skill-name>'
journalctl -u hermes-gateway --no-pager | grep 'skill not found'
```

**Fix:** удалить поглощённый скилл из списка `skills` у cron-джобы:
```bash
hermes cron update <job-id> --skills '<umbrella-skill>'
```
(заменить `--skills 'vpn-manager'` — без упоминания поглощённого скилла)

**Проверка после:**
```bash
journalctl -u hermes-gateway --no-pager | grep 'skill not found'
# Должно быть пусто после перезапуска gateway (делает Алекс)
```
