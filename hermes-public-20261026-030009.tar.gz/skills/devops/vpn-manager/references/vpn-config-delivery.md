# VPN Config Delivery Pattern

## Rule

When user asks to send VPN configs/links "here" (meaning Telegram chat) for forwarding to others:
- Send as **separate messages** in explicit step order
- Each message = one artifact (vpn:// link, text config, instructions)
- No explanatory text mixed in — pure forwardable content
- User will forward sequentially to recipient

## Example Structure

Message 1: `vpn://` link (copy → Safari → address bar → Go)
Message 2: Raw config text (for manual "Create from scratch" import)
Message 3: Numbered instructions (1-2-3 steps)

## iOS Specifics

- `vpn://` links NOT clickable in Telegram on iOS
- Workaround: Copy → Safari → paste in address bar → Go → iOS opens AmneziaWG
- Manual import via "Create from scratch" works but may miss obfuscation params (Jc, H1-H4)
- vpn:// via Safari is preferred — preserves all AmneziaWG obfuscation

## Files

Config files sent as Telegram document attachments for iPad transfer.

**Primary method — curl to Bot API (guaranteed to work):**
```bash
curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument" \
  -F "chat_id=420839805" \
  -F "document=@/tmp/config.conf" \
  -F "caption=Config description"
```

**Fallback — MEDIA: in response (may render as text on some clients):**
MEDIA:/tmp/config.conf

**PITFALL:** `send_message` with `MEDIA:` may send the literal string "MEDIA:/path"
as text instead of a file attachment. When user complains file is "text not file"
or "отправляешь как сообщение", switch to curl immediately. Do NOT retry MEDIA:
multiple times.

### VLESS Config Files

**Extension:** Always `.conf` — NOT `.txt`. DefaultVPN, Amnezia, V2Box, Streisand
expect `.conf` for file import. `.txt` confuses the user and clutters the chat.

**Delivery:** Bot API `sendDocument` WITHOUT caption. Caption text (even labeled
"config for Valera 2") is jarring when the file content is a VLESS URL — the
user sees it as junk appended to the config. Send clean — file only, no caption.

```bash
# Correct — no caption, .conf extension:
curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument" \
  -F "chat_id=420839805" \
  -F "document=@/tmp/name-vless.conf"
# Wrong — .txt, with caption:
curl ... -F "document=@/tmp/name.txt" -F "caption=описание"
```

**DefaultVPN** (iOS App Store, by AMNEZIA UNIPESSOAL LDA) is an Amnezia fork.
Supports VLESS Reality import from file: + → Import from file → select .conf.
Recognizes `vless://` URLs natively.

---

## Telegram Bot API File Delivery (merged sub-reference)

When `send_message` with `MEDIA:/path/to/file` sends the literal string "MEDIA:/tmp/file.conf" instead of a downloadable file attachment, switch immediately to the Telegram Bot API directly via `curl`.

### Exact Command

```bash
source /root/.hermes/.env 2>/dev/null
curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument" \
  -F "chat_id=<CHAT_ID>" \
  -F "document=@/absolute/path/to/file" \
  -F "caption=<optional caption>"
```

### Response Check

```json
{"ok":true,"result":{"document":{"file_name":"yulka.conf","file_size":425,...}}}
```

- `ok: true` — file delivered as native Telegram document (downloadable)
- `ok: false` — check `description` field for error

### Pattern: VPN Config Delivery

1. Write config to `/tmp/<name>.conf`
2. Send via `curl` → appears as downloadable `.conf` file (not text message)
3. Send instructions as separate `send_message` call

### Pitfalls

- **NEVER retry MEDIA: multiple times** — if first attempt sends literal text, second attempt will too. Switch to curl immediately.
- **Chat ID**: For Alex's chat, `chat_id=420839805`
- **Token source**: `.env` in profile directory (e.g., `/root/.hermes/profiles/nvidia/.env` for NemotronBot)
- **iPad behavior**: MEDIA: often fails on iPad Telegram client; curl approach works reliably