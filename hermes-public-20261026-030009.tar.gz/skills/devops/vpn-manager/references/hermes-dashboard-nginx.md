# Hermes Dashboard и nginx sites-enabled

**Hermes Dashboard:** systemd-сервис `hermes-dashboard` (Restart=always). Слушает 127.0.0.1:9118, nginx проксирует :9119→:9118. При 502 — `systemctl restart hermes-dashboard`. НЕ использовать `hermes dashboard &` (старый способ, ненадёжен). При удалении конфигов из sites-enabled не сносить `hermes-dashboard`.

**Nginx sites-enabled:** перед удалением любого конфига проверять `cat /etc/nginx/sites-enabled/<name>` — что он проксирует. `vpnlisa` — старый лендинг (можно удалить). `hermes-dashboard` — дашборд (не удалять).

## Hermes Dashboard

Дэшборд работает как **systemd-сервис** `hermes-dashboard.service` (порт 9118, nginx прокси 9119→9118).
При падении auto-restart через 5 секунд.

```bash
systemctl status hermes-dashboard
systemctl restart hermes-dashboard  # если 502
```

**НЕ использовать** `hermes dashboard &` — фоновый процесс ненадёжен, systemd надёжнее.
