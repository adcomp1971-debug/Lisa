# Production Security Hardening — 2026-06-02

Checklist для быстрой защиты VPS после развёртывания или аудита.

## UFW — Firewall

```bash
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp      # SSH
ufw allow 80/tcp      # nginx/HTTP
ufw allow 443/tcp     # XRay/HTTPS
ufw allow 51820/udp   # AWG
echo "y" | ufw enable
ufw status verbose
```

**Проверка:** административные панели (x-ui :49624, Uptime Kuma :3001, Hermes Dashboard :9119) должны быть BLOCKED.

## SSH Hardening

```bash
cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak.$(date +%Y%m%d_%H%M%S)
sed -i 's/^PermitRootLogin yes/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sed -i 's/^#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
systemctl reload ssh   # NOTE: Ubuntu uses 'ssh', not 'sshd'
```

## fail2ban

```bash
apt install fail2ban -y
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5
[sshd]
enabled = true
port = 22
logpath = /var/log/auth.log
EOF
systemctl enable fail2ban && systemctl start fail2ban
fail2ban-client status sshd
```

## Pitfalls

- **Ubuntu `sshd.service` не существует** — правильное имя `ssh.service`. `systemctl reload ssh` (не sshd).
- **UFW может иметь старые правила** — проверить `ufw status verbose` и удалить лишние `ufw delete allow <port>`.
- **После включения UFW** — проверить что SSH всё ещё доступен (не потерять доступ).
- **fail2ban `journalmatch`** — может не находить логи если sshd пишет в journal, а не в auth.log.
