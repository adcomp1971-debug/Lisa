# AmneziaWG Peer Fix: Remove + Re-Add Pattern

**Дата:** 25 Jun 2026

## Симптомы

- AWG peer в dump показывает handshake, трафик есть, но клиент говорит «не работает»
- AdvancedSecurity в конфиге `on`, но в dump показывает `off` (это поле не индикативно — ВСЕ пиры показывают `off`, даже работающие)
- `awg set awg0 peer <key> advanced-security on` — команда принимается (exit 0), но не меняет состояние

## Рабочий fix

```bash
# 1. Удалить пир
awg set awg0 peer <PUBLIC_KEY> remove

# 2. Создать temp-файл с peer-блоком
cat > /tmp/fix_peer.conf << 'WGEOF'
[Peer]
PublicKey = <PUBLIC_KEY>
PresharedKey = <PSK_KEY>
AdvancedSecurity = on
AllowedIPs = <IP>/32
WGEOF

# 3. Добавить обратно
awg addconf awg0 /tmp/fix_peer.conf

# 4. Проверить — ждать handshake от клиента
awg show awg0 | grep <IP>
```

## Pitfalls

- **`awg syncconf awg0 <full-config>` не работает** если в конфиге есть `Address = 10.9.0.1/24` — AWG не парсит CIDR в Address поле
- **`awg setconf awg0 <full-config>` — то же самое**, падает на Address
- **`awg set awg0 peer <key> advanced-security 1`** — принимается без ошибки, но флаг не меняется
- **Dump field `off/on`** — последнее поле в `awg show dump` НЕ означает AdvancedSecurity. Все пиры показывают `off` даже когда обфускация работает
- **Peer после remove теряет endpoint** — покажет `(none)`, нужен новый handshake от клиента
