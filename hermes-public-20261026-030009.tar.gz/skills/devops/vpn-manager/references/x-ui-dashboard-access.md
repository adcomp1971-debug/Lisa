# x-ui Dashboard Access

## URL

Панель 3x-ui доступна только по HTTPS на порту 49624 с кастомным base path:

```
https://76.13.77.105:49624/bSKXRhmWZZaWa2axfu/
```

Без base path (`/` или `/xui/`) — 404.

## SSL Certificate

Сертификаты из `/root/cert/ip/`:
- `fullchain.pem`
- `privkey.pem`

Выписаны Let's Encrypt **для IP-адреса** (не домена) через профиль `shortlived`.

**Важно:** Let's Encrypt НЕ поддерживает IP-сертификаты в дефолтном ACME-профиле. Только через `--cert-profile shortlived` (валидность ~7 дней).

## Renewal: acme.sh + shortlived profile

Let's Encrypt IP-сертификаты доступны только через профиль `shortlived` (валидность ~7 дней, авто-обновление каждые 7 дней).

### Первичный выпуск

```bash
# 1. acme.sh (установить если нет)
curl -sL https://get.acme.sh | sh -s email=adcomp1971@gmail.com

# 2. Остановить nginx (порт 80 занят)
systemctl stop nginx

# 3. Выпустить сертификат для IP
~/.acme.sh/acme.sh --issue --standalone -d 76.13.77.105 \
  --cert-profile "shortlived" --force

# 4. Скопировать в /root/cert/ip/
cp ~/.acme.sh/76.13.77.105_ecc/fullchain.cer /root/cert/ip/fullchain.pem
cp ~/.acme.sh/76.13.77.105_ecc/76.13.77.105.key /root/cert/ip/privkey.pem
chmod 644 /root/cert/ip/*.pem

# 5. Запустить nginx
systemctl start nginx

# 6. Перезагрузить x-ui
systemctl restart x-ui
```

### Установка deploy hook (для авто-обновления)

```bash
~/.acme.sh/acme.sh --install-cert -d 76.13.77.105 \
  --cert-file /root/cert/ip/fullchain.pem \
  --key-file /root/cert/ip/privkey.pem \
  --reloadcmd "systemctl restart x-ui" --force
```

После этого acme.sh cron (каждый день в 7:59 UTC) будет:
1. Проверять скорое истечение сертификата
2. Выпускать новый (через ARI suggested window)
3. Копировать в `/root/cert/ip/`
4. Рестартовать x-ui

### Принудительное обновление

```bash
~/.acme.sh/acme.sh --renew -d 76.13.77.105 --force
```

## x-ui Config in SQLite

Настройки панели хранятся в `/etc/x-ui/x-ui.db`, таблица `settings`:

```
webPort|49624
webBasePath|/bSKXRhmWZZaWa2axfu/
webCertFile|/root/cert/ip/fullchain.pem
webKeyFile|/root/cert/ip/privkey.pem
subCertFile|/root/cert/ip/fullchain.pem
subKeyFile|/root/cert/ip/privkey.pem
```

## Diagnostic Commands

```bash
# Проверить что панель слушает
ss -lntup | grep 49624

# Проверить что отвечает (с --insecure)
curl -sk -o /dev/null -w '%{http_code}' 'https://localhost:49624/bSKXRhmWZZaWa2axfu/'
# Expected: 200

# Получить base path из БД
sqlite3 /etc/x-ui/x-ui.db "SELECT value FROM settings WHERE key='webBasePath';"

# Проверить даты сертификата
openssl x509 -in /root/cert/ip/fullchain.pem -noout -dates

# Проверить сертификат через TLS соединение
echo | openssl s_client -connect 76.13.77.105:49624 2>/dev/null | openssl x509 -noout -dates
```

## Firewall

Порт 49624 открыт на 0.0.0.0 — панель доступна извне. Рекомендуется закрыть UFW и пускать только через Tailscale или SSH-туннель.

## Pitfalls

- **404 ≠ панель упала.** Скорее всего забыли base path. Всегда проверять через `sqlite3 ... settings`.
- **SSL может протухнуть.** Let's Encrypt для IP — короткий срок (7 дней через `shortlived` profile). Проверять: `openssl x509 -in /root/cert/ip/fullchain.pem -noout -dates`.
- **Браузер блокирует expired сертификат** — ошибка TLS, а не "сервер не отвечает". Проверять сначала локально через `curl -sk`, потом через `openssl s_client`.
- **Default profile не разрешает IP.** `--cert-profile shortlived` обязателен. Без него Let's Encrypt отвечает `rejectedIdentifier: Default profile does not permit IP address identifiers`.
- **Sub-сервер на 2096** — legacy, не используется. Можно удалить inbound в x-ui веб-панели.
- **acme.sh — standalone mode** требует свободный порт 80. Если nginx занял — временно остановить: `systemctl stop nginx && acme.sh --issue ... && systemctl start nginx`.
