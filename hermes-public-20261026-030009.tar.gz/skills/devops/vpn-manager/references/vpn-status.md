---
name: vpn-status
description: "Короткий единый статус VPN: AWG, 3x-ui/XRay, Tailscale, health-check."
version: 1.0.0
author: Hermes Agent
license: MIT
---

# vpn-status

Назначение: одним запросом вывести короткий и читаемый сводный статус VPN.

## Что показывает

1) AmneziaWG
- `awg show`
- количество клиентов (peer'ов)

2) 3x-ui / XRay
- статус `x-ui.service`
- количество inbound'ов
- количество клиентов

3) Tailscale
- `tailscale status`

4) Health-check
- краткий итог: `OK` или `WARN` + список проблем

## Формат вывода (коротко)

VPN STATUS
AWG: UP | clients: <N>
X-UI/XRAY: UP | inbounds: <N> | clients: <N>
TAILSCALE: UP | <summary>
HEALTH: OK

Если есть проблемы:
HEALTH: WARN
- <problem 1>
- <problem 2>

## Рекомендуемые read-only команды

- `awg show`
- `systemctl is-active awg-quick@awg0` — **ВАЖНО**: сервис называется `awg-quick@awg0`, не `amneziawg`. `systemctl is-active amneziawg` вернёт `inactive` даже при работающем AWG.
- `systemctl status x-ui --no-pager`
- `tailscale status`
- `sqlite3 /etc/x-ui/x-ui.db "SELECT value FROM settings WHERE key='webPort';"` — найти порт панели 3x-ui
- `sqlite3 /etc/x-ui/x-ui.db "SELECT value FROM settings WHERE key='webBasePath';"` — найти скрытый путь панели

Примечание: подсчёт inbound'ов/клиентов делать только чтением (без изменения конфигов).

## Поиск панели 3x-ui

Порт и путь панели 3x-ui хранятся в SQLite базе `/etc/x-ui/x-ui.db` в таблице `settings`. Порт может быть нестандартным (на этом сервере — 49624), а путь обфусцирован (`/bSKXRhmWZZaWa2axfu/`). Порт 2096 в `ss -lntp` — старый порт x-ui (возвращает 404), актуальный порт всегда в БД.

## Безопасность

- Этот скилл только для статуса/диагностики (read-only).
- Любые изменения, рестарты, правки конфигов и операции с клиентами — только через `vpn-safe`.
