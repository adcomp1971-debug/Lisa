# Второй вход VLESS/XHTTP+Reality на 443 за nginx stream

Класс задач: добавить запасной TCP-вход (XHTTP+Reality или второе Reality-ядро), не открывая новых портов и не задев живой парк (панель на 8443, AWG, сайты на 443).

## Схема, которая работает

- 443/tcp слушает **nginx stream** (`ssl_preread` по SNI), а не Xray напрямую.
- Каждый вход = свой SNI + свой backend:
  - существующий вход → `127.0.0.1:8443` (панель x-ui, живые клиенты);
  - новый вход → отдельный инстанс `xray -c <свой config.json>` на `127.0.0.1:8444`;
  - любой другой SNI → сайт на `127.0.0.1:4443`.
- Новый вход **не трогает панель и её БД**: свой unit, свой конфиг, свои клиенты в своём конфиге. Откат — `systemctl disable --now <unit>` + удалить строку из stream.
- Наружу новых портов нет, ufw не меняется — весь вход идёт через уже открытый 443.

Почему отдельный инстанс, а не inbound в панели: старая 3x-ui (2.8.x) не умеет XHTTP, а обновление панели ради протокола рвёт всех её клиентов и требует миграции БД. Отдельный процесс изолирует риск.

## Порядок (сначала доказать безопасность, потом включать)

### 1. Инвентаризация «до»

```bash
systemctl is-active x-ui nginx
awg show awg0 | grep -c 'latest handshake'   # число живых пиров — контрольная цифра
ss -lntup | grep -E ':(443|8443|8444)\b'
free -m | head -2
```

Число живых пиров AWG и `systemctl is-active x-ui` фиксируются ДО и сверяются ПОСЛЕ каждого теста. Это единственный честный ответ на «не оставил ли клиентов без VPN».

### 2. Сухой прогон конфига nginx (прод не трогать)

```bash
cp -a /etc/nginx/nginx.conf /etc/nginx/nginx-dryrun-test.conf
sed -i 's|        www.icloud.com        127.0.0.1:8443;|        <new-sni>             127.0.0.1:8444;\n        www.icloud.com        127.0.0.1:8443;|' /etc/nginx/nginx-dryrun-test.conf
nginx -t -c /etc/nginx/nginx-dryrun-test.conf
rm -f /etc/nginx/nginx-dryrun-test.conf
```

🔴 **Копию для теста класть в `/etc/nginx/`, а не в `/tmp`.** В конфиге относительные `include sites-enabled/*`, `include snippets/*` — из `/tmp` они не находятся, `nginx -t` падает на «open() ... failed», и это выглядит как ошибка правки, хотя правка верна.

Заодно проверить, что новый SNI не занят нашими сайтами: `grep -rl '<new-sni>' /etc/nginx/sites-enabled/ /etc/nginx/conf.d/`.

### 3. Проверить, что SNI маскировки валиден

```bash
timeout 8 openssl s_client -connect <dest-host>:443 -servername <dest-host> </dev/null 2>/dev/null \
  | grep -E 'subject=|issuer=|Protocol'
```

Живой сертификат реального сайта = active probing получает правдоподобный ответ. Мёртвый/самоподписанный dest — палево.

### 4. Сухой прогон сервера на loopback (без nginx, без systemd)

Поднять прод-конфиг вручную на `127.0.0.1:8444`, клиента — на локальный socks, прогнать E2E:

```bash
/usr/local/x-ui/bin/xray-linux-amd64 run -test -c config.json     # сначала валидация
```

- `xray -test` может упасть на отсутствующем каталоге логов → `mkdir -p /var/log/<name>`; падение из-за логов не значит, что конфиг плохой.
- E2E: `curl --socks5-hostname 127.0.0.1:<socks> https://api.ipify.org` → должен вернуть публичный IP нашего сервера.
- Клиентский outbound для XHTTP: `flow: ""` (пустой!), `type=xhttp`, `mode=auto`, `path` из серверного конфига. Для TCP+Vision наоборот `flow: xtls-rprx-vision`; перепутанный flow = соединение устанавливается и сразу рвётся.

### 5. Замер скорости — только проверенными источниками

```bash
curl -sL -o /dev/null --max-time 20 -A 'Mozilla/5.0' \
  -w '%{http_code} %{size_download} %{speed_download}\n' <url>
```

Рабочие на этом хосте: `https://proof.ovh.net/files/10Mb.dat`, `https://speed.cloudflare.com/__down?bytes=<N>` (только с UA, без него 403). Не отвечают: `ash-speed.hetzner.com`, `speedtest.tele2.net`, `ipv4.download.thinkbroadband.com`.

🔴 **Перед замерами через туннель проверить источник прямым curl, и брать существующее имя файла.** `proof.ovh.net/files/5Mb.dat` не существует → 0 байт за 0.15 с, и это легко принять за «туннель не тянет», хотя туннель в порядке.

Сравнение писать по трём числам: новый вход, старый вход (тот же сервер, другой порт) и оба одновременно в двух потоках. Одновременный прогон показывает, мешают ли входы друг другу.

### 6. Доказать, что reload nginx не рвёт живых клиентов

Скрипт: `scripts/nginx-stream-reload-test.py` (держим скачивание через рабочий вход на 443 с `--limit-rate`, в середине `systemctl reload nginx`, проверяем, что файл доехал целиком).

```bash
python3 scripts/nginx-stream-reload-test.py --socks 10812 --expect-bytes 10485760
```

`reload` (graceful) не рвёт established-соединения — новые worker'ы поднимаются, старые доигрывают. `restart` рвёт. Поэтому в план писать именно `reload`, а не `restart`.

### 7. Что докладывать

- Конфиг-тест: OK (и что прод-конфиг не менялся).
- E2E: IP через новый вход = наш.
- Скорость: новый vs старый vs одновременно.
- reload под нагрузкой: файл целиком.
- AWG/панель: те же цифры, что до теста.
- Предел поражения: если новый инстанс упадёт, затронуты только клиенты его SNI; остальные входы на других backend'ах.

## Как включено на этом сервере (17.10.2026)

- Unit `xray-xhttp.service` (standalone, не через панель): конфиг `/etc/xray-xhttp/config.json` (600), бинарь `/usr/local/x-ui/bin/xray-linux-amd64`, логи `/var/log/xray-xhttp`.
- nginx stream: `www.samsung.com → 127.0.0.1:8444`, `www.icloud.com → 127.0.0.1:8443`, `default → 127.0.0.1:4443`. Бэкап `/root/backups/nginx.conf.bak-20261017-063727`.
- Порядок применения: `xray -test` → `systemctl enable --now xray-xhttp` → правка nginx → `nginx -t` (провал → откат из бэкапа, reload не делать) → `systemctl reload nginx`.
- **Клиентская ссылка: адрес = IP сервера, SNI только в параметре `sni`.** `vless://<uuid>@76.13.77.105:443?type=xhttp&security=reality&sni=www.samsung.com&fp=chrome&pbk=...&sid=...&path=...&host=...&mode=auto`. Если адресом подставить сам SNI-домен, клиент пойдёт на чужой сервер.
- Журнал даёт `Warning: VLESS (with no Flow) is deprecated` — для XHTTP это норма (flow нужен только TCP+Vision), менять нечего.
- Проверка после включения: три клиента одновременно — XHTTP через 443, Vision через 443, Vision на 8443 напрямую — все отдают наш публичный IP; сайт на 443 = 200; `awg show awg0 | grep -c 'latest handshake'` совпадает с цифрой до включения.

## Питфоллы

- **Не менять `listen` в БД панели ради нового SNI** — это ломает IPv6-клиентов; роутинг решается в nginx stream.
- **`nginx -t` на копии из `/tmp`** даёт ложное падение (include) — см. шаг 2.
- **Замер через `speed.cloudflare` без `-A`** → 403, нулевая скорость, ложный вывод о просадке.
- **Смешивать AWG и Xray в одном отчёте** нельзя: разные контуры, разные клиенты. AWG-цифры — только как контроль «не сломали».
- **Ресурсы:** второй инстанс Xray ≈ 35–40 МБ RSS. Проверять `free -m`, не выключать существующие сервисы «чтобы освободить память».
- **Подтверждение на включение** — отдельная строка `YES, DO IT`. «Включай», «давай», «ок» не считаются: это изменение прод-входа.
