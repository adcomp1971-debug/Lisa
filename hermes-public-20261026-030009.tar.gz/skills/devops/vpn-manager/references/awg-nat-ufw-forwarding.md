# AWG: handshake есть, трафик нет (NAT и UFW forwarding)

### AWG handshake есть, NAT нет (трафик не идёт)

VPN подключается (handshake свежий), но интернет не работает — сайты не грузятся, ping никуда не проходит.

**Причина:** Нет MASQUERADE для AWG подсети в iptables. AWG-клиент (10.9.0.x) отправляет пакеты на сервер, сервер форвардит их в интернет (eth0), но ответные пакеты не возвращаются — нет NAT, который подменяет source IP на IP сервера.

**Отличие от UFW blocking forwarding:** UFW может быть inactive (`ufw status: inactive`) — проблема не в нём. Это чисто iptables NAT.

**Диагностика:**
```bash
iptables -t nat -L POSTROUTING -n -v | grep 10.9.0.0
# Пусто = правило отсутствует — трафик не пойдёт
```

**Фикс:**
```bash
iptables -t nat -A POSTROUTING -s 10.9.0.0/24 -o eth0 -j MASQUERADE
```

**Постоянное хранение (переживает ребут):**
```bash
# Через ufw before.rules
cat >> /etc/ufw/before.rules << 'EOF'
*nat
:POSTROUTING ACCEPT [0:0]
-A POSTROUTING -s 10.9.0.0/24 -o eth0 -j MASQUERADE
COMMIT
EOF

# ИЛИ через PostUp в awg0.conf (в секции [Interface]):
PostUp = iptables -t nat -A POSTROUTING -s 10.9.0.0/24 -o eth0 -j MASQUERADE

# ИЛИ через iptables-persistent:
iptables-save > /etc/iptables/rules.v4
```

**Проверка после фикса:**
```bash
iptables -t nat -L POSTROUTING -n -v | grep 10.9.0.0
# Должен показывать счетчик MASQUERADE, растущий при трафике
```
Клиенту нужно переткнуть VPN (off/on) на устройстве.

**Pitfall:** Если в `awg0.conf` нет `PostUp` — после перезагрузки сервера NAT правило исчезнет. Добавлять PostUp в `[Interface]` после `ListenPort` или настроить iptables-persistent.

### UFW блокирует forwarding после ребута (AWG подключён, но трафик не идёт)

AWG handshake проходит (`awg show` показывает `latest handshake`), но клиент не может открывать сайты — DNS и HTTP/HTTPS падают.

**Причина:** UFW default `deny (routed)` блокирует forwarding из `awg0` в `eth0` после перезагрузки. Пакеты входят в туннель (handshake есть), но не транзитятся дальше. Также нет NAT masquerade для AWG-подсети.

**Фикс (два правила):**
```bash
# Разрешить forwarding из AWG-туннеля в интернет (и обратно)
ufw route allow in on awg0 out on eth0

# NAT для AWG-клиентов, чтобы ответные пакеты возвращались через туннель
iptables -t nat -A POSTROUTING -s 10.9.0.0/24 -o eth0 -j MASQUERADE
```

**Проверка:**
- `ufw status verbose | grep ALLOW\ FWD` — должно показать `Anywhere on eth0 ALLOW FWD Anywhere on awg0`
- `iptables -t nat -L POSTROUTING -v | grep 10.9.0.0` — должен быть MASQUERADE, счётчик растёт при трафике
- После фикса — клиенту нужно переткнуть VPN (off/on) на устройстве, чтобы форснуть новый handshake

**Pitfall:** После ребута VPS UFW применяет default rules, и `deny (routed)` вступает в силу. `ufw route allow` — это rule-level exception, он добавляется в user.rules и переживает ребут. NAT masquerade (`iptables -t nat -A ...`) — НЕ переживает ребут. Нужно либо добавить в `ufw before.rules`, либо в `/etc/rc.local`, либо сделать systemd oneshot.

**Постоянный фикс NAT (через ufw before.rules):**
Добавить в `/etc/ufw/before.rules` перед `*filter`:
```
*nat
:POSTROUTING ACCEPT [0:0]
-A POSTROUTING -s 10.9.0.0/24 -o eth0 -j MASQUERADE
COMMIT
```
После этого `ufw reload` — правило переживёт ребуты.
