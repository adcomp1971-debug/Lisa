# X-Ray FaceTime/UDP Fix

## Problem

FaceTime аудио/видео звонки не работают через X-Ray VPN, хотя веб (Instagram, сайты) открывается нормально.

## Диагностика

```bash
# Проверить что XRay вообще работает
systemctl is-active x-ui && pgrep -a xray

# Проверить порт 443
ss -tlnp 'sport = :443'

# Проверить логи ошибок
tail -30 /var/log/x-ui/3xui.log 2>/dev/null
journalctl -u x-ui -n 30 --no-pager 2>/dev/null | grep -i "xray\|error\|fail\|warn"
```

## ⚠️ КРИТИЧЕСКИЙ ПИТФОЛЛ: network: "tcp,udp" НЕ РАБОТАЕТ

**НИКОГДА не устанавливай `"network": "tcp,udp"`** — XRay завершится с exit 23:
```
ERROR - XRAY: Config: unknown transport protocol: tcp,udp
```

XRay streamSettings.network принимает **только одно значение**: `"tcp"`, `"udp"`, `"kcp"`, `"ws"` и т.д. Comma-separated невалиден.

## Причина

FaceTime использует UDP для аудио/видео (порты 16393-16472). Но:

- **VLESS Reality с `xtls-rprx-vision` flow** — Vision уже обрабатывает UDP на уровне XTLS поверх TCP. Менять `network: "tcp"` не нужно. Vision проксирует UDP прозрачно.
- Для отдельного UDP-входа (если нужен): создать второй inbound с `"network": "udp"` и отдельным тегом.
- `"network": "tcp,udp"` НЕВОЗМОЖЕН в XRay — это ограничение движка.

**Если FaceTime не работает через VLESS + Vision, причина НЕ в network.** Искать в:
1. Логи XRay на reject
2. Клиент не поддерживает xtls-rprx-vision (старая версия)
3. Проблемы на самом iPhone/FaceTime

## Фикс (если XRay не запускается после неправильной правки)

```bash
# 1. Вернуть network как было через БД
sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET stream_settings = replace(stream_settings, '\"tcp,udp\"', '\"tcp\"') WHERE id=1;"

# 2. Перезапустить
systemctl restart x-ui

# 3. Проверить
systemctl is-active x-ui  # active
pgrep -a xray              # должен быть процесс
grep network /usr/local/x-ui/bin/config.json  # должно быть "tcp"
```

## Что НЕ делать

- **Не править `/usr/local/x-ui/bin/config.json` напрямую** — x-ui перезаписывает его из SQLite БД при рестарте. Только через `sqlite3 /etc/x-ui/x-ui.db`.
- **Не ставить `network: "tcp,udp"`** — невалидно, крашит XRay
- **Не перевыпускать конфиги** — изменения серверные, клиентам ничего не надо

## Если FaceTime не работает через AWG (клиентская проблема)

AWG full tunnel пропускает весь UDP. Если не работает — проблема на устройстве:

1. Split Tunneling / Excluded Apps — FaceTime исключён?
2. FaceTime → выкл/вкл в настройках
3. Перезагрузка телефона
4. FaceTime сервера Apple могут быть временно недоступны
