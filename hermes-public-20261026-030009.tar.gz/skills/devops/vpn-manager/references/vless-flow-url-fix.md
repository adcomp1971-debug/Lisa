# VLESS Flow Rejection и сборка URL

### VLESS Flow Rejection (Xray ≥26.x)

**Xray 26.2.6+ жёстко реджектит клиентов, которые не шлют `flow` в VLESS-заголовке.** Даже если в БД сервера flow прописан — клиент обязан его отправлять. Без flow: connection rejected instantly.

**Диагностика:** логи XRay в `/var/log/x-ui/3xui.log` (не путать с `journalctl -u x-ui` — там только логи веб-панели):
```bash
grep 'rejected.*flow.*empty' /var/log/x-ui/3xui.log | tail -5
# Выдаст: account <UUID> is rejected since the client flow is empty
```

**Два пути фикса:**

**A) Клиент может обновиться — добавить flow в клиентский конфиг:**
```bash
python3 -c "
import sqlite3, json
db = sqlite3.connect('/etc/x-ui/x-ui.db')
row = db.execute('SELECT id, settings FROM inbounds WHERE port=443').fetchone()
settings = json.loads(row[1])
for c in settings['clients']:
    if c.get('flow', '') == '':
        c['flow'] = 'xtls-rprx-vision'
        print(f'FIXED: {c[\"email\"]}')
db.execute('UPDATE inbounds SET settings=? WHERE id=?', (json.dumps(settings), row[0]))
db.commit()
"
systemctl restart x-ui  # регенерит config.json из БД
```
**Важно:** этого недостаточно! Клиент тоже должен отправлять `flow: xtls-rprx-vision`. Выдать клиенту новый конфиг/URL с flow.

**B) Клиент не может обновиться (legacy) — разрешить подключение без flow для конкретного клиента:**
```bash
python3 -c "
import sqlite3, json
db = sqlite3.connect('/etc/x-ui/x-ui.db')
row = db.execute('SELECT id, settings FROM inbounds WHERE port=443').fetchone()
settings = json.loads(row[1])
for c in settings['clients']:
    if c['email'] == 'ИМЯ_КЛИЕНТА':
        c['flow'] = ''
        print(f'LEGACY MODE: {c[\"email\"]}')
db.execute('UPDATE inbounds SET settings=? WHERE id=?', (json.dumps(settings), row[0]))
db.commit()
"
systemctl restart x-ui
```
Пустой flow на сервере → XRay не требует flow от клиента. Соединение пойдёт как plain VLESS (без XTLS Vision).

Проверить после любого фикса: `grep 'rejected.*flow.*empty' /var/log/x-ui/3xui.log` — должно быть пусто.

**Выдача нового VLESS URL клиенту (flow fix):**

Когда клиент реджектится по flow и нужен новый конфиг — не надо править БД (flow уже прописан).
Надо сгенерировать правильный `vless://` URL из существующих параметров и отдать клиенту.

1. Извлечь параметры Reality из БД:
```bash
python3 -c "
import sqlite3, json
db = sqlite3.connect('/etc/x-ui/x-ui.db')
row = db.execute('SELECT settings, stream_settings FROM inbounds WHERE port=443').fetchone()
clients = json.loads(row[0])
stream = json.loads(row[1])
rs = stream['realitySettings']
print('PUBKEY:', rs['settings']['publicKey'])
print('SNI:', rs['serverNames'][0])
print('SID:', rs['shortIds'][0])
print('FP:', rs['settings']['fingerprint'])
print('SPX:', rs['settings']['spiderX'])
# Поиск клиента
for c in clients['clients']:
    if c['email'] == 'ИМЯ':
        print('UUID:', c['id'])
        print('FLOW:', c.get('flow',''))
"
```

2. Собрать URL:
```
vless://UUID@76.13.77.105:443?type=tcp&security=reality&pbk=PUBKEY&fp=FP&sni=SNI&sid=SID&spx=SPX&flow=FLOW#ИМЯ
```
spx со значением `/` URL-кодируется как `%2F`.

3. Сохранить в `.conf` и отправить через Bot API без caption (см. `references/vpn-config-delivery.md`).
