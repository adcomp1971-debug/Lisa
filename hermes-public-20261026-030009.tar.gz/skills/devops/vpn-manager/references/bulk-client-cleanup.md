# Bulk Cleanup of Test/Temporary VPN Clients

Procedure for removing accumulated test clients from AmneziaWG and XRay/3x-ui after heavy testing sessions (e.g. GateBox QA). Always follows `vpn-safe` protocol.

## Pre-flight

1. Backup everything first:
```bash
sudo cp /etc/amnezia/amneziawg/awg0.conf /etc/amnezia/amneziawg/awg0.conf.bak.$(date +%Y%m%d_%H%M%S)
sudo cp /etc/x-ui/x-ui.db /etc/x-ui/x-ui.db.bak.$(date +%Y%m%d_%H%M%S)
```

2. Identify test clients by naming convention (e.g. `gatebox-*`).

## AmneziaWG Cleanup

### Step 1: Map IPs to peers

```bash
awg show awg0 | awk '
/^peer:/ { key=$2; ip=""; hs="" }
/^\s+allowed ips:/ { gsub(/\/32/,"",$3); ip=$3 }
/^\s+latest handshake:/ { hs=1 }
END {
  # Logic to filter gatebox IPs
}' | sort -t. -k4 -n
```

### Step 2: Identify LIVE vs DEAD peers

- **LIVE**: has `latest handshake: N seconds/minutes ago` — currently connected, DO NOT remove
- **DEAD**: no handshake line — safe to remove
- **CONFLICT**: IP overlaps with battle config (e.g. gatebox and lisa2 share same IP) — DO NOT remove peer, but CAN delete the test .conf file

### Step 3: Check for IP conflicts with battle configs

```bash
for ip in <gatebox-ips>; do
  for f in /etc/amnezia/amneziawg/*.conf; do
    [[ "$f" != *gatebox-* ]] && [[ "$f" != *awg0* ]] && grep -q "Address = $ip" "$f" && echo "CONFLICT: $ip in $f"
  done
done
```

### Step 4: Remove dead peers

**For small cleanups (≤10 peers):** use `awg set awg0 peer <key> remove` per peer. See method A below.

**For mass cleanups (10+ peers):** directly edit the config file — filter out [Peer] blocks without Endpoint. This is MUCH faster (one script vs N commands). See method B below.

#### Method A: awg set remove (small batches)

Preferred approach — use execute_code to parse `awg show`, extract IP→key mapping, cross-reference with known battle configs, and batch all `awg set` removals into one script.

> Note: the rest of this method is the original text below.

#### Method B: Config file editing (mass cleanup, 10+ peers)

When removing many peers at once, directly edit `/etc/amnezia/amneziawg/awg0.conf` to remove all [Peer] blocks without an Endpoint value. Then restart AWG.

```python
import re, shutil

CONF = '/etc/amnezia/amneziawg/awg0.conf'

# Always backup first
shutil.copy(CONF, CONF + '.bak.cleanup')

with open(CONF) as f:
    text = f.read()

# Split into [Interface] + [Peer] blocks
blocks = re.split(r'\n(?=\[)', text)

kept = []
for block in blocks:
    if block.startswith('[Interface]'):
        kept.append(block)
    elif block.startswith('[Peer]'):
        # Keep only peers with a non-empty Endpoint
        ep_match = re.search(r'Endpoint\s*=\s*(\S+)', block)
        if ep_match and ep_match.group(1):
            kept.append(block)

new_text = '\n'.join(kept).rstrip('\n') + '\n'

with open(CONF, 'w') as f:
    f.write(new_text)
```

Then restart:
```bash
awg-quick down awg0 && awg-quick up awg0
```

**Pitfall:** `awg-quick down/up` is a hard restart — all active connections drop momentarily. For production, prefer method A. For cleanup of dead/never-connected peers (no endpoint, no handshake), method B is safe and fast.

Best approach — use execute_code to parse `awg show`, extract IP→key mapping, cross-reference with known battle configs, and batch all `awg set` removals into one script. This avoids manual key transcription errors and provides clear logging.

```python
from hermes_tools import terminal

# 1. Parse awg show to get IP→key map
result = terminal("awg show awg0")
# ... extract peer keys by IP ...

# 2. Cross-reference with battle configs to build removal list
battle_ips = {102, 103, 105, 106, 108, 109}  # from known .conf files
keys_to_remove = [key for ip, key in ip_to_key.items() if ip not in battle_ips]

# 3. Write shell script and execute
script = "\n".join(f'awg set awg0 peer "{k}" remove' for k in keys_to_remove)
with open("/tmp/awg_cleanup.sh", "w") as f:
    f.write("#!/bin/bash\nset -e\n" + script)
terminal("bash /tmp/awg_cleanup.sh", timeout=120)

# 4. Verify
check = terminal("awg show awg0 | grep -c '^peer:'")
```

Fallback (bash loop):
```bash
while read key; do
  sudo awg set awg0 peer "$key" remove
done < /tmp/dead-keys.txt
```

### Step 5: Delete test config files

```bash
sudo rm /etc/amnezia/amneziawg/gatebox-*.conf
```

### Step 6: Verify

```bash
awg show awg0 | grep -c '^peer:'  # Should have decreased
ls /etc/amnezia/amneziawg/*.conf | wc -l  # Only battle configs remain
```

## XRay/3x-ui Cleanup

### Step 1: Query the database

```python
import sqlite3, json
conn = sqlite3.connect('/etc/x-ui/x-ui.db')
rows = conn.execute("SELECT id, settings FROM inbounds WHERE id = 1").fetchone()
settings = json.loads(rows[1])
clients = settings['clients']
```

### Step 2: Filter battle vs test

- Battle clients: names like Lisa, Valera, Sasha, Slava — DO NOT remove
- Test clients: names with `gatebox-` prefix

### Step 3: Remove test clients from DB

```python
battle = [c for c in clients if 'gatebox-' not in c.get('email','')]
settings['clients'] = battle
conn.execute('UPDATE inbounds SET settings = ? WHERE id = 1', (json.dumps(settings),))
conn.commit()
```

### Step 4: Restart x-ui to apply

```bash
sudo systemctl restart x-ui
```

### Step 5: Verify

```bash
# Check client count in x-ui panel or via DB query
```

## Pitfalls

- **IP conflicts**: vpnadd assigns IPs sequentially. If test and battle configs were created in interleaved order, they may share the same IP. Always check before removing peers.
- **Live handshakes**: some "test" IPs may show active handshakes because the user is currently testing from those devices. Never remove peers with active handshakes.
- **AWG service name**: `awg-quick@awg0`, NOT `amneziawg`. Check with `systemctl is-active awg-quick@awg0`.
- **XRay has no per-client handshake**: unlike AWG, you can't tell which XRay clients are connected. Remove test clients confidently — they're just UUIDs in the config.
- **All operations require `vpn-safe` protocol**: show plan/risks/rollback, get `YES, DO IT` confirmation.
- **System approval may block `rm` on .conf files**: even after vpn-safe confirmation, `rm` of files in `/etc/amnezia/amneziawg/` can be blocked by the system-level approval guard. The peer itself is removed via `awg set`, so the stale .conf file is harmless. Either request separate approval or ask user to delete manually.
