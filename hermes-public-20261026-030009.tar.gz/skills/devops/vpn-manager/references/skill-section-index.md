# Структура скилла — полная таблица разделов

## Структура скилла (consolidated umbrella)

Этот скилл объединяет 4 подраздела. Подробные процедуры — в `references/`:

| Раздел | Описание | Файл |
|--------|----------|------|
| **Безопасность** | Протокол `vpn-safe`: правила, план/риски/откат, строгое подтверждение | `references/vpn-safe.md` |
| **Добавление клиента** | `vpn-add-client`: диалог, preflight, выполнение, QR+конфиг | `references/vpn-add-client.md` |
| **Статус** | `vpn-status`: сводка AWG, XRay, Tailscale, health | `references/vpn-status.md` |
| **Перевыпуск AWG-клиента** | Замена офлайн peer'а с сохранением IP и обязательной проверкой нового конфига перед отправкой клиенту | `references/awg-client-reissue.md` |
| **Архитектура** | Read-only аудит production-инфраструктуры | `references/architecture-audit-2026-05-22.md` (latest) |
| **XRay + Tailscale Port Conflict** | Диагностика и fix конфликта порта 443 между XRay и Tailscale Funnel. Pitfall: x-ui перезаписывает config.json из БД — правки напрямую теряются | `references/xray-tailscale-port-conflict.md` |
| **VLESS Flow Rejection** | Xray 26.2.6+ реджектит клиентов без flow. Диагностика через 3xui.log, два пути фикса (клиентский + legacy workaround) | `references/xray-vless-flow-rejection.md` |
| **VLESS URL Generation** | Генерация VLESS Reality URL из БД x-ui для любого клиента: все параметры, pitfalls, пример скрипта | `references/vless-url-generation.md` |
| **Массовая чистка** | Удаление тестовых клиентов AWG + XRay после QA-сессий: IP-конфликты, живые/мёртвые пиры, бэкапы (23 мая 2026) | `references/bulk-client-cleanup.md` |
| **AWG Client→Peer Matching** | Match client `.conf` files to live server peers by deriving public key from private key via `awg pubkey` | `references/awg-client-conf-matching.md` |
| **Security Hardening** | Быстрая защита VPS: UFW, SSH hardening, fail2ban — чек-лист и pitfalls (июнь 2026) | `references/security-hardening.md` |
| **x-ui Dashboard Access** | Доступ к панели 3x-ui: HTTPS :49624, кастомный base path, SSL-сертификаты, диагностика 404 | `references/x-ui-dashboard-access.md` |
| **FaceTime/X-Ray UDP Fix** | Диагностика и fix: FaceTime звонки не работают через X-Ray если network только tcp. Править через БД, не config.json | `references/xray-facetime-udp-fix.md` |
| **AWG Peer Fix (remove+readd)** | Когда `awg set ... advanced-security` не работает: remove → addconf с temp-файлом. Pitfall: dump field `off` не индикативен | `references/awg-peer-fix-remove-readd.md` |
| **Telegram File Delivery + Config Delivery** | Доставка конфигов через Bot API curl, sendDocument без caption, pitfalls с MEDIA: | `references/vpn-config-delivery.md` |
