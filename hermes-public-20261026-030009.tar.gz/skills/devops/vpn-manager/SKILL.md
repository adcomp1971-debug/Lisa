---
name: vpn-manager
description: "Use when универсальный VPN-оркестратор: безопасность, статус, клиенты, диагностика. Единая точка входа, подпроцедуры в references/."
version: 2.1.0
author: Hermes Agent
license: MIT
---

# vpn-manager

Назначение: главный центральный скилл для ВСЕХ VPN-операций в продакшене VPN Лиса.
Объединяет в себе протокол безопасности, операции с клиентами и диагностику.

## Структура скилла (consolidated umbrella)

Подробные процедуры — в `references/`. Полные описания разделов — references/skill-section-index.md.

| Раздел | Файл |
|--------|------|
| Безопасность (`vpn-safe`) | `references/vpn-safe.md` |
| Добавление клиента | `references/vpn-add-client.md` |
| Статус | `references/vpn-status.md` |
| Перевыпуск AWG-клиента | `references/awg-client-reissue.md` |
| Архитектура (снимок) | `references/architecture-audit-2026-05-22.md` |
| XRay + Tailscale порт 443 | `references/xray-tailscale-port-conflict.md` |
| Второй вход на 443: XHTTP+Reality за nginx stream | `references/xhttp-reality-entry.md` |
| VLESS flow rejection | `references/xray-vless-flow-rejection.md` |
| VLESS URL | `references/vless-url-generation.md` |
| Массовая чистка | `references/bulk-client-cleanup.md` |
| AWG client→peer matching | `references/awg-client-conf-matching.md` |
| Security hardening | `references/security-hardening.md` |
| x-ui dashboard | `references/x-ui-dashboard-access.md` |
| FaceTime/X-Ray UDP | `references/xray-facetime-udp-fix.md` |
| AWG peer remove+readd | `references/awg-peer-fix-remove-readd.md` |
| Доставка конфигов | `references/vpn-config-delivery.md` |

## Роль скилла (single entrypoint)

`vpn-manager` — единая точка входа:
1) Показать статус (`/vpn-status`)
2) Выполнить диагностику (read-only)
3) Добавить клиента (только через `vpn-safe`)
4) Удалить клиента (только через `vpn-safe`)

Если запрос относится к VPN, сначала применять `vpn-manager`.
Подробные процедуры для каждой операции — в `references/` (см. таблицу выше).

## Критичные правила безопасности

1. Любое изменение состояния прода (клиенты, конфиги, рестарты, ключи, порты, inbound'ы) — только через протокол `vpn-safe` (см. `references/vpn-safe.md`).
2. Перед опасным действием обязательно показать:
   - План
   - Риски
   - Откат
4. Затем дословно запросить подтверждение:
   `Подтверди: YES, DO IT`
5. Выполнять изменения только после точного ответа:
   `YES, DO IT` (или `ДА, ДЕЛАЙ`, если это допустимо верхним policy).
   Проверка подтверждения должна быть строгой: без нормализации пунктуации/пробелов.
   Ответы вида `yes`, `yes,do it`, `YES DO IT`, `ок` невалидны и не дают права выполнять команды.

Примечание: допускается принимать `ДА, ДЕЛАЙ` как эквивалент только если это уже разрешено верхним policy; базовый стандарт этого скилла — точный `YES, DO IT`.

## Маршрутизация запросов

### 1) Статус

При запросах вида "статус", "проверь VPN", "что по сервисам":
- Использовать процедуру из `references/vpn-status.md`
- Вернуть короткую сводку:
  - AWG
  - X-UI/XRay
  - Tailscale
  - Health (OK/WARN)

**Критическое правило:** статус AWG и статус XRay показывать ОТДЕЛЬНЫМИ секциями/командами.
Не смешивать пиры/клиенты разных VPN-типов в одну таблицу.
Пользователь хочет видеть разделение — `/awg_status` и `/xray_status` (или эквиваленты).
Общий `/status` — только краткая сводка (сколько пиров, активен ли сервис), ссылающаяся на детальные команды.

### 2) Диагностика (безопасный режим, read-only)

Разрешено без подтверждения, если нет изменений:
- `type awg`
- `awg show`
- `ip a show awg0`
- `systemctl status awg-quick@awg0 --no-pager`  # NOTE: service is awg-quick@awg0, NOT amneziawg
- `systemctl status x-ui --no-pager`
- `systemctl status tailscaled --no-pager`
- `ss -lntup`
- `journalctl -u awg-quick@awg0 -n 200 --no-pager`
- `journalctl -u x-ui -n 200 --no-pager`  # только логи веб-панели x-ui (логины)
- `journalctl -u tailscaled -n 200 --no-pager`
- `tail -100 /var/log/x-ui/3xui.log`  # реальные XRay-логи: соединения, reject'ы, ошибки
- `grep -i 'reject\|error\|fail' /var/log/x-ui/3xui.log | tail -20`  # быстрый поиск проблем

Диагностика не должна менять состояние системы.

### 3) Перевыпуск офлайн AWG-клиента (с сохранением IP)

Всегда через протокол `vpn-safe` (см. `references/vpn-safe.md`). Использовать, когда:
- peer присутствует в `awg show`, но handshake долго отсутствует;
- серверный AWG исправен, другие peer'ы handshakes делают;
- старый клиентский `.conf`/`.vpnlink` утрачен, устарел или ему больше нельзя доверять.

Подробная процедура: `references/awg-client-reissue.md`.

Ключевые правила:
- сначала исключить серверную проблему read-only диагностикой;
- если мягкий рестарт awg0 не оживил peer, допускается перевыпуск клиента;
- **сохранять тот же `AllowedIPs` / клиентский IP**, если задача — восстановить существующего клиента, а не создать нового;
- в `awg0.conf` заменять только peer-блок проблемного клиента;
- перед отправкой нового конфига клиенту обязательно проверить:
  - `systemctl is-active awg-quick@awg0` → active
  - новый peer присутствует в `awg show`
  - public key, вычисленный из нового client private key, совпадает с peer на сервере
  - server public key в клиентском конфиге совпадает с `/etc/amnezia/amneziawg/server_public.key`
  - в клиентском конфиге корректны `Address`, `Endpoint`, `PresharedKey`
- клиенту отправлять оба артефакта, если доступны: `.conf` и `.vpnlink`
- явно предупреждать: старый конфиг больше недействителен, нужен переимпорт на устройстве

### 4) Добавление клиента

**Fast path (один клиент) — подтверждение ОБЯЗАТЕЛЬНО.** План (имя, клиентский IP, `full`/`split`, что меняется) → «да» / `YES, DO IT` → только потом выполнять. Детали: `references/vpn-add-client.md`, выдача: `references/vpn-config-delivery.md`.
- Бэкап: `cp /etc/amnezia/amneziawg/awg0.conf /etc/amnezia/amneziawg/awg0.conf.bak.$(date +%Y%m%d_%H%M%S)`
- Ключи, конфиг, [Peer] в awg0.conf. Без рестарта: temp-файл только с peer → `awg addconf awg0 /tmp/peer-<name>.conf` (addconf ниже). Пир в `awg show`. НЕ перезапускать AWG.
- Выдать конфиг.

**Full protocol (удаление, чистка, смена структуры):** `references/vpn-safe.md`. Имя и `full`/`split`, план/риски/откат, `YES, DO IT`. `full` → `vpnadd <name>`, `split` → `vpnadd-ru <name>`. Проверить `awg show`, QR + конфиг + путь к `.conf`. НЕ перезапускать `awg-quick@awg0`.
Подробности и примеры — references/vpn-add-client-core.md

### 5) Переподключение отвалившегося клиента (regenerate keys)

Handshake нет, сервер и другие клиенты живы — почти всегда клиент. Процедура — §3 и `references/awg-client-reissue.md`. iOS: `vpn://` не кликается в Telegram — копировать и открывать в Safari (`references/vpn-config-delivery.md`).

**Не** `systemctl restart awg-quick@awg0` ради одного пира. Горячо: `awg addconf awg0 <фрагмент-с-peer-блоком>`. **Не применять:** `awg addconf /etc/amnezia/amneziawg/awg0.conf` (нет имени интерфейса и фрагмента peer).
Подробности и примеры — references/awg-reconnect-notes.md

Всегда через протокол `vpn-safe` (см. `references/vpn-safe.md`).

**Идентификация мёртвых пиров (read-only):** `awg show` обрезает вывод — `head -30` не хватает. Полный список за один проход: `awg show awg0 2>&1 | grep -E "peer:|allowed|handshake"`. Нет endpoint и нет handshake = мёртвый пир; есть endpoint без handshake = возможно мёртвый (уточнить у Алекса).

**Удаление:** read-only идентификация кандидатов → таблица живые / возможно мёртвые / точно мёртвые → план, риски, откат → `YES, DO IT` → удаление: массовое (10+) — Method B из `references/bulk-client-cleanup.md` (фильтрация конфига по Endpoint + `awg-quick down/up`), малое (≤10) — `awg set awg0 peer <public-key> remove` → проверить результат (`awg show`) и дать отчёт → сохранить изменения в конфиг (`awg showconf awg0 > /etc/amnezia/amneziawg/awg0.conf`).

**Питфоллы:** `awg showconf` теряет `Address`/`MTU`/`DNS` — сразу после него восстановить Address (процедура и фикс — скилл `awg-operations`). **Откат:** бэкап перед удалением — `cp /etc/amnezia/amneziawg/awg0.conf /etc/amnezia/amneziawg/awg0.conf.bak.$(date +%Y%m%d_%H%M%S)`.

## Жёсткие запреты

Без протокола `vpn-safe` (см. `references/vpn-safe.md`) запрещено:
- `systemctl restart/stop` для `awg-quick@awg0`, `x-ui`, `xray`
- Любая запись в `/etc/amnezia/amneziawg/`
- Изменение конфигов 3x-ui/xray
- Добавление/удаление VPN-клиентов
- Изменение портов, ключей, inbound'ов

## Pitfalls

### vpnadd: ошибки в stdout, не stderr
Фикс: `echo "Сообщение" >&2`. В боте: `err_msg = result.stderr[:200] or result.stdout[:200] or "Неизвестная ошибка"`. Проверка: `vpnadd Имя 1>/dev/null`.
Подробности и примеры — references/vpnadd-stdout-stderr.md

### AWG handshake есть, трафик нет (NAT / UFW)
`iptables -t nat -L POSTROUTING -n -v | grep 10.9.0.0` пусто → `iptables -t nat -A POSTROUTING -s 10.9.0.0/24 -o eth0 -j MASQUERADE`. UFW после ребута: `ufw route allow in on awg0 out on eth0`. `iptables -t nat -A` ребут не переживает.
Подробности и примеры — references/awg-nat-ufw-forwarding.md

### Перед удалением пира — проверить .conf
`for f in /etc/amnezia/amneziawg/*.conf; do grep -l "$PEER_KEY" "$f" && echo "CONFIG: $f"; done`. Ключ найден — не удалять без вопроса. Живой handshake ≠ «конфиг утерян».
Подробности и примеры — references/awg-peer-deletion-guards.md

### AWG добавить peer без рестарта: addconf с фрагментом (не awg set)

**Правильный способ добавить peer в работающий AWG без перезагрузки — `awg addconf` с конфиг-фрагментом.**

`awg set awg0 peer <key> ...` может падать с `fopen: No such file or directory` (зависит от версии/сборки AWG). `awg addconf` надёжнее — он читает файл и добавляет peer'ы из него в работающий интерфейс без разрыва остальных соединений.

**Шаблон:**
```bash
cat > /tmp/peer-<name>.conf << 'EOF'
[Peer]
PublicKey = <public-key>
PresharedKey = <psk-key>
AllowedIPs = 10.9.0.X/32
EOF
awg addconf awg0 /tmp/peer-<name>.conf
```

После этого проверить: `awg show awg0` — пир появится (без handshake, ждёт клиента).

**Важно:**
- Фрагмент содержит ТОЛЬКО [Peer] секцию, не [Interface]
- `awg addconf` добавляет peer'ы к уже работающим — не кикает существующие соединения
- После addconf обязательно прописать peer в `awg0.conf` (persist после ребута)
- **Никогда** не использовать `systemctl restart awg-quick@awg0` для добавления одного пира — это обрывает ВСЕХ подключённых клиентов

### AWG: кириллица в именах файлов ключей
`awg set` может не работать с `Катерина.conf`. Имена — ASCII; ключи копировать в `/tmp/`.
Подробности и примеры — references/awg-cyrillic-filenames.md

### Telegram: доставка конфигов
Триггеры «синий файл», «синенькая иконка», «синяя иконка», «как док», «пришли файл» → `sendDocument`, не текст и не `MEDIA:`. iOS: не повторять MEDIA:. VLESS: `#ИМЯ-КЛИЕНТА`, файл `.conf`, без caption.
`source /root/.hermes/.env && curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument" -F "chat_id=<CHAT_ID>" -F "document=@/tmp/file.conf;filename=Anya.conf"`
`{"ok":true}` = доставлено. Подробности и примеры — references/telegram-file-delivery-triggers.md

### VLESS Flow Rejection (Xray ≥26.x)
Пустой flow реджектится. `grep 'rejected.*flow.*empty' /var/log/x-ui/3xui.log | tail -5` (не `journalctl -u x-ui`). Клиенту `flow: xtls-rprx-vision` и новый URL, либо пустой flow в БД (legacy). spx `/` → `%2F`.
Подробности и примеры — references/vless-flow-url-fix.md

### AmneziaWG: обфускация должна совпадать
Без этих значений handshake не пройдёт: `Jc = 4`, `Jmin = 40`, `Jmax = 70`, `S1 = 50`, `S2 = 100`, `H1 = 1106007595`, `H2 = 1284786334`, `H3 = 1463045443`, `H4 = 1537700372`. iOS: vpn://, не «Создать с нуля»; vpn:// в Telegram копировать в Safari.
Подробности и примеры — references/awg-obfuscation-ios-verify.md

### x-ui: не править config.json; порт 443
**НИКОГДА** `/usr/local/x-ui/bin/config.json` — перезапись из `/etc/x-ui/x-ui.db`. `sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET listen='76.13.77.105' WHERE port=443;"`, затем `systemctl restart x-ui`. Конфликт: `ss -tlnp 'sport = :443'`. Альтернатива: `port=8443` и новые URL.
Подробности и примеры — references/xray-config-db-port443.md

### Память ≠ реальность
Не полагаться на persistent memory о статусе VPN-сервисов. «XRay заблокирован» в памяти ≠ XRay не используется. Всегда проверять текущее состояние: `systemctl status x-ui`, `ss -tlnp`, `journalctl`. Живые клиенты могут быть даже если память говорит обратное.

### AWG peer: endpoint без handshake / статичный transfer
Endpoint без handshake — сторона клиента. Свежий handshake и статичный transfer — не рестартить AWG и не трогать UFW/iptables.
Подробности и примеры — references/awg-peer-handshake-states.md

### Новый вход на 443 (XHTTP/Reality) — сначала доказать безопасность
Новый вход = свой SNI + отдельный инстанс Xray на loopback + одна строка в nginx stream. Панель, её БД и AWG не трогаются. Перед включением обязательны три проверки: `nginx -t` на копии конфига **в `/etc/nginx/`** (из `/tmp` падает на относительных `include`), loopback E2E нового инстанса, и `systemctl reload nginx` под живым скачиванием через рабочий вход (`scripts/nginx-stream-reload-test.py`) — reload обязан доиграть соединение целиком. Контрольные цифры «до/после»: `systemctl is-active x-ui` и `awg show awg0 | grep -c 'latest handshake'`.
Подробности — references/xhttp-reality-entry.md

### Замер скорости через туннель — сначала проверить источник
`speed.cloudflare.com` без `-A` отдаёт 403, а несуществующий файл в имени (например `proof.ovh.net/files/5Mb.dat`) даёт 0 байт за доли секунды. Оба случая выглядят как «туннель не тянет». Проверять источник прямым curl до замера.
Подробности — references/xhttp-reality-entry.md

## Важные замечания по эксплуатации

**AmneziaWG сервис:** называется `awg-quick@awg0`, НЕ `amneziawg`.
`systemctl is-active amneziawg` всегда возвращает `inactive` — это ложный негатив.
Правильная проверка: `systemctl is-active awg-quick@awg0` или `awg show`.

### Read-only architecture audit
Без restart, правок, `awg set`, `wg-quick`, изменений iptables/ufw. Не печатать ключи и токены.
Подробности и примеры — references/architecture-audit-procedure.md

### Stale cron skill references
`hermes cron list 2>&1 | grep -B2 '<absorbed-skill-name>'`; `journalctl -u hermes-gateway --no-pager | grep 'skill not found'`. Фикс: `hermes cron update <job-id> --skills 'vpn-manager'`.
Подробности и примеры — references/cron-stale-skill-refs.md

### Hermes Dashboard и nginx
systemd `hermes-dashboard` (127.0.0.1:9118), не `hermes dashboard &`. 502: `systemctl restart hermes-dashboard`. Перед удалением сайта: `cat /etc/nginx/sites-enabled/<name>`.
Подробности и примеры — references/hermes-dashboard-nginx.md

## Режим "План"

Если пользователь пишет `План`, немедленно вернуть:
1. Пошаговый план
2. Риски
3. Откат
4. Строку подтверждения: `Подтверди: YES, DO IT`

## Формат отчётности

После любой операции:
- Что сделано
- Чем проверено
- Текущий статус
- Что НЕ изменялось

**Ссылки — отдельными сообщениями.** Каждый URL в своём send_message, plain text без маркдауна. Не блоки \`\`\` — на мобиле слипаются. Каждая ссылка копируется одним тапом.

## Связанные скиллы

- **`server-monitoring`** — watchdogs для диска, балансов провайдеров (no_agent=True).

Если есть конфликт между скоростью и безопасностью, всегда выбирать безопасность.
`vpn-manager` является главным центральным скиллом VPN-операций. Все подпроцедуры — в `references/`.
