# WhatsApp in-app proxy — TCP-протокол, официальный форвардер, деплой через VPN-туннель

Источник: https://github.com/WhatsApp/proxy (FAQ.md, proxy/src/proxy_config.cfg) — проверено 2026-08-07 на 76.13.77.105.

## Ключевые цитаты официального FAQ

- **Q5 (главное):** «WhatsApp currently does **NOT** support anything besides TCP proxying. This is just copying the incoming bytes to WhatsApp on the other end. So we don't support running through any intermediary that is a HTTP proxy. You are free to run your own pure TCP proxy as you see fit, as long as it forwards to `g.whatsapp.net`.»
- **Q4 (порты):** клиент по умолчанию идёт на порт **443** (TLS к прокси, хардкод — 443 НЕ ремапить). Порты 80 и 5222 ремапить можно — клиент их принимает в расширенных настройках. На не-443 портах TLS к прокси НЕ ожидается (сырой Noise).
- **Q7:** 7 портов не обязательны; типично достаточно 80/443/5222 (+ 587/7777 для медиа). Порт 8199 — HAProxy stats (health check).

Вывод: **squid (HTTP CONNECT) НЕ может работать со встроенным прокси WhatsApp ни на каком порту.** Симптом несовместимости: «Не удалось подключиться к прокси-серверу», в squid access.log — `NONE_NONE/400` (TLS/Noise-мусор в plain-HTTP порт) или полное отсутствие записей от клиента.

## Карта портов официального прокси (proxy_config.cfg)

| Порт | Куда форвардит | Назначение |
|---|---|---|
| 80 | g.whatsapp.net:80 | чат (plain) |
| 443 | g.whatsapp.net:5222 | чат, TLS-терминация (self-signed proxy.whatsapp.net.pem) — НЕ ремапить |
| 5222 | g.whatsapp.net:5222 | чат (основной для нашего кейса) |
| 587 | whatsapp.net:443 | медиа |
| 7777 | whatsapp.net:443 | медиа (резерв) |
| 8080/8443/8222 | то же + accept-proxy | только за NLB с PROXY header — не публиковать |
| 8199 | stats | HAProxy статистика/health |

## Деплой (проверено 2026-08-07, Ubuntu 24.04, docker 29)

```bash
docker pull facebook/whatsapp_proxy:latest
docker run -d --name whatsapp-proxy --restart unless-stopped \
  -p 10.9.0.1:5222:5222 \
  -p 10.9.0.1:587:587 \
  -p 10.9.0.1:7777:7777 \
  -p 10.9.0.1:8199:8199 \
  facebook/whatsapp_proxy:latest
```

**Биндить ТОЛЬКО на VPN-IP (10.9.0.1), не на 0.0.0.0.** Публичная публикация WA-прокси → РКН детектит WA-протокол к IP сервера → банит IP → умирает и сам AmneziaWG endpoint клиента. UFW не трогать: `iifname "awg0" accept` пропускает весь туннельный трафик, docker DNAT с dst=10.9.0.1 не светит наружу (проверить: `echo > /dev/tcp/<public-ip>/5222` → refused).

## iOS Full Tunnel — endpoint exclusion (важно!)

iOS при AllowedIPs 0.0.0.0/0 маршрутизирует **публичный IP самого VPN-сервера МИМО туннеля** (иначе туннель не построить). Поэтому прокси на публичном IP сервера недостижим «через VPN» — трафик пойдёт через местного провайдера (в РФ — блок/UFW). **Клиенту давать приватный IP сервера в туннеле (10.9.0.1) — он идёт внутри шифрованного AWG.** Провалы 2026-08-06 с 10.9.0.1:3128 были вызваны HTTP-протоколом squid, а не RFC1918.

## Инструкция клиенту (iPhone)

WhatsApp → Настройки → Хранилище и данные → Прокси-сервер → Использовать прокси:
- Адрес: `10.9.0.1` (ТОЛЬКО IP, без порта — иначе «Сохранить» серая)
- Расширенные/Порты: **Порт чата 5222**, **Порт медиа 587**
- VPN (AmneziaWG) должен быть включён — без него 10.9.0.1 недоступен (это норма)

## Проверка после деплоя

Скрипт: `scripts/verify-whatsapp-proxy.sh`. Ручные ключевые тесты:
- `curl -s 'http://10.9.0.1:8199/;csv'` → все backend = UP (L4OK)
- `echo | openssl s_client -connect 10.9.0.1:587 -servername www.whatsapp.net` → настоящий серт Meta `CN=*.whatsapp.net` (DigiCert, Verify OK) — доказывает E2E медиа-путь
- TCP connect 10.9.0.1:5222 OK; `<public-ip>:5222/587` — closed

## Связь с WARP-egress скиллом

Squid+WARP (skill `warp-egress-proxy`) остаётся валидным для приложений с честной HTTP-прокси поддержкой (браузер, curl, Telegram). Для WhatsApp — только этот TCP-форвардер. Прямой egress с Vilnius DC к g.whatsapp.net:5222/443 и mmg.whatsapp.net:443 работал без WARP (2026-08-07), WARP для WA-прокси не понадобился.
