## WhatsApp in-app proxy — это TCP-прокси, НЕ HTTP (решено 2026-08-07)

Официальный FAQ WhatsApp/proxy (Q5): **«WhatsApp does NOT support anything besides TCP proxying... we don't support running through any intermediary that is a HTTP proxy»**. Встроенная прокси-функция WhatsApp шлёт сырой Noise-протокол → **squid (HTTP CONNECT) не работает ни на каком порту** (3128/443/5222 — без разницы). Симптом: «Не удалось подключиться к прокси-серверу» при любых адресах; в squid access.log — `NONE_NONE/400` или ноль записей от IP клиента.

**Рабочее решение** — официальный TCP-форвардер `facebook/whatsapp_proxy` (HAProxy от Meta, docker):
- 5222 → g.whatsapp.net:5222 (чат), 587/7777 → whatsapp.net:443 (медиа); 443 — TLS-терминация, НЕ ремапить (клиент хардкодит TLS на 443)
- Биндить ТОЛЬКО на VPN-IP сервера: `docker run -d --name whatsapp-proxy --restart unless-stopped -p 10.9.0.1:5222:5222 -p 10.9.0.1:587:587 -p 10.9.0.1:7777:7777 -p 10.9.0.1:8199:8199 facebook/whatsapp_proxy:latest`
- Наружу не светить: РКН увидит WA-протокол к IP сервера → забанит IP → умрёт и VPN endpoint клиента. UFW не трогать (`iifname "awg0" accept` + docker DNAT на dst=10.9.0.1)

**Клиенту давать ПРИВАТНЫЙ `10.9.0.1` (через туннель), НЕ публичный.** При Full Tunnel iOS маршрутизирует публичный IP самого VPN-сервера МИМО туннеля (endpoint exclusion) → прокси на публичном IP пошёл бы через РФ-провайдера. Приватный IP в поле адреса РАБОТАЕТ — провалы с `10.9.0.1:3128` (2026-08-06) были из-за HTTP-протокола squid, не из-за RFC1918.

Инструкция клиенту (iOS): Настройки → Хранилище и данные → Прокси → адрес `10.9.0.1` (только IP, БЕЗ порта — иначе «Сохранить» серая) → расширенные порты: чат **5222**, медиа **587**. VPN включён.

Деплой-рецепт, карта портов, цитаты FAQ: `references/whatsapp-tcp-proxy.md`. Проверка после деплоя: `scripts/verify-whatsapp-proxy.sh` (бэкенды UP, E2E TLS через 587 возвращает настоящий серт Meta, публичные порты закрыты).
