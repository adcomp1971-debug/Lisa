#!/usr/bin/env bash
# Фиксированное окно наблюдения за входящими на порт туннеля.
#
# Зачем: показать, стучатся ли «молчащие» клиенты вообще — и не дать одному
# живому пиру съесть лимит пакетов. С `-c N` окно молча обрывается на первом
# же качающем пире, и «никто не стучится» превращается в артефакт метода.
#
# Использование:
#   capture-tunnel-sources.sh [секунды] [iface] [порт] [IP-исключения...]
#   по умолчанию: 120 секунд, eth0, 51820
#
# Пример:
#   capture-tunnel-sources.sh 120 eth0 51820 109.252.120.75 128.71.195.33
#
# Читать вывод так: список «N <IP>» = сколько пакетов пришло с адреса за окно.
# Пусто + «0 packets captured» = действительно никто не стучался.
# Пусто при живом потоке = ошибка разбора (обычно `-i any`), а не молчание.

set -u
SECS="${1:-120}"
IFACE="${2:-eth0}"
PORT="${3:-51820}"

FILTER="udp and dst port ${PORT}"
if [ "$#" -gt 3 ]; then
  for ip in "${@:4}"; do
    [ -n "$ip" ] && FILTER="${FILTER} and not src ${ip}"
  done
fi

echo "== окно ${SECS}s | iface ${IFACE} | фильтр: ${FILTER}"
start=$(date +%s)
# Дамп пишем в переменную/mktemp, а НЕ через `-w <файл>` в каталог root:
# tcpdump на этом хосте сбрасывает привилегии до юзера `tcpdump` (uid 107) и в
# `/root` (0700) писать не может — «Permission denied» даже с -Z root. Нужен
# файл — только в /tmp, живой поток читать с `-U`.
raw=$(mktemp)
# shellcheck disable=SC2086
timeout "$SECS" tcpdump -nn -i "$IFACE" "$FILTER" >"$raw" 2>&1
end=$(date +%s)
echo "== фактическая длительность: $((end-start))s (должна совпасть с ${SECS}s)"

echo "== источники:"
grep -E '^[0-9:.]+ IP6? ' "$raw" \
  | awk '{print $3}' \
  | sed -E 's/\.[0-9]+$//' \
  | sort | uniq -c | sort -rn

echo "== счётчик tcpdump:"
grep -E 'packets captured' "$raw" || echo "  (счётчика нет — проверить права/интерфейс)"

if ! grep -qE '^[0-9:.]+ IP6? ' "$raw"; then
  echo "!! разбор пуст: перепроверить iface и фильтр, НЕ делать вывод о молчании"
fi
rm -f "$raw"
