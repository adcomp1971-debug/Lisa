#!/usr/bin/env bash
# Доступность адресов из РФ через check-host.net (read-only, сервер не меняется).
# Использование: ./check-rf-reachability.sh host:port [host:port ...]
# Контроль 1.1.1.1:443 цепляется автоматически: вердикт по узлу действителен
# только если на том же узле ответил контроль.
set -u
NODES="ru1 ru2 ru3 ru4 de1"
CTRL="1.1.1.1:443"
HOSTS="$* $CTRL"

ids=$(mktemp)
for h in $HOSTS; do
  for n in $NODES; do
    r=$(curl -s -m 20 -H "Accept: application/json" \
        "https://check-host.net/check-tcp?host=${h}&node=${n}.node.check-host.net")
    id=$(printf '%s' "$r" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("request_id",""))' 2>/dev/null)
    [ -n "$id" ] && printf '%s\t%s\t%s\n' "$id" "$n" "$h" >> "$ids"
  done
done

sleep 15

while IFS=$'\t' read -r id n h; do
  curl -s -m 20 -H "Accept: application/json" "https://check-host.net/check-result/${id}" \
  | python3 -c '
import sys, json
h, n = sys.argv[1], sys.argv[2]
try:
    d = json.load(sys.stdin)
except Exception:
    print("%-28s %-4s нет ответа от API" % (h, n))
    raise SystemExit
if not d:
    print("%-28s %-4s результат ещё не готов" % (h, n))
for node, res in sorted(d.items()):
    if not res:
        print("%-28s %-4s %-22s узел не ответил" % (h, n, node))
        continue
    for r in res:
        if r.get("error"):
            print("%-28s %-4s %-22s FAIL %s" % (h, n, node, r["error"]))
        else:
            print("%-28s %-4s %-22s OK %ss" % (h, n, node, r.get("time")))
' "$h" "$n"
done < "$ids"
rm -f "$ids"
