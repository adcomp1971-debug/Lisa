#!/usr/bin/env python3
"""Сравнить живой AWG-конфиг с бэкапами по отпечаткам ключей (секреты не печатаются).

Usage: compare-config-backups.py <живой.conf> <бэкап1> [бэкап2 ...]

Пир идентифицируется первым адресом из AllowedIPs. Для каждой версии печатается
sha256[:8] от PublicKey и первые 4 символа sha256 от PresharedKey; строки, где
версии расходятся, помечаются — сразу видно, ЧЬИ ключи/PSK реально менялись и
когда (mtime каждой версии печатается над таблицей).

Зачем: при обвинении «ты всё сломал» доказательство строится на содержимом,
а не на mtime — восстановление через cp -p/shutil.copy2 возвращает файлу время
оригинала, и свежеоткаченный конфиг выглядит «не трогали месяц».
"""
import hashlib
import os
import sys


def parse(path):
    """{первый allowed-ip: {ключ: значение}} по каждому [Peer]."""
    peers = {}
    cur = None
    try:
        with open(path, encoding='utf-8', errors='replace') as fh:
            lines = fh.read().splitlines()
    except OSError as exc:
        print(f'!! не читается {path}: {exc}', file=sys.stderr)
        return peers
    for line in lines:
        s = line.strip()
        if s == '[Peer]':
            cur = {}
            continue
        if cur is None or '=' not in s:
            continue
        key, val = s.split('=', 1)
        cur[key.strip()] = val.strip()
        if 'PublicKey' in cur and 'AllowedIPs' in cur:
            ip = cur['AllowedIPs'].split(',')[0].split('/')[0].strip()
            peers[ip] = cur
    return peers


def fp(value):
    if not value:
        return '--------'
    return hashlib.sha256(value.encode()).hexdigest()[:8]


def sort_key(ip):
    parts = ip.split('.')
    return [int(p) for p in parts] if len(parts) == 4 and all(p.isdigit() for p in parts) else [0]


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    versions = sys.argv[1:]
    data = [parse(path) for path in versions]

    for path in versions:
        try:
            mtime = os.stat(path).st_mtime
        except OSError:
            mtime = None
        stamp = 'нет файла'
        if mtime is not None:
            import datetime
            stamp = datetime.datetime.fromtimestamp(mtime).strftime('%Y-%m-%d %H:%M')
        print(f'{path}  (mtime {stamp})')
    print()

    ips = sorted(set().union(*[set(d) for d in data]), key=sort_key)
    width = max(len(os.path.basename(p)) for p in versions) + 2
    print('пир'.ljust(16) + ''.join(os.path.basename(p).ljust(width) for p in versions))

    changed = 0
    for ip in ips:
        cells, values = [], []
        for peer_map in data:
            entry = peer_map.get(ip)
            if entry:
                cell = f"{fp(entry['PublicKey'])}/{fp(entry.get('PresharedKey', ''))[:4]}"
            else:
                cell = '-нет-'
            cells.append(cell)
            values.append(cell)
        same = len(set(values)) == 1
        changed += 0 if same else 1
        line = ip.ljust(16) + ''.join(c.ljust(width) for c in cells)
        print(line + ('' if same else '  <-- ОТЛИЧАЕТСЯ'))

    print(f'\nпиров всего: {len(ips)}; расходятся между версиями: {changed}')
    if changed == 0:
        print('ключи/PSK всех пиров идентичны во всех версиях — конфиг по этим данным не менялся')
    else:
        print('менялись ТОЛЬКО помеченные пиры; по остальным версии идентичны')
    return 0


if __name__ == '__main__':
    sys.exit(main())
