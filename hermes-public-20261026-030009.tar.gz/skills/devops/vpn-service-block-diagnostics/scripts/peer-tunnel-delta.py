#!/usr/bin/env python3
"""Per-peer AmneziaWG/WireGuard data-path check: snapshot twice, compare.

Answers the question the whole triage hinges on: does this peer's traffic actually
flow, or is the handshake just keepalive noise?

Three states that all look identical from the client side ("VPN не работает"):
  * handshake ADVANCES and rx/tx grow  -> tunnel + data path fine, look at the app layer
  * handshake ADVANCES, bytes flat     -> peer reaches us, payload does not move
                                          (idle device, MTU/fragmentation, DPI on full-size packets)
  * handshake FROZEN (or never, 0)     -> peer is not reaching the server at all:
                                          VPN off on device, keys mismatch, or ISP/DPI drops it upstream

`awg show <iface> transfer` has a different output shape and is easy to mis-grep;
use `dump`. Field order (tab-separated, amneziawg-tools v3.1.x):
  1 pubkey  2 psk  3 endpoint  4 allowed-ips  5 latest-handshake (unix)  6 rx  7 tx  8 keepalive
`latest-handshake` is 0 when the peer never connected; `endpoint` is "(none)" then.

Usage:
  peer-tunnel-delta.py                          # awg0, 60 s interval
  peer-tunnel-delta.py --interval 90 --only 10.9.0.10
  peer-tunnel-delta.py --files /tmp/a.txt /tmp/b.txt   # analyse saved dumps
"""
import argparse
import re
import subprocess
import sys
import time


def snapshot(iface):
    res = subprocess.run(["awg", "show", iface, "dump"], capture_output=True, text=True)
    if res.returncode != 0:
        sys.exit(f"awg show {iface} dump failed: {res.stderr.strip()}")
    return res.stdout.splitlines()[1:]


def parse(lines):
    peers = {}
    for line in lines:
        f = line.rstrip("\n").split("\t")
        if len(f) < 8:
            continue
        addr = f[3].split(",")[0]
        try:
            hs, rx, tx = int(f[4] or 0), int(f[5] or 0), int(f[6] or 0)
        except ValueError:
            continue
        peers[addr] = {"ep": f[2], "hs": hs, "rx": rx, "tx": tx, "ka": f[7]}
    return peers


def human(n):
    for unit in ("B", "KiB", "MiB", "GiB"):
        if abs(n) < 1024:
            return f"{n}{unit}" if unit == "B" else f"{n:.1f}{unit}"
        n /= 1024.0
    return f"{n:.1f}TiB"


def age(ts, now):
    return "никогда" if not ts else f"{(now - ts) // 60} мин"


def verdict(a, b, interval):
    hs_new = b["hs"] != a["hs"]
    drx, dtx = b["rx"] - a["rx"], b["tx"] - a["tx"]
    if hs_new and (drx or dtx):
        return "OK: путь данных живой"
    if hs_new and not (drx or dtx):
        return "handshake идёт, данных нет (MTU/DPI/устройство простаивает)"
    if not hs_new and (drx or dtx):
        return "трафик есть, handshake в окне не обновился"
    return "НЕ СТУЧИТСЯ: клиент выключен / ключи не сходятся / режет провайдер"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--iface", default="awg0")
    ap.add_argument("--interval", type=int, default=60)
    ap.add_argument("--files", nargs=2, metavar=("BEFORE", "AFTER"))
    ap.add_argument("--only", default=None, help="regex filter on allowed-ips")
    args = ap.parse_args()

    if args.files:
        a = parse(open(args.files[0]).read().splitlines())
        b = parse(open(args.files[1]).read().splitlines())
        interval = args.interval
    else:
        a = parse(snapshot(args.iface))
        time.sleep(args.interval)
        b = parse(snapshot(args.iface))
        interval = args.interval

    now = int(time.time())
    pat = re.compile(args.only) if args.only else None
    keys = sorted(set(a) | set(b), key=lambda x: [int(p) for p in re.findall(r"\d+", x)])
    print(f"{'адрес':<20}{'endpoint':<24}{'handshake':<12}{'обновился':<11}{'rx':<10}{'tx':<10}вердикт")
    for ip in keys:
        if pat and not pat.search(ip):
            continue
        pa = a.get(ip, {"hs": 0, "rx": 0, "tx": 0, "ep": "(none)"})
        pb = b.get(ip, pa)
        print(f"{ip:<20}{pb['ep']:<24}{age(pb['hs'], now):<12}"
              f"{('ДА' if pb['hs'] != pa['hs'] else 'нет'):<11}"
              f"{human(max(pb['rx'] - pa['rx'], 0)):<10}{human(max(pb['tx'] - pa['tx'], 0)):<10}"
              f"{verdict(pa, pb, interval)}")


if __name__ == "__main__":
    main()
