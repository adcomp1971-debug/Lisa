#!/usr/bin/env python3
"""Массовая сборка IPv6-транспортных AWG-профилей на весь парк пиров.

Endpoint заменяется на [<IPv6 сервера>]:51820, правки сервера НЕ требуются:
  * пир, у которого v6-адрес (fd00:...) уже стоит в AllowedIPs →
    Address = <v4>/32, <v6>/128   AllowedIPs = 0.0.0.0/0, ::/0
  * пир без v6-адреса в AllowedIPs →
    Address = <v4>/32              AllowedIPs = 0.0.0.0/0
    (сервер отвечает на v4-адрес из allowed-ips — туннель работает; fd00 нужен
     только для IPv6-интернета внутри туннеля)

Сверка ключей обязательна: pubkey клиента считается из его PrivateKey
(`awg pubkey` со STDIN) и сравнивается с пиром; при несовпадении ключа или PSK
профиль НЕ пишется (пир попадает в отчёт как проблемный). Пиры, чьих приватников
на сервере нет, выводятся отдельным списком — им нужен новый пир (ключи перевыпускаются).

Запуск:
  python3 gen-ipv6-profiles.py --endpoint 2a02:4780:c:8bb9::1 --out /root/v6-out
  python3 gen-ipv6-profiles.py --out /root/v6-out --iface awg0 --mtu 1200 --suffix -6

Перед раздачей: python3 verify-profiles.py <out>/*.conf
Имя туннеля в клиенте = ИМЯ ФАЙЛА: повторная раздача тех же имён даёт
«туннель с таким именем существует» — для второго прогона брать новый --suffix.
"""
import argparse
import glob
import os
import re
import subprocess
from pathlib import Path

KEYDIR = '/etc/amnezia/amneziawg'


def sh(args, **kw):
    return subprocess.run(args, capture_output=True, text=True, **kw)


def pubkey_of(priv: str) -> str:
    return sh(['awg', 'pubkey'], input=priv).stdout.strip()


OBF_KEYS = ('Jc', 'Jmin', 'Jmax', 'S1', 'S2', 'H1', 'H2', 'H3', 'H4')


def server_info(iface: str):
    """Публичный ключ сервера + параметры обфускации.

    Обфускацию берём из [Interface] конфига интерфейса (тот же регистр ключей,
    что ждёт клиент), а НЕ из вывода `awg show`: тот печатает их в нижнем
    регистре, и профиль с 'JMINE = ...' клиент молча не примет.
    """
    pub = sh(['awg', 'show', iface, 'public-key']).stdout.strip()
    head = Path(f'{KEYDIR}/{iface}.conf').read_text().split('[Peer]')[0]
    obf = {}
    for k in OBF_KEYS:
        m = re.search(rf'^\s*{k}\s*=\s*(\S+)', head, re.M | re.I)
        if m:
            obf[k] = m.group(1)
    return pub, obf


def parse_peers(iface: str):
    conf = Path(f'{KEYDIR}/{iface}.conf').read_text()
    peers = []
    for blk in conf.split('[Peer]')[1:]:
        pk = re.search(r'PublicKey\s*=\s*(\S+)', blk)
        psk = re.search(r'PresharedKey\s*=\s*(\S+)', blk)
        aips = re.search(r'AllowedIPs\s*=\s*(.+)', blk)
        if not (pk and aips):
            continue
        toks = [t.strip() for t in aips.group(1).split(',')]
        # CIDR обязателен снять: '10.9.0.105/32' -> '10.9.0.105', иначе ключ не найдётся
        v4 = next((t.split('/')[0] for t in toks if '.' in t), None)
        v6 = next((t.split('/')[0] for t in toks if ':' in t), None)
        if v4:
            peers.append({'pub': pk.group(1), 'psk': psk.group(1) if psk else None,
                          'v4': v4, 'v6': v6})
    return peers


def key_files():
    owners = {}
    for f in glob.glob(f'{KEYDIR}/*.private.key'):
        name = os.path.basename(f)[:-len('.private.key')]
        priv = Path(f).read_text().strip()
        psk_path = f'{KEYDIR}/{name}.psk.key'
        psk = Path(psk_path).read_text().strip() if os.path.exists(psk_path) else None
        if psk:
            owners[pubkey_of(priv)] = (name, priv, psk)
    return owners


def build(ep: str, mtu: int, dns: str, srv_pub: str, obf: dict, priv: str, psk: str,
          v4: str, v6: str) -> str:
    addr = f'{v4}/32' + (f', {v6}/128' if v6 else '')
    allowed = '0.0.0.0/0' + (', ::/0' if v6 else '')
    obf_lines = ''.join(f'{k} = {obf[k]}\n' for k in OBF_KEYS if k in obf)
    return (f'[Interface]\nPrivateKey = {priv}\nAddress = {addr}\nDNS = {dns}\nMTU = {mtu}\n'
            f'{obf_lines}\n[Peer]\nPublicKey = {srv_pub}\nPresharedKey = {psk}\n'
            f'Endpoint = [{ep}]:51820\nAllowedIPs = {allowed}\nPersistentKeepalive = 25\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--endpoint', required=True, help='IPv6-адрес сервера без скобок')
    ap.add_argument('--out', required=True)
    ap.add_argument('--iface', default='awg0')
    ap.add_argument('--mtu', type=int, default=1200)
    ap.add_argument('--dns', default='1.1.1.1, 8.8.8.8')
    ap.add_argument('--suffix', default='-6', help='суффикс имени файла = имя туннеля')
    a = ap.parse_args()

    srv_pub, obf = server_info(a.iface)
    if len(srv_pub) != 44:
        raise SystemExit('не получил публичный ключ сервера — проверь --iface')
    owners = key_files()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    made, no_keys, bad = [], [], []
    for p in parse_peers(a.iface):
        own = owners.get(p['pub'])
        if not own:
            no_keys.append(p)
            continue
        name, priv, psk = own
        if pubkey_of(priv) != p['pub'] or psk != p['psk']:
            bad.append((name, p['v4']))
            continue
        text = build(a.endpoint, a.mtu, a.dns, srv_pub, obf, priv, psk, p['v4'], p['v6'])
        f = out / f'{name}{a.suffix}.conf'
        f.write_text(text)
        os.chmod(f, 0o600)
        made.append((name, p['v4'], p['v6'], 'full' if p['v6'] else 'v4-only'))

    for name, v4, v6, mode in made:
        print(f'OK   {name:<16} {v4:<12} {v6 or "-":<16} {mode}')
    for p in no_keys:
        print(f'НЕТ ПРИВАТНИКА {p["v4"]:<12} pub={p["pub"][:12]}… -> нужен новый пир')
    for name, v4 in bad:
        print(f'КЛЮЧИ НЕ СОВПАЛИ {name} {v4} -> не выдавать')
    print(f'\nсобрано {len(made)}, без ключей {len(no_keys)}, проблемных {len(bad)} -> {out}')
    print(f'проверка перед выдачей: python3 verify-profiles.py {out}/*.conf')


if __name__ == '__main__':
    main()
