#!/usr/bin/env bash
# Замер пропускной способности через AWG-туннель с проверками, которые не дают соврать:
#   - цель резолвится через ahostsv4 (getent hosts отдаёт IPv6 → замер уходит мимо туннеля);
#   - маршрут только на цель /32 (default через тест-туннель рвёт свою SSH-сессию);
#   - проверяются `ip route get` и handshake — иначе скрипт печатает «замер невалиден», а не цифры;
#   - тестовый пир и интерфейс убираются через trap, даже при ошибке.
#
# Использование:
#   tunnel-throughput-probe.sh <srv_if> <endpoint_host> [endpoint_port] [key_prefix] [target_host] [bytes]
# Пример:
#   tunnel-throughput-probe.sh awg0 195.238.126.76 51820 /root/v10/test2
#
# Требует: <key_prefix>.key, <key_prefix>.pub, опционально <key_prefix>.psk.
set -euo pipefail

SRV_IF=${1:?укажи серверный интерфейс, напр. awg0}
EP_HOST=${2:?укажи адрес узла}
EP_PORT=${3:-51820}
KEY=${4:-/root/v10/test2}
TARGET=${5:-speed.cloudflare.com}
BYTES=${6:-20000000}
CONF=${SRV_CONF:-/etc/amnezia/amneziawg/${SRV_IF}.conf}
IF=${IF:-awgtst}
PEER_IP=${PEER_IP:-10.9.0.199}

TEST_KEY="$KEY.key"; TEST_PUB=$(cat "$KEY.pub")
[ -f "$TEST_KEY" ] || { echo "нет приватного ключа $TEST_KEY"; exit 1; }
# ключ из конфига вырезать вместе с префиксом — иначе awg set падает «Key is not the correct length or format»
SRV_PUB=$(grep -m1 '^PublicKey' "$CONF" | sed 's/^[A-Za-z]* *= *//' | tr -d '[:space:]')

cleanup() {
  ip route del "${TGT_IP:-169.254.255.255}/32" dev "$IF" 2>/dev/null || true
  ip link del "$IF" 2>/dev/null || true
  awg set "$SRV_IF" peer "$TEST_PUB" remove 2>/dev/null || true
}
trap cleanup EXIT

TGT_IP=$(getent ahostsv4 "$TARGET" | awk 'NR==1{print $1}')
[ -n "$TGT_IP" ] || { echo "не резолвится IPv4-адрес $TARGET"; exit 1; }
echo "цель: $TARGET -> $TGT_IP"

PSK_ARGS=(); [ -f "$KEY.psk" ] && PSK_ARGS=(preshared-key "$KEY.psk")

# пир на живом сервере — на лету, без рестарта
awg set "$SRV_IF" peer "$TEST_PUB" "${PSK_ARGS[@]}" allowed-ips "$PEER_IP/32"

ip link add dev "$IF" type amneziawg
awg set "$IF" private-key "$TEST_KEY"
ip addr add "$PEER_IP/32" dev "$IF"
ip link set "$IF" mtu 1200 up
awg set "$IF" peer "$SRV_PUB" "${PSK_ARGS[@]}" \
  endpoint "$EP_HOST:$EP_PORT" allowed-ips 0.0.0.0/0 persistent-keepalive 25

ip route add "$TGT_IP/32" dev "$IF"
sleep 5

HS=$(awg show "$IF" latest-handshakes | awk '{print $2}' || echo 0)
echo "handshake: ${HS:-0}"
[ "${HS:-0}" != "0" ] || { echo "ЗАМЕР НЕВАЛИДЕН: рукопожатия нет — проверять вход (endpoint/порт/фильтр), цифры не читать"; exit 2; }

ROUTE=$(ip route get "$TGT_IP" | head -1)
echo "маршрут: $ROUTE"
case "$ROUTE" in *"dev $IF"*) ;; *) echo "ЗАМЕР НЕВАЛИДЕН: цель уходит не в туннель"; exit 2 ;; esac

curl -s -o /dev/null -w 'down: %{speed_download} B/s за %{time_total}s\n' --max-time 60 \
  "https://$TARGET/__down?bytes=$BYTES"

# MTU того же пути перебрать так (на живом интерфейсе узла это безопасно):
#   ip link set mtu 1200 dev awgN  →  повторить замер
# Одинаковые цифры при 1200/1280/1420 ⇒ MTU не при чём.
