#!/usr/bin/env python3
"""Сверка клиентских AWG-профилей с сервером перед выдачей.

Проверяет для каждого .conf:
  1) в [Peer] PublicKey стоит ПУБЛИЧНЫЙ КЛЮЧ СЕРВЕРА (awg show <iface> public-key);
  2) публичный ключ клиента (awg pubkey <PrivateKey>) совпадает с пиром этого IP в конфиге интерфейса;
  3) PresharedKey совпадает с PSK того же пира.

Запуск: python3 verify-profiles.py /root/v9/*.conf
        python3 verify-profiles.py --iface awg0 /root/v6 /root/v7 /root/v8
"""
import re
import subprocess
import sys
from pathlib import Path

IFACE = 'awg0'
CONF = f'/etc/amnezia/amneziawg/{IFACE}.conf'


def pubkey_of(priv: str) -> str:
    return subprocess.run(['awg', 'pubkey'], input=priv, capture_output=True, text=True).stdout.strip()


def parse_server(conf_path: str):
    srv_pub = subprocess.check_output(['awg', 'show', IFACE, 'public-key']).decode().strip()
    assert len(srv_pub) == 44, 'не получил публичный ключ сервера — проверь имя интерфейса'
    peers = {}
    for blk in Path(conf_path).read_text().split('[Peer]')[1:]:
        pk = re.search(r'PublicKey\s*=\s*(\S+)', blk)
        sk = re.search(r'PresharedKey\s*=\s*(\S+)', blk)
        ip = re.search(r'AllowedIPs\s*=\s*([0-9.]+)', blk)
        if pk and ip:
            peers[ip.group(1)] = (pk.group(1), sk.group(1) if sk else None)
    return srv_pub, peers


def check(path: str, srv_pub: str, peers: dict):
    t = Path(path).read_text()
    prk = re.search(r'PrivateKey\s*=\s*(\S+)', t)
    pk = re.search(r'\[Peer\][^\[]*?PublicKey\s*=\s*(\S+)', t, re.S)
    psk = re.search(r'PresharedKey\s*=\s*(\S+)', t)
    ip = re.search(r'Address\s*=\s*([0-9.]+)', t)
    ep = re.search(r'Endpoint\s*=\s*(\S+)', t)
    if not (prk and pk and psk and ip):
        return False, 'не разобрал файл', ''
    have = peers.get(ip.group(1))
    client_ok = bool(have) and pubkey_of(prk.group(1)) == have[0]
    srv_ok = pk.group(1) == srv_pub
    psk_ok = bool(have) and have[1] == psk.group(1)
    who = 'OK' if (client_ok and srv_ok and psk_ok) else 'BAD'
    why = []
    if not srv_ok:
        why.append('в [Peer] не ключ сервера')
    if not client_ok:
        why.append('приватный ключ не соответствует пиру (или нет пира для этого IP)')
    if not psk_ok:
        why.append('PresharedKey не совпадает')
    return who == 'OK', who, (ep.group(1) if ep else '') + (' | ' + ', '.join(why) if why else '')


def main(argv):
    global IFACE
    args = []
    it = iter(argv)
    for a in it:
        if a == '--iface':
            IFACE = next(it)
        else:
            args.append(a)
    srv_pub, peers = parse_server(CONF)
    files = []
    for a in args:
        p = Path(a)
        files += sorted(p.glob('*.conf')) if p.is_dir() else [p]
    bad = 0
    for f in files:
        good, who, note = check(str(f), srv_pub, peers)
        bad += 0 if good else 1
        print(f'{who}  {f}' + (f'   [{note}]' if note else ''))
    print(f'\nвсего {len(files)}, проблемных {bad}')
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
