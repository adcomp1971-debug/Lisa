#!/usr/bin/env bash
# Честная проверка пропускной способности AWG-узла: реальное скачивание ЧЕРЕЗ туннель.
# Запускать на своём сервере (там, где есть awg/awg2 и приватный ключ тестового пира).
# ПРАВИТЬ только блок переменных ниже. Ничего постоянного не меняет: тестовый интерфейс и пир убираются в конце.
set -u

NODE="195.238.126.76"                 # адрес проверяемого узла
NODE_PORT="51820"
SSH_KEY="/root/.ssh/relay-ams"
SSH_USER="root"
IFACE_NODE="awg2"                     # интерфейс на узле
NODE_PUB="<публичный ключ узла>"       # из awg show awgN | grep -i public или из заголовка awgN.conf
TKEY="/root/v10/test2.key"            # тестовый клиент (приватный ключ)
TPUB_FILE="/root/v10/test2.pub"
TPSK="/root/v10/test2.psk"
TEST_IP="10.11.0.99/32"               # адрес тестового клиента в подсети узла
TIF="awgtest3"
SIZE="30000000"                       # сколько байт качать (30 МБ; >500 МБ наружу не тащить)

SSH="ssh -i $SSH_KEY -o ConnectTimeout=15 $SSH_USER@$NODE"
PUB=$(cat "$TPUB_FILE")
# ВАЖНО: только IPv4. getent hosts отдаёт IPv6 → AllowedIPs со /32 невалиден,
# маршрут не создаётся и тест молча меряет прямой канал сервера.
TARGET=$(getent ahostsv4 speed.cloudflare.com | awk 'NR==1{print $1}')
echo "цель (v4): $TARGET"

scp -q -O -i "$SSH_KEY" "$TPSK" "$SSH_USER@$NODE:/root/_t.psk"
$SSH "awg set $IFACE_NODE peer $PUB preshared-key /root/_t.psk allowed-ips $TEST_IP && rm -f /root/_t.psk"

ip link del "$TIF" 2>/dev/null || true
ip link add "$TIF" type amneziawg
awg set "$TIF" private-key "$TKEY"
# параметры обфускации ДОЛЖНЫ совпадать с узлом, иначе handshake не пройдёт
# awg set "$TIF" jc 4 jmin 40 jmax 70 s1 50 s2 100 h1 <H1> h2 <H2> h3 <H3> h4 <H4>
awg set "$TIF" peer "$NODE_PUB" preshared-key "$TPSK" endpoint "$NODE:$NODE_PORT" \
  allowed-ips "${TARGET}/32" persistent-keepalive 25
ip addr add "$TEST_IP" dev "$TIF"
ip link set mtu 1200 up dev "$TIF"
ip route add "${TARGET}/32" dev "$TIF"
sleep 3

# Проверка, что замер идёт именно через туннель, а не мимо
ROUTE=$(ip route get "$TARGET" | head -1)
echo "маршрут: $ROUTE"
case "$ROUTE" in *"dev $TIF"*) echo "OK: идёт через туннель";; *) echo "СТОП: маршрут НЕ через туннель — результат недействителен"; exit 1;; esac

echo "=== без туннеля (базовая скорость сервера) ==="
curl -s -o /dev/null -w "down: %{speed_download} B/s\n" --max-time 40 "https://speed.cloudflare.com/__down?bytes=$SIZE"

for M in 1200 1280 1420; do
  ip link set mtu "$M" dev "$TIF"; sleep 1
  echo "=== через туннель, MTU $M ==="
  curl -s -o /dev/null -w "down: %{speed_download} B/s\n" --max-time 40 "https://speed.cloudflare.com/__down?bytes=$SIZE"
  echo "--- потери (flood ping по туннелю):"; ping -f -c 200 -W 3 -q -I "$TIF" "$TARGET" 2>&1 | tail -2
done

echo "=== ошибки интерфейса ==="; ip -s link show "$TIF" | tail -4

echo "=== уборка ==="
ip link del "$TIF" && echo "интерфейс удалён"
$SSH "awg set $IFACE_NODE peer $PUB remove" && echo "тестовый пир удалён"
