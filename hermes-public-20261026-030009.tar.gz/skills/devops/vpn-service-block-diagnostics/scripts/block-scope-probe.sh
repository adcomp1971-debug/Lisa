#!/usr/bin/env bash
# Границы блокировки: наш /32 против всей подсети/провайдера.
# READ-ONLY: ничего на сервере не меняет, ничего не рестартит.
#
# Как работает:
#   1) TCP-connect-скан своего /24 С САМОГО СЕРВЕРА по портам, где обычно есть
#      слушатель -> список ЖИВЫХ чужих соседей (закрытый порт = не сосед).
#   2) эти живые адреса пробиваются снаружи из московских узлов check-host.
#      Соседи в том же /24 отвечают, наш молчит => фильтр /32 (адресный),
#      смена IPv4 у хостера решает даже в пределах того же /24.
#      Молчат все живые соседи => фильтр шире (подсеть/ASN), смена адреса
#      в этом пуле бессмысленна.
#
# Usage: block-scope-probe.sh [наш-IP] [порт1,порт2,...] [сколько-соседей]
#   по умолчанию: IP eth0, порты 80,443,22, 6 соседей
set -u
IFACE=${IFACE:-eth0}
OURARG=${1:-}
PORTS=${2:-80,443,22}
MAXNEIGH=${3:-6}

if [ -n "$OURARG" ]; then OURIP=$OURARG; else
  OURIP=$(ip -4 addr show "$IFACE" 2>/dev/null | awk '/inet /{print $2}' | head -1); OURIP=${OURIP%%/*}
fi
[ -n "$OURIP" ] || { echo "не определил свой IPv4 — передай его аргументом"; exit 1; }
BASE=$(echo "$OURIP" | cut -d. -f1-3)
echo "Наш адрес: $OURIP   подсеть: ${BASE}.0/24   порты: $PORTS"

echo "== 1. живые соседи изнутри (TCP-connect $BASE.0/24) =="
mapfile -t NEIGH < <(OURIP="$OURIP" BASE="$BASE" PORTS="$PORTS" python3 - <<'PY'
import os, socket, concurrent.futures
our=os.environ['OURIP']; base=os.environ['BASE']
ports=[int(p) for p in os.environ['PORTS'].split(',') if p.strip()]
def chk(a):
    ip,port=a
    s=socket.socket(); s.settimeout(1.0)
    try:
        s.connect((ip,port)); s.close(); return ip
    except Exception:
        return None
    finally:
        s.close()
tasks=[(f"{base}.{n}",p) for n in range(1,255) for p in ports]
if our.startswith(base+"."):
    tasks=[t for t in tasks if t[0]!=our]
found=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=120) as ex:
    for r in ex.map(chk, tasks):
        if r and r not in found: found.append(r)
for ip in found: print(ip)
PY
)
if [ ${#NEIGH[@]} -eq 0 ]; then
  echo "живых соседей не нашлось — сравнить не с чем; тогда брать чужие адреса того же хостера из других /24"
else
  echo "живых соседей: ${#NEIGH[@]}  (беру до $MAXNEIGH)"
fi

probe() {  # host:port -> статус по ru1/ru2 (Москва)
  local hp=$1 rid
  rid=$(curl -s -m 15 -H "Accept: application/json" \
    "https://check-host.net/check-tcp?host=${hp}&node=ru1.node.check-host.net&node=ru2.node.check-host.net" \
    | python3 -c "import sys,json;print(json.load(sys.stdin).get('request_id',''))" 2>/dev/null)
  [ -z "$rid" ] && { echo "$hp -> запрос не принят (rate limit?)"; return; }
  sleep 13
  curl -s -m 15 -H "Accept: application/json" "https://check-host.net/check-result/$rid" \
    | HP="$hp" python3 -c "
import sys,json,os
d=json.load(sys.stdin); out=[]
for n in sorted(d):
    r=d[n]; tag=n.split('.')[0]
    if not r: out.append(tag+':нет ответа'); continue
    x=r[0]
    out.append(tag+(':OK%.0fмс'%(x['time']*1000) if x.get('time') else ':'+str(x.get('error','?'))[:32]))
print(os.environ['HP']+' -> '+'  '.join(out))" 2>/dev/null
}

echo "== 2. те же узлы снаружи: наш адрес против живых соседей =="
probe "$OURIP:$(echo "$PORTS" | cut -d, -f2)"
n=0
for ip in "${NEIGH[@]:-}"; do
  [ -z "$ip" ] && break
  probe "$ip:$(echo "$PORTS" | cut -d, -f2)"
  n=$((n+1)); [ $n -ge $MAXNEIGH ] && break
done

echo "== 3. контроль: адреса стороннего VPN-сервиса (Mullvad relay API) =="
curl -s -m 20 https://api.mullvad.net/www/relays/all/ \
 | python3 -c "
import sys,json
seen=[]
try: d=json.load(sys.stdin)
except Exception: print('нет данных Mullvad'); sys.exit()
for r in d:
    ip=r.get('ipv4_addr_in')
    if ip and ip not in seen: seen.append(ip)
    if len(seen)>=2: break
print('\n'.join(seen))" 2>/dev/null | while read -r ip; do [ -n "$ip" ] && probe "$ip:443"; done

echo "ВЫВОД: соседи отвечают, наш нет -> фильтр /32 (менять IPv4 у хостера)."
echo "        молчат все живые адреса того же пула -> фильтр шире /24/ASN (смена адреса не поможет)."
