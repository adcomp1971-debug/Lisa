#!/usr/bin/env python3
"""Сверка клиентских AWG-конфигов с живыми пирами сервера (read-only).

Usage:
    python3 check-client-config.py                   # сканирует /root/*.conf
    python3 check-client-config.py /root/Anna.conf   # конкретные файлы
    AWG_IF=awg0 AWG_CONF=/etc/amnezia/amneziawg/awg0.conf python3 check-client-config.py

Для каждого файла печатает Address/Endpoint/AllowedIPs/MTU/DNS, совпадение
PublicKey (из клиентского PrivateKey) и PresharedKey с серверным пиром,
возраст последнего handshake и вердикт:
  * перевыпускать конфиг        — ключи не совпадают с сервером;
  * проблема на устройстве      — конфиг валиден, но клиент не выходит;
  * туннель живой               — конфиг валиден и пир активен.
Ничего не меняет: только читает конфиги и вызывает `awg show`.
"""
import base64
import glob
import os
import subprocess
import sys
import time

IFACE = os.environ.get("AWG_IF", "awg0")
SRV_CONF = os.environ.get("AWG_CONF", "/etc/amnezia/amneziawg/awg0.conf")
STALE_HOURS = int(os.environ.get("STALE_HOURS", "3"))


def sh(*args):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=15).stdout
    except Exception as exc:  # noqa: BLE001
        print("! не удалось выполнить %s: %s" % (" ".join(args), exc))
        return ""


def server_peers():
    """pubkey -> {'psk', 'allowed', 'ip'} из серверного конфига."""
    peers, cur = {}, None
    with open(SRV_CONF, errors="ignore") as fh:
        for raw in fh:
            line = raw.strip()
            if line.startswith("["):
                cur = {} if line == "[Peer]" else None
                continue
            if cur is None or "=" not in line:
                continue
            key, val = (part.strip() for part in line.split("=", 1))
            if key == "PublicKey":
                cur["pub"] = val
                peers[val] = cur
            elif key == "PresharedKey":
                cur["psk"] = val
            elif key == "AllowedIPs":
                cur["allowed"] = val
                first = val.replace(",", " ").split()[0]
                cur["ip"] = first.split("/")[0]
    return peers


def live_state():
    """server-ip -> {'age_min', 'rx', 'tx'} по данным awg show."""
    hs = {}
    for line in sh("awg", "show", IFACE, "latest-handshakes").splitlines():
        parts = line.split("\t")
        if len(parts) >= 2:
            try:
                hs[parts[0]] = int(parts[1])
            except ValueError:
                hs[parts[0]] = 0
    tr = {}
    for line in sh("awg", "show", IFACE, "transfer").splitlines():
        parts = line.split("\t")
        if len(parts) >= 3:
            tr[parts[0]] = (parts[1], parts[2])
    ips = {}
    for line in sh("awg", "show", IFACE, "allowed-ips").splitlines():
        parts = line.split("\t")
        if len(parts) >= 2:
            first = parts[1].replace(",", " ").split()[0]
            ips[parts[0]] = first.split("/")[0]
    now = int(time.time())
    state = {}
    for pub, ip in ips.items():
        ts = hs.get(pub, 0)
        rx, tx = tr.get(pub, ("0", "0"))
        state[ip] = {
            "age_min": int((now - ts) / 60) if ts else None,
            "rx": rx,
            "tx": tx,
        }
    return state


def parse_client(path):
    fields = {}
    cur = ""
    with open(path, errors="ignore") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("["):
                cur = line.strip("[]").strip().lower() + "."
                continue
            if "=" not in line:
                continue
            key, val = (part.strip() for part in line.split("=", 1))
            fields.setdefault(key, val)
            fields[cur + key] = val
    return fields


def pubkey_of(priv):
    """PublicKey из приватника. None = вычислить НЕ удалось (не «не тот ключ»).

    `awg pubkey`/`wg pubkey` читают ключ со STDIN и не принимают путь к файлу:
    вызов `awg pubkey /tmp/pr` печатает Usage и пустоту. Пустой ответ — отказ
    инструмента, а не признак чужого пира, поэтому есть резервный расчёт X25519,
    а при неудаче возвращается None, чтобы вердикт был «проверить вручную»,
    а не ложное «перевыпускать конфиг».
    """
    priv = priv.strip()
    if not priv:
        return None
    for cmd in (["awg", "pubkey"], ["wg", "pubkey"]):
        try:
            out = subprocess.run(
                cmd, input=priv + "\n", capture_output=True, text=True, timeout=15
            )
            got = out.stdout.strip()
            if len(got) == 44 and "Usage" not in got:
                return got
        except Exception:  # noqa: BLE001
            pass
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey

        raw = base64.b64decode(priv + "=" * (-len(priv) % 4))
        key = X25519PrivateKey.from_private_bytes(raw)
        return base64.b64encode(
            key.public_key().public_bytes(
                serialization.Encoding.Raw, serialization.PublicFormat.Raw
            )
        ).decode()
    except Exception:  # noqa: BLE001
        return None


def human_bytes(num):
    val = float(num or 0)
    for unit in ("B", "K", "M", "G", "T"):
        if val < 1024:
            return "%.1f%s" % (val, unit)
        val /= 1024
    return "%.1fP" % val


def check(path, peers, state):
    f = parse_client(path)
    priv = f.get("PrivateKey", "")
    addr = f.get("Address", "?")
    allowed = f.get("AllowedIPs", "?")
    ip = addr.split(",")[0].strip().split("/")[0]
    print("=== %s ===" % path)
    print("  Address    : %s" % addr)
    print("  Endpoint   : %s" % f.get("Endpoint", "?"))
    print("  AllowedIPs : %s" % allowed)
    print("  MTU        : %s   DNS: %s" % (f.get("MTU", "(не задан)"), f.get("DNS", "(не задан)")))
    if not priv:
        print("  ВЕРДИКТ    : нет PrivateKey — это не клиентский конфиг")
        return
    pk = pubkey_of(priv)
    if pk is None:
        print("  PublicKey  : вычислить из PrivateKey не удалось (отказ инструмента)")
        print("  ВЕРДИКТ    : НЕ приговор конфигу — пересчитать ключ вручную и повторить")
        return
    peer = peers.get(pk)
    if peer is None:
        print("  PublicKey  : %s… НЕ найден среди серверных пиров" % pk[:12])
        print("  ВЕРДИКТ    : конфиг не совпадает с сервером → перевыпускать")
        return
    psk_ok = (not peer.get("psk") and not f.get("PresharedKey")) or peer.get("psk") == f.get("PresharedKey")
    print("  PublicKey  : %s… совпадает с серверным пиром" % pk[:12])
    print("  PresharedKey: %s" % ("совпадает" if psk_ok else "НЕ СОВПАДАЕТ"))
    if not psk_ok:
        print("  ВЕРДИКТ    : конфиг не совпадает с сервером → перевыпускать")
        return
    if "::/0" in allowed and ":" not in addr:
        print("  ВНИМАНИЕ   : AllowedIPs с ::/0, но IPv6-адреса в Address нет —")
        print("               IPv6 уходит в туннель в чёрную дыру (сайты с AAAA не открываются)")
    live = state.get(ip)
    if live is None:
        print("  Сервер     : адрес %s не числится за пирами %s" % (ip, IFACE))
        print("  ВЕРДИКТ    : сверить Address с серверным AllowedIPs (не ключи)")
        return
    age = live["age_min"]
    print("  Сервер     : %s  rx=%s tx=%s" % (ip, human_bytes(live["rx"]), human_bytes(live["tx"])))
    if age is None:
        print("  Handshake  : ни одного не было")
        print("  ВЕРДИКТ    : конфиг валиден, устройство ни разу не выходило →")
        print("               импорт/приложение/выключен VPN, сервер ни при чём")
    elif age > STALE_HOURS * 60:
        print("  Handshake  : %s мин назад (%.1f сут)" % (age, age / 1440.0))
        print("  ВЕРДИКТ    : конфиг валиден, клиент давно не выходит → проблема на устройстве")
    else:
        print("  Handshake  : %s мин назад" % age)
        print("  ВЕРДИКТ    : конфиг валиден, туннель активен → искать прикладную причину")


def main():
    peers = server_peers()
    state = live_state()
    files = sys.argv[1:] or sorted(glob.glob("/root/*.conf"))
    if not files:
        sys.exit("нет .conf для проверки")
    for path in files:
        check(path, peers, state)
        print()


if __name__ == "__main__":
    main()
