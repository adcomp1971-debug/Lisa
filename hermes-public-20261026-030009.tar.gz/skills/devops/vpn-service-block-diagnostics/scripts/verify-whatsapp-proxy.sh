#!/usr/bin/env bash
# verify-whatsapp-proxy.sh — проверка официального WA TCP-прокси (facebook/whatsapp_proxy)
# Usage: bash verify-whatsapp-proxy.sh [bind_ip] [public_ip]
# Дефолты: bind 10.9.0.1, public — автодетект внешнего IPv4.
set -u
BIND="${1:-10.9.0.1}"
PUB="${2:-$(curl -s -4 -m 5 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')}"
fail=0

echo "== container =="
docker ps --filter name=whatsapp-proxy --format '{{.Names}} {{.Status}}' || { echo "NO CONTAINER"; exit 1; }

echo "== backends (HAProxy stats :8199) =="
curl -s -m 8 "http://$BIND:8199/;csv" | awk -F, 'NR>1 && $2!="FRONTEND" && $2!="BACKEND" && NF>20 {print $1"/"$2": "$18}' \
  | tee /tmp/wa-proxy-backends.txt
grep -q UP /tmp/wa-proxy-backends.txt || { echo "BACKENDS DOWN"; fail=1; }

echo "== media E2E: TLS через $BIND:587 -> whatsapp.net:443 =="
echo | timeout 10 openssl s_client -connect "$BIND:587" -servername www.whatsapp.net 2>/dev/null \
  | grep -E 'subject=|Verify return code' || { echo "MEDIA E2E FAIL"; fail=1; }

echo "== chat TCP connect =="
for p in 5222 7777; do
  timeout 5 bash -c "echo > /dev/tcp/$BIND/$p" 2>/dev/null && echo "$BIND:$p OK" || { echo "$BIND:$p FAIL"; fail=1; }
done

echo "== public exposure (должно быть closed!) =="
for p in 5222 587 7777; do
  timeout 5 bash -c "echo > /dev/tcp/$PUB/$p" 2>/dev/null \
    && { echo "WARNING: $PUB:$p OPEN НАРУЖУ"; fail=1; } \
    || echo "$PUB:$p closed OK"
done

[ $fail -eq 0 ] && echo "ALL CHECKS PASSED" || echo "FAILURES PRESENT"
exit $fail
