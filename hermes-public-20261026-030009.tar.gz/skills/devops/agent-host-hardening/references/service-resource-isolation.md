# Изоляция ресурсов на одном хосте (cgroups)

Задача: тяжёлая задача (индексация, эмбеддинги, длинный скрипт, много субагентов) не должна уронить клиентские сервисы (VPN, клиентские боты, gateway).

## Почему не «убивать постфактум»

Сторожевые скрипты, которые убивают процессы после того, как load вырос, действуют уже после ущерба: шлюз успел отвалиться, Telegram polling деградировал. Правильнее ограничить заранее.

## Техника

`systemctl set-property` применяется к уже запущенному сервису НА ЛЕТУ (пишет drop-in в `/etc/systemd/system/<unit>.d/`), рестарт не нужен:

```bash
# Тяжёлые/экспериментальные: жёсткие потолки
systemctl set-property hermes-gateway.service      CPUQuota=300% MemoryMax=6G TasksMax=2000
systemctl set-property mlflow-server.service       CPUQuota=100% MemoryMax=2G
systemctl set-property omniroute.service           CPUQuota=75%  MemoryMax=768M
systemctl set-property hermes-dashboard.service    CPUQuota=50%  MemoryMax=1G

# Критичные: приоритет, а не потолок
systemctl set-property awg-quick@awg0.service   CPUWeight=1000
systemctl set-property vpnbot.service           CPUWeight=500 MemoryMin=64M
systemctl set-property liskaanka-bot.service    CPUWeight=500 MemoryMin=64M
systemctl set-property hermetist-web.service    CPUWeight=500 MemoryMin=64M
```

## Семантика (не путать)

- `CPUQuota` — жёсткий потолок в процентах ОДНОГО ядра: `300%` = до трёх ядер. Применять к тому, что может разожраться.
- `CPUWeight` — относительный приоритет (по умолчанию 100), НЕ потолок: критичный сервис всё равно может занять простаивающие ядра. Так и надо — это защита «в час пик», а не троттлинг.
- `MemoryMax` — жёсткий предел: при превышении ядро убьёт процесс (OOM). Ставить с запасом от реального потребления, иначе получится самоубийство сервиса.
- `MemoryMin` — защищённый минимум для критичного сервиса под давлением памяти.
- `TasksMax` — предел числа процессов/потоков: защита от расползания субагентов и MCP-детей.

## Проверка

```bash
# что видит systemd
for s in hermes-gateway mlflow-server omniroute awg-quick@awg0; do
  printf "%-20s CPU=%s RAM=%s weight=%s\n" "$s" \
    "$(systemctl show $s -p CPUQuotaPerSecUSec --value)" \
    "$(systemctl show $s -p MemoryMax --value)" \
    "$(systemctl show $s -p CPUWeight --value)"
done

# что видит ядро (истина в cgroup)
cat /sys/fs/cgroup/system.slice/hermes-gateway.service/memory.max
cat /sys/fs/cgroup/system.slice/hermes-gateway.service/cpu.max      # "300000 100000" = 300%
```

**Обязательный шаг после применения — проверить, что клиенты не пострадали:**
```bash
systemctl is-active hermes-gateway vpnbot liskaanka-bot hermetist-web
awg show awg0 | grep -c 'peer:'          # число пиров не изменилось
awg show awg0 | grep 'latest handshake' | head -3   # handshake свежий = клиенты онлайн
uptime | awk -F'load average:' '{print $2}'
free -h | head -2
```

## Практические грабли

- Лимит на gateway ставить щедро (например 6G при текущем потреблении ~3G): слишком тесный `MemoryMax` = OOM-kill самого агента.
- Названия юнитов проверять фактически (`systemctl list-units | grep -i <имя>`) — в скриптах и документации они расходятся с реальностью чаще, чем кажется.
- `nice` и `CPUWeight` не ограничивают потребление — это приоритет. Если нужен потолок, нужен `CPUQuota`.
- Правило «тяжёлое только на GPU-хосте, не на маленьком VPS» остаётся в силе: cgroups ограничивают ущерб, но не делают слабый хост пригодным для тяжёлых задач.
