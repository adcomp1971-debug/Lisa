# Ключи конфига, меняющие поведение агента

Таблица для аудита. Правило первое: **не верить имени настройки** — открыть реализацию в `/usr/local/lib/hermes-agent/` и прочитать, что возвращает функция.

| Ключ | Опасное значение | Верное значение | Как проверить |
|---|---|---|---|
| `delegation.subagent_auto_approve` | `true` — YOLO: субагенты сами одобряют опасные команды | `false` — ребёнок получает восстановимый отказ | `grep -rn subagent_auto_approve /usr/local/lib/hermes-agent/tools/delegate_tool_config.py` |
| `approvals` (вся секция) | отсутствует — политика берётся из дефолтов версии | `mode: smart` явно | `python3 -c "import yaml;print(yaml.safe_load(open('/root/.hermes/config.yaml')).get('approvals'))"` |
| `delegation.child_timeout_seconds` | больше `gateway.timeout` — ребёнок работает после того, как родитель сдался | ≤ конверта минус запас на доставку | сравнить значения в config.yaml арифметикой |
| сумма `providers.*.request_timeout_seconds` | больше конверта — хвост fallback недостижим | вся цепочка влезает в конверт | сложить таймауты main + fallback и сравнить с `gateway.timeout` |
| `compression.target_ratio` | 0.2 — мало для восстановления смысла | 0.35-0.5 | `python3 -c "import yaml;print(yaml.safe_load(open('/root/.hermes/config.yaml'))['compression'])"` |
| `compression.protect_first/protect_last` | слишком мало — важное в середине вырезается | помнить, что защита ПОЗИЦИОННАЯ, а не смысловая | — |
| `plugins.<memory-store>.auto_extract` | `true` — мусор из RAG/писем/MCP становится «фактом» навсегда | `false` без фильтра по источнику | посмотреть секцию `plugins` в config.yaml |
| `providers.<name>.stale_timeout_seconds` | малое значение для reasoning-модели — легитимное думание выглядит как зависание | измерять время до первого токена и ставить с запасом | `python3 -c "import yaml;d=yaml.safe_load(open('/root/.hermes/config.yaml'));print({k:{kk:vv for kk,vv in v.items() if 'timeout' in kk} for k,v in d['providers'].items()})"` |
| `web.search_backend` / `web.extract_backend` | указан бэкенд, который в этой сборке не резолвится | проверить живым поиском, а не наличием ключа | один реальный поисковый запрос |
| `security.redact_secrets` | считается «политикой передачи данных» | это только маскирование в логах, не обезличивание исходящего контекста | — |

## Про проверку

`yaml.safe_load` доказывает только синтаксис. Он НЕ доказывает, что ключ поддерживается установленной версией и что он применился. Для каждого поведенческого ключа после рестарта — один реальный пробник:

- `approvals`/`subagent_auto_approve` → защищённая операция должна быть отклонена (а не молча пройти);
- `delegation.*` → делегировать тестовую задачу и убедиться, что ребёнок завершился и вернул результат;
- `auxiliary.vision` → прогнать изображение и получить непустой разбор;
- `compression` → дождаться/форсировать сжатие и проверить, что правила не пропали;
- fallback → `scripts/probe_routing.py` или равный пробник живыми запросами по каждому звену.

Только после пробника можно что-то называть работающим — и окончательное слово всё равно за пользователем.
