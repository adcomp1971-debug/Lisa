#!/usr/bin/env python3
"""Полный аудит хоста Hermes внешней сильной моделью (по умолчанию gpt-6-astra).

READ-ONLY: система не меняется — только чтение файлов/команд, ОДИН запрос к API,
сырой отчёт в <AUDIT_DIR>/astra-audit.md. Отправка файла Алексу — ТОЛЬКО по SEND=1:
аудит/ревью по умолчанию отдаётся инлайн (см. file-delivery-workflow), файл — только
если Алекс явно попросил.

Порядок работы:
  1) DRY_RUN=1 python3 astra-full-audit.py     # собрать промпт, БЕЗ вызова API (проверить размер/маскировку)
  2) python3 astra-full-audit.py                # реальный прогон — фоново, с notify

Переменные окружения:
  HERMES_HOME  (по умолчанию /root/.hermes)
  AUDIT_DIR    (по умолчанию <HERMES_HOME>/audit/<YYYYMMDD>)
  MODEL        (по умолчанию gpt-6-astra)
  DRY_RUN      =1 — только собрать промпт
  NO_SEND      (устарело — отправка теперь opt-in)
  SEND         =1 — отправить отчёт файлом в Telegram (по умолчанию только сохранить)
  INPUT_LIMIT  — сколько символов AGENTS.md класть в пакет (по умолчанию 30000)
  MAX_TOKENS   — max_completion_tokens (по умолчанию 8000)
"""
import json
import os
import subprocess
import urllib.request
from datetime import datetime, timezone

BASE = os.environ.get("HERMES_HOME", "/root/.hermes")
AUDIT_DIR = os.environ.get(
    "AUDIT_DIR", os.path.join(BASE, "audit", datetime.now(timezone.utc).strftime("%Y%m%d"))
)
MODEL = os.environ.get("MODEL", "gpt-6-astra")
INPUT_LIMIT = int(os.environ.get("INPUT_LIMIT", "30000"))
MAX_TOKENS = int(os.environ.get("MAX_TOKENS", "8000"))
os.makedirs(AUDIT_DIR, exist_ok=True)


def sh(cmd, timeout=90):
    """Выполнить read-only команду, вернуть stdout (ошибки — строкой, не исключением)."""
    try:
        return subprocess.run(cmd, shell=True, capture_output=True, text=True,
                              timeout=timeout).stdout.strip()
    except Exception as e:  # noqa: BLE001
        return f"[err: {e}]"


def read(path, limit=None):
    try:
        s = open(path, encoding="utf-8", errors="replace").read()
        return s if limit is None else s[:limit]
    except Exception as e:  # noqa: BLE001
        return f"[err: {e}]"


def env(name):
    for line in read(f"{BASE}/.env").splitlines():
        if line.startswith(name + "="):
            return line.split("=", 1)[1].strip().strip('"').strip("'")
    return ""


def scrub(o, depth=0):
    """Рекурсивно затереть значения ключей, похожих на секреты. Наружу — только признак наличия."""
    if depth > 8:
        return o
    if isinstance(o, dict):
        return {k: ("***SET***" if any(t in str(k).lower() for t in
                                       ("key", "token", "secret", "password", "passwd"))
                    else scrub(v, depth + 1)) for k, v in o.items()}
    if isinstance(o, list):
        return [scrub(v, depth + 1) for v in o]
    return o


def config_slice():
    import yaml
    c = yaml.safe_load(read(f"{BASE}/config.yaml")) or {}
    keep = ["model", "fallback_providers", "delegation", "auxiliary", "compression",
            "memory", "mcp_servers", "providers", "security", "approvals", "terminal",
            "web", "tools", "skills", "cron", "tts", "logging", "plugins"]
    return json.dumps(scrub({k: c[k] for k in keep if k in c}), ensure_ascii=False, indent=1)


def system_facts():
    return "## Системные факты (живьём)\n```\n" + "\n".join([
        "date: " + sh("date -u"),
        "uptime: " + sh("uptime"),
        "disk: " + sh("df -h / | tail -1"),
        "mem: " + sh("free -h | sed -n '1,3p'"),
        "top_rss: " + sh("ps aux --sort=-rss | sed -n '2,7p' | awk '{print $4\"% \"$6\" \"$11}'"),
        "hermes_version: " + sh("hermes --version 2>&1 | head -2"),
        "state_db: " + sh(f"ls -la {BASE}/state.db {BASE}/state.db-wal 2>/dev/null"),
        "du: " + sh(f"du -sh {BASE}/state.db {BASE}/logs {BASE}/sessions {BASE}/cache {BASE}/skills 2>/dev/null"),
        "skills_count: " + sh(f"find {BASE}/skills -name SKILL.md -not -path '*/.archive/*' | wc -l"),
        "memory_sizes: " + sh(f"python3 -c \"print('MEMORY', len(open('{BASE}/memories/MEMORY.md',encoding='utf-8').read())); print('USER', len(open('{BASE}/memories/USER.md',encoding='utf-8').read()))\""),
        "sessions_count: " + sh(f"ls {BASE}/sessions | wc -l"),
    ]) + "\n```"


def log_errors():
    """Топ ошибок: время вырезано, числа нормализованы — иначе каждый вариант уникален."""
    cmd = (f"grep -hE 'ERROR|CRITICAL|Traceback|timeout|402|429' {BASE}/logs/*.log {BASE}/agent.log* 2>/dev/null "
           "| sed -E 's/[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9:.,]+//' | sed -E 's/[0-9]{2,}/N/g' "
           "| sort | uniq -c | sort -rn | head -25")
    return "## Топ ошибок в логах за 7 дней\n```\n" + sh(cmd) + "\n```"


def build_prompt():
    return f"""Ты — внешний аудитор персонального ИИ-агента Hermes Agent (Nous Research) на прод-сервере.

ЗАДАЧА: полный аудит и приоритизированный план чистки/оптимизации по четырём областям.
1. ПАМЯТЬ (все слои): MEMORY.md, USER.md, AGENTS.md, архитектурные .md. Найти дубли, противоречия,
   устаревшее, процедуры, которые должны жить в скиллах, а не в памяти; разделить «факт для каждой
   сессии» vs «лог/история».
2. СКИЛЛЫ (активные + архив): дубли-кластеры, кандидаты в архив, внутренние дубли в жирных SKILL.md.
   Список защищённых скиллов трогать нельзя.
3. СИСТЕМА: что тормозит или может сломать агента; размеры БД/логов/сессий, swap, сервисы, cron.
4. ПРАВИЛА/БЕЗОПАСНОСТЬ: противоречия между правилами, опасные разрешения, что ужесточить.

ФОРМАТ ОТВЕТА (строго, без вступлений и вежливости):
## P0 — критично (сделать сразу)
## P1 — важно
## P2 — можно потом
Для каждого пункта: что именно (конкретные файлы/записи/скиллы), почему, что делать (конкретное
действие), ожидаемый эффект (символы/МБ/токены/риск).
## Что удалить из памяти (по идентификатору начала записи)
## Что удалить/архивировать из скиллов
## Что НЕ трогать и почему
## Итог: оценка экономии и 3 главных действия

Будь конкретен и приземлён: лишних ресурсов нет, каждое предложение должно быть исполнимо на этом
хосте. Не предлагай переустановки и миграции без нужды.

=== ДАННЫЕ ===

{system_facts()}

## Cron-джобы
```
{sh('hermes cron list 2>&1 | head -60')}
```

## Failed-юниты и ключевые сервисы
```
{sh('systemctl --failed --no-legend | head -20; echo ---; systemctl is-active hermes-gateway 2>&1')}
```

{log_errors()}

## config.yaml (секреты вычищены)
```yaml
{config_slice()}
```

## MEMORY.md (разделитель §)
```
{read(f'{BASE}/memories/MEMORY.md')}
```

## USER.md
```
{read(f'{BASE}/memories/USER.md')}
```

## AGENTS.md
```
{read(f'{BASE}/AGENTS.md', INPUT_LIMIT)}
```

## Инвентарь скиллов (use_count, дата последнего использования)
```
{read(os.path.join(AUDIT_DIR, 'skills-inventory.txt'))}
```
"""


def main():
    prompt = build_prompt()

    if os.environ.get("DRY_RUN"):
        p = os.path.join(AUDIT_DIR, "astra-prompt.txt")
        open(p, "w", encoding="utf-8").write(prompt)
        print(f"DRY_RUN: промпт {len(prompt)} символов -> {p}")
        return

    key = env("OPENAI_API_KEY")
    if not key:
        raise SystemExit("OPENAI_API_KEY не найден в .env")

    body = json.dumps({
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "Ты — старший инженер-аудитор. Отвечай по-русски, конкретно, "
                                           "без воды и комплиментов. Только факты, находки и действия."},
            {"role": "user", "content": prompt},
        ],
        "max_completion_tokens": MAX_TOKENS,
    }).encode()

    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
    )
    started = datetime.now(timezone.utc).isoformat()
    with urllib.request.urlopen(req, timeout=900) as r:
        resp = json.loads(r.read())

    text = resp["choices"][0]["message"]["content"]
    usage = resp.get("usage", {})
    path = os.path.join(AUDIT_DIR, "astra-audit.md")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# Аудит Hermes моделью {MODEL}\n\n- старт: {started}\n- usage: {usage}\n"
                f"- размер входа: {len(prompt)} символов\n\n---\n\n{text}\n")

    if os.environ.get("SEND") == "1":
        sh(f"python3 /root/send_file.py {path} 'Аудит Hermes от {MODEL}' 2>&1 | tail -2", timeout=120)
    else:
        print(f"Отчёт сохранён: {path} — вывести ключевые находки инлайн; файл только по явной просьбе (SEND=1)")


if __name__ == "__main__":
    main()
