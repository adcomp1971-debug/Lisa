---
name: mcp-troubleshooting
description: "Диагностика и фикс проблем с MCP серверами: AgentMail, Firecrawl, и другие stdio MCP."
version: 1.0.0
author: Alex
---

# MCP Server Troubleshooting

## AgentMail MCP — типовой сбой

**Симптом:** MCP сервер не подключается, "Cannot find module @modelcontextprotocol/sdk"

**Диагностика:**
1. Проверить SDK: `ls /root/.nvm/versions/node/v24.15.0/lib/node_modules/@modelcontextprotocol/sdk/`
2. Проверить bridge: `ls /root/.hermes/scripts/agentmail-stdio-bridge.mjs`
3. Проверить config.yaml: `grep -A10 'agentmail:' /root/.hermes/config.yaml`
4. Проверить ключ в .env: `grep AGENTMAIL /root/.hermes/.env`

**Фикс (проверено 2026-07-26, работает):**
```yaml
mcp_servers:
  agentmail:
    command: node
    args:
    - /root/.nvm/versions/node/v24.15.0/lib/node_modules/agentmail-mcp/build/index.js
    enabled: true
    env:
      AGENTMAIL_API_KEY: <реальный ключ из /root/.hermes/.env, 70 символов>
```

**Причины (были две):**
1. В Hermes MCP env vars не резолвятся из .env — `${AGENTMAIL_API_KEY}` передаётся как literal string. Нужно вписать ключ напрямую.
2. ⚠️ В config.yaml ключ оказался МАСКИРОВАННЫМ (`am_us_...98be`, 13 символов) — видимо после аудита/редакции. Сервер стартовал и молча умирал → "Connection closed". Проверять длину ключа: `awk '/AGENTMAIL_API_KEY/ {print length($0)}' config.yaml` — должно быть ~70+, не 38.
3. `npx -y agentmail-mcp` давал пустой stdout при handshake — заменён на прямой вызов `node <path>/build/index.js`, это детерминированно работает.

**Верификация handshake (без рестарта gateway):** используй `scripts/mcp-stdio-probe.sh` из этого скилла — шлёт initialize + tools/list, печатает список tools, exit 1 при пустом stdout (stderr сервера → /tmp/mcp-probe-stderr.log). Работает для ЛЮБОГО stdio MCP, не только agentmail:
```bash
AGENTMAIL_API_KEY=$(grep '^AGENTMAIL_API_KEY=' /root/.hermes/.env | cut -d= -f2-) \
  bash /root/.hermes/skills/devops/mcp-troubleshooting/scripts/mcp-stdio-probe.sh \
  node /root/.nvm/versions/node/v24.15.0/lib/node_modules/agentmail-mcp/build/index.js
# Ожидается: TOOLS OK (25): list_inboxes ... select_organization
```
Ручной вариант (если скрипт недоступен):
```bash
export AGENTMAIL_API_KEY=$(grep '^AGENTMAIL_API_KEY=' /root/.hermes/.env | cut -d= -f2-)
printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"t","version":"1"}}}' \
'{"jsonrpc":"2.0","method":"notifications/initialized"}' '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' \
| timeout 20 node /root/.nvm/versions/node/v24.15.0/lib/node_modules/agentmail-mcp/build/index.js
```

## Firecrawl — credit exhaustion

**Симптом:** web_extract возвращает "Payment Required: Insufficient credits"

**Fallback:** browser_navigate + browser_snapshot(full=true) вместо web_extract. Не повторять web_extract — переключаться на browser сразу.

## Firecrawl MCP — node v20 EBADENGINE (2026-08-15)

**Симптом:** в mcp-stderr.log: `npm error EBADENGINE ... @mendable/firecrawl-js@4.25.2 ... Required: {"node":">=22.0.0"} ... Actual: node v20.20.2`. MCP паркуется/падает каждые ~5 мин, инструменты firecrawl недоступны, хотя API жив (curl api.firecrawl.dev → 200).

**Причина:** `command: npx` в config.yaml резолвится на системный Node v20 (`/usr/bin/node`), когда gateway стартует с PATH без nvm-каталога (после ребута или при запуске из-под systemd-окружения). В терминале node v24 — поэтому «вручную работает, а у gateway нет».

**Фикс — явный путь npx в config.yaml** (не полагаться на PATH):
```yaml
mcp_servers:
  firecrawl:
    command: /root/.nvm/versions/node/v24.15.0/bin/npx   # ← вместо "npx"
    args:
    - firecrawl-mcp
    enabled: true
    env:
      FIRECRAWL_API_KEY: ${FIRECRAWL_API_KEY}
```
Проверка: `node --version` должен быть v24 (не v20), после правки — рестарт gateway (только Алекс).

## web_search backend `brave` не резолвится (2026-08-24)

**Симптом:** встроенный `web_search` → `web is configured to use 'brave' ... no registered web search provider has that name`. MCP `brave-search` при этом `✓ enabled`.

**Причина:** `config.yaml` `web.search_backend: brave` — строка не совпадает с именем зарегистрированного built-in провайдера. MCP и built-in web — разные реестры.

**Обход:** звать MCP напрямую (`mcp__brave_search__brave_web_search` / `brave_news_search` / `brave_llm_context`). Чинить имя бэкенда в config.yaml только после сверки `hermes tools` + рестарт gateway (Алекс). Не ретраить web_search — ошибка детерминированная.

## Плагины (не MCP, но тот же класс «внезапно отвалилось») — deprecated import paths

**Симптом (2026-09-14):** в `~/.hermes/.plugin-compat-report.json` и выводе `hermes plugins compat`:
`1 plugin DISABLED: they import paths removed on 2026-09-14: dynamic-workflows (3)`.
Плагин `plugins.enabled` в config.yaml, но не грузится: `hermes_dynamic_workflows/child/runner.py`
импортирует `tools.approval.set_current_session_key`, `tools.terminal_tool.cleanup_vm` — пути переехали
(`tools.approval_context.*`, `tools.terminal_tool_lifecycle.*`).

**Диагностика:**
```bash
hermes plugins compat     # таблица old path → new path по каждому плагину
hermes plugins list | grep -i <plugin>
cat /root/.hermes/.plugin-compat-report.json
```

**Что делать:**
1. Правильный путь — обновить плагин (правка импортов на новые пути).
2. `plugins.allow_deprecated_imports: true` — только как временная заглушка: compat-слой
   откатывается, и плагин умрёт окончательно. Ставить осознанно, а не «чтобы замолчало».
3. Не путать с реальной ошибкой MCP: tool-серверы (agentmail/firecrawl/brave/…) при этом живы.

**Шум в логе, не поломка:** `Plugin 'hermes-internal' has no register() function` — предупреждение
при каждой загрузке gateway; плагин отдаёт dashboard-ассеты, а не tools.

## Ограничение прав MCP-сервера: read-only доступ к БД

**Задача:** агенту нужен доступ к базе для диагностики (платежи, подписки, клиенты), но запись из агента недопустима — падение/галлюцинация не должно менять биллинг.

**Главный питфолл:** у популярных SQLite-MCP (в частности `mcp-server-sqlite-npx`) **НЕТ флага read-only** — проверено по исходникам пакета: регистрирует тулы `read_query` И `write_query`, открывает БД как `new sqlite3.Database(filename)` без `OPEN_READONLY`. Обёртки/флагов «только чтение» не искать.

**Рабочее решение — read-only снапшот:** MCP смотрит на отдельный файл-копию, живая БД агенту недоступна вообще.
```bash
# Безопасное согласованное копирование живой БД (SQLite Backup API, не блокирует писателя)
sqlite3 "file:/path/live.db?mode=ro" ".backup '/path/mcp-readonly.db.tmp'"   # фоллбэк: VACUUM INTO
chmod 444 '/path/mcp-readonly.db.tmp' && mv -f '/path/mcp-readonly.db.tmp' '/path/mcp-readonly.db'
sqlite3 "file:/path/mcp-readonly.db?mode=ro" "PRAGMA quick_check(1)"          # верификация
```
- В `config.yaml` путь MCP ведёт на снапшот; сам снапшот обновляет systemd-timer (30 мин достаточно для диагностических данных).
- Сверять количество строк в снапшоте и живой БД — если расходятся навсегда, снапшот не обновляется.
- **Не рассчитывать на права файла:** процесс MCP идёт от root, `chmod 444` его не остановит. Защищает именно то, что живая БД не смонтирована в MCP; любые записи агента уходят в снапшот и затираются следующим обновлением.
- `mode=ro` в URI — обязателен для любого внешнего чтения живой БД (см. правила про state.db).

## Python-MCP: сначала интерпретатор и версия SDK, потом логи

Локальный stdio-MCP на Python ломается по трём независимым причинам — проверять по порядку, каждая видна в `mcp-stderr.log`:

1. **`ModuleNotFoundError: No module named 'mcp'`** — ⚠️ ИСПРАВЛЕНО 2026-09-28: явный интерпретатор в `config.yaml` (`command: /usr/local/lib/hermes-agent/venv/bin/python3`) НЕ помогает. После смены runtime-поколения Hermes (25.09.2026, `~/.hermes/tools/python-3.14.7+…`) шлюз запускает python-MCP своим managed-интерпретатором БЕЗ site-packages, игнорируя указанный в конфиге путь (в `ps` легко убедиться: процесс сервера = `~/.hermes/tools/python-3.14…/bin/python3 <script>`). Проверка: `ps -eo pid,cmd | grep -i '<имя-сервера>'`.
   **Рабочий фикс — guard внутри самого скрипта** (проверено вживую на tavily 2026-09-28: сервер поднялся, но в `mcp-stderr.log` ещё 55 минут висели старые трacебеки — смотреть на ВРЕМЯ новой попытки, а не на хвост файла):
   ```python
   _NEEDED = ("mcp", "tavily")   # модули, без которых сервер не живёт

   def _ensure_runtime():
       import glob, os, subprocess, sys
       def _ok(exe):
           try:
               return subprocess.run([exe, "-c", "import " + ", ".join(_NEEDED)],
                                     capture_output=True, timeout=30).returncode == 0
           except Exception:
               return False
       if _ok(sys.executable):
           return
       cands = ["/usr/local/lib/hermes-agent/venv/bin/python"]
       cands += sorted(glob.glob("/root/.hermes/installs/*/environments/*/venv/bin/python"))
       for exe in cands:
           if os.path.exists(exe) and os.path.realpath(exe) != os.path.realpath(sys.executable) and _ok(exe):
               os.execv(exe, [exe, os.path.abspath(__file__)] + sys.argv[1:])
       raise SystemExit("cron-runtime guard: нет интерпретатора с %s" % (", ".join(_NEEDED),))

   _ensure_runtime()   # ВЫЗВАТЬ до импорта mcp/tavily
   ```
   `os.execv` сохраняет stdio — для stdio-MCP безопасно. Супервизор Hermes сам перезапускает упавший сервер каждые ~5 мин, так что фикс подхватывается без рестарта gateway; успех = новый процесс в `ps` + отсутствие НОВОГО трейсбека после времени последней попытки.
2. **`AttributeError: 'Server' object has no attribute 'list_tools'`** — скрипт написан под mcp 1.x (`@server.list_tools()` / `@server.call_tool()`), а в venv SDK 2.x: у низкоуровневого `Server` остались только `add_request_handler` / `create_initialization_options` / `run` / `streamable_http_app`, а `mcp.server.fastmcp` в 2.x отсутствует. Версию смотреть ДО правки конфига: `venv/bin/pip show mcp`. Смена интерпретатора такой сервер не оживит — это другой слой.
   **Рабочий шаблон под mcp 2.0** (проверен E2E 2026-09-28 — handshake + `tools/list` + `tools/call` с реальным ответом Tavily):
   ```python
   from mcp.server import MCPServer        # не Server/fastmcp: их декораторов в 2.0 нет
   mcp = MCPServer("tavily")

   @mcp.tool()
   def tavily_search(query: str, max_results: int = 5) -> str:
       """Description (первая строка docstring) + Args: секция — из них SDK собирает схему."""
       ...
       return text                        # str/лист[str] — не готовый TextContent

   if __name__ == "__main__":
       mcp.run(transport="stdio")
   ```
   Проверка без gateway: клиент mcp из venv — `StdioServerParameters(command=<голый python3>, args=[<копия скрипта в /tmp>], env=dict(os.environ))` → `ClientSession.initialize()` → `list_tools()` → `call_tool(...)`. **Питфолл:** без `env=dict(os.environ)` stdio-клиент отдаёт серверу минимальное окружение и тул возвращает «API key not set» — выглядит как баг сервера, а это артефакт пробника.
3. **Клиент отдаёт `ValidationError … CallToolResult … content Field required`, хотя сервер поднялся** — самописный JSON-RPC сервер возвращает payload прямо в `result`, без обязательного `content[]`. В хендлере `tools/call` оборачивать результат: `{"content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False, default=str)}], "isError": False}` (в `initialize` и `tools/list` формат свой, обёртка там ломает handshake).

Что делать с 1.x-сервером на SDK 2.x: отдельный venv с `mcp<2` (быстро, скрипт не трогаем), либо переписать на актуальный API, либо — если функцию уже закрывают живые серверы (brave-search, firecrawl) — выключить (`enabled: false`) и сказать пользователю, что дубль не нужен. Фактическая проверка без рестарта gateway — тем же stdio-пробником с добавленным `tools/call`. Детали, код обёртки и smoke-рецепт: `references/python-mcp-contract.md`.

## Общая диагностика MCP
1. `hermes mcp list` — проверить какие сервера зарегистрированы
2. `journalctl -u hermes-gateway --since '1 hour ago' | grep 'MCP server'` — найти ошибки подключения
3. Если stdio MCP падает — проверить команду и аргументы в config.yaml, запустить вручную из terminal
