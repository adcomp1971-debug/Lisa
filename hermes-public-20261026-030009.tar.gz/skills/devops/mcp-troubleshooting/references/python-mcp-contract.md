# Контракт Python-MCP-серверов (stdio, JSON-RPC)

Класс: локальные серверы вида `mcp_servers.<name>` → `command: <python>`, `args: [<script>.py]`.

## 1. Каким питоном запускать

Скриптовый MCP обязан запускаться интерпретатором Hermes:

```yaml
mcp_servers:
  <name>:
    command: /usr/local/lib/hermes-agent/venv/bin/python3   # НЕ "python3"
    args:
    - /root/.hermes/scripts/<name>_mcp_server.py
    enabled: true
```

Системный `python3` не содержит ни `mcp`, ни `PyYAML`. Симптом в `~/.hermes/logs/mcp-stderr.log`:
`ModuleNotFoundError: No module named 'mcp'` — по одной строке на каждую попытку переподключения (сотни за сутки).

## 2. Версия SDK диктует API

```bash
/usr/local/lib/hermes-agent/venv/bin/pip show mcp | head -2
/usr/local/lib/hermes-agent/venv/bin/python3 -c "from mcp.server import Server; print([m for m in dir(Server) if not m.startswith('_')])"
```

- **mcp 1.x** — низкоуровневый API с декораторами `@server.list_tools()` / `@server.call_tool()`, плюс `mcp.server.fastmcp.FastMCP`.
- **mcp 2.x** — декораторов у низкоуровневого `Server` нет; доступны `add_request_handler`, `add_notification_handler`, `create_initialization_options`, `get_capabilities`, `run`, `server_info`, `session_manager`, `streamable_http_app`. Модуля `mcp.server.fastmcp` в поставке нет (FastMCP вынесен отдельно).

Сервер, написанный под 1.x, на 2.x падает ещё до handshake:
`AttributeError: 'Server' object has no attribute 'list_tools'`. Это класс «код под старый SDK», а не «сервер сломался» — починка интерпретатора или конфига не помогает.

Варианты решения, по возрастанию цены:

1. Выключить сервер (`enabled: false`), если его функцию закрывают живые MCP — на этом хосте поиск уже дают `brave-search`, `firecrawl` и встроенный web-провайдер.
2. Отдельный venv на `mcp<2` и путь к его питону в `command` — скрипт не трогаем.
3. Переписать на актуальный API (или отдельный пакет FastMCP) — если сервер уникален и нужен.

## 3. Контракт результата: content[] обязателен

Ответ на `tools/call` валидируется клиентом как `CallToolResult` с обязательным полем `content`. Сервер, отдающийpayload напрямую, выглядит живым, но каждый вызов падает у клиента:

```
MCP call failed: ValidationError: 1 validation error for CallToolResult
content
  Field required [type=missing, input_value={'sessions': [...]}]
```

Правильный ответ — обёртка в самом хендлере `tools/call`, до отправки:

```python
def send_tool_result(request_id, payload):
    send_result(request_id, {
        "content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False, default=str)}],
        "isError": False,
    })
```

Замену `send_result` → `send_tool_result` делать ТОЛЬКО внутри хендлера `tools/call`.

## 4. Проверка живьём без рестарта gateway

```bash
printf '%s\n%s\n%s\n' \
  '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"smoke","version":"1"}}}' \
  '{"jsonrpc":"2.0","method":"notifications/initialized"}' \
  '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"<tool>","arguments":{}}}' \
| timeout 20 /usr/local/lib/hermes-agent/venv/bin/python3 <script>.py
```

Если сервер ждёт ключ — экспортировать его из `.env` перед прогоном (`export KEY=$(grep -m1 '^KEY=' /root/.hermes/.env | cut -d= -f2-)`).

Признаки разбора ответа:

- `id 1` → есть `protocolVersion` и `serverInfo` = handshake прошёл.
- `id 2` → в `result` есть `content[]`, и `json.loads(result.content[0].text)` парсится = контракт соблюдён.

Для node-серверов тот же приём упакован в `scripts/mcp-stdio-probe.sh`.

## 5. Порядок диагностики (не переставлять)

1. `grep -c "ModuleNotFoundError" ~/.hermes/logs/mcp-stderr.log` — какой сервер и как часто падает.
2. Строка `command:` этого сервера в `config.yaml` — правильный интерпретатор?
3. Версия SDK и наличие нужного API (см. §2).
4. Smoke-тест (§4) руками — только после этого трогать конфиг или код.
5. Правки конфига и патчи скриптов MCP въезжают в работу после рестарта gateway (рестарт — за пользователем).
