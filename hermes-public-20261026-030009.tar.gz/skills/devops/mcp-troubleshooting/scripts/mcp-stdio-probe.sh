#!/usr/bin/env bash
# mcp-stdio-probe.sh — verify a stdio MCP server answers initialize + tools/list.
# Use BEFORE restarting the gateway: proves command/args/env are correct.
#
# Usage:
#   ENV_VAR=value ... mcp-stdio-probe.sh <command> [args...]
# Example:
#   AGENTMAIL_API_KEY=$(grep '^AGENTMAIL_API_KEY=' /root/.hermes/.env | cut -d= -f2-) \
#     mcp-stdio-probe.sh node /root/.nvm/versions/node/v24.15.0/lib/node_modules/agentmail-mcp/build/index.js
#
# Exit 0 + "TOOLS OK (N)" on success; exit 1 + "PROBE FAILED" otherwise
# (server stderr is captured to /tmp/mcp-probe-stderr.log).
set -u
TIMEOUT="${MCP_PROBE_TIMEOUT:-20}"

printf '%s\n' \
  '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"mcp-probe","version":"1.0"}}}' \
  '{"jsonrpc":"2.0","method":"notifications/initialized"}' \
  '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' \
| timeout "$TIMEOUT" "$@" 2>/tmp/mcp-probe-stderr.log | python3 -c "
import sys, json
ok_init = ok_tools = False
for line in sys.stdin:
    try:
        d = json.loads(line)
    except Exception:
        continue
    if d.get('id') == 1 and 'result' in d:
        ok_init = True
        print('INIT OK:', d['result'].get('serverInfo'))
    if d.get('id') == 2 and 'result' in d:
        ok_tools = True
        tools = [t['name'] for t in d['result'].get('tools', [])]
        print(f'TOOLS OK ({len(tools)}):', ', '.join(tools))
if not (ok_init and ok_tools):
    print('PROBE FAILED — empty or invalid stdout; server stderr in /tmp/mcp-probe-stderr.log')
    sys.exit(1)
"
