# Дедуп алертов в cron-стороже (no_agent)

Зачем: `no_agent`-сторож доставляет stdout в Telegram на каждом тике. Сторож без состояния, который срабатывает по одной и той же причине (раздутый контекст, низкий баланс, забитый диск), начинает повторять одну и ту же строку — владелец читает это как поломку (жалоба на такой спам — сигнал переделать сторож, а не спорить). Понижение частоты до ежедневной снижает шум, но само по себе не решает: один и тот же «висящий» симптом будет напоминать о себе каждый день.

Правило: любой сторож, который может срабатывать много раз подряд по одной причине, держит состояние и подавляет повтор *того же самого* алерта, оставаясь полностью чувствительным к новому.

## Рабочая схема

```python
import hashlib, json, os
from datetime import datetime, timedelta, timezone

STATE = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "state", "<job>-state.json"))
REPEAT_HOURS = float(os.environ.get("<JOB>_REPEAT_HOURS", "72"))
REPEAT_GROWTH = float(os.environ.get("<JOB>_REPEAT_GROWTH", "1.5"))

now = datetime.now(timezone.utc).replace(tzinfo=None)   # наивный UTC — как в остальном скрипте
alerts = [...]                     # список строк алертов, пустой = тишина

if not alerts:
    return 0

sig = hashlib.sha1("|".join(alerts).encode()).hexdigest()[:16]
try:
    with open(STATE) as fh:
        prev = json.load(fh)
except Exception:
    prev = {}

if prev.get("sig") == sig:
    try:
        too_soon = (now - datetime.fromisoformat(prev["at"])) < timedelta(hours=REPEAT_HOURS)
    except Exception:
        too_soon = False
    prev_metric = float(prev.get("metric") or 0.0)
    grew = metric > prev_metric * REPEAT_GROWTH if prev_metric else True
    if too_soon and not grew:
        return 0          # тот же алерт, ничего не изменилось — молчим

print(...)                # сам алерт

os.makedirs(os.path.dirname(STATE), exist_ok=True)
with open(STATE, "wt") as fh:
    json.dump({"sig": sig, "at": now.isoformat(timespec="seconds"), "metric": round(metric, 4)}, fh)
```

## Ключевые решения

- **Сигнатуру брать по тексту алертов, а не по метрике.** Метрика колеблется в пределах шума (±цент), и любой её дрейф считался бы «новым событием»; изменённый *набор* симптомов (появилась новая сессия, новый порог) — настоящая новость.
- **Рост метрики — второй ключ к тому же замку.** Если расход/очередь реально ускоряется (в 1.5× и более от момента прошлого алерта), повтор уместен независимо от таймера — иначе подавится настоящий рост.
- **State-файл кладётся в `~/.hermes/state/`,** не рядом со скриптом и не в /tmp: он должен переживать рестарты и не уезжать в бэкапы кода.
- **Ошибки записи state не должны ломать job.** `except Exception: pass` + всегда `exit 0` — иначе cron отметит job упавшим и потеряет сам алерт.
- **Писать в state только когда алерт реально отправлен.** Иначе подавленное срабатывание сдвинет таймер.

## Проверка (обязательна перед «готово»)

```bash
python3 /root/.hermes/scripts/<job>.py; echo "exit=$?"   # 1-й прогон — алерт печатается
python3 /root/.hermes/scripts/<job>.py; echo "exit=$?"   # 2-й прогон — пустой stdout, exit 0
cat /root/.hermes/state/<job>-state.json                  # sig/at/metric записались
```

Для теста подавления без ожидания: увеличить метрику в state-файле или подправить SIG-сравнение вручную; чтобы сбросить и получить алерт снова — удалить state-файл.
