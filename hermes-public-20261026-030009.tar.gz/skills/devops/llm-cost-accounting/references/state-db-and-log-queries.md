# Запросы и парсеры для атрибуции LLM-расхода

Все запросы — read-only. Подключение:

```python
import sqlite3
c = sqlite3.connect("file:/root/.hermes/state.db?mode=ro", uri=True)
```

Живую БД при работающем gateway не открывать на запись/checkpoint/recover.

## Месяц целиком: объём и доля cache

```sql
SELECT SUM(input_tokens), SUM(output_tokens), SUM(cache_read_tokens), SUM(api_call_count), COUNT(*)
FROM sessions WHERE started_at > strftime('%s','now','-31 days');
```

## По источникам (telegram / cron / subagent / cli / api_server)

```sql
SELECT source, COUNT(*), SUM(api_call_count),
       SUM(input_tokens + cache_read_tokens) AS total_tk, SUM(output_tokens)
FROM sessions WHERE started_at > strftime('%s','now','-31 days')
GROUP BY source ORDER BY total_tk DESC;
```

## Сессии-пожиратели (сортировать по cache_read, не по input)

```sql
SELECT id, source, model, datetime(started_at,'unixepoch'),
       datetime(COALESCE(last_activity_at, ended_at),'unixepoch'),
       api_call_count, input_tokens, cache_read_tokens, output_tokens,
       message_count, ROUND(1.0*cache_read_tokens/NULLIF(api_call_count,0)) AS cache_per_call,
       title
FROM sessions ORDER BY cache_read_tokens DESC LIMIT 10;
```

`cache_per_call` = сколько контекста тащит один ход. Сотни тысяч → раздутый разговор, который рвётся новым чатом, а не сменой модели.

## Сессии по дню старта (осторожно: искажает для долгоживущих)

```sql
SELECT date(started_at,'unixepoch') AS day, source, COUNT(*),
       SUM(api_call_count), SUM(input_tokens), SUM(cache_read_tokens), SUM(output_tokens)
FROM sessions WHERE started_at > strftime('%s','now','-7 days')
GROUP BY day, source ORDER BY day DESC;
```

У долгоживущей сессии весь объём приписан дню СТАРТА — для честной картины по дням пользоваться парсером логов ниже.

## Почасовая/подневная реконструкция из логов агента

```python
import re, gzip, collections

pat = re.compile(r"^(\d{4}-\d{2}-\d{2}) (\d{2}):\d{2}:\d{2}.*?API call #\d+: model=(\S+).*?in=(\d+) out=(\d+).*?cache=(\d+)/(\d+)")
agg = collections.defaultdict(lambda: [0, 0, 0, 0, collections.Counter()])
for f in ["agent.log", "agent.log.1", "agent.log.2.gz", "agent.log.3.gz", "agent.log.4.gz"]:
    op = gzip.open if f.endswith('.gz') else open
    try:
        with op(f, 'rt', errors='ignore') as fh:
            for line in fh:
                m = pat.match(line)
                if not m:
                    continue
                d, h, model, i, o, cr, ci = m.groups()
                a = agg[(d, h)]
                a[0] += 1; a[1] += int(i); a[2] += int(o); a[3] += int(cr); a[4][model] += 1
    except FileNotFoundError:
        pass

for (d, h) in sorted(agg):
    c, i, o, cr, mods = agg[(d, h)]
    print(f"{d} {h}:00 calls={c:4d} in={i:8d} cache={cr:9d} out={o:7d} {dict(mods)}")
```

Файлы лежат в `/root/.hermes/logs/`; запускать оттуда или с полными путями. Ротаций хватает на ~5 дней — более раннее смотреть в state.db.

## Что проверять в самом стороже

```bash
ls -la /root/.hermes/scripts/ | grep -i cost
grep -n "started_at\|last_activity\|cache_read" /root/.hermes/scripts/cost-report.py
python3 -c "import json;d=json.load(open('/root/.hermes/cron/jobs.json'));[print(j['name'], j.get('schedule_display'), j.get('last_run_at'), j.get('last_status')) for j in d['jobs'] if 'cost' in j['name']]"
```

Красные флаги: фильтр по `started_at` в скрипте отчёта; расписание с пропущенными днями; `last_status: ok` в каждой записи при жалобах пользователя на счёт.
