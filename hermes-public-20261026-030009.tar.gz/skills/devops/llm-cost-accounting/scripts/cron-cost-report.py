#!/usr/bin/env python3
"""Cron LLM cost report from ~/.hermes/cron/usage_audit.jsonl.

Peak-aware pricing (DeepSeek Flash, per 1M tokens, verified 2026-10-05):
  peak  = Mon-Fri 01:00-04:00 and 06:00-10:00 UTC
  off-peak = everything else == exactly half of peak
  input cache-miss $0.15 off / $0.30 peak ; output $0.60 off / $1.20 peak

Note: usage_audit.jsonl has NO 'cost' field; job name lives only as job_id,
mapped through cron/jobs.json. Cron input is treated as cache-miss (fresh
run, cold cache) — this is an upper bound.
"""
import json, os, sys, collections, datetime

BASE = os.path.expanduser("~/.hermes/cron")
P_IN_OFF, P_IN_PEAK = 0.15, 0.30
P_OUT_OFF, P_OUT_PEAK = 0.60, 1.20


def load_jobs():
    p = os.path.join(BASE, "jobs.json")
    data = json.load(open(p, encoding="utf-8"))
    jobs = data.get("jobs", data) if isinstance(data, dict) else data
    if isinstance(jobs, dict):
        jobs = list(jobs.values())
    return {str(j.get("id") or j.get("job_id")): (j.get("name") or "?") for j in jobs}


def parse_ts(v):
    if isinstance(v, (int, float)):
        return datetime.datetime.utcfromtimestamp(v if v < 2e10 else v / 1000)
    try:
        return datetime.datetime.fromisoformat(str(v).replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        return None


def is_peak(t):
    return t.weekday() < 5 and (1 <= t.hour < 4 or 6 <= t.hour < 10)


def report(days):
    idmap = load_jobs()
    rows = []
    with open(os.path.join(BASE, "usage_audit.jsonl"), encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    rows.append(json.loads(line))
                except Exception:
                    pass
    now = datetime.datetime.now(datetime.UTC).replace(tzinfo=None)
    cut = now - datetime.timedelta(days=days)
    agg = collections.defaultdict(lambda: [0, 0, 0, 0.0, 0, 0.0])
    tot = [0, 0, 0, 0.0]
    for r in rows:
        t = parse_ts(r.get("ts"))
        if not t or t < cut:
            continue
        jid = str(r.get("job_id"))
        name = idmap.get(jid, jid)
        pin = r.get("prompt_tokens") or 0
        pout = r.get("completion_tokens") or 0
        peak = is_peak(t)
        c = (pin / 1e6 * (P_IN_PEAK if peak else P_IN_OFF)
             + pout / 1e6 * (P_OUT_PEAK if peak else P_OUT_OFF))
        a = agg[name]
        a[0] += 1; a[1] += pin; a[2] += pout; a[3] += c
        if peak:
            a[4] += 1; a[5] += c
        tot[0] += 1; tot[1] += pin; tot[2] += pout; tot[3] += c
    print(f"=== cron LLM cost, last {days}d (peak-aware) ===")
    for name, (n, pin, pout, c, npk, cpk) in sorted(agg.items(), key=lambda kv: -kv[1][3]):
        print(f"{name:30s} n={n:3d} in={pin/1e6:7.2f}M out={pout/1e6:6.3f}M "
              f"${c:6.2f}  peak_runs={npk} peak$={cpk:5.2f} avg_in={pin/max(n,1)/1000:5.0f}k")
    print(f"{'TOTAL':30s} n={tot[0]:3d} in={tot[1]/1e6:7.2f}M out={tot[2]/1e6:6.3f}M ${tot[3]:6.2f}")
    return tot


if __name__ == "__main__":
    d = int(sys.argv[1]) if len(sys.argv) > 1 else 7
    report(d)
