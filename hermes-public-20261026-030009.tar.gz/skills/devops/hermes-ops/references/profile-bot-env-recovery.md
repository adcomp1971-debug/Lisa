# Profile Bot .env Recovery — Liskaanka Case Study

## Scenario

A profile bot (Liskaanka, @Liskaanka_Bot) was running successfully for hours. `.env` was edited to fix the main bot token. After the edit, the bot kept running (token was loaded in memory) but would crash on next restart because its `LISKAANKA_BOT_TOKEN` was no longer in `.env`.

## Root Cause Pattern

1. Bot code (`/root/liskaanka_bot.py`) reads a SPECIFIC env var name: `LISKAANKA_BOT_TOKEN`
2. `.env` uses a DIFFERENT naming convention: `TELEGRAM_BOT_TOKEN_LISKA`
3. During `.env` edits (token fix, cleanup), the `LISKAANKA_BOT_TOKEN` line was present at bot-start time but lost afterward
4. Bot survived because Python loaded the token at import time — it's held in the `TOKEN` module-level variable
5. On restart, `load_token()` raises `ValueError("LISKAANKA_BOT_TOKEN not found in .env")`

## Detecting the Silent Failure

The bot appears active (polling Telegram) but is zombie-walking:

```bash
# Check what bot ID it's actually polling as
journalctl -u liskaanka-bot --since "10 minutes ago" | grep "getUpdates" | head -1
# Output: POST https://api.telegram.org/bot8848710683:***/getUpdates

# Compare with .env token
grep "TELEGRAM_BOT_TOKEN_LISKA" /root/.hermes/.env
# Different bot ID prefix = token mismatch. Bot uses token from when it started.
```

## Diagnostic Checklist

```bash
# 1. Is the env var the bot EXPECTS present?
grep "LISKAANKA_BOT_TOKEN" /root/.hermes/.env
# No output = will crash on restart

# 2. Is there a DIFFERENTLY-NAMED var for the same bot?
grep "LISKA" /root/.hermes/.env
# TELEGRAM_BOT_TOKEN_LISKA=775024...AxGc ← different naming convention

# 3. Test the token directly
TOKEN=*** "^TELEGRAM_BOT_TOKEN_LISKA=*** /root/.hermes/.env | cut -d= -f2)
curl -s "https://api.telegram.org/bot${TOKEN}/getMe"
# 404 = this token is dead/wrong. The real token was lost.

# 4. Check if any backup has the real token
grep -r "LISKAANKA_BOT_TOKEN" /root/.hermes/.env.bak.*
```

## Recovery

**If the real token is lost from all backups:** User must get it from @BotFather:
1. Telegram → @BotFather → `/mybots` → @Liskaanka_Bot → API Token
2. Add to `.env` with the EXACT var name the bot code expects:
   ```bash
   echo 'LISKAANKA_BOT_TOKEN=<token>' >> /root/.hermes/.env
   ```
3. Verify: `grep LISKAANKA_BOT_TOKEN /root/.hermes/.env` → should show the line
4. Restart: `systemctl restart liskaanka-bot`
5. Verify token is live: `curl -s "https://api.telegram.org/bot<TOKEN>/getMe"` → `{"ok":true}`

**If the token exists under a different name but is wrong:**
- The bot code hardcodes the var name (`LISKAANKA_BOT_TOKEN`). Either:
  - Rename the var in `.env` to match what the bot expects
  - Or add a NEW line with the correct name alongside the old one

## Prevention

- **Before editing `.env`**, snapshot the line count and all Telegram token vars:
  ```bash
  wc -l /root/.hermes/.env
  grep "BOT_TOKEN" /root/.hermes/.env
  ```
- **After editing `.env`**, re-verify the same:
  ```bash
  wc -l /root/.hermes/.env  # same or +1 expected
  grep "BOT_TOKEN" /root/.hermes/.env  # all vars still present
  ```
- **Name bot tokens consistently**: `TELEGRAM_BOT_TOKEN_<NAME>` avoids the mismatch with hardcoded expectations.
- **After gateway token fix, also check profile bot tokens** — they're easy to forget because the bot stays alive in memory.
