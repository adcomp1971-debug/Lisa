# Command-based MCP: Environment Variable Wrapper

**Problem:** Command-based MCP servers (npx, pipx) may not inherit all env vars from `~/.hermes/.env`. The Hermes gateway passes .env vars to HTTP-based MCPs via headers, but for command-based MCPs, the child process environment depends on how the gateway launches it.

**Symptom:** MCP server shows "enabled" in config but tools fail with "missing API key" or "please set [VAR] environment variable".

**Fix:** Replace the npx command with a wrapper script that explicitly sources .env before exec.

## Wrapper Script Template

```bash
#!/bin/bash
# Wrapper for <mcp-name> — loads API_KEY from .env
set -a
source /root/.hermes/.env
set +a
exec npx -y <npm-package> "$@"
```

Place at `~/.hermes/scripts/<name>-wrapper.sh`, `chmod +x`.

## Config Change

Replace the MCP server's `command` from `npx` to the wrapper path, and set `args: []`:

```yaml
# BEFORE:
  <name>:
    command: npx
    args:
      - -y
      - --args
      - <npm-package>
    enabled: true

# AFTER:
  <name>:
    command: /root/.hermes/scripts/<name>-wrapper.sh
    args: []
    enabled: true
```

The `--args` flag is Hermes-framework-internal, NOT an npx argument. When using a wrapper, omit `args` entirely (empty list).

## Real Case: AgentMail (Jun 27 2026)

`agentmail-mcp` needed `AGENTMAIL_API_KEY` in env. Gateway's npx-based launch didn't pass it. Wrapper at `~/.hermes/scripts/agentmail-wrapper.sh`:

```bash
#!/bin/bash
set -a
source /root/.hermes/.env
set +a
exec npx -y agentmail-mcp "$@"
```

Config changed to `command: /root/.hermes/scripts/agentmail-wrapper.sh` + `args: []`.

## Pitfalls

- `set -a` (allexport) makes ALL sourced vars visible to child processes — not just the one you need. This is fine for a dedicated wrapper.
- `exec` replaces the shell process with npx — no extra process overhead.
- After changing config, restart gateway via cron (one-shot no_agent script). The wrapper takes effect on next MCP spawn.
- Verify by using the MCP tool directly.
