# Gateway Restart Safety Rule (2026-06-29)

**Absolute rule:** Never issue `systemctl restart hermes-gateway`, `hermes gateway restart`, or any command that sends SIGTERM/SIGKILL to the gateway process from inside a gateway session.

**Why:** The gateway security layer intercepts the command and returns "Blocked: cannot restart or stop the gateway from inside the gateway process." Any attempt kills the current conversation before completion.

**Correct patterns:**
- Use a `no_agent=true` cron job scheduled 1-5 minutes in the future (via `cronjob` tool) with a shell script that calls `systemctl restart`.
- Schedule via `gateway-guard` or `gateway-watch` cron jobs that already exist.
- Perform the restart from a separate non-gateway CLI/SSH session.
- For config changes that require restart: write the change, create the cron one-shot, inform user that restart will happen on next tick.

**Never** use `hermes config set` for complex changes inside gateway — it destroys the file. Use Python yaml rewrite + cron one-shot restart instead.

This rule was added after explicit user correction on 2026-06-29.