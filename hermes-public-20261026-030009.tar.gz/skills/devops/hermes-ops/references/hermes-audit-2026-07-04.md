# 🔍 Hermes Production Audit — 2026-07-04

Полный аудит стека Hermes Agent + Codex CLI + 3 релея.

## Статус сервисов

| Сервис | Статус | RAM | WS |
|--------|--------|-----|----|
| hermes-gateway (default @AmseujBot) | 🟢 running | 1.1G (peak 2.1G) | — |
| hermes-gateway-buratino (@NemotrBot) | 🟢 running | 869M (peak 1.4G) | — |
| codex-relay (:4446 DeepSeek) | 🟢 running | 15M | ✅ |
| codex-relay-longcat (:4447) | 🟢 running | 10M | ✅ |
| codex-relay-glm (:4448) | 🟢 running | 6.7M | ✅ |

## Провайдеры API

Все доступны: DeepSeek, GLM (Z.AI), LongCat, OpenAI, xAI (Grok), NVIDIA, Google.
Критично: deepseek provider в default config НЕ имел base_url + api_key — Hermes роутил запросы через OpenRouter.

## Найденные проблемы и их исправления

### 🔴 Исправлено (критичное)
1. **DeepSeek провайдер без base_url** — добавлен `api_key: ${DEEPSEEK_API_KEY}`, `base_url: https://api.deepseek.com/v1`
2. **OPENROUTER_API_KEY в .env** — удалён (Hermes авто-детектил OpenRouter)
3. **WS на :4446 и :4447 отсутствовал** — добавлен WebSocket handler во все 3 релея
4. **Axum method routing** — `.route()` разделённые вызовы заменены на method chaining (get().post())
5. **Memory overflow** — `memory_char_limit` повышен с 1375 до 4000
6. **xai-oauth fallback** — в default `grok-4.3` указывал на несуществующий `xai-oauth`, исправлен на `xai`
7. **AGENTS.md устарел** — обновлён fallback chain и relay конфигурация

### 🟡 Требует внимания
8. **AGENTS.md fallback не совпадал с реальностью** — обновлён
9. **TimeoutStopSec vs drain_timeout** — уже исправлен drop-in (210s > 180s)
10. **hermes-ops SKILL.md = 107KB** — превышает лимит записи
11. **gateway-guard каждые 5 минут** — шум в логах
12. **awg-monitor каждые 15 минут** — избыточно
13. **Hermes 141 коммит позади upstream** — требуется `hermes update`
14. **CODEX_RELAY_API_KEY = 1 символ** — placeholder, не мешает работе

### 🟢 Рабочее (не трогать)
- Default + Buratino gateway работают
- Все 3 релея (HTTP + WS) отвечают
- LongCat-2.0, GLM 5.2, DeepSeek V4 Pro доступны
- Backup, monitoring cron задачи отрабатывают

## Релеи

| Порт | Модель | HTTP /v1/models | POST /v1/responses | WS /v1/responses |
|------|--------|----------------|-------------------|-------------------|
| 4446 | deepseek-v4-pro | ✅ | ✅ | ✅ 101 |
| 4447 | LongCat-2.0 | ✅ | ✅ | ✅ 101 |
| 4448 | glm-5.2 | ✅ | ✅ | ✅ 101 |

## Fallback Chain

**Default:**
1. LongCat-2.0 → longcat
2. grok-4.3 → xai (исправлено с xai-oauth)
3. deepseek-v4-pro → deepseek
4. glm-5.2 → glm

**Buratino:**
1. LongCat-2.0 → longcat
2. glm-5.2 → custom (Z.AI)
3. grok-4.3 → xai-oauth
4. deepseek-v4-pro → deepseek

## Delegation

Default + Buratino: LongCat-2.0 через longcat провайдер.
Дублирование base_url/api_key в delegation секции — риск рассинхрона.

## Cron

18 активных задач. gateway-guard (5 мин) и awg-monitor (15 мин) — избыточная частота.
