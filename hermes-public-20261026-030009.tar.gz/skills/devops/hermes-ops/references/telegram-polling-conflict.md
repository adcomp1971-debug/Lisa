# Telegram Polling Conflict

## Симптом

Бот @AmseujBot онлайн (`✓ telegram connected` в gateway.log), но не отвечает на сообщения в Telegram.

## Причина

Два инстанса gateway дерутся за Telegram polling. В логах:

```
WARNING telegram_platform.adapter: [Telegram] Telegram polling conflict (1/5)
  — previous session still held open on Telegram's servers.
  Error: Conflict: terminated by other getUpdates request;
  make sure that only one bot instance is running
```

Дополнительно в `errors.log` спам каждые ~10 секунд:

```
ERROR gateway.run: Another gateway instance is already running (PID xxx)
```

Это значит: systemd рестартит gateway, но старый процесс ещё держит Telegram long-polling. Telegram не позволяет двум getUpdates одновременно — бот получает сообщения, но не может их забрать.

## Диагностика

```bash
# 1. Проверить конфликт polling
grep "polling conflict" /root/.hermes/logs/gateway.log | tail -5

# 2. Проверить "already running" спам
grep "already running" /root/.hermes/logs/errors.log | tail -10

# 3. Проверить что бот реально подключён
grep "telegram connected" /root/.hermes/logs/gateway.log | tail -3
```

## Фикс

Рестарт gateway через systemd убивает старый процесс и очищает polling:

```bash
hermes gateway restart
```

Если `hermes gateway restart` таймаутит (30s+) — gateway всё равно рестартнул, проверить:

```bash
systemctl is-active hermes-gateway
tail -10 /root/.hermes/logs/gateway.log
```

Должно быть:

```
✓ telegram connected
Gateway running with 2 platform(s)
Sent home-channel startup notification to telegram:420839805
```

## Предупреждение

`gateway-guard.py` (cron every 5m) может вызывать "already running" спам в errors.log — это **нормально**. Guard проверяет что gateway жив, и если жив — пишет ошибку и уходит. Это НЕ конфликт polling.

Отличить: конфликт polling = `WARNING ... polling conflict` в gateway.log. Guard = только `ERROR ... already running` в errors.log без polling-варнингов.
