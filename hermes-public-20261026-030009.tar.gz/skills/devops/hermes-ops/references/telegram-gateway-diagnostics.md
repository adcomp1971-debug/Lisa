# Telegram Gateway Diagnostics

## Быстрая проверка: бот онлайн?

```bash
# 1. Systemd статус
systemctl is-active hermes-gateway

# 2. Gateway health
hermes gateway status

# 3. Самый важный лог — gateway.log (НЕ journalctl)
tail -30 /root/.hermes/logs/gateway.log
```

## Почему gateway.log, а не journalctl

`journalctl` обрезает вывод и может не показать ключевые сообщения типа `✓ telegram connected`. `gateway.log` содержит полный лог подключения платформ.

**Пример хорошего лога:**
```
2026-06-28 14:26:16,744 INFO gateway.run: Connecting to telegram...
2026-06-28 14:26:17,868 INFO ...: [Telegram] Connected to Telegram (polling mode)
2026-06-28 14:26:17,871 INFO gateway.run: ✓ telegram connected
2026-06-28 14:26:17,913 INFO gateway.run: Gateway running with 2 platform(s)
```

## Конфигурация Telegram в Hermes

Telegram подключается через переменные окружения в `/root/.hermes/.env`, не через секцию `telegram:` в config.yaml:

```ini
TELEGRAM_BOT_TOKEN=123456789:ABCdef...
TELEGRAM_ALLOWED_USERS=420839805
```

Секция `telegram:` в config.yaml содержит только настройки поведения (reactions, rich_messages и т.д.), **не токен**.

## Ошибки

```bash
# Последние ошибки gateway
tail -30 /root/.hermes/logs/errors.log

# Типичная безобидная ошибка (gateway-guard пытается запустить уже работающий gateway):
# "Another gateway instance is already running"
```
