# GitHub MCP Server Setup

**Package:** `github-mcp` (official GitHub MCP, via npx)
**Transport:** stdio
**Auth:** GITHUB_TOKEN env var (PAT from .env)

## Installation

```yaml
# In mcp_servers section of config.yaml:
github:
  command: npx
  args:
    - -y
    - github-mcp
    - stdio
  enabled: true
  env:
    GITHUB_TOKEN: "${GITHUB_TOKEN}"
```

## Notes

- Uses `npx github-mcp stdio` — the `stdio` transport argument is REQUIRED. Without it, the server starts but doesn't expose any tools.
- Token must be a classic PAT or fine-grained PAT with repo scope.
- `GITHUB_TOKEN` env var is read from the config's `env` section — the server does NOT auto-read from `.env`.
- Known tools: `list_issues`, `add` (limited set without OAuth scope expansion).
- Connection test: `hermes mcp test github` — should complete in ~1.3s.

## Pitfalls

- `@modelcontextprotocol/github` does NOT exist on npm (404). Use `github-mcp` instead.
- `hermes mcp add` may time out during connection test (40s default) even when the server would work. The config saves as `enabled: false`. Fix: edit config.yaml directly to set `enabled: true`, add `env` section, fix args format.
- The `args` list must have each arg as a separate YAML item — NOT comma-separated (`-y,github-mcp` is wrong, `-y` and `github-mcp` as two items is correct).
