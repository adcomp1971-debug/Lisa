# Gateway Config Visibility

**Ключевое правило:** config.yaml читается **только при старте gateway**. Любые изменения в конфиге не вступают в силу до рестарта gateway.

## Затрагиваемые секции

- `auxiliary.vision` — смена провайдера/модели vision
- `fallback_providers` — изменения вступают сразу (перечитываются на лету)
- `provider` / `model` — **НЕ** вступают до рестарта
- `tools` — **НЕ** вступают до рестарта
- `custom_providers` — **НЕ** вступают до рестарта

## Почему это важно

`vision_analyze` использует **активную основную модель** (config.yaml provider/model), а не `auxiliary.vision`. Если основная модель не умеет vision — падает с ошибкой, даже если auxiliary настроен на Grok.

При смене `auxiliary.vision.provider` в конфиге можно проверять `wc -c config.yaml` и `python3 -c "import yaml; yaml.safe_load(open('config.yaml'))"` — но даже если конфиг валиден, изменения не работают до рестарта.

## Диагностика

Если `vision_analyze` падает после правки auxiliary.vision:
1. Проверить что конфиг валиден (yaml safe_load)
2. Проверить что auxiliary.vision.provider и model правильные
3. **Если да, а vision всё равно падает — нужен рестарт gateway**

## Рестарт

**Правило:** gateway рестартит только Алекс. Не делать самому.
