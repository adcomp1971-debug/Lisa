# Web Search Backend Configuration

Diagnose and fix when `web_search` returns 401 or uses the wrong backend.

**Architecture:** `web_search` reads `web.search_backend` (or falls back to `web.backend`) from config.yaml. Available backends live in `/usr/local/lib/hermes-agent/plugins/web/<name>/`: `tavily`, `exa`, `firecrawl`, `searxng`, `brave_free`, `ddgs`, `parallel`, `xai`.

Each backend reads its own API key from the environment:

| Backend | Env var | Plugin path |
|---------|---------|-------------|
| `tavily` | `TAVILY_API_KEY` | `plugins/web/tavily/` |
| `exa` | `EXA_API_KEY` | `plugins/web/exa/` |
| `firecrawl` | `FIRECRAWL_API_KEY` | `plugins/web/firecrawl/` |
| `brave_free` | `BRAVE_API_KEY` | `plugins/web/brave_free/` |
| `ddgs` | (none — no key) | `plugins/web/ddgs/` |

**Diagnostic when web_search returns 401:**
1. Check which backend is active: `grep -A5 '^web:' ~/.hermes/config.yaml`
2. Verify the corresponding API key in `.env`: `grep '<VAR>' ~/.hermes/.env | head -1 | cut -d= -f1`
3. Test the key directly

**Common failure:** user updated TAVILY_API_KEY but config has `search_backend: exa` — the new key is invisible to web_search.

**Switching backends (safe sed):**
```bash
sed -i 's|search_backend: exa|search_backend: tavily|' ~/.hermes/config.yaml
sed -i 's|extract_backend: exa|extract_backend: tavily|' ~/.hermes/config.yaml
sed -i 's|backend: exa|backend: tavily|' ~/.hermes/config.yaml
```

**Requires `/reset` or gateway restart to take effect.** Config is read at session start.
