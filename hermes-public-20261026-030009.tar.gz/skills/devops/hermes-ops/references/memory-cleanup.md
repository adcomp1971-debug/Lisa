# Memory Cleanup Triggers

## Memory Overflow Check

Always check MEMORY.md against the 16,000 char limit during audits — overflow causes silent write rejections:

```bash
echo "Memory: $(wc -c < ~/.hermes/memories/MEMORY.md) / 16000 chars ($(echo "scale=0; $(wc -c < ~/.hermes/memories/MEMORY.md) * 100 / 16000" | bc)%)"
```

If >100%: trim stale entries before adding new ones. Use `memory` tool with `operations` array to batch-remove obsolete entries and add replacements atomically — a single batch call can stay under the limit even when an add alone would overflow.

## Memory cleanup trigger

When `memory usage` in system prompt exceeds **70%** (~11k/16k chars), proactively remove stale entries (completed tasks, resolved bugs, old cron schedules, duplicate entries, outdated config dumps). Target is ~50-60%. Do not capture task-progress or session artifacts in memory.

## Profile cleanup trigger

When `user profile` exceeds **90%** (~6.3k/7k chars), remove absorbed/obsolete preferences (old Upwork details, stale format preferences that are now encoded in skills, merged entries). Target is ~80%.
