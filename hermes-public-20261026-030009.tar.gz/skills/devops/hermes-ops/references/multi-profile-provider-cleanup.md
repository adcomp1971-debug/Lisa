# Multi-Profile Provider Cleanup

## Проблема
Профили (buratino, vasily) накапливают мёртвых провайдеров: nvidia, openai, xai, xai-oauth, anthropic — все с пустыми api_key. Они не используются, но висят в config.yaml и путают fallback routing.

## Процедура

### 1. Проверить все профили
```bash
for p in default buratino vasily; do
  echo "=== $p ==="
  python3 -c "import yaml; c=yaml.safe_load(open('/root/.hermes/${p:+profiles/$p/}config.yaml')); [print(f'  {k}: api_key={v.get(\"api_key\",\"N/A\")[:20]}') for k,v in c.get('providers',{}).items()]"
done
```

### 2. Найти мёртвых
Провайдер мёртвый если:
- `api_key: ''` (пустая строка)
- `api_key: ${VAR}` но VAR не задан в .env
- Провайдер не упоминается в model, fallback_providers, delegation

### 3. Удалить
```python
import yaml
with open(path, 'r') as f:
    config = yaml.safe_load(f)
for p in ['nvidia', 'openai', 'xai', 'xai-oauth', 'anthropic']:
    if p in config.get('providers', {}):
        del config['providers'][p]
with open(path, 'w') as f:
    yaml.dump(config, f, default_flow_style=False, sort_keys=True, allow_unicode=True)
```

### 4. MCP API keys в URL
Проверить MCP серверы на ключи в URL:
```bash
grep -n "api_key=\|apikey=\|ApiKey=" profile/config.yaml
```
Если ключ в URL — перенести в headers:
```python
srv['url'] = url_without_key
srv['headers'] = {'x-api-key': key}  # or 'Authorization': f'Bearer {key}'
```

### 5. Верификация
```bash
python3 -c "import yaml; c=yaml.safe_load(open('config.yaml')); print('OK:', list(c['providers'].keys()))"
```

## Найдено 2026-07-10
- buratino: 7 мёртвых провайдеров удалено (anthropic, nvidia, openai, xai, xai-oauth)
- buratino MCP: 3 API ключа в URL исправлены (exa, tavily — перенесены в headers)
- default: nvidia + openai удалены ранее в той же сессии
