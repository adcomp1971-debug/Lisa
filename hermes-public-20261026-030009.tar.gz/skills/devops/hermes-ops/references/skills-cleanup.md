# Skills Cleanup

Identify and remove dead, duplicate, or obsolete skills.

## Skills Cleanup Signal — User Complains Agent is Dumber

When the user says «слабый гермес какой то стал, с задачами хуже справляется, тупит, забывает, врёт», the skill bloat is a primary suspect alongside compression settings and state.db size.

**Diagnostic steps (in order):**
1. `skills_list` — count total skills. If >55, bloat is a factor
2. Check skill overlap: vpn-manager ↔ vpn-auto-doctor, server-ops ↔ vpn-manager
3. Classify each skill: active / duplicate / dead / borderline
4. Check `hermes cron list` before deleting — if a cron job references a skill, don't delete it
5. Use `skill_manage(action='delete', name='<skill>', absorbed_into='<target>')` for duplicates, `absorbed_into=''` for dead skills
6. For absorbed skills, verify the target skill already mentions the absorbed one

**Real case (Jun 29 2026):** 60 → 42 skills. Removed:
- 7 business/product skills (hooked-ux, improve-retention, jobs-to-be-done, lean-startup, mom-test, negotiation, obviously-awesome) — not used on server
- computer-use, petdex, web-pentest — decorative/inapplicable
- glm-zai-provider — one-time setup
- skill-router, task-router-production — duplicates, unused
- prism-3way, prism-discover, prism-reflect, prism-scan — prism-full covers all
- Absorbed: vpn-auto-doctor → vpn-manager
