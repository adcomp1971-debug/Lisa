# Workflow Authoring

Hermes Workflows are Python scripts that orchestrate multiple subagents deterministically. Stored at `~/.hermes/workflows/<name>.py`. Invoked via the `workflow` tool or by name.

## Script Structure

Every workflow script must begin with a pure literal `meta` dict:

```python
meta = {
    "name": "my-workflow",
    "description": "What this workflow does",
    "phases": [
        {"title": "Phase 1", "detail": "Description"},
        {"title": "Phase 2", "detail": "Description"},
    ],
}
```

The `meta` dict must be a PURE LITERAL — no variables, function calls, dict unpacking, or f-string interpolation.

## Available Globals (injected at runtime)

| Global | Usage | Description |
|--------|-------|-------------|
| `phase(title)` | `phase("Scan")` | Start a new progress phase |
| `agent(prompt, opts)` | `await agent("do X", {"schema": {...}})` | Spawn a subagent |
| `parallel(thunks)` | `await parallel([lambda: agent(...)])` | Run agents concurrently (barrier) |
| `pipeline(items, stage1, ...)` | `await pipeline(items, stage1, stage2)` | Multi-stage processing without barriers |
| `log(message)` | `log("Found 3 issues")` | Emit progress message to user |
| `json` | `json.dumps(data)` | Pre-imported JSON library |
| `args` | `args.get("path", ".")` | Input args passed to workflow |
| `return` | `return {"status": "OK"}` | Final result |

## Subagent Options

```python
await agent("prompt", {
    "label": "my-label",        # display label in progress tree
    "phase": "Phase Name",      # group under this phase
    "schema": {...},            # JSON Schema for structured output
    "model": "deepseek-v4-pro", # model override
    "agentType": "explore",     # 'explore' (faster), 'general-purpose' (default), 'verification'
    "toolsets": ["terminal"],   # restrict tools
})
```

## Key Patterns

**Parallel data collection:**
```python
phase("Collect")
results = await parallel([
    lambda: agent("check A", {"label": "a", "phase": "Collect"}),
    lambda: agent("check B", {"label": "b", "phase": "Collect"}),
])
```

**Multi-phase pipeline:**
```python
phase("Phase 1")
data = dict(await parallel([...]))

phase("Phase 2")
analysis = await agent(f"Analyze: {json.dumps(data)}", {"schema": ANALYSIS_SCHEMA})
```

## Pitfalls

- **LSP errors are expected** — globals like `agent`, `parallel`, `phase`, `json`, `args`, `return` don't exist at module level. Workflow engine injects them at runtime. Ignore Pyright "undefined variable" errors.
- **`import` is forbidden** — `json` and `math` are pre-imported. Any `import` statement causes a runtime error.
- **Scripts go in `~/.hermes/workflows/`** — Hermes discovers them by scanning this directory.
- **`return` statement at top level** — used instead of `print()` to output workflow results.
- **Concurrent agents capped** at min(16, cpu cores - 2) per workflow. Excess queue and run as slots free up.
- **Total agent limit**: 1000 per workflow (runaway guard).
- **`require_launch_approval: true` silently blocks in gateway** — there's no approve/deny UI in Telegram. The workflow reports as "launched" but never executes. Must be `false` for gateway use.

## Stack Upgrade Methodology (5 phases)

When upgrading a Hermes deployment comprehensively, follow this 5-phase sequence:

1. **Config Boosts** — Enable response_cache, tune curator/delegation, optimize smart routing
2. **Multi-Agent Workflows** — Create 4-6 named workflows in `~/.hermes/workflows/` covering audit, pulse, review, self-improve, incident response, intel
3. **Kanban Workspaces** — Create boards per active project (Pianoid, Hermes Box, Infra) with initial tasks
4. **Community Skills** — Install top official skills: grok, antigravity-cli, dspy, blackbox, scrapling, web-pentest, fastmcp, rest-graphql-debug
5. **Soul.md + Backup** — Update soul.md with new capabilities, install backup tools (rclone)

Each phase is ~5-15 minutes. Total: ~45 minutes for a full stack upgrade.

See `references/super-stack-build.md` for the concrete June 2026 build: exact commands, workflow scripts, kanban boards, and installed skills.
