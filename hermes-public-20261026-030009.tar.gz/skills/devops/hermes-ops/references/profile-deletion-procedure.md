# Profile Deletion Procedure

## When to use

When a Hermes profile (buratino, any named profile) is no longer needed and must be fully removed.

## Verified steps (buratino profile, 2026-07-18)

### 1. Backup (ALWAYS)
```bash
mkdir -p /root/backups
tar czf /root/backups/<profile>-profile-$(date +%Y%m%d).tar.gz -C ~/.hermes/profiles <profile>
ls -lh /root/backups/<profile>-profile-*.tar.gz
```

### 2. Stop gateway service (CANNOT do from inside gateway)
Terminal blocks `systemctl stop hermes-gateway-*` from inside the gateway process.
Send commands as .txt file to user via sendDocument:

```bash
systemctl stop hermes-gateway-<profile>.service
systemctl disable hermes-gateway-<profile>.service
```

### 3. After user confirms stop, delete:
```bash
rm -rf ~/.hermes/profiles/<profile>
rm -f /etc/systemd/system/hermes-gateway-<profile>.service
systemctl daemon-reload
```

### 4. Remove cron jobs
```python
# Use cronjob tool: action='list' to find job_id, then action='remove'
# Look for: <profile>-stats, <profile>-* patterns
```

### 5. Clean up artifacts (do AFTER profile deletion)
Files that reference the deleted profile and should be cleaned:

| Artifact | Location | Action |
|----------|----------|--------|
| Scripts | `~/.hermes/scripts/<profile>-*.py`, `~/.hermes/scripts/restart-<profile>.sh` | Delete |
| AGENTS.md | Full profile section | Rewrite (remove profile section, update date) |
| MEMORY.md | Profile mentions | Remove entries |
| Cron output | `~/.hermes/cron/output/restart-<profile>.txt` | Delete |
| Backup configs | `~/.hermes/bak-*/<profile>-config.yaml` | Leave (will be cleaned by backup retention) |
| Skills references | `skills/*/references/*<profile>*.md` | Review — keep if historical value, delete if stale |
| CLAUDE.md | References to `/root/<profile>/` | Update or remove |

### 6. Verify
```bash
# No systemd unit
systemctl status hermes-gateway-<profile>.service 2>&1 | grep -q "could not be found" && echo "OK: unit gone"

# No profile dir
test ! -d ~/.hermes/profiles/<profile> && echo "OK: profile dir gone"

# No cron jobs
hermes cron list | grep -i <profile>  # should be empty
```

## Common pitfalls

1. **Gateway block** — `systemctl stop hermes-gateway-*` from terminal tool inside gateway = blocked. Must send to user as .txt.
2. **Cron jobs survive deletion** — `buratino-stats` cron kept running for a day after profile deletion until manually removed. Always check `hermes cron list` after deletion.
3. **AGENTS.md drift** — profile description stays in AGENTS.md indefinitely. Must be rewritten manually.
4. **Backup bloat** — 27 nightly backups (~14GB) may still contain the deleted profile. Let `backup-cleaner` cron handle retention, don't delete manually.
5. **Skill references** — skills like `hermes-ops/references/buratino-openrouter-401-fix.md` mention the profile. These are historical fix records — keep them, they're still valid troubleshooting guides.

## Decision: backup vs delete

When user asks "should I backup?":
- **Always backup.** Profile contains: skills, sessions, memory, config. tar.gz compresses ~5:1.
- 536MB raw → 236MB compressed. With 58GB free disk, this is negligible.
- Backups live in `/root/backups/` — don't touch unless user says to delete.
