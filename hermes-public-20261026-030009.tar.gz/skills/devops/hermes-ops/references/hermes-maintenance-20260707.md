# Hermes Maintenance — Jul 7, 2026

## 1. Stunnel Fix (Claude Code через LongCat/GLM)

**Проблема:** `stunnel4.service` был inactive (dead). Порты :4451/:4452 не отвечали. Claude Code обёртки (claude-lc, claude-glm, buratino-claude, buratino-claude-glm) не работали.

**Диагностика:**
```bash
systemctl status stunnel4          # inactive (dead)
ss -tlnp | grep ':445[0-3]'       # :4451/:4452 не слушают
cat /etc/stunnel/*.conf            # конфиги есть, сертификат есть
```

**Фикс:**
```bash
systemctl start stunnel4
systemctl enable stunnel4
# Проверка — использовать HTTPS, не HTTP (stunnel — TLS туннель)
curl -sk https://127.0.0.1:4451/v1/models   # должно быть HTTP 200
curl -sk https://127.0.0.1:4452/v1/models   # HTTP 200
```

**Архитектура:**
- :4451 → stunnel → :4450 (codex-relay) → LongCat-2.0
- :4452 → stunnel → :4453 (codex-relay-glm) → GLM 5.2
- Сертификат: `/etc/stunnel/anthropic.pem` (самоподписанный, valid till Jul 2027)

## 2. Orphan Alias Cleanup

**Проблема:** `hermes doctor` показывал `⚠ Orphan alias: codex-worker → profile 'codex-worker' no longer exists`.

**Диагностика:**
```bash
hermes doctor | grep orphan
ls -la /root/.local/bin/codex-worker   # orphan wrapper
```

**Фикс:**
```bash
rm -f /root/.local/bin/codex-worker
# hermes profile alias codex-worker --remove не работает когда профиля нет
# Просто удалить файл вручную
```

**Проверка:**
```bash
hermes doctor | grep -c orphan   # должно быть 0
```

## 3. Watchdog Timer Cleanup

**Проблема:** `hermes-gateway-watchdog.timer` висел в системе, но сервис делал `/bin/true` — мёртвый артефакт. Reason: redundant after systemd `Restart=always` on the gateway service.

**Фикс:**
```bash
systemctl disable --now hermes-gateway-watchdog.timer
```

## 4. Config.yaml Improvements (v33 → v34)

**Добавлено:**
- `agent.gateway_timeout: 1800` (30 min default)
- `agent.gateway_timeout_warning: 900` (15 min warning)
- `web.search_backend: brave`
- `mcp_servers` section with 6 servers: agentmail, brave-search, firecrawl, github, playwright, sqlite-vpnbot

**Добавлено в .env:**
- `BRAVE_SEARCH_API_KEY` (алиас для `BRAVE_API_KEY` — Hermes ищет именно это имя)

**Патерн для редактирования конфига (безопасный):**
```bash
python3 << 'PYEOF'
import yaml
with open('/root/.hermes/config.yaml') as f:
    cfg = yaml.safe_load(f)
# модификация
cfg['_config_version'] = cfg.get('_config_version', 0) + 1
with open('/root/.hermes/config.yaml', 'w') as f:
    yaml.dump(cfg, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
PYEOF
```

## 5. Codex Base Wrapper

**Проблема:** В AGENTS.md написано что `codex` = LongCat-2.0 по умолчанию, но `/usr/local/bin/codex` не существовало. Работал только nvm-установленный `codex` с дефолтной моделью из `~/.codex/config.toml` (GLM 5.2).

**Фикс:**
```bash
cat > /usr/local/bin/codex << 'EOF'
#!/bin/bash
exec codex exec -c model='"LongCat-2.0"' -c model_provider='"longcat-relay"' --skip-git-repo-check "$@"
EOF
chmod +x /usr/local/bin/codex
```

**Все воркеры в /usr/local/bin/:** codex, codex-lc, codex-glm, codex-ds, claude-lc, claude-glm, buratino-codex, buratino-codex-lc, buratino-claude, buratino-claude-glm.

## 6. MLflow Server Setup

**Установка:**
```bash
pip3 install mlflow
```

**Systemd сервис:** `/etc/systemd/system/mlflow-server.service`
```
[Service]
ExecStart=/usr/local/lib/hermes-agent/venv/bin/mlflow server \
  --backend-store-uri sqlite:///root/buratino/mlflow/mlflow.db \
  --default-artifact-root /root/buratino/mlflow/artifacts \
  --host 0.0.0.0 --port 5050 \
  --allowed-hosts '"*"' --cors-allowed-origins '"*"'
Restart=always
```

**Запуск:**
```bash
systemctl daemon-reload
systemctl enable --now mlflow-server.service
ufw allow 5050/tcp          # открыть порт если нужен внешний доступ
```

**Проверка:**
```bash
curl -s http://127.0.0.1:5050/health    # должно быть "OK"
curl -s http://127.0.0.1:5050/          # должно быть HTML
```

**Интеграция в training:** `mlflow.set_tracking_uri("http://127.0.0.1:5050")` перед start_run.

## 7. Fallback Chain Reordering

**Было:** Flash → GLM → Grok → DS Pro → LongCat
**Стало:** Flash → GLM → LongCat → DS Pro → Grok

LongCat поднят выше Grok, потому что у LongCat 50M токенов пакет, Grok на SuperGrow подписке — экономия API токенов.

**Команда:** python3 heredoc с перестановкой `fallback_providers` массива.
