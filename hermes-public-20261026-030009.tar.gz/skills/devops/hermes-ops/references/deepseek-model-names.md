# DeepSeek Model Names & Config Reference

Verified working as of August 15, 2026:

| Config name | API model name | Maps to | Notes |
|-------------|----------------|---------|:-----:|
| `deepseek-v4-flash` | `deepseek-v4-flash` | V4 Flash (current checkpoint) | in-place, имя не меняется |
| `deepseek-v4-pro` | `deepseek-v4-pro` | V4-Pro-0813 GA (2026-08-13) | in-place, dated ID нет |
| `deepseek-chat` | (alias, не использовать) | historically → flash | не ставить в новый конфиг |

**INVALID model names:**
- `deepseek-v4-pro-0813` — HTTP 400: "supported names are deepseek-v4-pro or deepseek-v4-flash"
- `deepseek-pro` — API error: "supported names are deepseek-v4-pro or deepseek-v4-flash"
- `deepseek-reasoner` — silently maps to V4 Flash

Официально (api-docs.deepseek.com/news/news260813): «Model names remain unchanged». Пиковые/off-peak цены с 16:00 UTC 16.08.2026.

**Switch commands:**
```bash
hermes config set model.default deepseek-v4-pro   # Pro mode
hermes config set model.default deepseek-chat      # Flash mode (cheap)
```
