# Session Continuity Tools — Standalone Integrations

## Pattern
Build standalone scripts that extend Hermes functionality WITHOUT modifying core code. Use when you need session persistence, progress tracking, or cross-session state that outlives a single conversation.

## Integration Points (no code changes needed)
- **Env vars:** `HERMES_SESSION_ID`, `SESSION_ID` — auto-detected by tools if set
- **Progress directory:** `~/.hermes/progress/` — standard location for progress JSON files
- **Checkpoints:** `~/.hermes/checkpoints/` — Hermes's own checkpoint system
- **Config:** `~/.hermes/config.yaml` — read-only reference for session metadata
- **Session DB:** `~/.hermes/state.db` — SQLite with session history

## Architecture Decisions
1. **JSON over SQLite** — human-readable, no schema migrations, easy to debug
2. **Complementary to Hermes checkpoints** — never replace, only annotate/refer
3. **Env var + CLI arg fallback** — works both in and out of Hermes sessions
4. **Incremental checkpoints** — append-only, timestamped, numbered

## Example: Progress Harness
`/root/.hermes/scripts/progress_harness.py` — CLI tool for long-running sessions:
- `init` — create session with task description
- `checkpoint` — append progress with arbitrary JSON state
- `resume` — retrieve last checkpoint + next steps
- `merge` — annotate with Hermes checkpoint references
- `status` / `list` — view progress

Shows the full pattern: argparse CLI → JSON file → env var integration → Hermes checkpoint merge.

## When to Build Standalone vs Modify Hermes
- **Standalone:** user-facing tools, progress trackers, session helpers, data migration scripts
- **Modify Hermes:** core behavior changes, gateway logic, provider routing
