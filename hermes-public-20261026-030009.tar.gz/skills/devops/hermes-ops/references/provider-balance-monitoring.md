# Provider Balance Monitoring

Дата создания: 2026-07-03
Источник: Block A audit — provider health check + balance alert

## Назначение

Мониторинг здоровья провайдеров Hermes и алертинг о low balance / rate limits.
Скрипт: `/root/.hermes/scripts/check-balances.sh` (не входит в skills/, лежит в scripts/ общего хранения).

## Что проверяет (4 checks)

### 1. HTTP /v1/models доступность

Для каждого провайдера (deepseek, glm, xai, longcat) проверяет HTTP GET на `/v1/models`.
Результаты:
- `OK (200)` — провайдер жив
- `AUTH_FAIL (401)` — ключ истёк или неверный
- `RATE_LIMITED (429)` — баланс закончился
- `UNREACHABLE (000)` — сеть непускает

### 2. 429/401 ошибки в логах (последние 24ч)

Сканирует `agent.log` и `errors.log` на строки с `RateLimitError`, `HTTP 429`, `HTTP 401`.
Группирует по провайдеру через grep-паттерн `(RateLimitError|HTTP 4[02][19]).*$prov|$prov.*(RateLimitError|HTTP 4[02][19])`.
Порог алерта: **5 ошибок** за 24ч.

### 3. Z.AI (GLM) баланс

- Парсит `agent.log` на `Insufficient balance or no resource package` (код 1113)
- Делает тестовый chat/completions запрос к GLM-5.2 (HTTP 200 = баланс есть, 429 = exhausted)
- **Важно:** Z.AI не имеет работающего balance API (`/user/info`, `/credits`, `/billing/usage` — все 404). Единственный надёжный индикатор — код 1113 в ответе.

### 4. Codex-relay порты

Проверяет, что :4446, :4447, :4448 слушают (через `ss -tlnp`).

## Вывод скрипта

```
SUMMARY (2026-07-03 12:17:05)
ALERT — issues found:
  ALERT: glm — Z.AI — Insufficient balance / no resource package (HTTP 429 active)
exit code: 1  (0 = OK, 1+ = ALERT)
```

## Cron настройка

```bash
# Добавить через hermes cron
hermes cron create provider-balance-check \
  --schedule "0 9 * * *" \
  --command "bash /root/.hermes/scripts/check-balances.sh" \
  --timeout 30
```

## Pitfalls

### ⚠️ Инфляция счётчика 429/401

Каждый rate-limit логируется 3× (attempt 1/3, retry, summary). Реальный count = log-строки / 2-3.
Скрипт использует грубый threshold=5, и этого достаточно — если видит >5 строк, алерт корректен.

### ⚠️ Z.AI balance API не существует

Не использовать `/user/info`, `/credits`, `/billing/usage` — все возвращают 404.
Единственный способ: делать тестовый chat/completions с минимальным `max_tokens` и проверять код 1113.
GLM-5.2 с `max_tokens: 5` и `messages: [{"role":"user","content":"ping"}]`:
- HTTP 200 = баланс есть
- HTTP 429 = баланс < $0.01 (или 0)

### ⚠️ xai-oauth vs xai в fallback

В `fallback_providers` используется `provider: xai-oauth`, но в `providers:` определён только `xai`.
Если `xai-oauth` не определён в конфиге — провайдер не сработает. При аудите проверять соответствие.

### ⚠️ LongCat-2.0 первый в fallback

Текущий `fallback_providers` ставит LongCat-2.0 первым. Это специализированная SWE-модель, не универсальная.
Целевой порядок: DeepSeek V4 Flash → GLM-5.2 → Grok 4.3 → DeepSeek V4 Pro → LongCat-2.0.

### ⚠️ Дублирующиеся ключи в delegation

В config.yaml delegation блок содержит дублирующиеся поля:
- `api_key` (дважды — `${ZAI_API_KEY}` и `${LONGCAT_API_KEY}`)
- `max_iterations: 100` (дважды)
- `child_timeout_seconds: 600` (дважды)

YAML это схавает (последний победит) — но это баг, не фича. Надо чистить.

## Связанные references

- `references/provider-api-failure-diagnosis.md` — общая диагностика API failures
- `references/provider-timeout-tuning.md` — stale_timeout_seconds
- `references/cost-optimized-chain.md` — cost chain
- `references/delegation-glm-routing.md` — GLM routing

### Fallback chain discrepancy (bundled skill)

**`task-router-production` — bundled (не редактируется напрямую).**

В его `SKILL.md` раздел `## Fallback chain` описывает:
1. DeepSeek V4 Flash → DeepSeek V3 → Grok → Gemini 2.5 Flash

Реальная цепочка в `config.yaml` (`fallback_providers`):
1. LongCat-2.0 → GLM-5.2 → Grok (xai-oauth) → DeepSeek V4 Pro

**Расхождения:**
- `xai-oauth` не определён в `providers:` (есть только `xai`) — не отработает
- LongCat-2.0 первым (должен быть Flash)
- В скилле описаны модели (V3, Gemini), которых нет в конфиге
- Дублирующиеся ключи в delegation

Требуется синхронизация через `hermes skills install --force`.
