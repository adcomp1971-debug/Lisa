# Memory Files Emergency Cleanup

**Discovered:** 2026-07-09 during full Hermes audit

## Symptom
- USER.md at 138% of char limit (2,759/2,000) — memory tool refuses writes
- MEMORY.md at 92.5% of char limit (18,505/20,000) — close to blocking
- Gateway logs: `"After applying all 1 operations, memory would be at 2,122/2,000 chars -- over the limit"`

## Root cause
Memory files grow over time as agent adds entries. The `memory` tool enforces `memory_char_limit` (config.yaml) but doesn't auto-prune. User corrections, session notes, and accumulated context bloat the files.

## Files location
- `/root/.hermes/memories/USER.md` — user profile (limit: `user_char_limit`, default 2000)
- `/root/.hermes/memories/MEMORY.md` — agent memory (limit: `memory_char_limit`, default 20000)

## Cleanup procedure

### 1. Check current usage
```bash
wc -c /root/.hermes/memories/USER.md /root/.hermes/memories/MEMORY.md
```

### 2. Backup before cleanup
```bash
cp /root/.hermes/memories/USER.md /root/.hermes/memories/USER.md.bak
cp /root/.hermes/memories/MEMORY.md /root/.hermes/memories/MEMORY.md.bak
```

### 3. Rewrite with only high-value entries

**USER.md** — keep only:
- Communication format rules (.txt only, no tables, no inline)
- User preferences (zero-based explanations, no community skills)
- Key file delivery rules (curl sendDocument)
- Model preferences per task type

**MEMORY.md** — keep only:
- Infrastructure facts (IPs, ports, URLs, server layout)
- Key project state (Pianoid version, MLflow location)
- Provider/fallback chain (current config)
- Cron job count and status
- Important file paths

**Remove:**
- Duplicate entries (same fact stated multiple times)
- Outdated info (old versions, removed services)
- Session-specific notes that are no longer relevant
- Verbose explanations — condense to bullet points

### 4. Verify
```bash
wc -c /root/.hermes/memories/USER.md /root/.hermes/memories/MEMORY.md
# USER.md should be < 2000
# MEMORY.md should be < 16000 (80% of 20000)
```

## Result (2026-07-09)
- USER.md: 2,759 → 1,006 chars (50% of limit)
- MEMORY.md: 18,505 → 4,439 chars (22% of limit)

## Prevention
- Audit memory files monthly
- Remove duplicates immediately when found
- Prefer concise bullet points over prose
- Cross-check: if a fact is in AGENTS.md, it doesn't need to be in MEMORY.md
