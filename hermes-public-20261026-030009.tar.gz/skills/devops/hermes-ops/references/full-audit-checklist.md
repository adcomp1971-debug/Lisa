# Full Hermes Audit Checklist

Дата создания: 2026-07-01  
Источник: полный аудит Hermes (DeepSeek V4 Pro, 35+ tool calls)

## Структура аудита

Аудит делится на 12 зон. Выполняются параллельно где возможно.

### 1. System Health (система)

```bash
echo "=== DISK ===" && df -h /
echo "=== MEMORY ===" && free -h
echo "=== UPTIME ===" && uptime
echo "=== LOAD ===" && cat /proc/loadavg
echo "=== TOP PROCS ===" && ps aux --sort=-%mem | head -15
```

Что смотреть:
- Диск <75% (иначе ⚠️), <90% (🔴)
- Available RAM >20% от total
- Load average < CPU cores (обычно <1 на idle сервере)
- Top procs: gateway не должен быть >15% MEM в пике (норма ~8-10%)

### 2. Services (systemd)

```bash
echo "=== RUNNING ===" && systemctl list-units --type=service --state=running --no-legend
echo "=== FAILED ===" && systemctl list-units --type=service --state=failed --no-legend
echo "=== TIMERS ===" && systemctl list-timers --no-legend | head -20
# Проверить drop-in overrides (могут переопределять TimeoutStopSec и др.)
for svc in hermes-gateway hermes-gateway-buratino codex-relay codex-relay-longcat codex-relay-glm; do
    echo "=== $svc drop-ins ===" 
    systemctl cat $svc 2>/dev/null | grep -E 'Timeout|timeout|drain'
done
```

Проверить:
- Zero failed services = ✅
- Ключевые сервисы: hermes-gateway, hermes-gateway-*, nginx, tailscaled, docker
- XRay/3x-ui — проверить отдельно (может быть процессом, не systemd)
- **TimeoutStopSec vs drain_timeout:** systemd TimeoutStopSec ДОЛЖЕН быть >= drain_timeout + 30s. Проверять через `systemctl cat` (не `systemctl show` — drop-in override может скрываться)
- **stunnel4 проверка** — `systemctl is-active stunnel4`. Если dead — claude-lc/claude-glm не работают (порты :4451/:4452). Симптом: `curl -sk https://127.0.0.1:4451/v1/models` → timeout/Failed to connect. Фикс: `systemctl restart stunnel4`

### 3. Gateway Health

```bash
systemctl status hermes-gateway --no-pager -l | head -30
journalctl -u hermes-gateway --no-pager -n 20
```

Ключевые метрики:
- `Active: active (running) since ...` + uptime
- Memory (peak) — >3G = повод для беспокойства
- MCP серверы все подняты (AgentMail, Firecrawl, Brave Search, Playwright, GitHub, SQLite)
- Restarts: проверить `Main process exited` в journalctl за последние 7 дней
- Log warnings: `stale stream`, `Broken pipe`, `ReadError`, `skill not found`
- Повторить для каждого gateway-сервиса (default + buratino + др.)

**Pitfall:** gateway не может перезапустить сам себя через systemctl — только Алекс.

### 4. Cron Jobs

```bash
hermes cron list 2>&1
```

Что проверять:
- Все джобы `active` (не `paused`/`error`)?
- Последний ран `ok`?
- Нет `skill not found` warnings в логах gateway?
- Нет дублирования или мертвых джобов?

Сверка с AGENTS.md: добавить/убрать джобы если расходятся.

### 5. Skills

```bash
ls ~/.hermes/skills/ | wc -l
hermes skills list 2>&1 | head -5
```

Что проверять:
- Количество скиллов (должно совпадать с AGENTS.md или быть обновлено)
- Нет мусора (старые absorbed скиллы не должны висеть)
- Сверка: AGENTS.md пишет «60 skills» — реально может быть меньше после consolidation

### 6. Config.yaml

```bash
wc -c /root/.hermes/config.yaml
python3 -c "
import yaml
with open('/root/.hermes/config.yaml') as f:
    cfg = yaml.safe_load(f)
print(f'Model: {cfg.get(\\\"model\\\")}')
print(f'Provider: {cfg.get(\\\"provider\\\")}')
print(f'Fallback: {len(cfg.get(\\\"fallback_providers\\\",[]))} entries')
print(f'Web search: {cfg.get(\\\"web\\\",{}).get(\\\"search_backend\\\")}')
print(f'Gateway timeout: {cfg.get(\\\"agent\\\",{}).get(\\\"gateway_timeout\\\")}s')
# Check provider completeness
for pname, pcfg in cfg.get('providers',{}).items():
    has_burl = 'base_url' in pcfg
    has_key = 'api_key' in pcfg or 'api_key_env' in pcfg
    if not has_burl:
        print(f'⚠️  provider {pname} has NO base_url')
    if not has_key:
        print(f'⚠️  provider {pname} has NO api_key')
"
```

**Critical check:** каждый провайдер, на который ссылается fallback_providers или model, ДОЛЖЕН иметь `base_url` и `api_key`. Пустой провайдер (только timeout/stale) = Hermes роутит запросы через OpenRouter.

Проверить:
- Модель и fallback chain парсятся корректно
- Нет дублированных/пустых entries (старая проблема: provider auto model '' × N)
- BWS_ACCESS_TOKEN: если Bitwarden enabled но токен не установлен — warning на каждый запуск
- All auxiliary providers: `auto` = дорого. Пиннинг на Flash = экономия (см. `references/cost-optimization.md`)
- Provider stale timeouts: если провайдер таймаутится — добавить `stale_timeout_seconds` (см. `references/provider-timeout-tuning.md`)
- Gateway timeout (1800s = 30min нормально, 900s = 15min маловато для тяжёлых задач)
- **mcp_servers секция** — должна быть в config.yaml с явным списком MCP серверов. Если отсутствует — MCP работают через auto-discover, но явная конфигурация надёжнее
- **web.search_backend** — должен быть указан. Если `not-set` — web_search использует backend по умолчанию. Рекомендация: `brave` (если есть BRAVE_API_KEY в .env и BRAVE_SEARCH_API_KEY алиас)
- **Таймауты стека:** gateway_timeout должен быть > delegation.child_timeout_seconds. Текущие: gateway_timeout=1800s, child_timeout=600s — ✅

### 7. Memory & Базы

```bash
ls -lh ~/.hermes/state.db ~/.hermes/sessions.db ~/.hermes/memory.db
du -sh ~/.hermes/backups/
du -sh ~/.hermes/state-snapshots/
du -sh ~/.hermes/*/ | sort -rh | head -10

# Memory char limit check
python3 -c "
import yaml
cfg = yaml.safe_load(open('/root/.hermes/config.yaml'))
mcl = cfg.get('memory',{}).get('memory_char_limit', 1375)
ucl = cfg.get('memory',{}).get('user_char_limit', 1375)
print(f'memory_char_limit: {mcl}')
print(f'user_char_limit: {ucl}')
"
```

Что проверять:
- state.db рост: был 131MB → стал 145MB (Jul 1). Норма ~10-15MB/день
- memory.db: 0 bytes = не используется (ok — память через memory tool)
- backups: если >3GB подумать о retention
- snapshots: если >200MB подумать о `auto_prune`

### 8. Network & VPN

```bash
tailscale status
echo "=== AWG ===" && awg show awg0 2>&1
echo "=== X-UI INBOUNDS ===" && sqlite3 /etc/x-ui/x-ui.db "SELECT id, protocol, port, enable, expiry_time FROM inbounds;" 2>&1
echo "=== X-UI VLESS CLIENTS ===" && sqlite3 /etc/x-ui/x-ui.db "SELECT settings FROM inbounds WHERE port=443;" 2>&1 | python3 -c "import sys,json; clients=json.load(sys.stdin)['clients']; print(f'Total: {len(clients)} clients'); [print(f'  {c[\"email\"]} enabled={c[\"enable\"]}') for c in clients]" 2>&1
echo "=== PORTS ===" && ss -tlnp | grep -E '443|51820|49624|8080|8642'
```

Проверить:
- Tailscale: все пиры online? Funnel активен?
- AWG: количество пиров, handshake age (>4h = stale, но не удалять без подтверждения)
- X-UI: инбаунд VLESS:443 active? Все клиенты enabled? Expiry — есть просроченные?
- Ports: нет конфликтов, все ожидаемые порты открыты
- XRay managed как systemd? Если нет — ⚠️ не переживёт ребут

### 9. Provider Balances & OAuth

```bash
bash /root/.hermes/scripts/check-balances.sh 2>&1
echo "=== OAUTH TOKENS ===" && find /root/.hermes -maxdepth 1 -name "oauth_tokens.json" 2>/dev/null && echo "EXISTS" || echo "MISSING"
echo "=== FALLBACK OAUTH CHECK ===" && python3 -c "
import yaml
cfg = yaml.safe_load(open('/root/.hermes/config.yaml'))
for fb in cfg.get('fallback_providers',[]):
    if 'oauth' in fb.get('provider',''):
        print(f'⚠️  fallback {fb[\"model\"]} uses OAuth provider {fb[\"provider\"]} — verify token exists')
" 2>&1
```

Проверить:
- DeepSeek баланс >$1.00 (иначе ⚠️)
- GLM/Z.AI: 429 = баланс исчерпан (🔴)
- xAI OAuth: oauth_tokens.json существует? Если нет, но xai-oauth в fallback — 🔴
- LongCat: стабилен? 200 = ✅
- Все провайдеры, упомянутые в fallback_providers, реально доступны

**Pitfall:** GLM 429 `Insufficient balance or no resource package` — баланс Z.AI исчерпан. Затрагивает buratino профиль (primary = glm-5.2) и default fallback (первый в цепочке).

**Pitfall: OpenRouter hijack.** `OPENROUTER_API_KEY` в `.env` заставляет Hermes использовать OpenRouter вместо явно настроенного `deepseek` провайдера, даже если в конфиге указан `provider: deepseek`. Причина: Hermes авто-регистрирует провайдеры из env-переменных и OpenRouter имеет приоритет. Диагностика: `journalctl | grep "provider="` покажет `openrouter`. Фикс: удалить OPENROUTER_API_KEY из .env, добавить `provider: deepseek` в корень config.yaml + base_url/api_key в deepseek секцию. См. `references/provider-routing-quirks.md`.

### 10. Model Live Tests (прямые вызовы)

Не только `/v1/models` (может работать при исчерпанном балансе), но и реальный chat completion:

```bash
# DeepSeek
curl -s -o /dev/null -w "deepseek-flash: HTTP %{http_code} (%{time_total}s)\n" --connect-timeout 10 \
  https://api.deepseek.com/v1/chat/completions \
  -H "Authorization: Bearer $(grep DEEPSEEK_API_KEY /root/.hermes/.env | cut -d= -f2)" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-chat","messages":[{"role":"user","content":"hi"}],"max_tokens":5}'

# Grok — OAuth vs API key: пробовать оба, логировать разницу
# LongCat — через relay :4447 (Responses API, не Chat!)
curl -s -w "\n%{http_code}\n" --connect-timeout 10 \
  http://127.0.0.1:4447/v1/responses \
  -H "Content-Type: application/json" \
  -d '{"model":"LongCat-2.0","input":"hi","max_output_tokens":5}'
```

**Pitfall:** Codex relay порты (:4446, :4447, :4448) — это **Responses API** (формат Codex), не Chat Completions. `/v1/chat/completions` возвращает 404 — это НОРМАЛЬНО. Тестировать через `/v1/responses`. `/v1/models` работает на всех трёх.

### 11. AGENTS.md Sync

```bash
cat ~/.hermes/AGENTS.md
```

Сверка с реальностью:
- Количество skills (в AGENTS.md vs `ls ~/.hermes/skills/ | wc -l`)
- Список cron джобов (в AGENTS.md vs `hermes cron list`)
- Модель delegation (AGENTS.md может расходиться с config.yaml — проверять provider, model, fallback chain)
- Skills section (категории) — если расходится
- **Особое внимание:** AGENTS.md fallback chain vs config.yaml fallback_providers — часто расходятся
- **Релейные воркеры для default и buratino профилей:**
  - Проверить `/usr/local/bin/codex-lc`, `codex-glm`, `codex-ds`, `claude-lc`, `claude-glm` для default
  - Проверить `/usr/local/bin/buratino-codex`, `buratino-codex-lc`, `buratino-claude`, `buratino-claude-glm` для buratino
  - Модели и релеи в обёртках должны соответствовать AGENTS.md (LongCat-2.0 через :4447, GLM 5.2 через :4448, DS V4 Pro через :4446)
  - Для Claude Code обёрток проверить ANTHROPIC_BASE_URL (stunnel порты :4451 LongCat, :4452 GLM) и ANTHROPIC_MODEL
  - Если в AGENTS.md нет секции с воркерами — добавить
- **Profile-specific architecture:** проверить что AGENTS.md декларирует не только default, но и buratino, vasily — их модели, фоллбэки, воркеры

### 12. Security

- BWS_ACCESS_TOKEN: Bitwarden enabled но токен отсутствует → либо настроить, либо `secrets.bitwarden.enabled: false`
- Ручные конфиги (/root/bin/config.json) — не managed, не переживут ребут
- AWG конфиги — проверить, что все .conf файлы лежат в /etc/amnezia/amneziawg/
- XRay — если запущен процессом без systemd, добавить юнит
- **Orphan aliases** — `hermes doctor | grep orphan`. Orphan alias = wrapper script в /root/.local/bin/ для профиля, который удалён. Удалить через `rm -f /root/.local/bin/<name>`. `hermes profile alias <name> --remove` не сработает если профиля нет.

## После аудита: отчёт

Формат отчёта — **единая сводная таблица** с эмодзи-статусами (✅⚠️🔴) для всех зон:

```
| # | Компонент | Статус | Детали |
|---|-----------|--------|--------|
| 1 | System Health | ✅/⚠️/🔴 | цифры |
| 2 | Services | ✅ | active |
...
```

В конце: 🔴 КРИТИЧЕСКИЕ ПРОБЛЕМЫ (требуют действий), ⚠️ ПРЕДУПРЕЖДЕНИЯ, ✅ ВСЁ ОК, РЕКОМЕНДУЕМЫЕ ДЕЙСТВИЯ.

Не разбивать на три отдельных GREEN/YELLOW/RED секции — единая таблица быстрее читается.

## Триггеры для аудита

- Раз в неделю (пн 09:00 — weekly-hermes-audit cron)
- После ребута сервера
- После `hermes update`
- После крупного рефакторинга скиллов/конфигов
- Если Алекс говорит «полная жопа»

## Post-Update Pitfalls

### Stashed local gateway patches

Если в процессе `hermes update --yes` были локальные правки в gateway-файлах (gateway/config.py, gateway/run.py и др.), update может выдать:

```
Auto-merging gateway/config.py
CONFLICT (content): Merge conflict in gateway/config.py
Working tree reset to clean state.
```

Это НОРМАЛЬНО — update сбрасывает конфликтные файлы до upstream-версии, а локальные правки сохраняет в stash:

```bash
git stash show -p cafdc92d9a857c80e6cf6b7fd09cd122944b4520
git stash apply cafdc92d9a857c80e6cf6b7fd09cd122944b4520  # вернуть
```

**Pitfall:** stash-хэш уникален — после apply/clear восстановить нельзя. Записать хэш перед продолжением.

**Pitfall:** после `hermes update` gateway auto-перезапускается (это встроено). Если stash не применить, local правки пропадут до ручного восстановления.

**Pitfall:** `hermes update` сам выполняет `systemctl restart hermes-gateway` для ВСЕХ gateway-сервисов (default + buratino + др.). Не дублировать команду restart после update — возможен race condition.

### Verification after update

Минимальный чеклист после `hermes update`:

```bash
hermes --version                    # up to date?
hermes doctor                       # no errors?
hermes config check                 # config version ok?
hermes fallback list                # fallback chain intact?
systemctl is-active hermes-gateway  # default gateway running?
systemctl is-active hermes-gateway-buratino  # buratino gateway running?
```

### Обновлённые bundled skills

`hermes update` синхронизирует bundled skills. Если были локальные модификации bundled skills — они помечаются как `user-modified (kept)`. Проверить после update:

```bash
hermes skills list-modified         # посмотреть что изменилось
```

Если bundled skill был модифицирован, а апстрим изменился — Hermes сохраняет локальную версию (не перезаписывает). Важно: если локальная правка была для фикса бага, который уже починили в апстриме — лучше `hermes skills uninstall` + переустановить bundled.
