# Codex Relay Architecture (Rust)

## Overview

Кодекс релеи — Rust-бинари (`codex-relay`), которые конвертируют **Responses API** (Codex CLI) ↔ **Chat Completions** (LLM провайдеры). Работают как HTTP + WebSocket bridge.

## Port Layout

| Port | Model | Провайдер | Сервис | WS |
|------|-------|-----------|--------|-----|
| 4446 | DeepSeek V4 Pro | DeepSeek | `codex-relay.service` | ✅ 101 |
| 4447 | LongCat-2.0 | LongCat | `codex-relay-longcat.service` | ✅ 101 |
| 4448 | GLM 5.2 | Z.AI | `codex-relay-glm.service` | ✅ 101 |

## Как это работает

```
Codex CLI ──WS/HTTP──→ codex-relay (:4447) ──HTTP──→ api.longcat.chat
                           ↓
                    translate.rs: Responses → Chat Completions
                    stream.rs: SSE → Responses events
                    ws.rs: WebSocket upgrade handler
```

## WebSocket support (2026-07-04)

Раньше WS не работал. Теперь работает на всех 3 релеях.

### CRITICAL: Axum 0.7 route quirk

**НЕЛЬЗЯ** использовать отдельные `.route()` вызовы для одного пути:

```rust
// ❌ НЕ РАБОТАЕТ — второй .route() ПЕРЕЗАПИСЫВАЕТ первый
.route("/v1/responses", post(handle_responses))
.route("/v1/responses", get(handle_ws_upgrade))

// ✅ РАБОТАЕТ — method chaining
.route("/v1/responses", get(handle_ws_upgrade).post(handle_responses))
```

В Axum 0.7, вызов `.route()` для уже существующего пути **заменяет** предыдущий handler, а не добавляет метод. Только method chaining через `.get().post()` работает.

### WS handler pattern

```rust
async fn handle_ws_upgrade(
    State(state): State<AppState>,
    ws: WebSocketUpgrade,
) -> Response {
    ws.on_upgrade(move |socket| async move {
        ws::handle_ws(socket, state.client.clone(), ...).await;
    })
}
```

Обработчик читает JSON Responses-запросы, проксирует как HTTP stream к upstream, возвращает SSE-подобные события как WS сообщения.

## Структура проекта

```
/root/codex-relay-rust/
├── src/
│   ├── main.rs       — маршруты, handler, args
│   ├── ws.rs         — WebSocket handler (добавлен 04.07)
│   ├── stream.rs     — SSE streaming
│   ├── translate.rs  — Responses ↔ Chat Completions
│   ├── types.rs      — структуры
│   └── session.rs    — управление сессиями
├── Cargo.toml
├── run-relay.py          — :4446 (DeepSeek)
├── run-relay-longcat.py  — :4447 (LongCat)
└── run-relay-glm.py      — :4448 (GLM)
```

## Wrapper скрипты

Каждый релей запускается через Python wrapper, который:
1. Читает правильный API ключ из `/root/.hermes/.env`
2. Ставит `CODEX_RELAY_API_KEY` в env процесса
3. Запускает Rust бинарь с нужным портом и upstream URL

```python
# run-relay-longcat.py
env['CODEX_RELAY_PORT'] = '4447'
env['CODEX_RELAY_UPSTREAM'] = 'https://api.longcat.chat/openai/v1'
env['CODEX_RELAY_API_KEY'] = key
subprocess.Popen(['/root/codex-relay-rust/target/release/codex-relay'], env=env)
```

## Codex CLI config (`.codex/config.toml`)

```toml
model_provider = "longcat-relay"
model = "LongCat-2.0"

[model_providers.longcat-relay]
name = "LongCat via Relay"
base_url = "http://localhost:4447/v1"
wire_api = "responses"
env_key = "CODEX_RELAY_API_KEY"
requires_openai_auth = false
```

### Важные параметры:
- `base_url` — **обязательно с `/v1`** (без него Codex бьёт в `/responses` без префикса)
- `wire_api = "responses"` — Responses API формат
- `requires_openai_auth = false` — не требовать OpenAI OAuth
- `env_key` — имя env-переменной для API ключа (должна быть в `.env` или system env)

## Переключение модели в Codex

```bash
# LongCat (default)
codex

# GLM 5.2
codex exec -c model='"glm-5.2"' -c model_provider='"glm-relay"' "задача"

# DeepSeek V4 Pro
codex exec -c model='"deepseek-v4-pro"' -c model_provider='"deepseek-relay"' "задача"
```

## Hermes provider config

В профилях (default/buratino) кодекс-релей добавляется как обычный провайдер:

```yaml
providers:
  codex-relay:
    api_key: ${LONGCAT_API_KEY}
    base_url: http://127.0.0.1:4447/v1
  glm-relay:
    api_key: ${ZAI_API_KEY}
    base_url: http://127.0.0.1:4448/v1
```

## Systemd

| Сервис | Порт | Описание |
|--------|------|----------|
| `codex-relay.service` | 4446 | DeepSeek V4 Pro |
| `codex-relay-longcat.service` | 4447 | LongCat-2.0 |
| `codex-relay-glm.service` | 4448 | GLM 5.2 |

```bash
systemctl restart codex-relay-longcat
systemctl restart codex-relay-glm
systemctl restart codex-relay
```

## Диагностика

```bash
# HTTP test
curl -s http://localhost:4447/v1/models | python3 -m json.tool

# HTTP Responses API
curl -s http://localhost:4447/v1/responses \
  -H "Content-Type: application/json" \
  -d '{"model":"LongCat-2.0","input":"ping","stream":false,"max_output_tokens":5}'

# WebSocket test
curl -s -o /dev/null -w "%{http_code}" \
  -H "Upgrade: websocket" -H "Connection: Upgrade" \
  -H "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==" \
  -H "Sec-WebSocket-Version: 13" \
  http://localhost:4447/v1/responses --max-time 5
# Ожидается: 101 (Switching Protocols)

# Логи
journalctl -u codex-relay-longcat --since "5 min ago" --no-pager | tail -20
```

## История

- 2026-07-03: Созданы релеи на Rust вместо Python
- 2026-07-04: Добавлен WS handler через Axum WebSocketUpgrade
- 2026-07-04: Исправлен баг с Axum route merging (отдельные .route() перезаписываются)
- 2026-07-04: Добавлены /responses (без /v1/) маршруты для Codex 0.139.0
- 2026-07-04: CODEX_RELAY_API_KEY добавлен в .env
- 2026-07-04: Codex CLI config переведён на model_providers формат
