# Codex Relay Healthcheck — False Positives & Fix

## Problem (03.07.2026)

Cron `codex-relay-healthcheck` (every 30m) reported:

```
❌ Codex relay healthcheck FAILED:
LongCat-2.0 (:4447) — timed out
```

But relay was actually alive and responding normally.

## Root Cause

Healthcheck script (`/root/.hermes/scripts/codex-relay-healthcheck.py`) used `timeout=5` seconds with no retry. Transient delays (cold start, upstream API latency, TCP handshake jitter) exceeded 5s, triggering false alarm.

## Fix Applied

1. **Timeout:** 5s → 10s
2. **Retry:** Added 1 retry with 1s sleep before failing
3. **Script updated:** `/root/.hermes/scripts/codex-relay-healthcheck.py`

### Updated script

```python
#!/usr/bin/env python3
import http.client, json, time

relays = [
    ("DeepSeek V4 Pro", 4446),
    ("LongCat-2.0", 4447),
    ("GLM 5.2", 4448),
]

errors = []
for name, port in relays:
    for attempt in range(2):
        try:
            conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
            conn.request("GET", "/v1/models")
            resp = conn.getresponse()
            data = json.loads(resp.read())
            if not data.get("data"):
                errors.append(f"{name} (:{port}) — 0 models returned")
            conn.close()
            break
        except Exception as e:
            if attempt == 1:
                errors.append(f"{name} (:{port}) — {e}")
            else:
                time.sleep(1)

if errors:
    print("❌ Codex relay healthcheck FAILED:\n" + "\n".join(errors))
```

## How to test relay manually

```bash
# Check if relay is listening
ss -tlnp | grep -E '4446|4447|4448'

# Check models endpoint
curl -s http://127.0.0.1:4447/v1/models | python3 -m json.tool | head -5

# Check GLM relay (uses Responses API, NOT Chat Completions)
curl -s -X POST http://127.0.0.1:4448/v1/responses \
  -H "Content-Type: application/json" \
  -d '{"model":"glm-5.2","input":"Say hello"}'

# Direct Z.AI API test (bypass relay)
source /root/.hermes/.env
curl -s https://api.z.ai/api/paas/v4/chat/completions \
  -H "Authorization: Bearer $ZAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"glm-5.2","messages":[{"role":"user","content":"hi"}],"max_tokens":10}'
```

## Pitfalls

- GLM relay (:4448) uses `/v1/responses` (Responses API), not `/v1/chat/completions`
- LongCat relay (:4447) uses standard `/v1/chat/completions`
- DeepSeek relay (:4446) uses standard `/v1/chat/completions`
- Z.AI returns `"Insufficient balance"` when out of credits — relay works, upstream fails
- Healthcheck should never restart the relay — only report
