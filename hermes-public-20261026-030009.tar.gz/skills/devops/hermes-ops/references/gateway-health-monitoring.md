# Gateway Health Monitoring

Скрипт `~/.hermes/scripts/gateway-watch.py` — no_agent watchdog, проверяет количество exit-code крашей gateway за 24ч.

## Крон

```bash
cronjob(
  action='create',
  name='gateway-watch',
  script='gateway-watch.py',
  schedule='every 3h',
  no_agent=True,
  deliver='origin'
)
```

## Поведение

- 0-3 exit-code за 24ч → молча (всё ок)
- >3 exit-code → 🔴 алерт пользователю: "Gateway crashed Nx in last 24h"

## Gateway TimeoutStopSec fix (stale systemd unit)

**Проблема:** `systemctl show hermes-gateway -p TimeoutStopUSec` показывает 90s, но `drain_timeout=180s`. systemd SIGKILL gateway при drain'е → crash-loop с exit-code.

**Фикс через drop-in (не требует переустановки unit):**

```bash
mkdir -p /etc/systemd/system/hermes-gateway.service.d
cat > /etc/systemd/system/hermes-gateway.service.d/timeout.conf << 'EOF'
[Service]
TimeoutStopSec=210
EOF
systemctl daemon-reload
```

После этого рестарт gateway (изнутри блокируется — через no_agent cron скрипт).

**Pitfall:** Drop-in сбрасывается при `hermes gateway install` — после переустановки gateway service нужно пересоздать timeout.conf.
