# Auxiliary Service Configuration — Direct Providers

## Policy

All auxiliary Hermes services (vision, approval, curator, title generation, session search, kanban, triage, MCP, skills hub) MUST use direct providers — never OpenRouter unless the model has no direct API.

## Configuration Pattern

Each auxiliary service in `~/.hermes/config.yaml` has:
```yaml
auxiliary:
  <service_name>:
    provider: <direct_provider>    # deepseek / google / openai / nvidia / xai
    model: <model_name>
    base_url: ''                   # omit to use provider default
    api_key: ''                    # omit to inherit from provider section
    timeout: 30
```

When `api_key` and `base_url` are empty strings, the service inherits from the matching `providers.<name>` section. To use a custom endpoint, specify them directly.

## Vision — Direct OpenAI GPT-4o

**Migration from Gemini → direct OpenAI GPT-4o (June 13, 2026):**

```yaml
auxiliary:
  vision:
    provider: openai
    model: gpt-4o
    base_url: https://api.openai.com/v1
    api_key: ${OPENAI_API_KEY}     # references provider.openai.api_key
    timeout: 120
```

Key points:
- `provider: openai` uses the OpenAI provider config (reads `OPENAI_API_KEY` from `providers.openai.api_key`)
- GPT-4o is the best vision model available — significantly better than Gemini for reading UI, code on screenshots, diagrams
- DeepSeek does NOT have vision — always use GPT-4o, Grok, or Gemini for image analysis
- Previous setup used Gemini 3.5 Flash via Google API — migration was trivial, just changed provider/model/base_url
- Grok 4.3 also has vision via `provider: xai` but GPT-4o is more accurate

## Other Auxiliary Services

### Approval / Curator / Title / Session Search / Kanban / MCP / Skills Hub / Triage

All on DeepSeek V4 Flash — straight from `providers.deepseek`:

```yaml
auxiliary:
  approval:
    provider: deepseek
    model: deepseek-v4-flash
    base_url: ''
    api_key: ''
    timeout: 30
```

Configuration is trivial — just set `provider: deepseek`, `model: deepseek-v4-flash`, leave `base_url` and `api_key` empty.

### Using `hermes config set` for Auxiliary Services

For simple scalar values, `hermes config set` works correctly:

```bash
# ✅ Works — sets scalar values correctly
hermes config set auxiliary.vision.provider openai
hermes config set auxiliary.vision.model gpt-4o
hermes config set auxiliary.vision.base_url "https://api.openai.com/v1"
hermes config set auxiliary.vision.api_key '${OPENAI_API_KEY}'
```

The value `${OPENAI_API_KEY}` must be wrapped in **single quotes** to prevent bash variable expansion. Without quotes or with double quotes, bash replaces `${OPENAI_API_KEY}` with the actual key value before passing it to `hermes config set`.

⚠️ For `api_key` values that reference `${VAR}` from `.env`, always use single quotes: `'${VARIABLE_NAME}'`. If the value should contain the `${}` literal, single quotes are mandatory.

## Testing Vision After Config Change

```bash
# Quick test: send a request to OpenAI GPT-4o (for vision)
source ~/.hermes/.env
curl -s -w "\nHTTP: %{http_code}" https://api.openai.com/v1/models \
  -H "Authorization: Bearer *** -2
# Expect: "...\"gpt-4o\"..." and "HTTP: 200"

# Test actual vision capability (requires sending an image)
# The gateway auto-uses auxiliary.vision — just send a picture in Telegram
```

**Safe key testing pattern:** Always `source /root/.hermes/.env` then use `$VARIABLE_NAME` in curl — never paste the key value into the command text. This avoids Hermes auto-redaction (`***`) breaking string literals in the tool output.

## Fallback Chain — Direct First

```yaml
fallback_providers:
- model: deepseek-v4-flash
  provider: deepseek
- model: deepseek-v4-pro
  provider: deepseek
- model: o3-mini
  provider: openai               # reasoning layer — strong but cheap
- model: google/gemini-3.5-flash
  provider: google
- model: grok-4.3
  provider: xai
- model: nvidia/llama-3.3-nemotron-super-49b-v1
  provider: nvidia
- model: moonshotai/kimi-k2.7-code
  provider: openrouter        # only because Kimi has no direct API
```

**WARNING:** `hermes config set fallback_providers` stores the value as a YAML-quoted JSON string, not a proper YAML list. After setting with `hermes config set`, the config will look like:
```yaml
fallback_providers: '[{"provider":"deepseek","model":"..."}]'
```
This breaks fallback resolution. **Fix:** use Python to re-write the YAML:
```python
import yaml, json
with open('/root/.hermes/config.yaml') as f:
    config = yaml.safe_load(f)
if isinstance(config['fallback_providers'], str):
    config['fallback_providers'] = json.loads(config['fallback_providers'])
with open('/root/.hermes/config.yaml', 'w') as f:
    yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
```

## Provider Availability

| Provider | Key Format | Endpoint | Status |
|----------|-----------|----------|--------|
| DeepSeek | `sk-...` | api.deepseek.com | ✅ Always on |
| Google/Gemini | AIza... | generativelanguage.googleapis.com | ✅ Free tier |
| NVIDIA | `nvapi-...` | integrate.api.nvidia.com/v1 | ✅ Free tier |
| xAI/Grok | (OAuth or key) | api.x.ai/v1 | ✅ SuperGrok sub |
| OpenAI | `sk-proj-...` | api.openai.com/v1 | ✅ If key provided |
| OpenRouter | `sk-or-...` | openrouter.ai/api/v1 | ❌ Last resort only |
