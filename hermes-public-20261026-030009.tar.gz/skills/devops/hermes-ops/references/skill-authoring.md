# Skill Authoring & Installation

## Installing Official Optional Skills

Official optional skills ship with Hermes but are inactive by default. Installation triggers a security scan + interactive confirmation:

```bash
# Interactive — prompts confirm [y/N]
hermes skills install official/<category>/<skill>

# Non-interactive (bypass security prompt for trusted official sources)
yes | hermes skills install official/<category>/<skill>
```

The `yes |` pipe answers "y" to the security scan's "DANGEROUS — Install anyway?" prompt. Safe for official/builtin skills (Nous-maintained). Only use `yes |` for official skills — for community/scraped skills, review the scan verdict first.

Known working installs (June 2026):
```bash
yes | hermes skills install official/devops/watchers
yes | hermes skills install official/devops/docker-management
yes | hermes skills install official/email/agentmail
```

## Installing Community Skills (git clone)

Community skills are git repositories that you clone directly into `~/.hermes/skills/`. They appear in `skills_list` automatically after the next Hermes session start (`/reset` or restart).

```bash
cd ~/.hermes/skills
git clone https://github.com/<author>/<repo>.git
```

Pitfalls:
- **No security scan** — community skills bypass the hub's quarantine+scan pipeline. Review the SKILL.md before first use.
- **Name collision** — if two repos have identically-named skills, Hermes loads the alphabetically-first one.
- **Git pull updates** — `cd ~/.hermes/skills/<repo> && git pull` updates all skills in that repo.
- **Cloned repos persist across `hermes update`** — they're outside the bundled/hub system.

## Creating Skills

Create and maintain in-repo `SKILL.md` files:
- **Frontmatter:** Must include `name`, `description`, `category`, and `version`.
- **Validator:** Ensure YAML frontmatter is valid and markdown body follows the standard structure (Overview, Steps, Pitfalls).
- **Support files:** Use `references/`, `templates/`, and `scripts/` directories for session-specific detail. Do not bloat the main `SKILL.md`.

## Standalone Middleware Scripts

When extending Hermes behavior without touching production code, use the **standalone middleware pattern** — see `references/standalone-middleware-pattern.md` for the full recipe (threshold monitoring, exit-code signaling, ad-hoc verification workflow).
