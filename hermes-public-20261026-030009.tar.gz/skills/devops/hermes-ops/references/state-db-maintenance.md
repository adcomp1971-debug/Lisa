# State.db Maintenance

## state.db maintenance cron

Add a weekly cron to prevent state.db bloat (>200MB = degraded search). Create with:

```bash
cronjob(action='create', name='state-db-prune', script='state-db-prune.sh',
        schedule='0 4 * * 1', deliver='local', no_agent=True)
```

Script content (`~/.hermes/scripts/state-db-prune.sh`):
```bash
#!/bin/bash
hermes sessions prune --older-than 14 -y 2>&1
hermes sessions optimize 2>&1
```

Deliver='local' — тихий запуск без уведомлений. Проверить: `hermes cron list`.

## State.DB Diagnostics

When state.db appears large (100MB+), check if it's genuine usage or bloat:

```bash
# Total sessions, with real column names
sqlite3 ~/.hermes/state.db "SELECT COUNT(*) as sessions, ROUND(SUM(length(content))/1024.0) as kb_total,
  datetime(MIN(started_at),'unixepoch') as oldest, datetime(MAX(started_at),'unixepoch') as newest FROM messages;"

# Daily message distribution  
sqlite3 ~/.hermes/state.db "SELECT date(started_at,'unixepoch') as day, COUNT(*) as msgs FROM messages GROUP BY day ORDER BY day;"

# Session table — sessions older than N days
sqlite3 ~/.hermes/state.db "SELECT COUNT(*) FROM sessions WHERE started_at < unixepoch('now', '-14 days') AND archived=0;"

# Check for unused free pages
sqlite3 ~/.hermes/state.db "SELECT page_count * page_size / 1024 / 1024 AS total_mb, freelist_count * page_size / 1024 / 1024 AS free_mb FROM pragma_page_count(), pragma_page_size(), pragma_freelist_count;"

# VACUUM to reclaim if free pages exist
sqlite3 ~/.hermes/state.db "VACUUM;"
```

## Session Pruning

`hermes sessions prune --older-than N` requires `--yes` flag when run without TTY (cron jobs, background tasks). Without it, prompts `[y/N]` and silently cancels.

```bash
# Correct cron usage:
hermes sessions prune --older-than 30 --yes
```

**Pitfall:** Actual state.db is at `~/.hermes/state.db` (often 200-300 MB with 175+ sessions). The file `~/.hermes/sessions/state.db` is a 0-byte placeholder — NOT the real DB.

**Pitfall:** `hermes sessions prune` manages the DB ONLY. Old JSON dump files in `~/.hermes/sessions/` (`session_*.json`, `request_dump_*.json`) accumulate and are NOT cleaned by prune.

**Pitfall:** 195MB for 35MB message content + FTS5 full-text indexes is normal. VACUUM reclaims nothing if freelist_count = 0 — the space is genuinely in use by FTS5 indexes.

**Pitfall — prune filters by `ended_at`, NOT `started_at`:** `hermes sessions prune --older-than N` only deletes sessions where `ended_at IS NOT NULL AND ended_at < now - N days`. Active sessions (no `ended_at`) are never pruned regardless of age. Verify before pruning:

```sql
-- How many sessions are actually prunable (ended + older than N days)?
sqlite3 ~/.hermes/state.db \
  "SELECT COUNT(*) FROM sessions WHERE ended_at IS NOT NULL AND ended_at < strftime('%s','now','-30 days');"
```

**Pitfall — 30-day prune can return 0 on a large DB:** Cron jobs create hundreds of short-lived sessions per week. All of them have `ended_at` set, but if none are older than 30 days, prune returns 0. The DB stays large because the sessions are recent. When this happens, use a shorter window (7–14 days) to clear short-lived cron noise:

```bash
# 30-day prune returned 0 but DB was 180MB with 388 sessions?
# Drop to 7 days — clears hundreds of ended cron sessions:
hermes sessions prune --older-than 7 --yes
# Then VACUUM to reclaim freed pages:
sqlite3 ~/.hermes/state.db "VACUUM;"
```

**Verified result (2026-07-05):** 30-day prune → 0 deleted. 7-day prune → 183 deleted. VACUUM shrunk DB from 180MB → 142MB (38MB reclaimed). 205 sessions remained, oldest from 2026-06-15.
