# Cost-Optimized Model Chain

## Chain (June 14, 2026)

```
User (Telegram)
└── DeepSeek V4 Flash ($0.5/M input) ← default (90% of tasks)
    ├── Complex tasks → DeepSeek V4 Pro ($2/M) ← manual switch
    ├── Delegation → DeepSeek V4 Pro ($2/M)
    ├── Vision → GPT-4o (OpenAI direct) ← best vision model
    ├── Cron jobs → Gemini 3.5 Flash ($0.08/M) ← all LLM cron
    └── Fallback: Flash → V4 Pro → Claude Sonnet 4.6 (OpenRouter) → Gemini 3.5 (direct)
```

**Compressed from 8 to 4 providers (Jun 14, 2026):** Removed duplicate DeepSeek Flash, Grok 4.3, o3-mini, Kimi K2.7. User preference: V4 Pro over Grok as 2nd line.

**Policy: Direct providers first. OpenRouter only as last resort.**

## Apply Chain

```bash
# Set default
hermes config set model.default deepseek-v4-flash
hermes config set model.provider deepseek

# Set delegation
hermes config set delegation.model deepseek-v4-pro
hermes config set delegation.provider deepseek

# Set aux models
hermes config set auxiliary.approval.provider deepseek
hermes config set auxiliary.approval.model deepseek-v4-flash
hermes config set auxiliary.vision.provider openai
hermes config set auxiliary.vision.model gpt-4o
hermes config set auxiliary.vision.base_url "https://api.openai.com/v1"
hermes config set auxiliary.vision.api_key '${OPENAI_API_KEY}'

# Set fallback chain — WARNING: hermes config set will stringify arrays!
# Use direct YAML edit or Python to write proper list (see aux-reference).
# Correct YAML (as applied Jun 14, 2026):
fallback_providers:
- provider: deepseek
  model: deepseek-v4-pro
- provider: openrouter
  model: anthropic/claude-sonnet-4.6
- provider: google
  model: google/gemini-3.5-flash

# Verify
hermes fallback list
grep -A 8 "^fallback_providers:" ~/.hermes/config.yaml

## Cost Guard Rules
- Anthropic models: BLOCKED (user prohibition, June 12, 2026)
- Cron LLM: Gemini 3.5 Flash only ($0.08/M)
- Vision: GPT-4o via OpenAI direct (was Gemini → moved June 13, 2026)
- Session default: DeepSeek V4 Flash ($0.5/M)
- Heavy tasks: DeepSeek V4 Pro (~$2/M) — switch manually
- All auxiliary services on direct providers — never OpenRouter unless no direct API
- Fallback chain compressed to 4 providers (Jun 14): no Grok, o3-mini, Kimi, dupe Flash
- All auxiliary services on direct providers — never OpenRouter unless no direct API
