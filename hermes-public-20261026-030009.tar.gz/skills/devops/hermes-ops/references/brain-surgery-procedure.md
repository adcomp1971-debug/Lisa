# Brain Surgery Procedure — Hermes Config/Memory Synchronization

## Когда применять
- При расхождении fallback chain между config.yaml, AGENTS.md, MEMORY.md
- После обновления Hermes (update может перетереть конфиг)
- При аудите «мозгов» (по запросу пользователя или weekly-audit)

## Принцип
**config.yaml — единственный источник правды.**
Всё остальное (AGENTS.md, MEMORY.md, скиллы) — производные и обязаны совпадать.

## Порядок действий

### 1. Зафиксировать эталон
```bash
grep -A12 "^fallback_providers:" /root/.hermes/config.yaml
# Для каждого профиля:
grep -A8 "^fallback_providers:" /root/.hermes/profiles/buratino/config.yaml
grep -A4 "^fallback_providers:" /root/.hermes/profiles/vasily/config.yaml
```

### 2. Синхронизировать AGENTS.md
Сравнить секцию «Фоллбэк» для каждого профиля с эталоном:
```bash
grep "Фоллбэк" /root/.hermes/AGENTS.md
```
Расхождения → patch через skill_manage или write_file.

Проверить: нет ли примеров с запрещёнными провайдерами (gpt-5.5, openai-codex).

### 3. Синхронизировать MEMORY.md
```bash
grep -in "fallback\|openai\|nvidia\|xai_api" /root/.hermes/memories/MEMORY.md
```
Каждая запись про fallback/providers должна совпадать с config.yaml.
Удалить дубли (например «AGENTS.md: N cron, M skills» — это в AGENTS.md, не в памяти).

### 4. Мёртвые провайдеры
Проверить: какие провайдеры в config.yaml не referenced ни в model, ни в fallback:
```bash
python3 -c "
import yaml; c = yaml.safe_load(open('/root/.hermes/config.yaml'))
providers = set(c.get('providers',{}).keys())
used = set()
if 'provider' in c.get('model',{}): used.add(c['model']['provider'])
for f in c.get('fallback_providers',[]): used.add(f.get('provider',''))
print('Providers:', providers)
print('Used:', used)
print('Dead:', providers - used)
"
```
Мёртвые → удалить из config.yaml (python3 yaml.load/dump). Ключи из .env — в бэкап.

### 5. YAML-валидация
```bash
python3 -c "import yaml; yaml.safe_load(open('/root/.hermes/config.yaml')); print('OK')"
```

### 6. Верификация
```bash
echo "=== config ===" && grep -A8 "^fallback_providers:" /root/.hermes/config.yaml
echo "=== AGENTS ===" && grep "Фоллбэк" /root/.hermes/AGENTS.md
echo "=== MEMORY ===" && grep -i "fallback" /root/.hermes/memories/MEMORY.md
```

## Config Hardening

### subagent_auto_approve
- default: `false` — дети наследуют MCP-тулсеты включая sqlite-vpnbot (прод-БД!)
- buratino: `true` — изолированные ML-задачи, нет прод-БД

### verify_on_stop
- `true` — при /stop сохранять состояние в память (одна строка: что делал, на чём остановился)

### security.redact_secrets
- `true` — маскировать ключи/токены в выводе инструментов

### provider timeouts
- Каждый провайдер должен иметь `request_timeout_seconds` и `stale_timeout_seconds`
- google — типичный зомби без таймаутов (добавить 600/300)

## Cost Guard Setup

### cost-report.py
Скрипт: `~/.hermes/scripts/cost-report.py`
- Принимает аргумент: окно в днях (по умолчанию 7)
- Env: `COST_ALERT_THRESHOLD` (по умолчанию 7.0)
- Exit 0: расход в норме, exit 1: превышение (для cron алерта)
- Модели в `MODEL_COSTS`: deepseek, LongCat, glm, gemini, grok, claude

### Cron
```
daily-cost-guard: 0 22 * * * — проверка расхода за день, алерт при > $7
weekly-cost-report: 12:00 пн — полный отчёт за неделю
```

## SOUL.md v2 Rules
- Лимит: ≤ 60 строк
- Владеет ВСЕМИ поведенческими правилами: не врать, смена темы, community skills, cost, /stop, статус
- voice-transcript, project-context, truth-check — ссылаются на SOUL, не дублируют

## Skill Diet Rules
- SKILL.md ≤ 150 строк. Сверх → references/
- Бэкап перед диетой: `tar czf /root/skills-backup-$(date +%F).tgz -C /root/.hermes skills/`
- Zero-use agent-created → `/root/.hermes/skills-archive/`
- Дубли между скиллами → удалить из младшего, оставить в umbrella
- SkillOpt/GEPA/DSPy → в references/ (не в теле self-improver)
- Mem0 секции → в references/ (мёртвый код, 400 неустранима)

## Memory & Profile Rules
- USER.md: только про Alex (стиль, риск-толерантность, язык кода)
- MEMORY.md: декларативные факты, < 80% лимита (16000 chars)
- Технические детали (MIDI, partitura) → в MEMORY к проекту, НЕ в USER
- Конвенция дат: новые записи начинаются с `[YYYY-MM-DD]`

## Weekly Hermes Audit
- Cron: `weekly-hermes-audit` (пн 09:00)
- Чек-лист:
  1. Fallback config == AGENTS == MEMORY (grep-сравнение)
  2. check-references.sh без битых ссылок
  3. Размеры: SOUL ≤ 60, SKILL.md ≤ 150, MEMORY < 80%
  4. Даты: новые записи [YYYY-MM-DD]
  5. Мёртвые провайдеры не вернулись
- Расхождение → Telegram алерт, НЕ самовольная правка

## Дефолты (когда Алекс говорит «Ну!»)

«Ну!» = хватит спрашивать, делай с дефолтными значениями:
- nvidia/openai провайдеры → удалить
- subagent_auto_approve → false (default), true (buratino)
- cost guard → $7/день
- Рестарт gateway → Алекс делает сам, команда текстом в ответе
- Простые вопросы («когда рестартить?») → одна строка ответ, не раздумывать

## Buratino audit (найдено 2026-07-10)
При аудите стэка обнаружено: buratino profile содержит 7 мёртвых провайдеров (anthropic, nvidia, openai, xai, xai-oauth — все с пустыми api_key). Также 3 MCP API ключа (exa, serpapi, tavily) в открытых URL в config. При следующем обслуживании buratino — очистить мёртвых провайдеров и переместить API ключи из URL в headers.

## Бэкапы (обязательны перед каждой правкой)

```bash
cp config.yaml config.yaml.bak-$(date +%F-%H%M)
cp AGENTS.md AGENTS.md.bak-$(date +%F-%H%M)
cp memories/MEMORY.md memories/MEMORY.md.bak-$(date +%F-%H%M)
cp memories/USER.md memories/USER.md.bak-$(date +%F-%H%M)
cp .env .env.bak-$(date +%F-%H%M)
tar czf /root/skills-backup-$(date +%F).tgz -C /root/.hermes skills/
```

## Чеклист «топ-мозги»
- [ ] Одна fallback-цепочка во всех трёх местах
- [ ] Ноль мёртвых провайдеров в конфиге
- [ ] subagent_auto_approve: false (default)
- [ ] verify_on_stop: true
- [ ] security.redact_secrets: true
- [ ] google provider имеет request/stale timeouts
- [ ] Cost guard cron активен
- [ ] SOUL ≤ 60 строк, владеет поведенческими правилами
- [ ] Скиллы ≤ 150 строк, references не битые
- [ ] Память датирована, USER.md только про Alex
- [ ] weekly-audit ловит дрейф
