# Multi-Gateway Deployment — Multiple Telegram Bots, One Hermes

Один Hermes может обслуживать несколько Telegram-ботов, каждый со своим профилем и конфигом.

## Когда нужно

- Отдельный бот для ML-проекта (Pianoid/buratino) с другими лимитами/таймаутами
- Разделение рутины (VPN, дайджесты, cron) и тяжёлой разработки
- Изоляция настроек: один профиль не влияет на другой

## Архитектура

```
@AmseujBot ── systemd: hermes-gateway.service ── default profile
@NemotrBot ── systemd: hermes-gateway-<name>.service ── <name> profile
```

Каждый gateway:
- Использует свой Telegram Bot токен (из `.env` профиля)
- Запускает свои MCP серверы
- Имеет собственную память, скиллы, cron
- Независимый systemd-сервис

## Порядок настройки

### 1. Создать профиль

```bash
hermes profile create <name> --clone --description "Описание профиля"
```

### 2. Прописать токен бота в .env профиля

```bash
sed -i 's|^TELEGRAM_BOT_TOKEN=.*|TELEGRAM_BOT_TOKEN=<токен>|' ~/.hermes/profiles/<name>/.env
```

Проверить:
```bash
source ~/.hermes/profiles/<name>/.env && \
curl -s "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe"
```

### 3. Создать systemd-сервис

Файл: `/etc/systemd/system/hermes-gateway-<name>.service`

```ini
[Unit]
Description=Hermes Gateway - <name> profile (@BotUsername)
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
User=root
Group=root
ExecStart=/usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main gateway run --profile <name>
WorkingDirectory=/root/.hermes
Environment="HOME=/root"
Environment="USER=root"
Environment="LOGNAME=root"
Environment="PATH=/usr/local/lib/hermes-agent/venv/bin:/usr/local/lib/hermes-agent/node_modules/.bin:/root/.nvm/versions/node/v24.15.0/bin:/root/.local/bin:/root/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
Environment="VIRTUAL_ENV=/usr/local/lib/hermes-agent/venv"
Environment="HERMES_HOME=/root/.hermes"
ExecStartPre=-/bin/sh -c 'rm -f /root/.hermes/gateway.pid /root/.hermes/gateway.lock'
ExecStop=/bin/kill -TERM $MAINPID
Restart=always
RestartSec=30
TimeoutStopSec=210

[Install]
WantedBy=multi-user.target
```

Важно: **НЕ используй pkill в ExecStartPre** — убьёт основной gateway.

```bash
systemctl daemon-reload
systemctl enable hermes-gateway-<name>.service
systemctl start hermes-gateway-<name>.service
```

### 4. Проверить

```bash
systemctl status hermes-gateway-<name>.service
journalctl -u hermes-gateway-<name>.service -n 20 --no-pager
```

## ⚠️ Питфолы

1. **Нельзя управлять gateway изнутри gateway-сессии.** `hermes gateway start/stop/restart` блокируется внутри Telegram-бота. Команды запуска — только из отдельного shell (SSH, Blink Shell).
2. **PID/lock файлы.** Разные профили используют один pid/lock по умолчанию. ExecStartPre должен чистить только pid/lock, НЕ pkill конкурентов.
3. **Python version mismatch.** Hermes использует venv (Python 3.11). Пакеты ставить через `.venv/bin/python3 -m pip install`, не через голый `pip`.
4. **Gateway не может сам себя перезапустить** для перечитывания конфига. Нужен `systemctl restart hermes-gateway-<name>.service` извне.
5. **API server port conflict (8642).** По умолчанию каждый gateway пытается открыть API сервер на порту 8642. Если два gateway-сервиса (default + buratino) запущены одновременно, второй gateway логирует `ERROR gateway.platforms.api_server: [Api_Server] Port 8642 already in use` каждые 5 минут. **Fix — два варианта:**

   **Вариант A — .env переменная (проще):**
   ```bash
   echo 'API_SERVER_PORT=8643' >> ~/.hermes/profiles/<name>/.env
   ```
   Hermes читает `API_SERVER_PORT` из профильного `.env` при старте gateway. Не нужно править YAML.
   
   **Вариант B — config.yaml (с правильным путём):**
   ```yaml
   # ~/.hermes/profiles/<name>/config.yaml
   platforms:
     api_server:
       extra:
         port: 8643  # или любой свободный
   ```
   **Важно:** ключ `extra.port`, не просто `port`. Путь `platforms.api_server.extra.port`, а не `gateway.api_server.port` (это другой раздел).
   
   После смены порта — перезапустить gateway извне: `systemctl restart hermes-gateway-<name>.service`.

6. **RestartSec=5 слишком мало для multi-gateway.** При рестарте одного gateway его `RestartSec` может привести к гонке, если второй gateway ещё не завершил Telegram handoff. Увеличить до 30:
   ```ini
   RestartSec=30
   ```
