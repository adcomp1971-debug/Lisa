# Hermes Health Scoring Rubric

10-layer scoring for "оценка гермеса" requests. Each layer scored /10. Final score = average.

## Layers

1. **AWG (WireGuard)** — handshakes, peer count, traffic flow, port listening
2. **Docker** — containers Up, healthy, no crash-loops
3. **Gateway + nginx** — active, config OK, no 401/403/429/500 in recent logs
4. **API Keys** — curl test each provider, all must return 200
5. **Система** — disk <85%, RAM available, load normal, uptime
6. **Cron** — all jobs ok, no errors, schedules verified
7. **MCP** — servers enabled, tools exposed, no broken configs
8. **Конфиг** — version current, fallback chain efficient, approvals smart
9. **Профили** — configs exist, models configured, no dead profiles
10. **Память** — consistency with config, no stale claims, char_limit adequate

## Scoring

- 10/10: pristine
- 9/10: minor cosmetic issue
- 8/10: warning, non-critical
- 7/10: needs attention within a week
- 6/10: degraded, fix today
- <6: critical, fix immediately

## Key Rules

- **Runtime verification only** — никогда не оценивать по статическому config.yaml. Каждый провайдер — curl test. Каждый контейнер — docker ps. Каждый cron — last_run status.
- **No tables** — plain numbered list, Russian.
- **Краткий вывод** — общая оценка + 3-5 пунктов что тянет вниз.

## Example (Jun 26, 2026)

| Layer | Score | Note |
|-------|-------|------|
| AWG | 9/10 | 8 peers, all handshakes |
| Docker | 10/10 | 4 containers, all healthy |
| Gateway | 8/10 | active, minor warnings only |
| API Keys | 10/10 | all 4 providers 200 |
| System | 9/10 | disk 65%, RAM 11G free |
| Cron | 8/10 | 17/18 ok, vasily-freelance 429 |
| MCP | 9/10 | 6/8 enabled |
| Config | 7/10 | 175 commits behind, same-key fallback |
| Profiles | 7/10 | vasily missing config |
| Memory | 6/10 | char_limit 2200 vs 10K file |
| **Total** | **8.3/10** | stable production |

### Post-audit actions (Jun 26)
1. vasily-freelance: gemini→deepseek-v4-flash (quota exhausted)
2. memory_char_limit: 2200→16000
3. approvals: manual→smart
4. Fallback: removed deepseek-v4-pro (same key)
5. Pending: hermes update (+175 commits)
