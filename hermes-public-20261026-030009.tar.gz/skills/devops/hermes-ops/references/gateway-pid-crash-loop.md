# Gateway PID Crash Loop — «Already Running» After Restart

## Symptom

Gateway crashes 10+ times on restart with:
```
❌ Gateway already running (PID 190405).
hermes-gateway.service: Main process exited, code=exited, status=1/FAILURE
hermes-gateway.service: Failed with result 'exit-code'.
```

Gateway-watch alerts: 19 crashes in 24h. Telegram bot offline.

## Root Cause (3 detection mechanisms, not just gateway.pid!)

`get_running_pid()` in `gateway/status.py` checks THREE things, not just the PID file:

1. **`{HERMES_HOME}/gateway.pid`** — JSON with PID, start_time
2. **`{HERMES_HOME}/gateway.lock`** — runtime lock file (secondary PID source)
3. **`gateway_state.json` runtime status** — `get_runtime_status_running_pid()`

**Deleting only `gateway.pid` is NOT enough.** If `gateway.lock` or runtime status still points to the old (zombie) process, the new gateway will see it and refuse to start.

### Crash sequence:

1. `hermes gateway restart` (or systemctl restart) sends SIGTERM
2. Gateway drains (~2 min), exits code 1
3. systemd kills orphaned child processes (systemctl, MCP servers)
4. systemd starts NEW gateway immediately
5. NEW gateway calls `get_running_pid()` → finds old PID via `gateway.lock` → zombie MCP subprocesses still alive → **«already running»** → exit 1
6. `Restart=always` + `RestartSec=5` → retry every 5 sec → crash loop (10+ times)

## Fix — COMPLETE (all 3 mechanisms)

### systemd drop-in

```ini
# /etc/systemd/system/hermes-gateway.service.d/timeout.conf
[Service]
TimeoutStopSec=210
ExecStartPre=-/bin/sh -c 'rm -f /root/.hermes/gateway.pid /root/.hermes/gateway.lock'
```

What this does:
- `TimeoutStopSec=210` — gives gateway 210s to drain (was 90s, caused SIGKILL during drain)
- `rm -f gateway.pid gateway.lock` — cleans BOTH PID sources so new instance doesn't see stale lock
- `-` prefix — don't fail the unit if files don't exist

### Additional hardening — main unit changes

Beyond the drop-in, three more changes to the main unit (`/etc/systemd/system/hermes-gateway.service`) prevent restarts from causing collisions:

**1. Remove pkill from ExecStartPre in the main unit:**
```ini
# Replace aggressive pkill with simple cleanup:
ExecStartPre=-/bin/sh -c 'rm -f /root/.hermes/gateway.pid /root/.hermes/gateway.lock'
```
(Without this, if the drop-in is ever lost or overridden, the main unit's pkill would cause the same crash loop.)

**2. Increase RestartSec from 5 to 30:**
```ini
RestartSec=30
```
Why: Telegram servers hold old long-poll connections for ~20 seconds after process death. With `RestartSec=5`, the new instance starts before Telegram releases the old session → "polling conflict" errors. 30 seconds gives enough time for:
- Old process's Telegram poll to timeout (~20s)
- MCP server ports to release
- Buratino gateway (if also cascaded) to fully claim its bot token

**3. Add explicit ExecStop:**
```ini
ExecStop=/bin/kill -TERM $MAINPID
```
Without ExecStop, systemd uses `KillMode=mixed` — SIGTERM to main PID + immediate SIGKILL to all children. Adding ExecStop ensures the main process gets a clean SIGTERM first, giving it time to drain child processes before the cgroup sweep.

### Full recommended unit (main service)

After all fixes, `systemctl cat hermes-gateway` should show:
```ini
ExecStartPre=-/bin/sh -c 'rm -f /root/.hermes/gateway.pid /root/.hermes/gateway.lock'
ExecStop=/bin/kill -TERM $MAINPID
TimeoutStopSec=210
Restart=always
RestartSec=30
KillMode=mixed
KillSignal=SIGTERM
```
No pkill anywhere. One ExecStartPre (not two). Graceful stop configured.

**⚠️ CRITICAL: NEVER add `pkill` to ExecStartPre!** 

A drop-in containing `pkill -9 -f hermes_cli.main` creates a self-perpetuating crash cycle:
1. systemd starts gateway → ExecStartPre runs pkill → kills ALL gateway processes
2. New gateway sees dying process via lock → "already running" → exit 1
3. systemd restarts → ExecStartPre kills again → loop forever

This was discovered 28 Jun 2026: the original drop-in had both `rm -f pid/lock` AND `pkill -9 -f hermes_cli.main`. The pkill caused 4 additional crashes during restart at 04:15 and a full crash at 12:57 when a cron job triggered restart. **Fix:** remove pkill, keep only `rm -f`. Verified: 0 crashes after fix.

**⚠️ Duplicate ExecStartPre via drop-in merging (Jul 3 2026)**

`ExecStartPre` is a **multi-value** directive in systemd. When specified in BOTH the main unit AND a drop-in, systemd **appends** them — both run in sequence, NOT replace. If the same command appears in both places, it runs **twice**.

Real case: the main unit had:
```
ExecStartPre=-/bin/sh -c 'rm -f /root/.hermes/gateway.pid /root/.hermes/gateway.lock ; pkill -9 -f "hermes_cli.main gateway run" 2>/dev/null; sleep 2'
```
And `timeout.conf` drop-in had the **exact same line**. Result: `sleep 2` × 2 = 4s startup delay, and `pkill -9` ran twice, doubling the race window for collisions. Systemd confirmed both existed: `systemctl show hermes-gateway -p ExecStartPre` showed **two identical entries**.

**Fix — clear all inherited ExecStartPre values first, then add the desired one:**
```ini
# In the drop-in (timeout.conf):
[Service]
TimeoutStopSec=210
ExecStartPre=                            # ← EMPTY: clears ALL inherited ExecStartPre
ExecStartPre=-/bin/sh -c 'rm -f /root/.hermes/gateway.pid /root/.hermes/gateway.lock'
```

Order matters: `ExecStartPre=` (empty) **must come before** the new `ExecStartPre=...`. Systemd processes directives top-to-bottom within a file. If you write them in reverse order, the empty one overrides the meaningful one.

**Verification:** `systemctl show hermes-gateway -p ExecStartPre` must show exactly ONE entry. If it shows two, the drop-in doesn't have the clearing line first.

**⚠️ pkill pattern `hermes_cli.main gateway run` matches ALL gateway processes**

When running multiple gateway services (e.g. main + buratino), `pkill -9 -f "hermes_cli.main gateway run"` kills BOTH because both commands contain that substring:

```
Main:    python -m hermes_cli.main gateway run
Buratino: python -m hermes_cli.main gateway run --profile buratino
       ^--- both match ---^
```

Result in logs (confirmed Jul 2 2026):
```
Jul 02 05:43:49 hermes-gateway-buratino: Main process exited, code=killed, status=9/KILL
Jul 02 05:44:09 hermes-gateway-buratino: Main process exited, code=killed, status=9/KILL
Jul 02 06:34:00 hermes-gateway-buratino: Main process exited, code=killed, status=9/KILL
Jul 02 14:51:35 hermes-gateway-buratino: Main process exited, code=killed, status=9/KILL
Jul 02 15:37:29 hermes-gateway-buratino: Main process exited, code=killed, status=9/KILL
Jul 02 15:43:44 hermes-gateway-buratino: Main process exited, code=killed, status=9/KILL
```
Every main gateway restart caused buratino to get SIGKILL. The buratino gateway then restarted via its own `Restart=always`, creating cascading restarts and Telegram polling conflicts on every cycle.

**Fix:** Remove `pkill` from ExecStartPre entirely. Systemd manages processes via cgroups — no manual cleanup needed.

**⚠️ NEVER restart gateway from inside the gateway process.**

Any attempt to run `systemctl restart hermes-gateway` or `systemctl stop hermes-gateway` from a cron job or terminal command while inside a gateway session will:
1. Gateway detects self-harm → blocks the command
2. But the subprocess already initiated systemd shutdown sequence
3. ExecStartPre fires → kills everything → exit-code crash

**Safe way to restart:** Tell the user to run it manually. The only automated way is a no_agent cron script (`no_agent=True`) that runs outside the gateway's security context.

### Source code patch

In `/usr/local/lib/hermes-agent/hermes_cli/gateway.py`, function `generate_systemd_unit()`, add after `Environment="HERMES_HOME=..."`:

```python
ExecStartPre=-/bin/sh -c 'rm -f {hermes_home}/gateway.pid {hermes_home}/gateway.lock'
```

Both templates (system=True and system=False) need this line.

## TimeoutStopSec crash (original problem, Jun 27-28 2026)

**Separate from the PID crash-loop above.** This was the original gateway crash problem:

- systemd unit default: `TimeoutStopSec=90s`
- Gateway's internal `drain_timeout` / `restart_drain_timeout`: 180s
- Result: systemd kills gateway after 90s with SIGKILL, before drain completes
- Symptom: `Killing process NNNN (systemctl) with signal SIGKILL` in journal
- `Failed with result 'exit-code'` → systemd auto-restarts → loop

**Fix:** Drop-in with `TimeoutStopSec=210` (>180s drain).

**Verification:** `systemctl show hermes-gateway -p TimeoutStopUSec` shows `3min 30s`.

## Telegram Polling Conflict

**Symptom:** After restart, log shows:
```
WARNING: Telegram polling conflict (1/5) — previous session still held open on Telegram's servers.
Error: Conflict: terminated by other getUpdates request
```

**Root cause:** Telegram servers hold the old long-poll connection open for ~20 seconds even after the process is killed. New instance gets "Conflict" error. Gateway auto-retries (up to 5 attempts, 20s apart) and recovers.

**This is normal and self-healing.** Gateway's built-in retry handles it (up to 5 attempts, 20s apart). No manual intervention needed.

## Silent Polling Stall

**Symptom:** Bot online (getMe OK), gateway "active", but no messages delivered. Last Telegram log entry >30 min old.

**Root cause:** After `httpx.RemoteProtocolError: Server disconnected without sending a response.`, Telegram polling reconnects but silently stalls — the polling loop is alive but not fetching messages. Gateway thinks it's connected.

**Detection:**
```bash
grep -i "telegram" /root/.hermes/logs/gateway.log | tail -1
# If >30 min ago and gateway is running → stall
```

**Fix:** `systemctl restart hermes-gateway` (the guard cron covers this)

## Voice Echo Issue (28 Jun 2026)

The gateway was echoing voice message transcriptions back to the user. When Alex sent a voice message, the transcribed text was sent back as a separate message.

**Fix:** Add these settings to `config.yaml`:
```yaml
stt_echo_transcript: false    # root level
telegram:
  echo_transcript: false      # under telegram section
```

These settings were present in config backups but were lost after crash recovery. Without them, the default is to echo the transcription.

## Permanent Guard (survives everything)

### Guard script: `/root/.hermes/scripts/gateway-guard.py`

- Checks drop-in matches expected content (lock file cleanup only, no pkill)
- If broken/missing → rewrites + `daemon-reload`
- If gateway dead → cleans up + starts it
- Silent when everything is OK (exit 0, no output)
- Runs as `no_agent` cron (no LLM overhead)

### Cron job: `gateway-guard`

```
schedule: every 5m
no_agent: true
script: gateway-guard.py
deliver: telegram:420839805 (only on fix/repair)
```

## Diagnostic Commands

```bash
# Crash count in 24h
journalctl -u hermes-gateway --since '24 hours ago' | grep -c 'Failed with result'

# Crash loop detection
journalctl -u hermes-gateway --since '24 hours ago' | grep 'already running'

# All gateway state files
ls -la /root/.hermes/gateway.{pid,lock} /root/.hermes/gateway_state.json

# Drop-in status
cat /etc/systemd/system/hermes-gateway.service.d/timeout.conf

# Full effective config
systemctl cat hermes-gateway

# Telegram connection status
grep -i "telegram" /root/.hermes/logs/gateway.log | tail -5

# Polling conflict check
grep "polling conflict" /root/.hermes/logs/gateway.log | tail -3

# Guard script health
python3 /root/.hermes/scripts/gateway-guard.py; echo "exit=$?"

# TimeoutStopSec verification
systemctl show hermes-gateway -p TimeoutStopUSec --no-pager

# RestartSec verification (shows as RestartUSec in systemd)
systemctl show hermes-gateway -p RestartUSec --no-pager

# ExecStartPre count verification (must be 1, not 2)
systemctl show hermes-gateway -p ExecStartPre --no-pager | grep -c 'ExecStartPre='
```

## Related

- `references/gateway-restart-via-cron.md` — restart workaround from inside gateway
- `references/gateway-troubleshooting.md` — health endpoint discovery
- `references/telegram-gateway-crash-debug.md` — token rejection debugging
