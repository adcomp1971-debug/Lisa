# Cron Output Viewing

When search tools fail (session_search not finding recent cron runs), use terminal to list cron output files directly:

```bash
# List all vasily-freelance output files, most recent first
ls -lt ~/.hermes/cron/output/cb734d35a5c6/ 2>/dev/null | head -20
# Read a specific output file
cat ~/.hermes/cron/output/cb734d35a5c6/2026-06-27_10-11-44.md
```

Job IDs map:
- `cb734d35a5c6` = vasily-freelance
- `17d58b89e125` = vasily-morning
- Find other IDs via `grep "name:" ~/.hermes/cron/jobs.json`
