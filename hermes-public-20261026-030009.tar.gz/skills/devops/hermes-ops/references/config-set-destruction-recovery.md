# `hermes config set` — Config Destruction & Recovery

**Discovery date:** June 26, 2026
**Observed failures:** 2 times in one session

## The Problem

`hermes config set` does NOT merge into config.yaml — it **overwrites** the entire file with ONLY the key being set. A healthy 21KB config (883 lines) becomes ~53 bytes.

This affects ALL values: `hermes config set model.default deepseek-v4-flash`, `hermes config set model.base_url ""`, `hermes config set web.search_backend tavily` — every call is equally destructive.

## Detection

```bash
# Immediate verification after ANY hermes config set call:
wc -c ~/.hermes/config.yaml       # Normal: ~21,000+ bytes. Destroyed: 53-200 bytes
grep -c 'model:' ~/.hermes/config.yaml   # Normal: 30+. Destroyed: 1-2
grep 'fallback_providers:' ~/.hermes/config.yaml  # Must exist
```

## Recovery Workflow

```bash
# 1. Find the latest pre-update backup
ls -la ~/.hermes/backups/*.zip | tail -1

# 2. Extract config.yaml only (no other files touched)
cd /tmp
unzip -o ~/.hermes/backups/pre-update-2026-06-25-131159.zip config.yaml -d /tmp/hermes-restore/
cp /tmp/hermes-restore/config.yaml ~/.hermes/config.yaml

# 3. Create a batch fix script with ALL changes
cat > /tmp/apply-fixes.sh << 'SCRIPT'
#!/bin/bash
CFG=/root/.hermes/config.yaml

# DeepSeek provider — direct API
sed -i '/^  deepseek:/a\    base_url: https://api.deepseek.com/v1\n    api_key_env: DEEPSEEK_API_KEY' "$CFG"

# Model default — flash
sed -i '0,/default: deepseek-v4-pro/s//default: deepseek-v4-flash/' "$CFG"

# exa MCP package name
sed -i 's|- exa-mcp-server|- @exa-labs/exa-mcp-server|' "$CFG"

# cloud_provider
sed -i 's|cloud_provider: browser-use|cloud_provider: none|' "$CFG"

# Session parameters
sed -i 's|^  max_turns: 90|  max_turns: 150|' "$CFG"
sed -i 's|^  gateway_timeout: 300|  gateway_timeout: 600|' "$CFG"
sed -i 's|^  gateway_timeout_warning: 900|  gateway_timeout_warning: 300|' "$CFG"
sed -i 's|^  reasoning_effort: medium|  reasoning_effort: high|' "$CFG"

# Memory
sed -i 's|memory_char_limit: 16000|memory_char_limit: 24000|' "$CFG"
sed -i 's|^  flush_min_turns: 6|  flush_min_turns: 4|' "$CFG"
sed -i 's|^  nudge_interval: 10|  nudge_interval: 5|' "$CFG"

# Compression
sed -i '0,/threshold: 0.6/s//threshold: 0.35/' "$CFG"

# File read
sed -i 's|file_read_max_chars: 100000|file_read_max_chars: 200000|' "$CFG"

# Display language
sed -i 's|^  language: en|  language: ru|' "$CFG"

# Search backend
sed -i 's|search_backend: exa|search_backend: tavily|' "$CFG"
SCRIPT

bash /tmp/apply-fixes.sh

# 4. Verify recovery
python3 -c "import yaml; yaml.safe_load(open('/root/.hermes/config.yaml'))"
wc -c ~/.hermes/config.yaml
grep 'fallback_providers:' ~/.hermes/config.yaml
grep 'mcp_servers:' ~/.hermes/config.yaml
grep 'base_url.*deepseek' ~/.hermes/config.yaml
