# Axum 0.7 Method Chaining — CRITICAL

## Проблема: `.route()` перезаписывает, не мержит

В Axum 0.7 повторный вызов `.route()` для одного и того же пути **перезаписывает** первый, а не добавляет метод.

### НЕПРАВИЛЬНО — второй `.route()` заменяет первый:

```rust
let app = Router::new()
    .route("/v1/responses", post(handle_responses))   // ← будет заменён
    .route("/v1/responses", get(handle_ws_upgrade))   // ← заменяет POST!
    .fallback(handle_fallback);
```

Все запросы на `/v1/responses` пойдут в `handle_ws_upgrade`, POST будет 405 Method Not Allowed.

### ПРАВИЛЬНО — method chaining:

```rust
let app = Router::new()
    .route("/v1/responses", get(handle_ws_upgrade).post(handle_responses))
    .route("/v1/models", get(handle_models))
    .route("/responses", get(handle_ws_upgrade).post(handle_responses))
    .fallback(handle_fallback);
```

`get(handler).post(handler)` — Axum 0.7 method chaining syntax. GET → WS upgrade, POST → обычный запрос.

## Симптом

- WebSocket upgrade не работает (timeout/404)
- curl с `-H "Upgrade: websocket"` возвращает 405 вместо 101
- POST запросы на endpoint с WS работают, но WS upgrade — нет

## Причина

Была допущена ошибка при добавлении WebSocket в codex-relay. Вместо `get().post()` на одном `.route()`, были написаны два отдельных `.route()` для одного пути. Axum тихо заменил первый вторым.

## История (codex-relay, Jul 4 2026)

1. Изначально: только `post(handle_responses)` — HTTP работал
2. Добавлен WS: `post()` + отдельный `get()` — WS НЕ работал (замена)
3. Исправлено на `get(ws_upgrade).post(responses)` — WS 101 + HTTP 200 ✅

## Проверка

```bash
# HTTP должен быть 200
curl -s -o /dev/null -w "%{http_code}" -X POST http://localhost:4447/v1/responses -d '{}'
# WS должен быть 101  
curl -s -o /dev/null -w "%{http_code}" -H "Upgrade: websocket" -H "Connection: Upgrade" \
  -H "Sec-WebSocket-Key: key" -H "Sec-WebSocket-Version: 13" http://localhost:4447/v1/responses --max-time 3
```
