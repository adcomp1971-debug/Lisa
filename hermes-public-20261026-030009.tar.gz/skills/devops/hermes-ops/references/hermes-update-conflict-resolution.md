# Post-Update Merge Conflict Resolution

Когда `hermes update` находит конфликты в gateway файлах (из-за ваших локальных правок), он:
1. Сташит локальные изменения (`git stash`)
2. Сбрасывает рабочий tree до clean upstream
3. Выводит stash ref — сохранить для восстановления

## Процедура восстановления после конфликта

### 1. Применить stash

```bash
cd /usr/local/lib/hermes-agent
git stash apply <stash-ref>
```

### 2. Разрешить конфликты

Три файла обычно конфликтуют:
- `gateway/config.py`
- `gateway/run.py`
- `hermes_cli/gateway.py` (редко)

**Проверить конфликты:**
```bash
grep -n '<<<<<<< \|=======\|>>>>>>>' gateway/config.py gateway/run.py hermes_cli/gateway.py
```

### 3. Стратегия разрешения: проверить upstream

Upstream часто уже содержит аналогичную фичу, но под другим именем или с другой имплементацией.

**Пример:** stash добавлял `stt_echo_transcript` (singular), а upstream уже имеет `stt_echo_transcripts` (plural) с методом `_should_echo_stt_transcripts()`.

В таких случаях — **брать upstream** и отбрасывать stash-версию, т.к. upstream-решение более полное.

### 4. Удалить маркеры конфликтов

```bash
patch -- описанным патчем
```

Брать всю секцию от upstream (первый вариант после `<<<<<<< Updated upstream` до `=======`), удалить stash-секцию и `>>>>>>> Stashed changes`.

### 5. Проверить синтаксис

```bash
cd /usr/local/lib/hermes-agent
grep -c '<<<<<<<' gateway/run.py gateway/config.py  # должно быть 0
python3 -c "import py_compile; py_compile.compile('gateway/config.py', doraise=True); print('OK')"
python3 -c "import py_compile; py_compile.compile('gateway/run.py', doraise=True); print('OK')"
```

### 6. Рестарт gateway

Изменения в gateway файлах вступают только после рестарта:
```bash
systemctl restart hermes-gateway
systemctl restart hermes-gateway-buratino  # если есть buratino profile
```

## Если upstream уже имеет фичу

Проверить по имени функции/класса:
```bash
grep -n '_should_echo_stt_transcripts\|stt_echo_transcripts' gateway/run.py gateway/config.py
```

Если фича есть в upstream — просто принять upstream и не восстанавливать stash-версию. Бэкап stash-ref сохранить на случай если понадобится отличающееся поведение.

## Советы

- Stash сохраняется в git — он не теряется при `hermes update`. В любой момент можно достать.
- Если stash конфликтует с новым кодом по всему файлу (не только в 2-3 местах) — возможно, проще переписать фичу заново поверх нового upstream.
- После разрешения конфликтов commit не нужен — gateway работает напрямую из git-директории.
