# Config Recovery from Backup Zip

If `config.yaml` gets corrupted (invalid YAML after bad edit), Hermes auto-saves a `.corrupt` backup. To restore from pre-update zip:

```bash
# 1. Find the latest pre-update backup
ls -la ~/.hermes/backups/*.zip | tail -1

# 2. Check what's inside (find config.yaml path)
unzip -l <backup.zip> | grep config

# 3. Extract and restore
cd /tmp && unzip -o <backup.zip> config.yaml
cp config.yaml ~/.hermes/config.yaml

# 4. Verify restoration
python3 -c "import yaml; c=yaml.safe_load(open('/root/.hermes/config.yaml')); print('OK' if c else 'FAIL')"
hermes fallback list
```

The corrupt file is saved as `config.yaml.corrupt.<timestamp>.bak`. You can diff it against the restored version to understand what broke.
