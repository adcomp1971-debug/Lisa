# Full Hermes Production Audit (2026-07-04)

Образцовый аудит production стека. Порядок проверки:

1. **Systemd сервисы** — статус, uptime, RAM, CPU, ошибки в логах за последний час
2. **Провайдеры API** — прямой curl к каждому API (не через Hermes), проверка DNS/HTTPS/Auth
3. **Релеи (codex-relay)** — HTTP /v1/models, POST /v1/responses, WS /v1/responses (upgrade 101)
4. **Fallback chain** — соответствует ли реальности, нет ли мёртвых провайдеров
5. **Delegation** — model/base_url/api_key консистентность
6. **Memory** — memory_char_limit, не переполнен ли
7. **Cron задачи** — модель/провайдер, частота, не сломан ли
8. **Gateway логи** — ошибки, предупреждения, watchdog
9. **Security** — .env защита, ключи не в логах, profile isolation
10. **AGENTS.md sync** — соответствует ли реальной конфигурации
11. **Version drift** — сколько коммитов позади upstream
12. **System resources** — RAM/Disk/Load/uptime

## Critical findings from 2026-07-04 audit

- WS endpoint only worked on :4448 (GLM), :4446/:4447 returned 405 — Axum route chaining fix needed
- memory_char_limit (1375) 93% full — needs increase or cleanup
- grok-4.3 fallback with `xai-oauth` provider missing in default config
- TimeoutStopSec=90s < drain_timeout=180s — systemd kills during drain
- 3+ gateway/relay restarts in 30min window — investigate cause
