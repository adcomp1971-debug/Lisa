# Cron Job Model/Provider Mismatch

**Discovered:** 2026-07-09 during full Hermes audit

## Symptom
Cron job has `model: gemini-3.5-flash` but `provider: deepseek`. DeepSeek API doesn't know Gemini model → every cron run fails with HTTP 400/404.

Or: `model: gpt-4o-mini` but `provider: deepseek` — same problem.

## How to detect
```bash
# List all cron jobs with model+provider
hermes cron list 2>&1 | grep -E "model:|provider:"

# Check each job's compatibility:
# - deepseek provider → only deepseek-* models (deepseek-v4-flash, deepseek-v4-pro, deepseek-chat, deepseek-reasoner)
# - google provider → only google/gemini-* models
# - openai provider → only gpt-*, o1.*, o3.* models
# - xai provider → only grok-* models
# - longcat provider → only LongCat-2.0
# - glm provider → only glm-* models (glm-5.2, glm-4.9, etc.)
```

## Known mismatches found (July 2026)
| Job | Wrong model | Wrong provider | Fix |
|-----|-------------|----------------|-----|
| vpn-auto-doctor | gemini-3.5-flash | deepseek | → deepseek-v4-flash |
| it-evening-digest-daily | gemini-3.5-flash | deepseek (via google base_url?) | → deepseek-v4-flash or google provider |

## Validation rule
For every cron job with `model` set, verify that the model name prefix matches the provider:
- `deepseek-*` → `deepseek`
- `gpt-*` / `o1.*` / `o3.*` → `openai`
- `gemini-*` / `google/gemini-*` → `google`
- `grok-*` → `xai`
- `LongCat-*` → `longcat`
- `glm-*` → `glm`

If mismatched, either change `provider` to match the model, or change `model` to match the provider.

## Fix
Use cronjob tool:
```python
cronjob(action='update', job_id='...', model='deepseek-v4-flash', provider='deepseek')
```

## Detection script
```python
import json, subprocess
result = subprocess.run(['hermes', 'cron', 'list', '--json'], capture_output=True, text=True)
# Parse and validate each job's model/provider pair
```

## Prevention
When creating cron jobs with `model` always verify compatibility. The cron tool does NOT validate model/provider compatibility — it will accept any combination.
