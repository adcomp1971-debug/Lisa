# Dynamic Workflows — Test Results (June 16, 2026)

## Tests Performed

Three workflow runs to validate `lingjiuu/hermes-dynamic-workflows` plugin.

### Test 1: 3 parallel agents (uptime, disk, docker) + synthesis
- **Run ID:** wf_c9fbcbd7-3b8
- **Duration:** 17 seconds
- **Result size:** 465 chars
- **Outcome:** Completed (parallel + pipeline worked)

### Test 2: Repeat of test 1 (resume cache)
- **Run ID:** wf_8d8b70d2-ba5
- **Duration:** 2 seconds
- **Result size:** 465 chars
- **Outcome:** Cache hit — subagent results reused

### Test 3: Single agent (simple echo)
- **Run ID:** wf_890c4a95-a90
- **Duration:** 140 seconds
- **Result size:** 462 chars
- **Outcome:** Completed (slow — Hermes subprocess spawn overhead)

## Key Findings

1. **Plugin works.** All 3 workflows completed successfully (confirmed in `agent.log`: `tool workflow completed`).
2. **Notification delivery** works via `<task-notification>` injection + gateway fallback. Results not persisted as files — delivered via notification mechanism.
3. **`require_launch_approval: true` blocks in gateway** — no approve UI in Telegram.
4. **Initial spawn is slow** (~17s for parallel agents, ~140s for single agent on cold start). Cached resume is fast (2s).

## Config Applied

```yaml
plugins.entries.dynamic-workflows.dynamic_workflows.require_launch_approval: false
```

Why: Gateway sessions have no approve/deny UI. `child_approval_policy: inherit` + `approvals.mode: smart` provides adequate safety.
