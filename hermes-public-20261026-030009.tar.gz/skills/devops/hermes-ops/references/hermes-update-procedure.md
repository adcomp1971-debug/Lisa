# Hermes Update Procedure (2026-07-06)

## Behaviour change: `hermes update` now auto-restarts ALL profile gateways

Unlike earlier versions where you had to stop the gateway manually before updating and start it after, the current updater handles gateway lifecycle:

1. Drains active sessions on ALL profile gateways (up to 45s per gateway — `draining (up to 45s)...`)
2. Restarts every profile gateway (`hermes-gateway`, `hermes-gateway-buratino`, etc.) after update
3. Syncs bundled skills to ALL profiles — stats like `default: ~3 user-modified, buratino: +1 new, ~3 user-modified, vasily: +1 new, ↑2 updated`
4. User-modified skills are **kept** across all profiles; new bundled skills are added alongside them
5. MCP servers survive the restart (brave-search, firecrawl, playwright, github, sqlite all reconnect)
6. **Dashboard process is stopped** (if running) — restart manually with `hermes dashboard --port <port>`
7. **Gateway unit marked outdated** after update — look for `Installed gateway service definition is outdated` warning; refresh with `sudo hermes gateway restart --system`

**You can now run `hermes update --yes` from any CLI session without manual gateway management.**  
The old rule "NEVER run update from inside gateway" was based on the updater killing the process mid-update — that's now handled (update drains first, then restarts).

## Pre-update checklist

```bash
hermes --version
cd /usr/local/lib/hermes-agent && git rev-parse --short HEAD
cd /usr/local/lib/hermes-agent && git rev-list --count HEAD..origin/main
```

## Backup

```bash
backup_dir="/root/hermes-update-backup-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$backup_dir"
cp /root/.hermes/config.yaml "$backup_dir/config.yaml"
cp /root/.hermes/.env "$backup_dir/env"
cp /root/.hermes/AGENTS.md "$backup_dir/"
```

## Post-update stash recovery (when local changes existed)

If you had local modifications (e.g., `gateway/config.py`, `gateway/run.py`), the updater:

1. Stashes them: `Saved working directory and index state On main: hermes-update-autostash-<timestamp>`
2. Resets working tree to clean upstream
3. Stash ref is printed: `Stash ref: cafdc92d9a857c80e6cf6b7fd09cd122944b4520`

**To restore:**

```bash
cd /usr/local/lib/hermes-agent
git stash apply <stash-ref>
```

Expect merge conflicts if upstream changed the same files. Resolve manually by picking upstream version when upstream already has the feature.

### STT echo transcripts — known conflict point

Upstream now has `stt_echo_transcripts` (plural) config field + `_should_echo_stt_transcripts()` method.  
Old local hacks using singular `stt_echo_transcript` via `getattr(self.config, 'stt_echo_transcript', True)` will conflict.

**Resolution:** take upstream version — it's the same feature with a cleaner API.

```python
# Upstream (keep this):
stt_echo_transcripts: bool = True  # Whether to echo raw STT transcripts back to the user
# Method: self._should_echo_stt_transcripts()
```

## Post-update verification

```bash
hermes --version
hermes doctor
hermes config check
hermes fallback list
hermes gateway status
systemctl is-active hermes-gateway
systemctl is-active hermes-gateway-buratino
```

## If update breaks

Three recovery paths (from most to least granular):

1. **Git reset:** `git reset --hard <pre-update-commit>` then `pip install -e .[all]`
2. **Config restore:** `cp $backup_dir/config.yaml /root/.hermes/config.yaml`
3. **Full dotdir restore:** `tar xzf hermes-dotdir-*.tar.gz -C /`
