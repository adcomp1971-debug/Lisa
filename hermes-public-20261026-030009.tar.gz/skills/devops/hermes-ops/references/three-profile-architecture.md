# Three-Profile Architecture (June 2026)

Hermes runs three independent profiles, each acting as a separate agent with isolated state:

## Profile Overview

| Profile | Channel | Purpose | Key Traits |
|---------|---------|---------|------------|
| **default** | @AmseujBot (Telegram) | Server ops, VPN, GateBox, devops | Main CLI session. Full model chain. All MCPs. |
| **vasily** | Cron only (no gateway) | Job hunting for Anna (wife): hh.ru, resumes | Own config, own cron, own skills. DeepSeek V4 Flash + fallbacks. |
| **buratino** | @NemrBot (Telegram, planned) | Pianoid ML training on Vast.ai | Long timeouts (600s), 200k/8k tool output. Own state.db, own skills. |

## What's Isolated Per Profile

- **config.yaml** — own model, providers, fallback chain, timeouts, toolsets
- **state.db** — own conversation history (FTS5 indexed)
- **memories/** — own memory files (don't cross-contaminate)
- **cron/** — own scheduled tasks
- **skills/** — own skill library (can differ from default)
- **plugins/** — own enabled plugins
- **.env** — own API keys (DO NOT inherit from main ~/.hermes/.env!)

## What's Shared

- Gateway binary (Hermes core)
- System-level services (nginx, systemd)
- Tailscale network
- Hardware (disk, RAM, GPU via Vast)

## Entry Points

```bash
# CLI session under a profile
hermes chat --profile vasily
hermes chat --profile buratino

# Cron jobs under a profile (configured in jobs.json)
# Each profile has its own cron/jobs.json at ~/.hermes/profiles/<name>/cron/
```

## Consequences

- **Default config changes DON'T propagate** — updating model/fallback in default requires separate edits in each profile's config.yaml
- **state.db grows per profile** — 300MB for default, separate for each profile
- **Memory isolation** — vasily's job-hunt context doesn't leak into default's server ops
- **Cron isolation** — vasily-morning etc. run under vasily profile with vasily's .env and config
