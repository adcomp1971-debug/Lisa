# Anthropic Provider Configuration (June 2026)

## Current Setup

**Key location:** `~/.hermes/.env` → `ANTHROPIC_API_KEY`
**Provider config:** `~/.hermes/config.yaml` → `providers.anthropic`
**Active endpoint:** `https://api.anthropic.com/v1`
**Default model:** `claude-sonnet-4-20250514` (Fable 5)

## Key Transition (June 12, 2026)

The user switched from a shared/OpenRouter Anthropic key to their **own API key** linked to their personal account (adcomp1971@gmail.com).

**The misconception:** Claude Pro subscription ($20/mo) and Anthropic API are separate billing systems at Anthropic. Pro gives web/mobile access only. API requires separate API key billing (pay-as-you-go, not $20/mo flat). The user confused Pro subscription with API access.

**Resolution:** User had an API key (`sk-ant-...`) already. It was set in `.env` and the config already pointed to `providers.anthropic` with `claude-sonnet-4-20250514`. No config changes were needed — the key just needed to be valid and active.

## Provider Configuration in config.yaml

```yaml
providers:
  anthropic:
    base_url: https://api.anthropic.com/v1
  # Model routing  
  default_model: anthropic/claude-sonnet-4-20250514
```

The `anthropic/` prefix in model names routes to the `anthropic` provider section.

## Verification

```bash
# Test key validity
curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{"model":"claude-sonnet-4-20250514","max_tokens":10,"messages":[{"role":"user","content":"hi"}]}' \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if 'content' in d else d)"

# Expected success: returns content array
# Expected failure (bad key): {"error": {"type": "authentication_error", ...}}
# Expected failure (zero balance): {"error": {"type": "invalid_request_error", "message": "credit balance is too low"}}
```

## Anthropic vs OpenRouter Model Names

| Hermes config | Actual API model | Notes |
|--------------|-----------------|-------|
| `anthropic/claude-sonnet-4-20250514` | `claude-sonnet-4-20250514` | Fable 5, via anthropic provider |
| `openrouter/anthropic/claude-sonnet-4` | `anthropic/claude-sonnet-4` | Same model, via OpenRouter routing |
| `google/gemini-3.5-flash` | `gemini-2.0-flash-001` | Used by cron jobs for cheap tasks |

## Pitfalls

- **API key in `.env` ≠ usable.** The config.yaml must have `providers.anthropic` section AND model must use `anthropic/` prefix.
- **Key can be valid but account has zero balance.** Anthropic returns `"credit balance is too low"` error. The API key format and signature are valid — the account just needs payment.
- **OpenRouter key vs Anthropic direct key are different formats.** OpenRouter uses `sk-or-v1-...` format. Anthropic direct uses `sk-ant-...` format. Mixing them causes auth errors.
- **Do NOT set GATEWAY_ALLOW_ALL_USERS=true** — it crashes gateway on startup.
