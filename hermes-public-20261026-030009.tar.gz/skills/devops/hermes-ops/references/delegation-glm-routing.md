# GLM 5.2 Delegation Routing Policy

Установлено: 30 июня 2026. Источник: сессия настройки delegation.

## Правило маршрутизации

| Тип задачи | Куда | Почему |
|---|---|---|
| Простая рутина (поиск, статус, дайджест, VPN-check, вопросы) | Flash напрямую | Быстро, дёшево, 1M контекста |
| Сложная задача (код, архитектура, Prism, Deep Research, рефакторинг, мульти-файл) | `delegate_task` → GLM 5.2 | Alex: «однозначно на GLM-5.2» |

## Параметры delegation (config.yaml с 30.06.2026)

```yaml
delegation:
  model: glm-5.2
  provider: custom
  base_url: https://api.z.ai/api/paas/v4
  api_key: ${GLM_API_KEY}
  child_timeout_seconds: 600    # 10 мин на подзадачу
  subagent_auto_approve: true   # без ручного подтверждения
  max_iterations: 100           # хватит на сложное
  max_spawn_depth: 1            # только дети, без внуков
  inherit_mcp_toolsets: true    # дети получают MCP
```

## Статус

- **Баланс:** пустой (HTTP 1113 Insufficient balance). Алекс пополнит позже.
- **После пополнения:** работает сразу, рестарт не нужен — ключ в .env, конфиг готов.
- **Тест:** после пополнения запустить `delegate_task(goal="простое задание на проверку GLM")`. Если subagent вернул результат — всё ок.

## Провалы

- Если GLM 5.2 не отвечает (таймаут 600s) — subagent фейлится. Fallback на parent model (DeepSeek Flash) не настроен — дети не имеют fallback chain.
- `inherit_mcp_toolsets: true` — дорого по токенам, но для сложных задач нужны все инструменты.
- `max_iterations: 100` — subagent может уйти в цикл при плохом промпте. Следить за логами gateway при первых запусках.
