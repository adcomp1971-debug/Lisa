# MCP Server Credential Diagnostics

Diagnose MCP servers that are configured but don't expose tools.

## Key insight: `hermes mcp list` shows "enabled" even for broken servers

The Hermes MCP client reports a server as `enabled` if the config entry is syntactically valid. It does NOT mean the server actually connected or authenticated. A server with a bad API key, expired credential, or wrong URL will still show `enabled`.

## Diagnostic steps

### 1. Check if MCP server exposed any tools

```bash
hermes tools list | grep "mcp_<server_name>"
```

If empty, the server never registered its tools.

### 2. Check MCP stderr logs

```bash
tail -80 ~/.hermes/logs/mcp-stderr.log
```

Failed auth often leaves a trace here.

### 3. Check if the subprocess is alive

```bash
ps -eo pid,ppid,user,stat,etime,cmd | grep -Ei 'mcp|npx|node' | grep -v grep
```

No process = server failed to start.

### 4. Test the server URL directly

For Remote MCP URLs with embedded API keys:

```bash
# Test the auth endpoint directly (if known)
curl -s -o /dev/null -w "%{http_code}" "<url>"

# For WebSocket-based MCP, check basic HTTP connectivity
curl -s -I "<base_url_without_path>"
```

### 5. Verify the embedded credential matches what's expected

If you have a credential hash from the user (SHA-256), compute the hash of the URL or credential embedded in the MCP config:

```python
import hashlib
url = "https://mcp.example.com/mcp/?apiKey=actual-key-here"
h = hashlib.sha256(url.encode()).hexdigest()
print(h)  # Compare with user-provided hash
```

## Common patterns

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `enabled` in MCP list, no tools | Auth failure (bad key/expired) | Update key in config URL or env var |
| `enabled` in MCP list, subprocess not running | Command not found or startup timeout | Check PATH, increase `connect_timeout` |
| `enabled` in MCP list, tools from other servers visible | This one server failed independently of others | Check this server's logs specifically |
| Remote MCP URL with embedded key — `401` | Dev/expired key in URL | Replace with valid production key |
| Remote MCP URL with key from env var — `401` | Env var not resolved at connect time | Embed key directly in URL or use `headers` field |

## Tavily MCP Example

Tavily Remote MCP URL with dev key (`tvly-dev-...`) does NOT work:
- `hermes mcp list` shows `enabled`
- No tools ever appear
- REST API returns `401 Unauthorized`
- Fix: use production API key or switch to `web.backend: tavily` (built-in provider in Hermes plugins)

The built-in Tavily provider (`plugins/web/tavily/provider.py`) uses `TAVILY_API_KEY` from `.env` and works with dev keys. The MCP endpoint does not.
