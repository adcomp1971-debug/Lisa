# MCP Server Env Var Resolution

## Правило

`${VAR_NAME}` синтаксис в `env:` секции MCP сервера в `config.yaml` **НЕ расширяется** из окружения shell/.env.

## Почему

Hermes парсит `config.yaml` и передаёт `env:` словарь как plain key-value в процесс MCP сервера. Переменные окружения **не подставляются** — значение `${AGENTMAIL_API_KEY}` передаётся буквально как строка `"${AGENTMAIL_API_KEY}"`.

Это отличается от поведения в других частях конфига (например, `fallback_providers`), где env vars работают.

## Что делать

Всегда вставлять literal значение ключа в `config.yaml`:

```yaml
# НЕПРАВИЛЬНО — не работает:
mcp_servers:
  some-server:
    env:
      API_KEY: ${SOME_API_KEY}

# ПРАВИЛЬНО — literal значение:
mcp_servers:
  some-server:
    env:
      API_KEY: "am_actual_key_value_here"
```

## Проверка

После правки — убедиться что `$` нет в значении:

```bash
grep -c '\$' /root/.hermes/config.yaml
# должно быть 0 в env: значениях MCP серверов
```

## Затрагиваемые MCP сервера

Все MCP сервера, использующие `env:` с секретами:
- **brave-search** — `BRAVE_API_KEY`
- **firecrawl** — `FIRECRAWL_API_KEY`
- **tavily** — `TAVILY_API_KEY`
- **agentmail** — `AGENTMAIL_API_KEY`
- **github** — `MCP_GITHUB_API_KEY` (но он использует gh auth)

Ключи, которые уже зашиты literal'ом в конфиге — трогать не надо. Проблема только с `${VAR_NAME}` синтаксисом.

## История

Найдено 2026-07-19: agentmail MCP не подключался. Причина — `AGENTMAIL_API_KEY: ${AGENTMAIL_API_KEY}` в config.yaml. Gateway получал буквальную строку `${AGENTMAIL_API_KEY}` как API ключ.

**Дополнительно:** даже после замены на literal ключ, сервер `mcp.agentmail.to` оказался недоступен (connection timeout). Если env var фикс не помог — проверять доступность удалённого MCP хоста:

```bash
curl -s -o /dev/null -w "%{http_code}" "https://HOSTNAME/mcp" -X POST \
  -H "Content-Type: application/json" -d '{"jsonrpc":"2.0","id":1,"method":"initialize"}' \
  --max-time 5
```

Timeout = проблема на стороне провайдера, не в конфиге.
