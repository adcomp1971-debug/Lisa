# Profile Bots

Manage background Telegram polling bots for specific Hermes profiles:
- **Dependencies:** Ensure all required packages are installed in the Hermes venv.
- **Lifecycle:** Start, stop, restart, and verify bot processes.
- **Environment:** Profile-specific `.env` loading is critical. A bot started in the wrong profile will lack credentials.
- **Debugging:** Check logs for stuck/silent bots; common issues include expired Telegram tokens or network blocks.
- **Token loss:** Bots that were running may have their token removed from `.env` during edits. They'll survive until restart, then crash with `ValueError`. See `references/profile-bot-env-recovery.md` for the Liskaanka case study and recovery steps.
