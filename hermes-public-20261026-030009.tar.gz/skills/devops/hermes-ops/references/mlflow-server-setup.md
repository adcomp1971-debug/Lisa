# MLflow Server Setup — Pianoid Experiment Tracking

## Installation
```bash
pip3 install mlflow
```

## Systemd Service (`/etc/systemd/system/mlflow-server.service`)
```ini
[Unit]
Description=MLflow Tracking Server — Pianoid experiment tracking
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/buratino
ExecStart=/usr/local/lib/hermes-agent/venv/bin/mlflow server \
  --backend-store-uri sqlite:////root/buratino/mlflow/mlflow.db \
  --default-artifact-root /root/buratino/mlflow/artifacts \
  --host 0.0.0.0 \
  --port 5050 \
  --allowed-hosts '*' \
  --cors-allowed-origins '*'
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

**⚠️ CRITICAL: 4 слеша в SQLite URI.** `sqlite:///root/...` (3 слеша) = относительный путь от WorkingDirectory. Если WorkingDirectory=/root/buratino, путь станет `/root/buratino/root/...`. **Фикс:** `sqlite:////root/...` (4 слеша = абсолютный).

## Service lifecycle
```bash
systemctl daemon-reload
systemctl enable --now mlflow-server.service
systemctl restart mlflow-server  # после обновления конфига
systemctl status mlflow-server
```

## Доступ

### Через Tailscale Funnel (рекомендуется)
1. Освободить 443 порт (если занят XRay/VLESS): `sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET port=8443 WHERE port=443;" && systemctl restart x-ui`
2. Запустить Funnel: `tailscale funnel --bg 8080` (направляет на nginx :8080)
3. Убедиться что nginx слушает на 8080 (добавить listen 8080 в server block)
4. URL: `https://gpu-qwen.tail0c8f2f.ts.net/`

### Через прямой порт
- `--host 0.0.0.0 --port 5050 --allowed-hosts '"*"' --cors-allowed-origins '"*"'`
- `ufw allow 5050/tcp`
- URL: `http://<ip>:5050/`

### Через nginx subpath — НЕ РАБОТАЕТ
MLflow 3.14 React SPA делает fetch() в корень (/api/2.0/...), игнорируя subpath (/mlflow/). sub_filter не чинит. Только корень.

## API routing с другими сервисами
Когда MLflow на корне, а другие сервисы (GateBox API) используют /api/:
```nginx
# MLflow API — ДО /api/ catch-all
location /api/2.0/mlflow/ {
    proxy_pass http://127.0.0.1:5050;
    proxy_set_header Host 127.0.0.1:5050;
}
location /api/ {
    proxy_pass http://127.0.0.1:5010;  # GateBox API
}
```

## Проверка
```bash
curl -s -X POST http://127.0.0.1:5050/api/2.0/mlflow/experiments/search \
  -H 'Content-Type: application/json' -d '{"max_results":10}'
```

## Известные проблемы
- **Invalid Host header:** nginx proxy_set_header Host должен быть `127.0.0.1:5050`, не `$host`
- **React SPA не из подпути:** только корень или отдельный порт
- **allowed-hosts и cors:** обязательны для внешнего доступа, иначе security middleware блокирует
