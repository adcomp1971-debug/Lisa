# Buratino Profile OpenRouter 401 Errors

**Discovered:** 2026-07-09 during full Hermes audit

## Symptom
Buratino gateway logs show repeated HTTP 401 errors from OpenRouter when trying to use model `{"default": "glm-5.2", "provider": "zai"}`. Buratino profile should NOT access OpenRouter at all.

## Root cause
In buratino profile's `config.yaml`, auxiliary services (vision, compression, approval, etc.) had `provider: auto`. When Hermes starts with `provider: auto`, it auto-detects providers from environment variables. If `OPENROUTER_API_KEY` exists in `.env`, OpenRouter gets registered and buratino tries to route requests through it.

Buratino profile is explicitly configured to NOT use OpenAI/OpenRouter (only LongCat + GLM + DS Pro), but `provider: auto` overrides this.

## Detection
```bash
# Check buratino logs for OpenRouter errors
journalctl -u hermes-gateway-buratino --since "1 hour ago" | grep -i "openrouter\|401"

# Check buratino config for auto providers
grep -n "provider: auto" /root/.hermes/profiles/buratino/config.yaml
```

## Fix
Replace all `provider: auto` with explicit provider in buratino config:
```bash
sed -i "s/    provider: auto/    provider: deepseek/g" /root/.hermes/profiles/buratino/config.yaml
```

## Prevention
When creating new profiles, NEVER use `provider: auto`. Always specify the explicit provider. Auto-detection is unpredictable and can pull in unwanted providers from environment variables.

## Verification
```bash
# After fix, restart buratino gateway
systemctl restart hermes-gateway-buratino

# Verify no more OpenRouter errors
journalctl -u hermes-gateway-buratino --since "5 min ago" | grep -i "openrouter" | wc -l
# Should be 0
```
