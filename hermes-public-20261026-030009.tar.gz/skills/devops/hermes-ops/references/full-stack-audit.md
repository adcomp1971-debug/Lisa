# Full Stack Audit

Comprehensive read-only audit of the entire Hermes stack. Run on "аудит стека" / "полный аудит" requests. Covers config, .env integrity, API connectivity, cron, MCP, profiles, gateway, system resources, and fallback chain in one pass.

## Audit Procedure (8 layers)

```
1. HERMES CORE
   ├── hermes --version              — version + commit distance
   ├── hermes doctor                 — diagnostics + issues
   ├── hermes status --all           — component health, API keys, auth
   └── hermes config                 — key settings display

2. CONFIG & .ENV INTEGRITY
   ├── hermes config check           — config migration needed?
   ├── wc -l ~/.hermes/.env          — line count (alarm if <50)
   ├── ls -la ~/.hermes/.env*        — compare against backups
   ├── diff / count vars vs backup   — detect missing keys
   └── grep for critical vars: API_KEY, TOKEN, SECRET

3. PROFILES (per-profile audit)
   ├── hermes profile list           — all profiles, models, gateway status
   └── hermes profile show <name>    — per-profile: has .env? config valid?

4. API CONNECTIVITY (curl test each provider)
   ├── DeepSeek → curl to api.deepseek.com
   ├── OpenRouter → curl /api/v1/auth/key (check remaining limit)
   ├── xAI/Grok → curl /v1/models (check for "Incorrect API key")
   ├── Anthropic → curl /v1/messages (or check cost_guard blocking)
   ├── NVIDIA → curl /v1/models
   └── Google/Gemini → curl /v1beta/openai/models

5. FALLBACK & ROUTING
   ├── hermes fallback list          — chain order + provider/model
   └── Verify each chain link is actually functional (step 4)

6. BACKGROUND SYSTEMS
   ├── hermes cron list              — 13+ jobs: schedule, last run, errors
   ├── hermes mcp list               — MCP servers status
   ├── hermes tools list             — enabled/disabled toolsets
   └── cat ~/.hermes/cost_guard.yaml — model blocking rules

7. GATEWAY & LOGS
   ├── systemctl status hermes-gateway
   ├── journalctl -u hermes-gateway --since "2 hours ago" | grep -iE "error|invalid|fail|401|403|429|500"
   └── Check for repeated warnings

8. SYSTEM RESOURCES
   ├── df -h /
   ├── free -h
   ├── docker ps
   ├── docker inspect <name> --format '{{json .RestartCount}}'
   └── systemctl is-active <service>
```

## Common Findings to Flag

| Finding | Severity | Implication |
|---------|----------|-------------|
| `.env` truncated (19 vs 461 lines) | CRITICAL | Missing NVIDIA, Gemini, FAL keys |
| xAI key returns "Incorrect API key" | CRITICAL | Fallback #3 dead |
| `providers.anthropic.enabled` ignored | WARNING | Config noise in logs |
| Profile missing .env or config | WARNING | vasily, nvidia profiles dead |
| Buratino has 7 dead providers | WARNING | nvidia, openai, xai, xai-oauth, anthropic — all empty api_key |
| Buratino MCP: API keys in plain URLs | WARNING | exa, serpapi, tavily keys exposed in config |
| Swap > 80% used | WARNING | Server under memory pressure, may cause OOM |
| 37/52 skills over 150 lines | INFO | Diet incomplete, only server-ops done |
| AWG peers show empty | INFO | `awg show peers` returns nothing — investigate |

## Audit output for external review ("для фаблы")

When user asks to export the full stack audit for an external AI (Claude Fable 5, etc.):

1. Collect: system info, all profile configs, relay services, Docker, VPN, UFW, MCP servers, cron, skills sizes, memory files, cost report, security settings
2. Write to a single .txt file
3. Send via sendDocument
4. Include a "criteria v2" status section at the end showing what passes/warns

Key sections to include:
- Server (OS, disk, RAM, swap, Hermes version)
- Models & providers per profile (highlight dead providers)
- Relay architecture (ports, services, stunnel)
- Gateway & bots
- Docker containers
- VPN & network (AWG, XRay, Tailscale, UFW)
- MCP servers (flag exposed API keys)
- Cron jobs
- Skills (count, over-limit list)
- Memory (sizes, limits, convention)
- Cost (today, daily limit)
- Security (redact_secrets, auto_approve, verify_on_stop)
- Issues found
- Criteria v2 status

## Pitfalls

- **VERSION RESOLUTION:** `hermes doctor` shows issues; `hermes status --all` shows API connectivity; check BOTH.
- **ENV BACKUPS ARE INCOMPLETE:** Backups may themselves be from after truncation. Check OLDEST backup.
- **CURL KEY TESTING:** Never hardcode secrets.
- **COST GUARD vs ACTUAL KEYS:** cost_guard.yaml blocks Anthropic by provider name, but the key may still be in .env.
- **GATEWAY LOGS:** A single `status=1/FAILURE` from old PID on restart is normal (SIGTERM exit).
