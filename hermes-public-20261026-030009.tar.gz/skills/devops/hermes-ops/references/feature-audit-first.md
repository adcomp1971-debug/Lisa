# Feature Suggestion Workflow — Audit First

**Pitfall:** When the user asks "что можно добавить/усилить" (what features can we add/upgrade), NEVER start by researching/searching what's new. The user will be frustrated if you suggest features already active.

**Always audit current state first:**

1. **Check version:** `hermes --version` — may already be latest
2. **Check MCP servers:** `hermes mcp list` — know what's enabled/disabled
3. **Check skills:** `skills_list` — know what's installed
4. **Check config:** grep key sections (credential pools, provider routing, voice/TTS, checkpoints, hooks, etc.)
5. **Check .env** for available keys (ElevenLabs, FAL, etc.)

Only AFTER full audit, suggest things that are TRULY absent. If the user says "это всё есть" — apologize briefly, don't argue.

## Typical features we already have (do not suggest)

- Voice/TTS (ElevenLabs key configured ✅)
- Credential pools ✅
- Provider routing / fallback chain ✅
- Checkpoints / rollback ✅
- Event hooks ✅
- Kanban ✅
- Mem0 ✅
- Batch processing ✅
- Webhooks ✅
- SkillOpt / self-optimization ✅
- Community skills (via git clone)
- Nous Portal (not needed — all separate keys collected)

## What's actually missing (limited set)

- SOUL.md customization
- Tool Gateway (Nous Portal subscription, $20/mo)
- Additional MCP servers (Notion, Sentry, Filesystem)

## Already active (verify before suggesting)

- Tool Search (`tools.tool_search.enabled: auto`) — progressive disclosure is ON. MCP tools only load when needed. ✅
- GitHub MCP (`github-mcp` via npx) — installed, 2 tools (list_issues, add), needs GITHUB_TOKEN env var
- All listed features above in "already have" table are CONFIRMED active

**Trigger pattern for this section:** When the user says "поищи фичи для гермеса", "что можно усилить", "какие фичи добавить" — LOAD THIS SKILL FIRST, then run the audit checklist below BEFORE suggesting anything.
