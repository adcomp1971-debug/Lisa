# Nous Research Portal — Hermes OAuth & Dashboard Redirect

## Портал

`https://portal.nousresearch.com/hermes` — управление Hermes Agent OAuth-клиентами.

## Что там настроено

- **OAuth client ID:** `agent:cmqxc13ko000c` (создан 28.06.2026)
- **Dashboard redirect URI:** URL, на который портал отправляет `/auth/callback` после OAuth

## Как настроить

1. Зайти на `https://portal.nousresearch.com/hermes`
2. В поле **Dashboard redirect URI** ввести базовый URL, где висит Hermes Dashboard
   — портал сам добавляет `/auth/callback` к URL
   — поддерживаются `http://`, IP-адреса, localhost
   — пример: `http://srv1593922.hstgr.cloud/dash`
3. Нажать **Save**

## Pitfalls

- **Неполный URL:** Если ввести только `srv1593922` без `.hstgr.cloud/dash` — OAuth callback не дойдёт до Dashboard.
- **HTTPS не обязателен:** Портал принимает http:// для IP и hostname (без TLS).
- **Hostinger VPS hostname:** `srv1593922.hstgr.cloud` — этот URL форвардит на VPS. Добавлять в `server_name` nginx если используется.
- **SPA sub-path:** Dashboard висит на `/dash/` — это sub-path, не корень. Указывать полный путь: `http://host/dash` (портал добавляет `/auth/callback` = `http://host/dash/auth/callback`).
