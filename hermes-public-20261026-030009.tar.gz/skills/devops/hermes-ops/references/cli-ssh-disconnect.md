# Hermes CLI SSH Disconnect Recovery

## Symptom

Hermes was running in an SSH session. The SSH connection dropped. The user later reconnects and finds Hermes crashed.

**Terminal output on crash:**
```
[Errno 5] Input/output error
process_loop unhandled error (msg may be lost)
```

**`last` shows:**
```
root     pts/0        85.65.221.123    Sat Jun 13 17:10 - 17:37  (00:26)
root     pts/0        85.65.221.123    Sat Jun 13 17:38   still logged in
```

Session at 17:10 disconnected at 17:37; reconnected at 17:38.

## Root cause

Hermes CLI runs as a foreground process inside the SSH session. When the SSH connection drops:
1. The PTS (pseudo-terminal slave) gets SIGHUP
2. All processes attached to that PTS receive SIGPIPE or I/O errors
3. Hermes' `process_loop` catches `[Errno 5] Input/output error` — stdin/stdout are dead
4. The Python process exits with an unhandled exception

## Why this happens

- `hermes` (CLI mode) or `hermes gateway run` (foreground gateway) binds to stdin/stdout of the SSH session
- Unlike a systemd service, there's no supervision — no auto-restart, no resilience
- The gateway systemd service (`hermes-gateway.service`) does NOT have this problem — systemd restarts it automatically

## Recovery

1. Reconnect via SSH
2. Restart Hermes: `hermes` (or `hermes gateway run` for gateway mode)
3. If the user had long-running work (SkillOpt, training, builds), check if child processes survived:
   ```bash
   ps aux | grep -E "train|skillopt|python" | grep -v grep
   ```
   Child processes started with `background=true` or via `delegate_task` may still be alive because they run in their own process group.

## Prevention

**Option A (recommended — always-on):** Run Hermes through the systemd gateway service:
```bash
hermes gateway run --service  # or systemctl start hermes-gateway
```
The gateway is decoupled from SSH — survives disconnects, auto-restarts on crash.

**Option B (tmux/screen):** If CLI interaction is needed persistently:
```bash
tmux new -s hermes
hermes
# Ctrl+B D to detach. Reconnect with: tmux attach -t hermes
```

**Option C (background process):** Not recommended — Hermes CLI is designed for interactive use and may behave unexpectedly without a real terminal attached.

## Detecting the cause after reconnect

```bash
# 1. Check SSH sessions around the crash time
last | head -10

# 2. Check if Hermes crashed with I/O error
tail -20 /root/.hermes/logs/errors.log | grep -i "input/output\|process_loop\|Errno 5"

# 3. Check if the process is gone
ps aux | grep hermes | grep -v grep | grep -v gateway | grep -v dashboard

# 4. Check child processes that survived
ps --ppid <old_pid> -o pid,stat,etime,cmd 2>/dev/null
```
