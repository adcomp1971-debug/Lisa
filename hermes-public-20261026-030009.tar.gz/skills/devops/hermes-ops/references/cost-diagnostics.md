# Cost Diagnostics — Tracing Model Spending via State DB

Дата: 2026-07-02
Источник: аудит GLM 5.2 vs DeepSeek расходов, выявивший fallback leak

## Проблема

Визуально «жрёт деньги» GLM 5.2 (Z.AI дашборд), но реальный жор может быть на **DeepSeek фоллбэках**, которые триггерятся когда GLM таймаутится. Нужно смотреть цифры, а не дашборды.

## Основной запрос — расходы по модели и провайдеру

```sql
SELECT model, billing_provider AS provider, 
       COUNT(*) AS sessions,
       SUM(input_tokens) AS input_tk,
       SUM(output_tokens) AS output_tk,
       ROUND(SUM(estimated_cost_usd), 3) AS cost_usd
FROM sessions 
WHERE started_at > strftime('%s', 'now', '-7 days')
  AND estimated_cost_usd > 0
GROUP BY model, billing_provider 
ORDER BY cost_usd DESC;
```

**Что даёт:** реальные затраты где $ реально ушёл. Показывает cross-provider leaks (когда model=glm-5.2 а billing_provider=deepseek).

## Расходы по API endpoint (куда реально уходят деньги)

```sql
SELECT 
  CASE WHEN billing_base_url LIKE '%deepseek%' THEN 'DeepSeek API'
       WHEN billing_base_url LIKE '%z.ai%' THEN 'Z.AI API'
       WHEN billing_base_url LIKE '%x.ai%' THEN 'xAI API'
       WHEN billing_base_url LIKE '%openai%' THEN 'OpenAI API'
       ELSE billing_base_url END AS 'API endpoint',
  COUNT(*) AS sessions,
  SUM(input_tokens) AS in_tk,
  SUM(output_tokens) AS out_tk,
  ROUND(SUM(estimated_cost_usd), 3) AS cost
FROM sessions 
WHERE started_at > strftime('%s', 'now', '-7 days')
  AND estimated_cost_usd > 0
GROUP BY CASE WHEN billing_base_url LIKE '%deepseek%' THEN 'DeepSeek API'
       WHEN billing_base_url LIKE '%z.ai%' THEN 'Z.AI API'
       WHEN billing_base_url LIKE '%x.ai%' THEN 'xAI API'
       WHEN billing_base_url LIKE '%openai%' THEN 'OpenAI API'
       ELSE billing_base_url END
ORDER BY cost DESC;
```

## Топ самых дорогих сессий

```sql
SELECT model, billing_provider, billing_mode, source,
       input_tokens, output_tokens,
       api_call_count,
       ROUND(estimated_cost_usd, 3) AS cost,
       title
FROM sessions 
WHERE started_at > strftime('%s', 'now', '-7 days')
  AND estimated_cost_usd > 0
ORDER BY estimated_cost_usd DESC
LIMIT 10;
```

Позволяет найти конкретный дорогой разговор («Аудит 60 скиллов» за $1.11, «Буратино статус» за $0.83).

## Detecting fallback leaks

Самый важный запрос — когда модель падает на другой провайдер, но имя модели остаётся:

```sql
SELECT model, billing_provider, billing_base_url,
       COUNT(*) AS sessions,
       SUM(input_tokens) AS in_tk,
       SUM(output_tokens) AS out_tk,
       ROUND(SUM(estimated_cost_usd), 3) AS cost
FROM sessions 
WHERE model = 'glm-5.2'
  AND started_at > strftime('%s', 'now', '-7 days')
GROUP BY model, billing_provider, billing_base_url
ORDER BY cost DESC;
```

**Eсли видишь model=glm-5.2 но billing_provider=deepseek — это и есть fallback leak.** GLM не смог ответить через Z.AI, фоллбэк подхватил, но конфиг всё ещё просит glm-5.2 → DeepSeek API получает модель «glm-5.2» и заряжает за свой счёт (возможно, мапит на дефолтную модель).

## Расходы по billing_mode (основная модель vs auxiliary)

```sql
SELECT billing_mode, model, billing_provider,
       COUNT(*) AS sessions,
       SUM(input_tokens) AS in_tk,
       SUM(output_tokens) AS out_tk,
       ROUND(SUM(estimated_cost_usd), 3) AS cost
FROM sessions 
WHERE started_at > strftime('%s', 'now', '-7 days')
  AND estimated_cost_usd > 0
GROUP BY billing_mode, model, billing_provider
ORDER BY cost DESC;
```

`billing_mode = NULL` = основной разговор. `chat_completions` = прямой API вызов (делегация). `auxiliary_*` = вспомогательные модели.

## Расходы по source (Telegram vs CLI vs subagent)

```sql
SELECT source, 
       COUNT(*) AS sessions,
       SUM(input_tokens) AS in_tk,
       SUM(output_tokens) AS out_tk,
       ROUND(SUM(estimated_cost_usd), 3) AS cost
FROM sessions 
WHERE started_at > strftime('%s', 'now', '-7 days')
  AND estimated_cost_usd > 0
GROUP BY source
ORDER BY cost DESC;
```

## Типичные паттерны жора

| Симптом | Причина | Что делать |
|---------|---------|------------|
| Одна модель (glm-5.2) через несколько провайдеров | Фоллбэк с leak-ом | Починить основную модель (увеличить таймаут) или сменить |
| deepseek-v4-pro дороже всех | Тяжёлые сессии (аудит, рефакторинг) | Поменять фоллбэк цепочку: убрать Pro, оставить Flash |
| DeepSeek API > Z.AI API при основном GLM | GLM падает, фоллбэки на DeepSeek копят счёт | См. выше |
| $0.0 cost на custom провайдере | Не настроена цена для custom provider | Добавить `pricing.model.<model>: $0.XX/1M` в config.yaml |
| sessions ≠ NULL billing_provider | Сессия не завершена или без LLM-вызова | Нормально для статус-запросов |

## Как проверять фоллбэк цепочку

Из конфига:
```bash
python3 -c "import yaml; c=yaml.safe_load(open('/root/.hermes/config.yaml')); fp=c.get('fallback_providers',[]); [(print(f'{i}. {p[\"model\"]} via {p[\"provider\"]}') if isinstance(p,dict) else print(f'{i}. {p}')) for i,p in enumerate(fp,1)]"
```

Сверять с реальными фоллбэк-сессиями в state.db.

## Питфолы

- `estimated_cost_usd` — **эстимейт**, не факт. Hermes считает по дефолтным ценам. Фактический счёт на Z.AI/DeepSeek может отличаться.
- `billing_base_url` может быть NULL — тогда billing_provider не даёт полной картины.
- Сессии с `estimated_cost_usd = 0` могут быть не-LLM (статусные) или custom-провайдер без цены.
- SQLite timestamp — Unix timestamp в секундах, а не ISO дата. `strftime('%s', 'now', '-7 days')` корректно работает.
- **Не путать** `model` (что запрошено) с `billing_provider` (кто реально ответил). Разница = fallback leak.
- Для Z.AI раздельных `billing_base_url`: `/api/paas/v4` (обычный) и `/api/coding/paas/v4` (coding plan) — могут быть разные цены.
