# Tailscale Funnel + Port Conflicts

Tailscale Funnel требует порт 443 для внешнего HTTPS-доступа. Если на сервере другой сервис уже занимает 443 (XRay, nginx, другой reverse proxy), Funnel не запустится с ошибкой `listener already exists for port 443`.

## Решение

**Вариант A: Перенести сервис, освободить 443**
1. Найти что на 443: `ss -tlnp | grep ':443 '`
2. Если XRay (через x-ui): сменить порт inbound в БД
   ```bash
   sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET port=8443 WHERE port=443;"
   systemctl restart x-ui
   ```
3. Запустить Funnel: `tailscale funnel --bg 8080`
4. Настроить nginx на 8080 для приёма трафика от Funnel

**Вариант B: Использовать Tailscale Serve (только tailnet)**
- `tailscale serve --bg --https 4433 127.0.0.1:5050` — доступно только внутри Tailscale сети
- Не требует свободного 443, не открывает наружу

**Вариант C: nginx + self-signed SSL на 443**
- Перенести XRay
- Поднять nginx на 443 с самоподписанным сертификатом
- HTTP (80) → редирект на HTTPS

## Питфолы
- `tailscale funnel --bg 8080` — БЕЗ `--bg` Funnel работает в foreground и умирает при закрытии SSH
- После `tailscale funnel --https=443 off` конфигурация сбрасывается. Заново: `tailscale funnel --bg 8080`
- XRay на 443 блокирует Tailscale Funnel. Даже если nginx на 8080 — Funnel не может открыть порт
- Если внешний порт 443 блокируется хостинг-провайдером (некоторые VPS блокируют 443), Funnel не поможет — только Tailscale Serve (tailnet only)
