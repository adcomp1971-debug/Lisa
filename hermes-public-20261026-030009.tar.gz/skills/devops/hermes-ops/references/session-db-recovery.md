# Session DB Recovery

Diagnose and recover when `session_search` fails to find past conversations.

**Symptom:** `session_search()` returns "database disk image is malformed" or "Failed to list recent sessions".

**Root cause:** The FTS5 index at `~/.hermes/sessions.db` can become corrupted or empty (4KB with no tables). The main conversation data lives in `~/.hermes/state.db` which has a `messages` table with `id`, `role`, `content` columns.

**Recovery workflow:**
1. **Check session_search DB integrity:**
   ```bash
   sqlite3 ~/.hermes/sessions.db ".tables"
   sqlite3 ~/.hermes/sessions.db "PRAGMA integrity_check;"
   ```
   Empty/no tables = corrupted.

2. **Check state.db integrity:**
   ```bash
   sqlite3 ~/.hermes/state.db "SELECT COUNT(*) FROM messages;"
   sqlite3 ~/.hermes/state.db "PRAGMA integrity_check;"
   ```
   State.db is typically 300MB+ with thousands of messages.

3. **Search state.db directly (fallback):**
   ```sql
   -- Search by keyword
   SELECT id, role, substr(content, 1, 200) as snippet
   FROM messages
   WHERE content LIKE '%keyword%'
   ORDER BY id DESC
   LIMIT 20;

   -- Get full message by ID
   SELECT content FROM messages WHERE id = <id>;

   -- Get context around a message
   SELECT id, role, content
   FROM messages
   WHERE id > <start_id> AND id < <end_id>
   ORDER BY id;
   
   -- Browse recent messages
   SELECT MAX(id) FROM messages;
   ```

4. **Optional - rebuild sessions.db:**
   ```bash
   rm ~/.hermes/sessions.db
   hermes session index   # or equivalent rebuild command
   ```
   Check if Hermes has a `hermes session rebuild` CLI command. If not, `sessions.db` may auto-regenerate.

**Schema reference:** See `references/session-db-recovery.md` for a full state.db schema dump and common recovery patterns.
