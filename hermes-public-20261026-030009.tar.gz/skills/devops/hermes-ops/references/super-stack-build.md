# Super Hermes Stack Build — June 23, 2026

Complete upgrade of the Hermes deployment at gpu-qwen.tail0c8f2f.ts.net (Alex Skver).

## Config Changes Applied

```bash
hermes config set response_cache true
hermes config set curator.interval_hours 24
hermes config set curator.min_idle_hours 1
hermes config set curator.stale_after_days 14
hermes config set curator.consolidate true
hermes config set delegation.max_concurrent_children 5
```

## Workflows Created (6)

All at `~/.hermes/workflows/`:

| Workflow | Purpose | Agents per run |
|----------|---------|----------------|
| `deep-audit` | Полный аудит AWG, Docker, nginx, дисков, cron, MCP, памяти | 8 collect + 1 analyze + 1 summarize |
| `project-pulse` | Статус Pianoid, Hermes Box, GateBox, KNX, инфры | ~20 scans + 1 report |
| `code-review` | Ревью с 4 ракурсов (корректность, безопасность, производительность, архитектура) | 1 find + N×4 reviews + 1 synthesis |
| `self-improve` | Анализ скиллов, памяти, конфига, поиск точек роста | 5 diag + 1 analyze + 1 report |
| `incident-response` | Детекция → RCA → восстановление → отчёт | ~8 checks + 1 rca + recovery + verify + report |
| `morning-intel` | IT-новости + почта + сервер + фриланс + GitHub | 5 sources + 1 digest |

## Kanban Boards (3)

```bash
hermes kanban boards create pianoid --name "Pianoid AI" --icon "🎹" --color "#8b5cf6"
hermes kanban boards create hermes-box --name "Hermes Box" --icon "📦" --color "#00bfff"
hermes kanban boards create infra --name "Infrastructure" --icon "🔧" --color "#10b981"
```

Tasks on each board:
- **Pianoid** (3): Vast.ai check, MIDI test v4.2, Pianoid dashboard
- **Hermes Box** (2): UI update, documentation page
- **Infrastructure** (3): S3 backup, SSL certs, Telegram alerting

## Community Skills Installed (8)

```bash
yes | hermes skills install official/autonomous-ai-agents/grok
yes | hermes skills install official/autonomous-ai-agents/antigravity-cli
yes | hermes skills install official/autonomous-ai-agents/blackbox
yes | hermes skills install official/mlops/research/dspy
yes | hermes skills install official/research/scrapling
yes | hermes skills install official/security/web-pentest
yes | hermes skills install official/mcp/fastmcp
yes | hermes skills install official/software-development/rest-graphql-debug
```

## System State

- OS: Ubuntu 24.04, kernel 6.8.0-124-generic
- RAM: 15G total, 3.7G used (25%)
- Disk: 193G, 123G used (64%)
- Docker: hermes-ollama, hermes-rag, hermes-webui, hermes-core (all Up)
- Uptime: 1 week 4 days 21 hours
- All services: nginx, hermes-gateway, liskaanka-bot, docker — active
- rclone v1.60.1 installed (needs `rclone config` for S3/B2 backup)

## Soul.md

Rewritten at `~/.hermes/soul.md` — now includes Super Stack capabilities, 6 workflows, 3 kanban boards, and showcases.
