# MCP Search Server Setup

## Brave Search (Free, 2000 req/mo)

**Server:** `@brave/brave-search-mcp-server` (official Brave MCP)
**Auth:** `BRAVE_API_KEY` env var
**Get key:** https://brave.com/search/api/

### Config

```yaml
mcp_servers:
  brave-search:
    command: "npx"
    args: ["-y", "@brave/brave-search-mcp-server"]
    env:
      BRAVE_API_KEY: "BSA-..."
    enabled: true
```

After adding to config.yaml, restart Hermes or call `/reset`. Tools appear as `mcp_brave_search_*`.

### Key format

Brave keys start with `BSA-` (Basic Search API). The free tier gives 2000 queries/month.

## Tavily (Paid required for MCP)

**Server:** Remote MCP via URL
**Auth:** API key in URL query param or `Authorization: Bearer` header
**Get key:** https://app.tavily.com/home

### Config

```yaml
mcp_servers:
  tavily:
    url: "https://mcp.tavily.com/mcp/?tavilyApiKey=tvly-..."
    enabled: true
```

### Dev keys DON'T work

Keys with `tvly-dev-` prefix (from the free/signup tier) **do not authenticate** with the Remote MCP server or REST API. Both return `401 Unauthorized`.

To use Tavily MCP, you need a production key from app.tavily.com (no `dev-` prefix).

### Verification

```bash
curl -s -X POST "https://mcp.tavily.com/mcp/?tavilyApiKey=tvly-..." \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"0.6","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}'
```

Expected: HTTP 406 with `"Not Acceptable: Client must accept both application/json and text/event-stream"` — this means the MCP server is reachable (SSE transport required). HTTP 401 = key invalid.

For REST API test:
```bash
curl -s -X POST "https://api.tavily.com/search" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer tvly-..." \
  -d '{"query":"test","topic":"news","max_results":3}'
```
HTTP 200 = working. HTTP 401 = key invalid.
