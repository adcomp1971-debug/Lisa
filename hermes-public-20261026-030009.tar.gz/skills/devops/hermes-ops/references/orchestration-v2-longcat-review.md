# Orchestration V2 — LongCat Review Pattern

## Signal
User wants orchestration/stack changes reviewed by **LongCat-2.0** (via delegate_task or buratino profile) rather than done inline by the main agent.

## When to Apply
- User says "сделай ревью", "настрой оркестрацию", "LongCat пусть сделает"
- Multi-profile changes (default + buratino + vasily)
- Cost optimization analysis
- Full stack model changes

## Pattern
1. Do NOT make changes directly in main context
2. Delegate to LongCat-2.0 with `delegate_task` (model: LongCat-2.0)
3. Collect results, report to user in .txt format
4. User approves → apply changes

## Why
- LongCat-2.0 has broader context on model capabilities
- Cost analysis is better done by a model that understands pricing
- User explicitly requested this pattern multiple times in July 2026

## Example
```
delegate_task(
  goal="Провести ревью стека моделей и предложить оптимальную оркестрацию. Доступные модели: DeepSeek Flash/Pro, LongCat-2.0 ($12.6/мес), GLM-4.5/4.6/4.7/5/5.1/5.2 (Z.AI), Gemini 2.0/2.5/3/3.5. Grok КЛЮЧ УДАЛЕН. Учитывать: default primary = Flash, buratino primary = LongCat, vasily = Flash.",
  context="...",
  model="LongCat-2.0",
  provider="longcat"
)
```

## Pitfall
- Do NOT substitute Flash for LongCat when user explicitly wants LongCat review
- Flash is cheaper but lacks LongCat's broader model knowledge for orchestration decisions
