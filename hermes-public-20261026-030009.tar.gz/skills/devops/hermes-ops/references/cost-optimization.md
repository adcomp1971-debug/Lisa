# Cost-Optimized Orchestration Chain

Configure Hermes for minimum cost at maximum utility. The user (Alex) has strict budget constraints.

**Core policy: Direct providers first. OpenRouter only as last resort.**
OpenRouter is a paid middleman — use it ONLY when a model is not available on any direct provider (e.g. Kimi K2.7-Code). All ancillary services (vision, approval, curator, title gen, session search, etc.) MUST use direct providers — never OpenRouter by default.

Available direct providers: DeepSeek (primary), Google/Gemini (free tier available), NVIDIA (free NVAPI tier), xAI/SuperGrok (subscription bundled), OpenAI (if key provided). These cover all practical needs — there is almost never a reason to route auxiliary traffic through OpenRouter.

## Current Orchestration Chain (June 29, 2026)

```
User (Telegram)
├── Main session   → DeepSeek V4 Flash     ($0.28/$0.14 per M) ← switched from V4 Pro Jun 29
├── Telegram bot   → DeepSeek V4 Flash                          ← default model
├── Heavy tasks    → deepseek-v4-pro / glm-5.2                  ← user switches via /model in-session
├── Delegation     → GLM 5.2 (Z.AI, custom provider)            ← сложные задачи (код, архитектура, Prism, Deep Research)
│   ├── child_timeout_seconds: 600                              ← 10 min max per subagent
│   ├── subagent_auto_approve: true                             ← без ручного подтверждения
│   ├── max_iterations: 100                                     ← запас на сложные задачи
│   ├── max_spawn_depth: 1                                      ← только листовые дети
│   └── ⚠️ Баланс Z.AI пустой                                   ← HTTP 1113, требует пополнения
├── Aux (vision)   → auto (inherits default)                   
├── Cron jobs      → Gemini 3.5 Flash       ($0.08/M in, free) ← all LLM cron
├── Fallback chain → deepseek-v4-flash → gpt-4o-mini (OpenAI) → grok-4.3 (xAI) → deepseek-v4-pro → gemini-3.5-flash (Google free)
├── 🔴 OpenRouter — ПОЛНОСТЬЮ УДАЛЁН (Jun 29). User: "опенроутер не юзаю". Заменён на прямой OpenAI gpt-4o-mini.
├── Default model: deepseek-v4-flash (switched from v4-pro Jun 29)
├── Compaction: threshold=0.9, summary_target_ratio=0.7 (Jun 29 — было 0.5)
├── State.db: 287MB → 131MB (Jun 29 — hermes sessions optimize после жалоб на "тупит забывает")
├── state-db-prune cron: каждый понедельник 04:00 UTC — prune --older-than 14 + optimize (no_agent)
├── Skills: 42 (было 60 — чистка Jun 29)
├── Memory: 57% (было 90% — чистка Jun 29)
├── tool_output.max_bytes: 100KB (было 50KB — Jun 29)
└── Providers → DeepSeek, OpenAI direct, xAI/Grok (free via SuperGrok), Google (free), NVIDIA NIM (ключ есть), GLM 5.2 (Z.AI — для делегирования)
```

## Model Selection Strategy

**Principle: Direct providers first. OpenRouter only as deep fallback — never in active rotation.**
**Cost policy: Pay only DeepSeek + OpenAI direct. Everything else free (Grok SuperGrok, Google free tier) or not needed.**
**NVIDIA NIM excluded: 100+ opensource models but no unique advantage over free/cheap options.**
**Fallback chain rule: only DIFFERENT providers/keys. Same-provider fallback (DeepSeek→DeepSeek) бесполезен.**
**OpenRouter полностью удалён (Jun 29).**

| Task Type | Model | Provider | Why |
|-----------|-------|----------|-----|
| Routine Telegram | DeepSeek V4 Flash | DeepSeek (direct) | $0.28/$0.14 — дёшево, 1M ctx |
| Complex / architecture | deepseek-v4-pro или glm-5.2 | DeepSeek direct / Z.AI | User switches via /model in-session |
| Vision (images) | **GPT-4o** | **OpenAI (direct)** | Лучший vision |
| Approval / curator / title / search | DeepSeek V4 Flash | DeepSeek (direct) | Все aux сервисы — прямые |
| Cron jobs | Gemini 3.5 Flash | Google (direct) | $0.08/M (free tier) |
| Subagent delegation | GLM 5.2 | Z.AI (direct) | Сложные задачи |
| Fallback #1 | GPT-4o-mini | OpenAI (direct) | $0.15/M — дёшево, другой провайдер |
| Fallback #2 | Grok 4.3 | xAI (SuperGrok, free) | Бесплатный тяжёлый флагман |
| Fallback #3 | DeepSeek V4 Pro | DeepSeek (direct) | Если Flash не справился |
| Fallback #4 | Gemini 3.5 Flash | Google (free) | Бесплатная страховка |
| **NOT used** | OpenRouter | — | Полностью удалён Jun 29 |
| **NOT used** | NVIDIA NIM | — | Ключ есть, но модели нестандартные |

## Compression Tuning — Context Retention

**Симптом:** Hermes теряет контекст через 3-4 сообщения — начинает переспрашивать, забывает о чём речь.

**Первичная диагностика — проверить compaction settings:**
```bash
grep -A5 'compaction:' ~/.hermes/config.yaml
```

| Параметр | Назначение | Рекомендация |
|----------|-----------|-------------|
| `threshold_percent` | % заполнения контекста при котором начинается сжатие | 0.9 (сжимать поздно) |
| `summary_target_ratio` | до какого % от текущего объёма сжимать историю | 0.7 (держать 70% истории) |
