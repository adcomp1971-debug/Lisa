# OpenAI Codex Provider Auth — Headless Server Device Code Flow

Дата: 2026-07-02
Источник: сессия по замене модели Hermes на DeepSeek Flash — Alex спросил «Кодекс проверь»

## Когда нужно

- Настраиваешь OpenAI Codex как провайдер в Hermes
- `hermes status` показывает `OpenAI Codex ✗ not logged in — No Codex credentials stored`
- Сервер без браузера (headless VPS, SSH-only, без X11/wayland)

## Процесс аутентификации

```bash
hermes auth add openai-codex --manual-paste
```

**`--manual-paste`** — ключевой флаг для headless-серверов. Без него Hermes пытается:
1. Открыть локальный браузер (упадёт на сервере)
2. Запустить loopback HTTP сервер на 127.0.0.1 для приёма callback URL (недоступен с машины пользователя)

С `--manual-paste` Hermes выдаёт **device code flow**:

```
To continue, follow these steps:

  1. Open this URL in your browser:
     https://auth.openai.com/codex/device

  2. Enter this code:
     JUQN-D8C6P

Waiting for sign-in... (press Ctrl+C to cancel)
```

## Что нужно сделать

1. Запустить `hermes auth add openai-codex --manual-paste` **в фоне** (`background=true`)
2. Считать URL и код из вывода
3. Отправить пользователю: ссылка + код
4. Пользователь открывает ссылку в своём браузере, вводит код, авторизует
5. Процесс дожидается подтверждения и сохраняет credentials

## Проверка результата

```bash
hermes status | grep -i codex
# Должно быть: OpenAI Codex  ✓ logged in
```

## Питфоллы

- **Не забыть `--manual-paste`** — без флага процесс зависнет в попытке запустить браузер
- **Background обязателен** — foreground команда с `&` блокируется (использовать `terminal(background=true)`)
- **Код одноразовый** — истекает через ~5 минут. Если пользователь не успел — перезапустить
- **Только для headless** — на машине с GUI можно без `--manual-paste`, браузер откроется сам
- **OAuth, не API key** — Codex это не просто API ключ OpenAI. Нужна именно OAuth-сессия для Codex CLI. Обычный `$OPENAI_API_KEY` для Codex не подходит.
