# SPA Proxy Pitfalls (React SPA из подпути)

## Проблема
React SPA (Single Page Application) делает API/fetch запросы к **абсолютным путям от корня** (`/api/2.0/...`), игнорируя subpath (`/mlflow/`). Если nginx проксирует `/app/` → `localhost:5000`, то:
- HTML/CSS/JS грузятся (относительные пути работают)
- API запросы идут в `/api/...` а не в `/app/api/...` → **INTERNAL_ERROR**

## Пример: MLflow 3.14
- Попытка: `location /mlflow/ { proxy_pass http://127.0.0.1:5050; }`
- Результат: UI открывается, но API возвращает ошибки, вкладка Runs показывает "INTERNAL_ERROR"

## Что НЕ работает
- **sub_filter** — подменяет `href="/` → `href="/mlflow/` в HTML, но React fetch() из JS бандла не подменяется (динамические строки, сжатый JS, хэшированные имена)
- **rewrite** — не чинит проблему, только меняет путь на стороне nginx, не в браузере

## Что работает
1. **Отдельный порт** — Tailscale Serve на другой порт:
   ```bash
   tailscale serve --bg --https 4433 127.0.0.1:5050
   ```
   Только tailnet. Если нужен внешний доступ — добавить `tailscale funnel`.

2. **Прямой доступ по IP+порту** — открыть порт в ufw, MLflow слушает на 0.0.0.0:
   ```bash
   mlflow server --host 0.0.0.0 --port 5050 --allowed-hosts '*'
   ufw allow 5050/tcp
   ```

3. **Tailscale Funnel на корень** — если освободить 443 порт, Funnel вешает корень домена на MLflow:
   ```bash
   tailscale funnel --bg 8080  # → nginx :8080 → MLflow :5050
   ```

4. **Отдельный поддомен** (если есть) — MLflow на `mlflow.domain.com`, nginx на корне.

## Проверка
curl -sk https://gpu-qwen.tail0c8f2f.ts.net/ | head -3
Должен быть HTML с `id="root"` — React SPA загрузилась. 
Проверить API:
curl -sk -X POST 'https://gpu-qwen.tail0c8f2f.ts.net/api/2.0/mlflow/experiments/search' -H 'Content-Type: application/json' -d '{"max_results":10}'
Должен вернуть JSON с experiments.
