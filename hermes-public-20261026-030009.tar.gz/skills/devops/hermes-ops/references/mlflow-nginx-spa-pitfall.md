# MLflow + Nginx SPA Proxy Pitfall

**Discovered:** 2026-07-07 while setting up MLflow UI behind nginx

## Symptom
MLflow UI (React SPA) loads HTML shell but all JS/CSS return 404 or wrong content. Page shows blank screen or "Invalid Host header" error.

## Root cause
MLflow 3.x is a React Single-Page Application. It uses absolute paths (`/static/js/main.js`, `/api/2.0/mlflow/`) that don't include the nginx subpath prefix.

When nginx proxies `/mlflow/` → `http://127.0.0.1:5050/`, the browser requests `/static/js/main.js` (not `/mlflow/static/js/main.js`), so nginx can't find it.

## Failed approaches (don't repeat)
1. **sub_filter** — tries to rewrite HTML paths but breaks API calls (`/api/` → `/mlflow/api/` breaks MLflow's internal API routing)
2. **rewrite** — same problem, breaks the SPA's internal routing
3. **Separate port via Tailscale Funnel** — works but requires non-standard port (4433) and Tailscale Serve config

## Working solution
**Put MLflow at the ROOT of the site**, not a subpath.

```nginx
server {
    listen 443 ssl http2;
    server_name _;
    
    # MLflow UI — root path
    location / {
        proxy_pass http://127.0.0.1:5050;
        proxy_set_header Host 127.0.0.1:5050;
        proxy_http_version 1.1;
        proxy_buffering off;
    }
    
    # Other services — subpaths
    location /dash/ { ... }
    location /webui/ { ... }
}
```

Then access other services via subpaths (`/dash/`, `/webui/`, `/xui/`, `/api/`, `/gatebox/`, `/swarm/`).

## Alternative (if root is occupied)
Use Tailscale Funnel on a separate port:
```bash
tailscale funnel --bg 4433 127.0.0.1:5050
```
Access via `https://gpu-qwen.tail0c8f2f.ts.net:4433/`

## MLflow security
MLflow 3.x has built-in security middleware that blocks external Host headers. Must start with:
```bash
mlflow server --host 0.0.0.0 --port 5050 --allowed-hosts '*' --cors-allowed-origins '*'
```

## Verification
```bash
# Test MLflow API
curl -s http://127.0.0.1:5050/health
curl -s -X POST http://127.0.0.1:5050/api/2.0/mlflow/experiments/search \
  -H 'Content-Type: application/json' -d '{"max_results":10}'
```
