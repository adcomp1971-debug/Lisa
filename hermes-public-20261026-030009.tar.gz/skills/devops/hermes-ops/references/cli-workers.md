# CLI Workers & Daily Cost

## CLI Workers

| Worker | Команда | Статус | Авторизация |
|--------|---------|--------|-------------|
| **CodeWhale** (ex-DeepSeek TUI) | `codewhale exec --auto "prompt"` | ✅ Работает | API ключ из .env |
| **Aider** | `aider --model openai/deepseek-chat --yes "task"` | ✅ Работает | `export OPENAI_API_KEY=$DEEPSEEK_API_KEY` |
| **Grok Build** | `grok -p "prompt" --always-approve` | ✅ Работает | SuperGrok, headless ready |
| **Codex CLI** | `codex exec "prompt"` | ✅ Работает | OpenAI key |
| **Headroom** | Docker :8787 | ✅ Работает | OpenAI + Anthropic |

**CodeWhale replaces DeepSeek TUI:** `npm install -g codewhale`.

**Grok Build CLI auth pitfall:** `XAI_API_KEY` из `.env` — это OAuth-токен провайдера `xai-oauth`, Grok Build CLI его НЕ принимает. Нужен отдельный API-ключ с console.x.ai или `grok login --device-auth`.

## Typical Daily Cost (June 2026)

| Component | Model | Est. Daily Cost |
|-----------|-------|----------------|
| Cron jobs (3 active LLM) | Gemini 3.5 Flash (free tier) | $0.00-0.02 |
| Main session | DeepSeek V4 Flash | $0.50-2.00 |
| Subagents (Flash) | DeepSeek V4 Flash | $0.10-0.40 |
| Vision/triage | GPT-4o (OpenAI) | $0.05-0.30 |
| Fallback (rare) | GPT-4o-mini / Grok 4.3 (free) / V4 Pro | $0.00-0.20 |
| **Total** | | **~$0.65-2.92/day** |

## Cost Guard Rules

- Anthropic models blocked at runtime by cost_guard.yaml
- Cron jobs: always Gemini 3.5 Flash ($0.08/M, free tier) — verified, no exceptions
- Subagent delegation: DeepSeek V4 Flash
- Vision: GPT-4o via OpenAI direct
- Fallback: GPT-4o-mini (OpenAI) → Grok 4.3 (xAI, free) → V4 Pro (DeepSeek) → Gemini 3.5 Flash (Google, free) → Claude Sonnet 4.6 (OpenRouter, deep)
- All auxiliary services use direct DeepSeek Flash — never OpenRouter

## Profile deletion — CRITICAL

When the user says a profile «удалён» or «пропал», DO NOT assume deletion. First verify:
```bash
hermes profile list
ls ~/.hermes/profiles/<name>/
ls ~/.hermes/profiles/<name>/config.yaml
```

Common case: the profile `.env` and `config.yaml` exist, but cron jobs stopped working. Recovery is often just restarting services.

If the profile truly is deleted, recreate from scratch:
1. `hermes profile create vasily`
2. Write `config.yaml` with model + fallback_providers
3. Copy `.env` keys from main or operator input
4. Restore cron jobs from `~/.hermes/cron/jobs.json`
