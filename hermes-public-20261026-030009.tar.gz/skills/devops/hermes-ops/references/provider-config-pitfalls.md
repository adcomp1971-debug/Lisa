# Hermes Provider Config Pitfalls

## 1. DeepSeek provider needs explicit config

Симптом: Hermes показывает `provider=openrouter` для deepseek-v4-flash, хотя в config.yaml model: deepseek-v4-flash и deepseek provider есть.

**Причина:** Hermes авто-детектит провайдеры из `.env`. Если `OPENROUTER_API_KEY` есть в `.env`, Hermes создаёт провайдер `openrouter` и роутит deepseek-v4-flash туда, игнорируя конфиг deepseek.

**Фикс (комплексный, все три шага):**
```yaml
# 1. В providers.deepseek — base_url и api_key:
providers:
  deepseek:
    api_key: ${DEEPSEEK_API_KEY}
    base_url: https://api.deepseek.com/v1
    request_timeout_seconds: 600
    stale_timeout_seconds: 120

# 2. Явный provider: deepseek на уровне model:
model: deepseek-v4-flash
provider: deepseek

# 3. Удалить OPENROUTER_API_KEY из .env (если OpenRouter не используется)
```

**Проверка после фикса:**
```bash
# 1. Прямой API работает
curl -s https://api.deepseek.com/v1/models -H "Authorization: Bearer $DEEPSEEK_API_KEY"

# 2. Gateway не использует openrouter
grep -i openrouter ~/.hermes/config.yaml
# → должен быть 0 результатов

# 3. После рестарта gateway — в логах нет openrouter
journalctl -u hermes-gateway --since "1 min ago" --no-pager | grep provider=
# → должно быть provider=deepseek, не provider=openrouter
```

## 2. xai-oauth vs xai (OAuth подписка vs API key)

- `provider: xai` — использует XAI_API_KEY из .env (pay-as-you-go)
- `provider: xai-oauth` — использует SuperGrok подписку (OAuth)

Симптом: пришли неожиданные счета от xAI. Фикс: переключить fallback с `xai` на `xai-oauth`.

## 3. Fallback provider must exist in providers section

Симптом: `grok-4.3` в fallback, но провайдер `xai-oauth` не определён в `providers:` → fallback падает с ошибкой.

**Фикс:** либо добавить провайдер в `providers:`, либо заменить на существующий:

```yaml
# Вариант A — добавить провайдер (если нужно OAuth)
providers:
  xai-oauth:
    api_mode: oauth
    base_url: https://api.x.ai/v1

# Вариант B — использовать существующий (xai с XAI_API_KEY)
fallback_providers:
  - model: grok-4.3
    provider: xai      # не xai-oauth!
```

**Проверка:** каждый `provider:` в `fallback_providers` должен иметь соответствующий блок в `providers:`.

## 4. Memory limits silent overflow

Симптом: `WARNING memory: Memory at X/Y chars. Adding this entry would exceed the limit.`

**Фикс:** добавить/увеличить `memory_char_limit` в config.yaml:

```yaml
memory:
  memory_enabled: true
  user_profile_enabled: true
  memory_char_limit: 4000     # было 1375 (дефолт)
  user_char_limit: 1375
```

Memory entries живут в сессионном state. После увеличения лимита — `/reset` или рестарт gateway.

## 5. profile config drift

Изменения в default профиле НЕ применяются к buratino и другим профилям.
После изменения default проверять buratino:
```bash
diff <(grep -A1 '^delegation:' ~/.hermes/config.yaml) \
     <(grep -A1 '^delegation:' ~/.hermes/profiles/buratino/config.yaml)
diff <(grep -A6 '^fallback_providers:' ~/.hermes/config.yaml) \
     <(grep -A6 '^fallback_providers:' ~/.hermes/profiles/buratino/config.yaml)
```
