# Hermes Update & Systemd Unit Drift Warning

## Issue: Buratino Systemd TimeoutStopSec Mismatch

After `hermes update` (which auto-drains + restarts gateways), the buratino
profile may emit:

```
WARNING gateway.run: Stale systemd unit detected: hermes-gateway-buratino.service
  has TimeoutStopSec=90s but drain_timeout=180s (expected >=210s).
  systemd may SIGKILL the gateway mid-drain.
  Run `hermes gateway install --force` to regenerate the unit, or
  shorten agent.restart_drain_timeout.
```

### Impact
- Non-critical during normal operation (buratino runs fine after restart).
- On slow-drain exits (>90s), systemd sends SIGKILL before graceful shutdown completes.
- Active Telegram conversations get orphaned, user sees bot offline momentarily.

### Fix (run when convenient)
```bash
sudo hermes gateway install --force
# Regenerates unit files with matching TimeoutStopSec
```

### Detection
```bash
# Check TimeoutStopSec vs drain_timeout alignment
grep TimeoutStopSec /etc/systemd/system/hermes-gateway-buratino.service
hermes config show | grep drain_timeout
```

## Issue: HTTP API Server Silent After Update

After updating from v0.18.0 → v0.18.2, the HTTP API server (port 4000)
returned empty responses (`curl http://localhost:4000/api/status` → exit 7).

### Root Cause
The `api` section in config.yaml was empty (`{}`). The HTTP API server
binds to port 8642/8643 (profile-specific), not 4000. Port 4000 was
previously served by a different service or nginx proxy.

### Verification
```bash
# Check which ports Hermes actually listens on
ss -tlnp | grep hermes
# Expected: 127.0.0.1:8642 (default), 127.0.0.1:8643 (buratino)

# Check if API is reachable on correct port
curl -s http://localhost:8642/api/status
curl -s http://localhost:8643/api/status
```

## Issue: GLM API Balance Zero (HTTP 429)

After restart, if GLM is in the fallback chain, expect:
```
WARNING agent.conversation_loop: API call failed (attempt 1/3)
  error_type=RateLimitError provider=glm model=glm-5.2
  summary=HTTP 429: 余额不足或无可用资源包,请充值。
```

### Behavior
- Hermes correctly falls back to next provider (Gemini, then LongCat).
- No user action needed unless GLM is the only provider.
- If GLM is primary and balance is zero, all requests fail until recharged.

### Detection
```bash
journalctl -u hermes-gateway.service --since "5 min ago" | grep "429\|余额不足"
```

## Post-Update Verification Checklist

Run after every `hermes update`:

```bash
# 1. Version bump confirmed
hermes --version

# 2. All gateways active
systemctl is-active hermes-gateway.service hermes-gateway-buratino.service

# 3. No crash-loop in journal
journalctl -u hermes-gateway.service --since "5 min ago" -p err --no-pager
journalctl -u hermes-gateway-buratino.service --since "5 min ago" -p err --no-pager

# 4. MCP servers connected (check process list)
ss -tlnp | grep -E "(hermes|8642|8643)"

# 5. Cron jobs intact
hermes cron list | head -10

# 6. Telegram connectivity (check for "Connecting to Telegram" success)
journalctl -u hermes-gateway.service --since "2 min ago" | grep "Telegram.*connected\|fallback IP"

# 7. Provider balance (if GLM in chain)
journalctl -u hermes-gateway.service --since "5 min ago" | grep "429" | tail -3
```
