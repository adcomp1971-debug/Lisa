# Telegram Gateway Token Debugging

## Case Study (2026-06-12): Token Rejected After Restart

### Symptom
```
ERROR gateway.platforms.telegram: [Telegram] Failed to connect to Telegram:
The token `7429906531:***` was rejected by the server.
telegram.error.InvalidToken: Unauthorized
```

Bot was working fine for hours. Gateway restarted (systemd auto-restart after crash), then immediately token rejected.

### Timeline Reconstruction

Key command: correlate gateway restarts with error onset.
```bash
journalctl -u hermes-gateway --since "15:50" --until "16:00" --no-pager
```

What happened:
- **15:51** — SQLite state DB corrupted: `database disk image is malformed`
- **15:56:40** — Gateway deactivated (crashed)
- **15:56:45** — Systemd restarted gateway (PID 578262)
- **15:56:51** — IMMEDIATELY: token rejected

**Key insight:** Token was valid in old process (PID 553752), rejected in new process (PID 578262). The old process had the token working via cached/initialized session. The new process read it fresh from `.env` and Telegram rejected it.

### Diagnostic Steps

1. **Verify token directly with Telegram API:**
```bash
TOKEN=*** "^TELEGRAM_BOT_TOKEN=*** /root/.hermes/.env | cut -d= -f2)
curl -s "https://api.telegram.org/bot${TOKEN}/getMe"
```
Response codes:
- `200 {"ok":true}` — token valid
- `401 Unauthorized` — token format valid but rejected (revoked/expired)
- `404 Not Found` — token format invalid (wrong length, malformed)

2. **Check .env integrity:**
```bash
wc -l /root/.hermes/.env           # line count
ls -la /root/.hermes/.env*         # size + modification timestamps
```

3. **Compare with .env backups:**
```bash
diff <(grep "TELEGRAM_BOT_TOKEN" /root/.hermes/.env) \
     <(grep "TELEGRAM_BOT_TOKEN" /root/.hermes/.env.bak.20260602_1630)
```

4. **Check if token changed between backups** (Python, since shell escaping is fragile):
```python
import subprocess

def get_token(path):
    result = subprocess.run(['grep', 'TELEGRAM_BOT_TOKEN=*** path], capture_output=True, text=True)
    return result.stdout.strip().split('=', 1)[1]

current = get_token('/root/.hermes/.env')
backup = get_token('/root/.hermes/.env.bak.20260602_1630')
print(f"Current: {current[:15]}...  (len={len(current)})")
print(f"Backup:  {backup[:15]}...  (len={len(backup)})")
print(f"Match: {current == backup}")
```

### Common Root Causes

1. **Token was valid when gateway started, but expired/revoked while running.** Old process kept working (already authenticated). New process fails on init.

2. **`.env` was modified between gateway start and restart.** Check `ls -la` timestamps against gateway start time. The gateway reads `.env` at startup, so any edit between last successful start and current attempt is suspect.

3. **`.env` was truncated.** Compare `wc -l ~/.hermes/.env` against a known-good backup. In one case, the file went from 467 lines to 13 — all non-essential vars stripped. Abnormally low line count (under 20 for a production setup) means the file was overwritten. Restore from the most recent backup with normal line count.

4. **Token was regenerated in BotFather.** Old value still in `.env`. Need new token from @BotFather.

### Recovery

1. Get new token from @BotFather: `/mybots` → select bot → API Token → Revoke/Regenerate
2. Test token before committing: `curl -s "https://api.telegram.org/bot<TOKEN>/getMe"` — must return `{"ok":true}`
3. **Update `.env` with Python (NEVER sed — tokens contain special chars):**
```bash
python3 -c "
import re
TOKEN='<new_token>'
with open('/root/.hermes/.env') as f: content = f.read()
content = re.sub(r'^TELEGRAM_BOT_TOKEN=.*', f'TELEGRAM_BOT_TOKEN={TOKEN}', content, flags=re.M, count=1)
with open('/root/.hermes/.env', 'w') as f: f.write(content)
# verify
with open('/root/.hermes/.env') as f:
    for line in f:
        if line.startswith('TELEGRAM_BOT_TOKEN=*** and 'LISKA' not in line:
            tok = line.strip().split('=', 1)[1]
            print(f'Written: len={len(tok)} (expect 46)')
"
```
4. Restart gateway: `systemctl restart hermes-gateway`
5. Verify: `journalctl -u hermes-gateway -f` — should see Telegram connected, no InvalidToken errors
6. Send `/ping` in Telegram to confirm end-to-end

### Pitfall: NEVER use sed for token updates

Bot tokens contain characters like `/`, `-`, `_`, `:` that `sed` may interpret or truncate. In this session, `sed` silently truncated a 46-char token to 14 chars. Always use Python `re.sub()` — it handles all characters literally.

### Prevention

- Always take a `.env` snapshot before `hermes update` or gateway restart: `cp ~/.hermes/.env ~/.hermes/.env.bak.$(date +%Y%m%d-%H%M)`
- After gateway restart, send `/ping` in Telegram within 30 seconds
- Monitor `journalctl -u hermes-gateway -f` for 1 minute after any restart
- After `hermes update`, check for package downgrades: `hermes --version | grep "OpenAI SDK"` — if version dropped, re-upgrade with `/usr/local/lib/hermes-agent/venv/bin/pip3 install --upgrade openai`
- Verify `.env` line count matches expectations: `wc -l ~/.hermes/.env`
