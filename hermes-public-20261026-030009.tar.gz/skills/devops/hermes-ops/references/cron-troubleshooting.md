# Cron Troubleshooting

Diagnose and fix Hermes cron job failures:
- **Error patterns:** Check `hermes cron list` for `failed` status. Common culprits: missing env vars, script path errors, or LLM model timeouts.
- **Debug workflow:** Run the script manually in the terminal first. If it works manually but fails in cron, the issue is environment (cron has a minimal PATH and no `.bashrc` sourcing).
- **Common fixes:** Add `source ~/.hermes/.env` at the top of bash scripts.
- **no_agent jobs:** Ensure `no_agent=True` scripts exit with 0 on success and produce no stdout unless an alert is needed.

**CRITICAL: always verify skill names in cron jobs.** Referencing a non-existent skill in a cron job's `skills` list silently fails — the job runs but the missing skill is skipped with "Skill(s) not found and skipped: <name>". Before creating/updating a cron job with `skills:`, run `hermes skills list` to confirm the skill name exists.

**CRITICAL: always specify language in cron prompts.** When creating/updating cron jobs that produce text for a non-English user, the prompt MUST explicitly include language instructions (e.g. `Только на русском языке. Ответ полностью на русском.`). Models default to English. Add language instruction at the END of the prompt for maximum compliance.

**CRITICAL: `hermes cron list` HIDES model/provider overrides — always check `jobs.json`.** The CLI output shows schedule, skills, scripts, and last-run status but DOES NOT display per-job `model` or `provider` overrides. A cron job silently running on an expensive or quota-exhausted model looks identical to one running on DeepSeek Flash. **When a cron job fails with provider errors, inspect `~/.hermes/cron/jobs.json` directly.**

**Real case (Jun 26):** `vasily-freelance` silently pinned to `google/gemini-3.5-flash` in jobs.json. `hermes cron list` showed it as healthy until Gemini quota exhausted → HTTP 429. Fixed by switching to `deepseek/deepseek-v4-flash` in jobs.json.
