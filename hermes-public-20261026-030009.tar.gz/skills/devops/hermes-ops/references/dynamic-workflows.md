# Dynamic Workflows Plugin

Dynamic Workflows (`lingjiuu/hermes-dynamic-workflows`) adds Claude-Code-style orchestration to Hermes: `agent()`, `parallel()`, `pipeline()` for spawning subagents in sandboxed Python scripts. Installed from git source at `~/.hermes/plugins/dynamic-workflows/`.

## Configuration

```yaml
plugins:
  enabled:
    - dynamic-workflows
  entries:
    dynamic-workflows:
      dynamic_workflows:
        concurrency: 8                # Max concurrent agents
        max_concurrency: 16           
        max_agents: 500               # Runaway guard
        workflow_timeout_seconds: 900 # 15 min wall-clock
        child_timeout_seconds: 300    # 5 min per agent
        keep_worktrees: false
        allow_model_override: true    # agent(model=...) allowed per-call
        require_launch_approval: false # Must be false for gateway sessions
        notify_on_complete: true      # Inject result notification (default)
        notify_result_preview_chars: 2000  # Truncate result in notification
        child_approval_policy: inherit  # Uses Hermes approvals.mode chain
```

- `require_launch_approval: true` **silently blocks in gateway sessions** — there is no approve/deny UI in Telegram/Discord gateway. The workflow reports as "launched" but never executes.
- `notify_on_complete: true` (default) injects `<task-notification>` into the agent's conversation on completion. In gateway sessions, also sends a `✅ Workflow completed` message to the origin chat.
- `child_approval_policy: inherit` uses Hermes' own `approvals.mode` chain (smart/manual/off). For gateway, `smart` mode auto-approves low-risk child commands while blocking the genuinely dangerous.
- `allow_model_override: true` lets child agents be assigned specific models via `agent(model='...')`. The user's existing cost controls still apply (expensive models only after plan+confirm).

## Notification System

Workflow results are delivered via two paths (both gated by `notify_on_complete`):

1. **In-session injection** — `ctx.inject_message()` injects a `<task-notification>` block into the parent agent's conversation. The agent sees it as a system message between turns.
2. **Gateway fallback** — if injection fails, sends directly to the origin Telegram/Discord chat via `adapter.send()`. The message includes status icon (✅/⏹/❌), task ID, and up to 2000 chars of result preview.

Results are NOT stored as `result.json` on disk — they live in the workflow record and are delivered via the notification mechanism. The journal (`journal.jsonl`) tracks events but is empty until agents start.

## Live Dashboard (optional)

```bash
python3 ~/.hermes/plugins/dynamic-workflows/scripts/install-hermes-workflows.py
# Then in a separate terminal: hermes-workflows
```

## Critical Gateway Limitations

1. **`require_launch_approval: true` blocks in Telegram gateway.** There is no approval UI in gateway sessions. The workflow reports as "launched" but never executes — it waits for an approval prompt that the user never sees. Journal stays empty, no agents ever start. **Fix:** Set `require_launch_approval: false` for gateway use. Keep `true` only for CLI sessions where the approval prompt is visible.

2. **Result delivery** works via `notify_on_complete` (default: `true`). Notifications arrive as `<task-notification>` injected into the agent's conversation, or as a direct message to the Telegram chat via gateway fallback. However, the agent may not see the notification if it continues making tool calls without processing incoming system messages. Use `/workflows` in-session or run `hermes-workflows` in a separate terminal to watch progress.

3. **Config changes need `/reset`** (new session) — plugins read config at startup. `hermes config set` changes don't take effect mid-session. For gateway, a `/reset` or `hermes gateway restart` is required after any plugin config change.

## Invocation

```python
meta = {"name": "my-workflow", "description": "..."}
phase("Check")
results = await parallel([
    lambda: agent("check X", {"toolsets": ["terminal"], "label": "x-check"}),
    lambda: agent("check Y", {"toolsets": ["terminal"], "label": "y-check"}),
])
phase("Synthesize")
summary = await agent("Synthesize: " + json.dumps(results), ...)
return summary
```

The script must NOT contain `import` statements — `json`, `math` are pre-imported. Use `scriptPath` parameter to reference a file on disk. Support files: `references/dynamic-workflows-test-results.md` for session reproduction data.

## Pitfalls

- `import` is forbidden in workflow scripts — `json` and `math` are pre-available
- `require_launch_approval: true` silently blocks workflows in gateway — the workflow reports as "launched" but never executes
- Result delivery back to gateway session is broken — results are logged but not delivered
- Schedule dashboard separately — `hermes plugins install` does NOT install the dashboard binary
