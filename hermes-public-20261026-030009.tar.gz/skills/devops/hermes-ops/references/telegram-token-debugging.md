# Telegram Gateway Token Debugging

Diagnose when the Hermes gateway reports `InvalidToken` or `Unauthorized` for the main Telegram bot after a restart.

**Symptom:** Gateway was working, then after restart (manual or systemd auto-restart): `The token was rejected by the server.`

**Root cause (most common):** The token was already invalid/expired but the old gateway process had it cached from initial auth. The restart forces a fresh `getMe()` call which fails.

**Diagnostic sequence:**
1. Correlate restart time with error onset: `journalctl -u hermes-gateway --since "HH:MM" --until "HH:MM"`
2. **Quick `.env` integrity:** `wc -l ~/.hermes/.env` — if count is abnormally low (e.g. 13 lines instead of 400+), the file was truncated.
3. Test token directly: `curl -s "https://api.telegram.org/bot<TOKEN>/getMe"` — 401=revoked, 404=malformed
4. Compare token across `.env` backups with hash comparison

**Recovery:** Get new token from @BotFather, update `.env`, `systemctl restart hermes-gateway`.

Full case study with timeline, commands, and Python diagnostics: `references/telegram-gateway-crash-debug.md`.
