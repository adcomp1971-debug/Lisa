# Anthropic Messages API Relay (:4450)

## Overview

Релей на порту `:4450`, принимающий **Anthropic Messages API** (Claude Code)
и конвертирующий в OpenAI Chat Completions → LongCat-2.0.

Создан 2026-07-04, расширен 2026-07-05 (HTTPS + рабочий Claude Code стек).

## Архитектура

```
Claude Code → claude-lc wrapper (env vars)
         ↓
  ANTHROPIC_BASE_URL=https://localhost:4451
         ↓
  stunnel (:4451, HTTPS → HTTP)
         ↓
  codex-relay-anthropic (:4450, Anthropic → Chat Completions)
         ↓
  POST /chat/completions → api.longcat.chat
         ↓
  ← Anthropic-формат ответ обратно
```

## Полный стек воркеров

### GLM вариант (:4452/:4453)

Аналог LongCat релея, но upstream → Z.AI (GLM 5.2):

```
Claude Code → claude-glm wrapper
         ↓
  ANTHROPIC_BASE_URL=https://localhost:4452
         ↓
  stunnel-anthropic-glm (:4452, HTTPS → HTTP)
         ↓
  codex-relay-anthropic-glm (:4453, Anthropic → Chat Completions)
         ↓
  POST /chat/completions → https://api.z.ai/api/paas/v4
         ↓
  ← Anthropic-формат обратно (glm-5.2)
```

```bash
systemctl status codex-relay-anthropic-glm  # :4453 → Z.AI
stunnel /etc/stunnel/anthropic-glm.conf     # :4452 → :4453 HTTPS
```

### Таблица всех воркеров (8 шт)

**Глобальные:**

| Команда | Инструмент | Модель | Use case |
|---------|-----------|--------|----------|
| `codex-glm` | Codex CLI | GLM 5.2 🧠 | Сложный код, архитектура |
| `codex-lc` | Codex CLI | LongCat ⚡ | Быстрые скрипты, тесты |
| `claude-lc` | Claude Code | LongCat 🛠️ | Универсальный, ФС/сеть |
| `claude-glm` | Claude Code | GLM 5.2 🧠🛠️ | Самое мощное |

**Buratino (@NemotrBot):**

| Команда | Инструмент | Модель | Use case |
|---------|-----------|--------|----------|
| `buratino-codex` | Codex CLI | GLM 5.2 🧠 | Сложный код, MIDI/данные |
| `buratino-codex-lc` | Codex CLI | LongCat ⚡ | Быстрые скрипты |
| `buratino-claude` | Claude Code | LongCat 🛠️ | Файлы, сеть |
| `buratino-claude-glm` | Claude Code | GLM 5.2 🧠🛠️ | Самое мощное для buratino |

### Multi-profile PATH fix

Buratino gateway не наследует PATH от глобального shell.
`env_passthrough: []` не передаёт PATH → бинарники codex/claude не найдены.
Фикс: добавить `PATH` в `terminal.env_passthrough` в config.yaml buratino профиля.

### Systemd сервисы

| Сервис | Порт | Upstream |
|--------|------|----------|
| `codex-relay-anthropic.service` | :4450 | LongCat |
| `codex-relay-anthropic-glm.service` | :4453 | Z.AI (GLM 5.2) |
| `stunnel-anthropic.service` | :4451 → :4450 | LongCat HTTPS |
| `stunnel-anthropic-glm.service` | :4452 → :4453 | GLM HTTPS |

## Полный стек

### Релей (:4450)
```bash
systemctl status codex-relay-anthropic
# upstream: https://api.longcat.chat/openai/v1
```

### stunnel (HTTPS :4451 → HTTP :4450)
```bash
stunnel /etc/stunnel/anthropic-relay.conf
# Сертификат self-signed: /etc/stunnel/anthropic.pem
```

### Claude Code wrapper (/usr/local/bin/claude-lc)
```bash
export ANTHROPIC_BASE_URL="https://localhost:4451"
export ANTHROPIC_AUTH_TOKEN="<LONGCAT_API_KEY>"
export ANTHROPIC_API_KEY=""  # ДОЛЖЕН БЫТЬ ПУСТЫМ!
export ANTHROPIC_MODEL="LongCat-2.0"
export ANTHROPIC_DEFAULT_SONNET_MODEL="LongCat-2.0"
export ANTHROPIC_DEFAULT_OPUS_MODEL="LongCat-2.0"
export ANTHROPIC_DEFAULT_HAIKU_MODEL="LongCat-2.0"
export NODE_TLS_REJECT_UNAUTHORIZED=0
exec claude "$@"
```

## Ключевые моменты

### Версия Claude Code
Работает с v2.0.5: `npm install -g @anthropic-ai/claude-code@2.0.5`
На v2.1.146+ `settings.json` с `anthropic-base-url` **не работает** — игнорируется.

### Model mapping (case-insensitive)
Все Claude модели мапятся на `LongCat-2.0` в `anthropic.rs`.
Без этого Claude Code шлёт `longcat-2.0` (lowercase) → LongCat отвечает 400.

### HTTPS обязателен
Claude Code SDK требует HTTPS для не-localhost. Решение: stunnel.

### ANTHROPIC_API_KEY должен быть пустым
Если не пустой — Claude Code пытается идти в официальный Anthropic API.

## Симптомы и решения

- `Not logged in` → добавить env vars в wrapper (не settings.json)
- `Invalid API key` → проверить что ANTHROPIC_API_KEY="" (пустая строка)
- `Cannot read properties...` → обновить model mapping (case-insensitive)
- Connection refused :4451 → `stunnel /etc/stunnel/anthropic-relay.conf`

## Воркеры

- `claude-lc "задача"` — Claude Code через LongCat
- `buratino-claude "задача"` — для buratino профиля
- `buratino-codex "задача"` — Codex CLI для buratino профиля

## Файлы

- `/root/codex-relay-rust/src/anthropic.rs` — handler + translation
- `/root/codex-relay-rust/run-relay-anthropic.py` — wrapper
- `/etc/systemd/system/codex-relay-anthropic.service`
- `/etc/stunnel/anthropic-relay.conf` — stunnel конфиг
- `/etc/stunnel/anthropic.pem` — self-signed cert
- `/usr/local/bin/claude-lc` — Claude Code wrapper
- `/usr/local/bin/buratino-claude` — buratino Claude Code
- `/usr/local/bin/buratino-codex` — buratino Codex CLI
