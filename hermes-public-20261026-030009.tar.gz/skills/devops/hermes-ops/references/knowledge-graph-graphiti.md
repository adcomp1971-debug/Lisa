# Knowledge Graph — Graphiti + Neo4j

Установлен на Fabula 5 для связной памяти агентов.

## Компоненты

- **Neo4j 5** — графовая БД, Docker контейнер
- **graphiti-core** (v0.29.2) — Python библиотека для temporal knowledge graph
- **Порты:** 7687 (Bolt), 7474 (HTTP UI)

## Статус

- Docker контейнер: `graphiti-neo4j`, автостарт (`--restart unless-stopped`)
- Креды: `neo4j / graphiti123`
- Граф: ~66 узлов, ~88 связей (memory факты + категории + сущности)
- Категории: проект, человек, инструмент, сервер, конфиг, правило, знание

## Скрипты

| Файл | Назначение |
|------|-----------|
| `/root/scripts/graphiti_bridge.py` | Поиск + статистика по графу |
| `/root/scripts/graphiti_load_memory.py` | Первичная загрузка memory в граф |
| `~/.hermes/scripts/graphiti-sync.py` | Cron-синхронизация каждый час |

## Использование

```bash
# Поиск по графу
python3 /root/scripts/graphiti_bridge.py query "Buratino"

# Статистика
python3 /root/scripts/graphiti_bridge.py stats
```

## Важно

- При пересоздании контейнера: `python3 /root/scripts/graphiti_load_memory.py --force`
- Скрипты в `.hermes/scripts/` работают через cron
- Синхронизация новых memory записей — автоматическая, раз в час
