# Kanban Board Management

Kanban boards provide durable SQLite-backed task tracking shared across Hermes profiles. Each board = one project/workstream with isolated DB and dispatcher.

## Creating Boards

```bash
hermes kanban boards create <slug> --name "Display Name" --icon "emoji" --color "#hex" --description "Optional desc"
```

Flags:
- `--name` — human-readable name (defaults to Title Case of slug)
- `--icon` — emoji or single character for dashboard
- `--color` — hex color for dashboard
- `--switch` — immediately switch to new board
- `--default-workdir` — workspace path for tasks on this board

## Switching Boards

```bash
hermes kanban boards switch <slug>
hermes kanban boards current     # print active board
hermes kanban boards list        # list all boards with task counts
```

## Creating Tasks

```bash
hermes kanban create --priority N "Task title"
hermes kanban create --priority N --body "Description of task" "Task title"
```

**Pitfalls:**
- `--priority` expects an INTEGER (1=high, 2=medium, 3=low), NOT string
- `--board <slug>` flag is NOT available on `kanban create` — switch board first
- Task status is `ready` when created. Tasks with `assignee=-` are unclaimed.

## Listing & Showing Tasks

```bash
hermes kanban list     # list all tasks on active board
hermes kanban show <task_id>   # show task with comments + events
```

## Use Case: Project Tracking

Create boards per active project, add tasks with priority, then dispatch to subagents:
- `kanban create --priority 1 "Task"` for high-priority work
- Switch board context when changing projects: `hermes kanban boards switch <slug>`
