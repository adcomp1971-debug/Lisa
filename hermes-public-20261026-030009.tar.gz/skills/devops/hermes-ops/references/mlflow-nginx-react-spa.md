# MLflow 3.14 + nginx: React SPA subpath problem

MLflow 3.14 использует React SPA (фреймворк). При размещении за nginx subpath (`/mlflow/`) JS-код делает fetch() запросы к корню, игнорируя префикс. В UI — `INTERNAL_ERROR`.

## Почему не чинится

- **sub_filter** заменяет строки в HTML/CSS/JS перед отдачей, но React/bundler компилирует URL путей в рантайм-код, который sub_filter не видит
- **rewrite** в nginx ломает пути к статике (JS, CSS, assets)
- **proxy_pass** с `/` (слэш на конце) работает для статики, но API запросы от React всё равно идут в `/api/2.0/...` вместо `/mlflow/api/2.0/...`

## Работающие решения

**Решение A — корень сайта (рекомендуется):**
- Весь домен/порт отдать MLflow на корень
- Остальные сервисы повесить на подпути
- Пример: nginx на 443, `location / { proxy_pass http://127.0.0.1:5050; }`, а dash/webui/api — подпутями

**Решение B — отдельный порт:**
- nginx на порту 5050: `listen 5050; location / { proxy_pass http://127.0.0.1:5050; }`
- Или прямой доступ к MLflow: `--host 0.0.0.0 --allowed-hosts '*'`

**Решение C — Tailscale Serve:**
- `tailscale serve --bg --https 4433 127.0.0.1:5050`
- Только tailnet, но без nginx, React SPA работает корректно

## Invalid Host header

MLflow security middleware блокирует запросы с незнакомым `Host`. В nginx:
```
proxy_set_header Host 127.0.0.1:5050;   # НЕ $host
```

## Port 443 conflicts

XRay/VLESS часто занимает 443 порт. Перенос:
```bash
sqlite3 /etc/x-ui/x-ui.db "UPDATE inbounds SET port=8443 WHERE port=443;"
systemctl restart x-ui
```
