# Z.AI Coding Plan Migration — Switching from Regular to Coding Endpoint

Дата: 2026-07-02
Источник: GLM 5.2 расходы — regular `/api/paas/v4` сжигал prepaid баланс вместо Coding Plan подписки

## Проблема

Z.AI имеет два billing трека:

| Endpoint | Тип | Тарификация |
|----------|-----|-------------|
| `api.z.ai/api/paas/v4` | Regular (prepaid) | Снимает с залитого баланса |
| `api.z.ai/api/coding/paas/v4` | Coding Plan (подписка) | Идёт в счёт подписки |

Если в дашборде Z.AI виден "Coding Plan" / "Coding" тариф, но в конфиге стоит regular endpoint — каждый запрос сжигает prepaid деньги вместо подписки.

## Симптомы

- Дашборд Z.AI показывает утекающий баланс
- Скорость расходов не совпадает с ожидаемой по подписке
- На скриншоте дашборда виден "Coding Plan" но base_url в конфиге — `/api/paas/v4`

## Фикс

Поменять base_url в **обоих** местах конфига:

```bash
hermes config set providers.glm.base_url "https://api.z.ai/api/coding/paas/v4"
hermes config set delegation.base_url "https://api.z.ai/api/coding/paas/v4"
```

### Почему оба?

- `providers.glm.base_url` — отвечает за основной разговор через GLM 5.2
- `delegation.base_url` — отвечает за суб-агентов (delegate_task), которые тоже шлют запросы через GLM

Если поменять только один — суб-агенты продолжат жечь prepaid.

## Верификация

После изменения конфига — протестировать через curl на coding endpoint:

```bash
curl -s -w "\nHTTP: %{http_code}" \
  -H "Authorization: Bearer $GLM_API_KEY" \
  -H "Content-Type: application/json" \
  "https://api.z.ai/api/coding/paas/v4/chat/completions" \
  -d '{"model":"glm-5.2","messages":[{"role":"user","content":"test"}],"max_tokens":10}'
```

Ожидается HTTP 200. HTTP 429 = закончился баланс или ресурсный пакет.

## Консистентность

После фикса — проверить что в конфиге нет других упоминаний `/api/z.ai/api/paas/v4` (без `coding`):

```bash
grep -n 'z.ai' /root/.hermes/config.yaml
```

Должны быть только строки с `/coding/paas/v4`.

## Питфоллы

- **Не забудь delegation.** Основной провайдер может быть пофикшен, а delegation остаётся на regular — суб-агенты продолжают жечь деньги.
- **Рестарт gateway** нужен для применения изменений. Конфиг читается при старте gateway.
- Сам тест через curl НЕ является подтверждением что в Hermes всё работает. После рестарта gateway — спросить у пользователя "работает ли?".
- Если после переключения на coding endpoint модель не отвечает — убедиться что Coding Plan активен в дашборде Z.AI. Не все аккаунты имеют этот тариф.
