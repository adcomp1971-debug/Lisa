# CLI Resilience & SSH Disconnect Recovery

Hermes CLI runs as a foreground process inside the SSH session. If the SSH connection drops, Hermes gets `[Errno 5] Input/output error` and the `process_loop` crashes.

**Symptom:** User reconnects to find Hermes dead. `tail -20 /root/.hermes/logs/errors.log` shows `process_loop unhandled error: [Errno 5] Input/output error`.

**Root cause:** PTS gets SIGHUP on SSH disconnect → stdin/stdout dead → Hermes crashes.

## First response after reconnect

1. Restart Hermes CLI: `hermes`
2. Check if child processes survived: `ps aux | grep -i train` (SkillOpt, builds, etc. may be alive in their own process group)
3. If SkillOpt was running, check `/root/SkillOpt/outputs/*/runtime_state.json` for progress

## Prevention

Run Hermes through the systemd gateway service (`systemctl start hermes-gateway`) or use tmux. Full diagnosis and recovery: `references/cli-ssh-disconnect.md`.

Also applies to `hermes gateway run` in foreground terminal mode.
