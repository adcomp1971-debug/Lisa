# Context Retention Fix — June 29, 2026

## Симптом
Пользователь: «слабый гермес какой то стал раньше лучше был», «хуже с задачами стал спраляться на всех моделях тупит забывает врет».

## Диагностика

### 1. Проверить настройки компрессии
```bash
grep -A5 'summary_target_ratio\|target_ratio' ~/.hermes/config.yaml
```
Было: `summary_target_ratio: 0.5` — сжимало контекст до 50%. После 3-4 сообщений терялась половина истории.

Фикс:
```bash
hermes config set compression.target_ratio 0.7
```
Стало: `summary_target_ratio: 0.7` — сохраняется 70% истории. Пользователь подтвердил улучшение.

### 2. Проверить state.db
```bash
ls -lh ~/.hermes/state.db
```
Было: **287 MB** — FTS5 индексы раздуты, поиск по сессиям медленный.

Фикс:
```bash
hermes sessions optimize
```
Результат: **287 MB → 131 MB** (освобождено 156 MB). Оптимизация FTS5 + VACUUM. Без потери данных.

### 3. Проверить fallback chain
```bash
grep -A10 'fallback_providers:' /root/.hermes/config.yaml
```
Убедиться что фоллбэк-цепочка использует разные провайдеры (не все через одного). Если все через DeepSeek — при падении API все падают.

### 4. Проверить модель
```bash
grep 'default:' /root/.hermes/config.yaml | head -1
```
Если `deepseek-v4-flash` — модель значительно слабее Pro. При жалобах на качество:
- Вернуть Pro: `/model deepseek-v4-pro` (сессионно) или `sed -i` в config.yaml
- Или оставить Flash, но пользователь должен понимать что это экономия в 10× ценой качества

## Результат после фикса
- state.db: 287 MB → 131 MB
- summary_target_ratio: 0.5 → 0.7 (меньше сжатия контекста)
- Fallback chain: OpenRouter удалён, gpt-4o-mini (OpenAI) добавлен напрямую
- Default модель: deepseek-v4-pro → deepseek-v4-flash (по просьбе пользователя)
