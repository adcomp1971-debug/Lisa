---
name: source-library
description: "Research ancient texts via Source Library MCP (22k+ books)."
version: 1.0.0
---

# Source Library — исследование древних первоисточников

## Когда вызывать
- Запрос про древние тексты, философию, эзотерику, алхимию, каббалу, герметизм
- «Найди в первоисточниках», «что писал Парацельс/Фладд/Ньютон о...»
- Нужны цитаты с ссылками из 2500 лет мудрости
- Источник: канал «Горизонт событий» (t.me/your_event_horizon/1806)

## Что это
Source Library (sourcelibrary.org) — крупнейшая открытая библиотека AI-переведённых древних источников:
- 22,068 книг, 7,450+ авторов, 116+ языков
- 17,814 переводов, 5,813 впервые переведены
- Коллекции: Sacred Texts (1644), Classical Philosophy (1666), Hermetica (1197), Mysticism (1279), Alchemy (1236), Magic & Occult (702), Astrology (715), Natural Philosophy (1817), Renaissance Philosophy (1127), Medicine (1516), Secret Societies (379)
- 15,842 artworks, 217,353 иллюстрации
- Инициатива Embassy of the Free Mind (Амстердам), Bibliotheca Philosophica Hermetica
- Все переводы с цитатными URL, публикации с DOI (Zenodo)

## MCP-сервер (главный способ)

**Endpoint (streamable HTTP, без ключа):**
```
https://sourcelibrary.org/api/mcp
```

**Tools (14):**
| Tool | Назначение |
|------|-----------|
| search_library | Полнотекстовый поиск книг по каталогу |
| search_translations | Поиск цитируемых пассажей по ключевым словам |
| search_concept | **Семантический поиск** — ловит перефразировки и смежные идеи, не только ключи |
| search_within_book | Поиск внутри конкретной книги |
| list_books | Фильтры: язык, год, категория, статус перевода |
| list_editions | Все издания работы, языки и века |
| get_book | Метаданные: саммари, главы, DOI |
| get_book_text | Чтение 50+ страниц за раз (OCR/перевод/оба) |
| get_quote | Точный текст страницы со стабильной цитатной ссылкой |
| get_quotes | Дословный текст + ссылки до 25 страниц |
| get_locus | Канонические ссылки: Беккер (Аристотель), Стефанус (Платон) |
| search_images | Иллюстрации/арт по сюжету, символу, типу |
| submit_feedback | Баги/запросы |
| share_findings | Вклад цитируемого досье (рецензируется) |

## REST API (без авторизации)

Base: `https://sourcelibrary.org/api`

- `GET /search?q=<query>&language=<lang>&year_from=&year_to=&sort=`
- `GET /books/:id` — метаданные, саммари, DOI
- `GET /books/:id/text?content=translation&from=1&to=50` — полный текст
- `GET /books/:id/search` — внутри книги
- `GET /books/:id/quote` — дословная страница + цитатный блок
- `GET /verify?book_id=&page=` — alias для веб-агентов
- `GET /gallery` — 150k+ иллюстраций
- `GET /catalog/csv` — полный каталог CSV

## CLI

```bash
npm install -g @source-library/mcp-server
source-library search "Paracelsus" --language=German
source-library translations "harmony of the spheres"
source-library text history-of-both-worlds-macrocosm-fludd --from=1 --to=50
source-library quote history-of-both-worlds-macrocosm-fludd 57
source-library images --subject=alchemy --type=emblem
source-library search "alchemy" --json | jq .results
```

## Проверенные промпты

- «Use sourcelibrary.org to find what Paracelsus says about the spagyric process. Quote passages with citation URLs»
- «Search sourcelibrary.org for early modern texts on the harmony of the spheres — give me three with page links»
- «Find all alchemical emblems depicting the ouroboros. What texts are they from?»
- «What does Copernicus say about the Sun's centrality in De Revolutionibus? Key passages with citations»
- «Search for 'prima materia' across the collection. Which authors discuss it, how do treatments differ?»

## Как звать из Hermes

1. **Через web_extract** (просто, без настройки):
   - `web_extract(["https://sourcelibrary.org/api/search?q=<query>"])` — REST JSON
   - Или открыть страницу книги: `https://sourcelibrary.org/book/<id>`
2. **Через MCP** (если добавлен в config.yaml):
   - `mcp__sourcelibrary__search_concept(query="prima materia", limit=5)`

## Питфоллы

- Сайт — Next.js SPA: web_extract может вернуть только превью; полный контент — через REST API (`/api/search`, `/api/books/:id/text`)
- API без ключа работает, но rate-limit ниже; бесплатный ключ через Sign in → Developers
- Переводы AI — для научных цитат сверять с OCR/оригиналом (OCR% и Translated% видны в каталоге)
- Китайские/тибетские рукописи часто частично OCR (15-40%) — проверять статус
- DOI есть только у опубликованных изданий (Zenodo)

## Связанные проекты

- Канал «Горизонт событий» — агрегатор новостей/эзотерики, откуда узнали
- Идея: «Суверенный ИИ» — библиотека как контент для RAG по философии
- Скилл research-workflow — общий ресёрч
