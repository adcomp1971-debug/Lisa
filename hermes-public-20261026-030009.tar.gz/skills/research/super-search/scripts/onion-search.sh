#!/usr/bin/env bash
# Поиск в onion-сети через Tor (движок Torch).
# Использование: onion-search.sh "запрос" [max_results]
# Требует: tor активен и слушает 127.0.0.1:9050. Только чтение, ничего не качаем.
# Проверено 2026-09-25: Torch отвечает, индекс ~3,642,332 документа.
set -euo pipefail
Q="${1:?usage: onion-search.sh \"query\" [max]}"
MAX="${2:-10}"
SOCKS="127.0.0.1:9050"
TORCH="http://xmh57jrknzkhv6y3ls3ubitzfqnkrwxhopf5aygthi7d6rplyvk3noyd.onion/cgi-bin/omega/omega"
OUT="$(mktemp "${TMPDIR:-/tmp}/onion.XXXXXX.html")"
trap 'rm -f "$OUT"' EXIT

# Важно: параметр именно P= (htdig/Omega). query= или DB=en дают ошибку базы.
timeout 90 curl -s --socks5-hostname "$SOCKS" --max-time 85 -A 'Mozilla/5.0' \
  --get --data-urlencode "P=$Q" "$TORCH" -o "$OUT"

python3 - "$OUT" "$MAX" <<'PY'
import re, sys, html
path, mx = sys.argv[1], int(sys.argv[2])
t = open(path, encoding='utf-8', errors='ignore').read()
if "couldn't be opened" in t:
    sys.exit('Torch: база не открылась — повтори позже или смени движок')
rows = re.findall(r'<a[^>]+href="(http[^"]+\.onion[^"]*)"[^>]*>(.*?)</a>', t, re.S | re.I)
seen, n = set(), 0
for url, label in rows:
    if url in seen:
        continue
    seen.add(url)
    title = html.unescape(re.sub(r'<[^>]+>', ' ', label)).strip()[:80]
    print(f'{n+1}. {title}\n   {url[:110]}')
    n += 1
    if n >= mx:
        break
print(f'\nвсего ссылок в выдаче: {len(seen)}')
PY
