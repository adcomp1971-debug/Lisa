#!/usr/bin/env python3
"""Сравнение кредита и самостоятельного гашения долга.

  python3 loan_compare.py annuity <сумма> <ставка_%> [сроки...]
  python3 loan_compare.py paydown <сумма> <ставка_%> <платёж_в_мес>

Примеры:
  python3 loan_compare.py annuity 8226.40 11.27 12 24 36 60 120
  python3 loan_compare.py paydown 8226.40 11.75 500

Печатает платёж и ПОЛНУЮ переплату по каждому сроку: месячный платёж без
полной суммы выплат вводит в заблуждение на длинных сроках.
"""
import sys


def annuity_payment(principal: float, annual_rate: float, months: int) -> float:
    r = annual_rate / 100.0 / 12.0
    if r == 0:
        return principal / months
    return principal * r / (1 - (1 + r) ** (-months))


def cmd_annuity(args):
    principal = float(args[0])
    rate = float(args[1])
    terms = [int(x) for x in args[2:]] or [12, 24, 36, 60, 120]
    print(f"Ссуда {principal:,.2f} под {rate}% годовых")
    for n in terms:
        pay = annuity_payment(principal, rate, n)
        total = pay * n
        over = total - principal
        print(
            f"  {n:>3} мес — платёж {pay:>8,.0f}/мес, всего {total:>10,.0f}, "
            f"переплата {over:>9,.0f} ({over / principal * 100:>5.1f}%)"
        )


def cmd_paydown(args):
    principal = float(args[0])
    rate = float(args[1])
    monthly = float(args[2])
    r = rate / 100.0 / 12.0
    bal, interest, months = principal, 0.0, 0
    while bal > 0 and months < 600:
        acc = bal * r
        if monthly <= acc:
            print(
                f"Платёж {monthly:,.0f} меньше процентов {acc:,.0f}/мес — долг не закрывается никогда"
            )
            return
        bal += acc
        interest += acc
        bal -= monthly
        months += 1
    if bal > 0:
        print("Долг не закрылся за 600 месяцев")
        return
    print(
        f"Гашение {monthly:,.0f}/мес под {rate}%: {months} мес, "
        f"процентов {interest:,.0f}, всего выплачено {principal + interest:,.0f}"
    )


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    mode = sys.argv[1]
    args = sys.argv[2:]
    if mode == "annuity":
        cmd_annuity(args)
    elif mode == "paydown":
        cmd_paydown(args)
    else:
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
