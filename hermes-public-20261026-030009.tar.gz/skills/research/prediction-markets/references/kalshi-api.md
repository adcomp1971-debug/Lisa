# Kalshi / Polymarket — verified API and rules notes

Values below were observed live from this server (non-US, non-RF IP). Re-probe before relying on them; endpoints drift.

## Kalshi public market data (no key, no registration)

Base: `https://api.elections.kalshi.com/trade-api/v2`

- `GET /exchange/status` → 200 `{"exchange_active":true,...}` — cheapest reachability probe.
- `GET /markets?limit=200&status=open` → 200, but the default feed is dominated by multileg combos (`KXMVECROSSCATEGORY-…`), which carry no bid/ask.
- `GET /markets?series_ticker=KXHIGHNY&status=open&limit=5` → single markets with real prices. Known-good series: `KXBTCD` (BTC daily), `KXHIGHNY` (NYC high temperature — highest volume observed, 31k+ contracts).
- `GET /series/<SERIES>/markets/<TICKER>/candlesticks?start_ts=<unix>&end_ts=<unix>&period_interval=60` → OHLC history in cents. Both timestamps required.

Price fields (current schema): `yes_bid_dollars`, `yes_ask_dollars`, `no_bid_dollars`, `no_ask_dollars`, `last_price_dollars`, `previous_price_dollars` — decimal strings in dollars (`"0.1100"` = 11c). Legacy `yes_bid` / `yes_ask` are returned as `null`; do not filter on them.
Volume/open interest: `volume_fp`, `volume_24h_fp`, `open_interest_fp`, `yes_ask_size_fp`.

## Fees

General event-contract taker fee (from the CFTC filing behind the public fee schedule):

```
fees = round_up(0.07 × C × P × (1 − P))
```

C = contracts, P = price in dollars. Effective cost: 3.85% of stake at 45c, 3.50% at 50c, 2.45% at 65c. Makers pay less or no fee on some series — verify per series before modelling.

## Who may trade (Kalshi Member Agreement, Section VI)

Restricted Jurisdictions (~56): Afghanistan, Algeria, Angola, Australia, Belarus, Belgium, Bolivia, Bulgaria, Burkina Faso, Cameroon, Canada, Central African Republic, Côte d'Ivoire, Cuba, DR Congo, Ethiopia, France, Haiti, Hungary, India, Iran, Iraq, Ireland, Italy, Kenya, Laos, Lebanon, Libya, Mali, Monaco, Mozambique, Myanmar, Namibia, New Zealand, Nicaragua, Niger, North Korea, PRC, Poland, Portugal, Russia, Singapore, Somalia, South Sudan, Sudan, Switzerland, Syria, Taiwan, Thailand, Ukraine, UAE, UK, Venezuela, Yemen, Zimbabwe, plus US-sanctioned territories.

**Israel is not on the list** — registration and event-contract trading are allowed. Restricted persons may still hold membership and trade non-event-contract products.

Signup: identity verification (government ID + selfie) and country of residence. No US phone required. International deposits: debit card (Visa/Mastercard), crypto, wire (min $1,000). ACH/PayPal/Venmo are US-only.

## Polymarket (crypto alternative)

`GET https://gamma-api.polymarket.com/markets?limit=2&closed=false` → 200 with market objects (question, slug, conditionId). No key needed for reads. Settlement is on-chain USDC; jurisdictional rules differ from Kalshi — check before recommending either.

## Calibration test (the cheap, decisive experiment)

Goal: decide whether priced markets are beatable before spending money.

1. Pick 10–20 series with real volume; pull 30–90 days of hourly candles for resolved markets.
2. Bucket every observation by price (0–10c, 10–20c, …, 90–100c).
3. For each bucket compute the realised resolution rate.
4. If realised rate ≈ bucket midpoint ± noise, the market is calibrated and no LLM signal without private information has an edge — stop here.
5. Only persistent, statistically significant gaps become tradeable strategies, and each must still clear the fee curve above.
