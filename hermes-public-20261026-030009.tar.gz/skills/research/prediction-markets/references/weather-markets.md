# Weather (temperature) markets: resolution rules and the NBM feed

Why this file exists: weather is the one prediction-market class where the resolution source is a fully public hourly feed, so it looks like the obvious place for a speed edge. It was tested and the edge is not there — but the plumbing is reusable for any market that resolves off an official weather observation, and for the next attempt (per-station calibration) if one is ever made.

## How the market resolves

- Series are per city and per metric: `KXHIGHNY`, `KXHIGHLAX`, `KXHIGHCHI`, `KXHIGHMIA`, `KXHIGHAUS` (daily high, °F); `KXRAIN`; `KXHIGH…` siblings for other months.
- Ticker: `KXHIGHNY-26OCT15-B64.5`. Tail encodes the strike: `B<lo>.<hi>` = between (settles 1 if the daily max is inside the **integer** range, i.e. 64.5 means 64–65), `T<v>` = greater than v, `T<v>` prefixed markets with `strike_type: less` come from `cap_strike`.
- Resolution source: the official NWS daily summary for that station, i.e. the **local-day** maximum in °F. Not UTC, not the calendar day in your timezone.
- Market fields that matter: `strike_type` (`between` / `greater` / `less`), `floor_strike`, `cap_strike`, `close_time`, `result`.

## The forecast feed: NOAA NBM on public S3

National Blend of Models is the NWS ensemble whose derivatives commercial vendors publish — i.e. the same information the market already prices. Public bucket, no key, no registration:

```
https://noaa-nbm-grib2-pds.s3.amazonaws.com/blend.YYYYMMDD/CC/core/blend.tCCz.core.fNNN.co.grib2
```

- Cycles `CC` = 00/06/12/18; steps `NNN` are 1–36 hourly, then 3-hourly. `/co` is the CONUS subset (needed — the full domain is enormous).
- **Never download the whole GRIB2.** Each file is hundreds of MB and there are dozens per day. Use the sibling `.idx`: it lists `msgNum:byteOffset:d=YYYYMMDDCC:ELEMENT:level:step`, then fetch only the `TMP:2 m above ground` message with an HTTP `Range` header.
- Parse the `.idx` by description fields, not by first token: the file starts with `APTMP:2 m above ground` (apparent temperature) — a `line.startswith('TMP')` filter finds nothing and silently returns `None` for every hour. Match `parts[3] + ':' + parts[4] == 'TMP:2 m above ground'`, and take the next message's offset as the range end.
- Decode with eccodes CLI, not Python GRIB libraries: `apt-get install -y --no-install-recommends libeccodes-tools` gives `grib_get`, `grib_ls`, `grib_get_data`. `grib_get_data -w shortName=2t file.grib2` prints `Latitude Longitude Value` for every grid point (~3.7M for CONUS) — pick the nearest point in Python by squared lat/lon distance. Longitude is **0–360**, so New York is `(40.724, 285.901)`, not `-73.97`.
- Values are Kelvin: `°F = (K − 273.15) × 9/5 + 32`.
- Cost: ~15–30 s per forecast hour (idx fetch + range fetch + decoding 3.7M points). A year of daily-max studies is not feasible in one pass — sample every 2nd hour, cache per `(series, day, fh)` in a JSON file, and run it in the background (`setsid nohup python3 -u script.py > log 2>&1 &` with `pty: true`, since plain background launches returned exit -1 on this host).
- `scripts/nbm_point.py` in this skill does exactly the above.

Archive of observations (for ground truth, not forecasts): `https://archive-api.open-meteo.com/v1/archive?latitude=&longitude=&start_date=&end_date=&hourly=temperature_2m&temperature_unit=fahrenheit&timezone=<tz>` — free, hourly, no key.

## Measured result (do not re-litigate without new data)

Test: 464 observations, 7 city-days, forecast run 00z of the event day, `μ` = max of the run over the day, `σ` = 3 °F, `P(strike)` from the normal distribution; price = Kalshi `yes_ask.close_dollars` at the matching hour.

- Brier market **0.0745**, Brier NBM **0.1676**, Brier of a constant **0.1663** → NBM was not even better than a base rate, let alone the price.
- NBM daily-max error: mean 3.19 °F, median 3.21 °F, worst 6.6 °F.
- Betting the divergence between model and price gave ROI −14% / +8.8% / +29% / −107% at thresholds +0.05 / +0.10 / +0.15 / +0.20 — the sign flipping across adjacent thresholds is the signature of noise, not signal.

Conclusion to give Alex: the price already contains the official forecast plus market-maker adjustment; a public hourly feed is not an edge. The only untested angle is per-station bias calibration (airport microclimate that a 2.5 km blend grid does not resolve), and it needs months of observations before it is worth a line of code.
