---
name: prediction-markets
description: "Use when judging a Kalshi/Polymarket trading bot idea."
category: research
version: 1.1.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [trading, kalshi, polymarket, statistics, risk]
    related_skills: [purchase-research, tech-advisory-triage]
---

# Prediction markets (event contracts): evaluating a trading idea

## When to Use

- Alex forwards a video/demo of a bot or LLM trading binary event contracts on Kalshi, Polymarket, or a similar venue.
- He asks «нам это надо?» / «стоит ли» about prediction-market trading or a trading-bot project.
- He asks to build, extend, or backtest such a bot.
- He asks whether he can even register on one of these platforms from Israel.

The job is NOT to admire the demo — check four things in order and give a verdict with numbers.

## Order of checks (never skip ahead to the money question)

1. **Can the account even exist?** Read the platform's Member Agreement restricted-jurisdiction list, not blog posts — blogs contradict each other. Kalshi: Section VI of `https://kalshi.com/docs/kalshi-member-agreement.pdf`. Alex lives in Israel → allowed (not on the list). KYC = government ID + selfie; deposits for non-US: debit card (Visa/MC), crypto, wire from $1000; ACH/PayPal/Venmo unavailable.
2. **Is the API reachable from our server?** Probe public market data before discussing registration. Kalshi works from our Lithuanian IP (see `references/kalshi-api.md` for endpoints and the field-format trap).
3. **What does a trade cost?** Kalshi taker fee = `ceil(0.07 × C × P × (1−P))`, i.e. ≈3.5% of stake at 50c and ≈2.5% at 65c. Fees alone kill a thin edge; a demo reporting gross profit hides this.
4. **Is the reported result statistically real?** Run `scripts/edge_significance.py` instead of eyeballing percentages.
5. **If calibration holds, test the one edge that survives:** price lag on a public feed. Recipe and measured result in the next section; the feed plumbing lives in `references/weather-markets.md`.

## The decisive arithmetic (always show it)

- **EV = p − P − fee**, where `p` is the model's own probability and `P` the contract price. A model that answers «up or down» without comparing to the price has no edge by construction: at 50c it needs >51.75% hit rate just to break even, at 70c it needs >70%.
- **Beating 50% is not an edge.** A 15/23 = 65% run has one-sided p ≈ 0.105; ~92 trades are needed to separate 65% from 50% at 80% power. Say this out loud instead of repeating the demo's «faster win».
- **Drawdown in percent of bankroll, not dollars.** −$567 on $1000 is a 57% drawdown; a human stops there, so «recovered later» is not a strategy.
- **Report decisions, not contracts.** 300 contracts per session is one decision; the effective sample is 23 or 82.

## When the market is calibrated: the only remaining edge

Once calibration holds, «know better than the market» is dead and exactly one mechanism is left — **being faster than the market on genuinely public data**, i.e. the price lagging a public update. Test it, never assume it:

1. Pick a class whose resolution source is a public machine-readable feed (weather: official NWS observation; macro: BLS/Fed print; crypto: exchange index).
2. Pair every historical price snapshot with the value the feed had **at that same timestamp**. A forecast without a time-aligned price, or a price without the forecast of that hour, is not a test.
3. Score model and market on the SAME observations, same metric (Brier or log-loss), and compare the model against **the market's score**, not against the base rate. The price is the opponent; a constant is not.
4. Interpret: model ≈ market → no edge; model worse → the price already contains that feed plus market-maker adjustment; only a stable gap that clears the fee curve is tradeable.
5. Before believing any gap, check whether its sign flips across decision thresholds. ROI of +29% at one threshold and −107% at the next one on the same data is noise, not a signal.

Weather markets are the canonical case and they are **closed**: on 464 paired observations the price beat the official NBM ensemble (market Brier 0.075 vs NBM 0.168, NBM's daily-max error 3.2 °F). State that verdict and move on — do not re-test city by city, and do not offer a weather bot again without new data.

## Verdict shape Alex expects

Short, plain text, no tables, no hype: what in the demo is honest, what is noise, what is broken in the method, what is actually reachable from our infrastructure, then a direct «надо / не надо» with the cheapest first step.

- Never recommend funding an account on the strength of a demo run.
- Cheapest first step always: pull public price history (free, no registration) and test **calibration** — when the market prices an outcome at 30%, does it resolve at 30%? If the market is calibrated, an LLM without private information has no edge and the question is closed at zero cost.
- Only after a measured, systematic mispricing exists does building a bot and putting money in make sense.

## Pitfalls

- Blog roundups disagree about country eligibility (some say US-only, others 140+ countries). Trust the Member Agreement PDF; extract it and search for the country name in lower case.
- Kalshi API field names changed: `yes_bid`/`yes_ask` return `null`, prices live in `yes_bid_dollars`/`yes_ask_dollars`/`last_price_dollars`. A naive `if m['yes_ask']` filter yields 0 priced markets out of 200.
- Default `/markets` returns multileg combos (`KXMVECROSSCATEGORY…`) with no book. Pass `series_ticker=` (e.g. `KXBTCD`, `KXHIGHNY`) to get single markets with prices and volume.
- `candlesticks` needs both `start_ts` and `end_ts`; omitting `end_ts` returns 400 with a misleading `series_ticker` complaint.
- `kalshi.com` HTML returns 429 to plain curl — probe the API, not the marketing site.
- Do not open the money question with «а давай попробуем $1000» — Alex's own rule is plan first, and a trading loss is unrecoverable while a calibration test is free.
- **Never quote a model's Brier next to the base-rate Brier and call the difference an edge.** Only the market's own Brier on the same observations is a benchmark; being better than «always say 20%» says nothing about beating a 20c price.
- **Convert to the market's LOCAL timezone before computing anything time-dependent.** Temperature strikes settle on a local-day max in °F; folding UTC hours into a «remaining heating» curve shifts the whole projection and manufactures spectacular fake mispricing (dozens of «obvious» bets at −107% ROI). Same trap for any market that resolves on a local business day.
- Weather-market series die and are replaced (hourly crypto strikes like `KXBTCD`/`KXETHD` carry volume 0 and one candle — unusable for calibration). Filter `volume_fp > 0` and a sane spread first, then report how many snapshots the filter threw away; un-traded strikes sit at 95c and resolve «no», which alone fabricates a favourite-longshot bias.
- Sample sizes by *decisions*, and be explicit about multiple comparisons: 50 bucket tests guarantee a few «significant» bins. The favourite-longshot bin (10–20c) is the one that keeps reappearing — it needs ≥1000 observations and a real correction before it is a strategy.

Support files: `references/kalshi-api.md` (endpoints, fields, fees, jurisdictions), `references/weather-markets.md` (weather resolution rules, NBM feed plumbing, measured market-vs-forecast result), `scripts/edge_significance.py` (p-value, Wilson CI, required n, EV with fees), `scripts/nbm_point.py` (point temperature °F out of an NBM GRIB2 file over public S3).
