#!/usr/bin/env python3
"""Point temperature (degF) out of NOAA NBM GRIB2 files — public S3, no key.

Setup:  apt-get install -y --no-install-recommends libeccodes-tools
        (gives grib_get_data; python GRIB libraries are not needed)

Usage:
  ./nbm_point.py 2026-10-15 --lat 40.724 --lon -73.97
  ./nbm_point.py 2026-10-15 --lat 40.724 --lon -73.97 --step 2 --cache nbm.json

Prints '<forecast_hour> <degF>' per line. Longitude is accepted in -180..180
and normalised to the 0..360 grid. Each forecast hour costs one .idx fetch,
one byte-range fetch and a decode of ~3.7M grid points (~15-30 s), so use
--step 2 for bulk work and always pass --cache when iterating over days.
"""
import argparse
import json
import os
import re
import subprocess
import urllib.request

BUCKET = "https://noaa-nbm-grib2-pds.s3.amazonaws.com"
UA = {"User-Agent": "hermes-nbm/1.0"}


def s3_list(prefix, n=300):
    url = f"{BUCKET}/?list-type=2&max-keys={n}&prefix={prefix}"
    try:
        x = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30).read().decode()
        return re.findall(r"<Key>([^<]+)</Key>", x)
    except Exception:
        return []


def tmp2m_range(key):
    """Byte range of the 'TMP:2 m above ground' message, from the sibling .idx.

    The .idx description is fields 4+5 (element + level), and the file's first
    entry is APTMP (apparent temperature): matching on the first token finds
    nothing and every hour silently returns None.
    """
    try:
        lines = urllib.request.urlopen(
            urllib.request.Request(f"{BUCKET}/{key}.idx", headers=UA), timeout=30
        ).read().decode().splitlines()
    except Exception:
        return None
    entries = []
    for ln in lines:
        p = ln.split(":")
        if len(p) >= 5:
            try:
                entries.append((int(p[1]), p[3] + ":" + p[4]))
            except ValueError:
                continue
    for i, (off, desc) in enumerate(entries):
        if desc == "TMP:2 m above ground":
            return off, (entries[i + 1][0] - 1 if i + 1 < len(entries) else None)
    return None


def point_temp(key, lat, lon, tmp="/tmp/nbm_one.grib2"):
    r = tmp2m_range(key)
    if not r:
        return None
    start, end = r
    hdr = dict(UA)
    hdr["Range"] = f"bytes={start}-{end}" if end else f"bytes={start}-"
    try:
        blob = urllib.request.urlopen(urllib.request.Request(f"{BUCKET}/{key}", headers=hdr),
                                     timeout=120).read()
    except Exception:
        return None
    open(tmp, "wb").write(blob)
    try:
        out = subprocess.run(["grib_get_data", "-w", "shortName=2t", tmp],
                             capture_output=True, text=True, timeout=180).stdout
    except Exception:
        return None
    best, bestd = None, 9e18
    for ln in out.splitlines()[1:]:
        p = ln.split()
        if len(p) < 3:
            continue
        try:
            la, lo, v = float(p[0]), float(p[1]), float(p[2])
        except ValueError:
            continue
        d = (la - lat) ** 2 + (lo - lon) ** 2
        if d < bestd:
            bestd, best = d, v
    if best is None:
        return None
    return round((best - 273.15) * 9 / 5 + 32, 2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("date", help="event day, YYYY-MM-DD")
    ap.add_argument("--lat", type=float, required=True)
    ap.add_argument("--lon", type=float, required=True)
    ap.add_argument("--cycle", default="00", choices=["00", "06", "12", "18"])
    ap.add_argument("--step", type=int, default=2, help="take every N-th hour (1 = all)")
    ap.add_argument("--max-hour", type=int, default=36)
    ap.add_argument("--cache", default=None, help="JSON cache keyed by day|cycle|fh")
    a = ap.parse_args()

    lon = a.lon % 360
    ymd = a.date.replace("-", "")
    cache = {}
    if a.cache and os.path.exists(a.cache):
        cache = json.load(open(a.cache))

    keys = [k for k in s3_list(f"blend.{ymd}/{a.cycle}/core/", 400)
            if re.search(r"\.f(\d{2,3})\.co\.grib2$", k)]
    keys.sort(key=lambda k: int(re.search(r"\.f(\d{2,3})\.co", k).group(1)))
    if not keys:
        raise SystemExit(f"no NBM CONUS files under blend.{ymd}/{a.cycle}/core/ "
                         f"(not published yet, or wrong cycle)")

    for k in keys:
        fh = int(re.search(r"\.f(\d{2,3})\.co", k).group(1))
        if fh > a.max_hour or fh % a.step:
            continue
        ck = f"{a.date}|{a.cycle}|{fh}"
        if ck in cache:
            print(f"{fh} {cache[ck]}", flush=True)
            continue
        v = point_temp(k, a.lat, lon)
        if v is not None:
            cache[ck] = v
            print(f"{fh} {v}", flush=True)
        if a.cache:
            json.dump(cache, open(a.cache, "w"))


if __name__ == "__main__":
    main()
