#!/usr/bin/env python3
"""Check whether a reported win rate is real, and what a trade actually costs.

Usage:
    python3 edge_significance.py --wins 15 --trades 23
    python3 edge_significance.py --wins 47 --trades 82 --price 0.50 --contracts 300

Prints: win rate, one-sided binomial p-value against 50%, Wilson 95% CI,
trades needed to prove the observed edge, Kalshi fee and break-even hit rate.
"""
from __future__ import annotations

import argparse
import math


def binom_sf(k: int, n: int, p: float = 0.5) -> float:
    """P(X >= k) for X ~ Binomial(n, p)."""
    return sum(math.comb(n, i) * p**i * (1 - p) ** (n - i) for i in range(k, n + 1))


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (0.0, 1.0)
    w = k / n
    denom = 1 + z * z / n
    center = (w + z * z / (2 * n)) / denom
    half = z * math.sqrt(w * (1 - w) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, center - half), min(1.0, center + half))


def required_n(edge: float) -> int:
    """Trades needed to distinguish p=0.5+edge from 0.5 (alpha 5%, power 80%)."""
    return math.ceil(((1.96 * 0.5 + 0.84 * 0.5) / edge) ** 2)


def kalshi_fee(contracts: float, price: float) -> float:
    """round_up(0.07 * C * P * (1-P)) — general event-contract taker fee."""
    raw = 0.07 * contracts * price * (1 - price)
    return math.ceil(raw * 100) / 100


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--wins", type=int, required=True)
    ap.add_argument("--trades", type=int, required=True)
    ap.add_argument("--price", type=float, default=None, help="contract price in dollars, e.g. 0.50")
    ap.add_argument("--contracts", type=float, default=100.0, help="contracts per trade (default 100)")
    a = ap.parse_args()

    n, k = a.trades, a.wins
    if n <= 0 or k < 0 or k > n:
        raise SystemExit("need 0 <= wins <= trades")

    wr = k / n
    p = binom_sf(k, n)
    lo, hi = wilson(k, n)
    print(f"win rate        : {k}/{n} = {wr*100:.1f}%")
    verdict = "significant at 5%" if p < 0.05 else "NOT significant - consistent with luck"
    print(f"p vs 50%        : {p:.3f}  ({verdict})")
    print(f"95% CI (Wilson) : [{lo*100:.1f}%, {hi*100:.1f}%]")

    edge = abs(wr - 0.5)
    if edge > 0:
        print(f"trades to prove : ~{required_n(edge)}")

    if a.price is not None:
        P = a.price
        stake = a.contracts * P
        fee = kalshi_fee(a.contracts, P)
        print(f"\nKalshi fee on {a.contracts:g} contracts @ {P*100:.0f}c: ${fee:.2f}"
              f" = {fee/stake*100:.2f}% of ${stake:.2f} stake")
        breakeven = P + fee / a.contracts
        print(f"break-even hit rate on YES @ {P*100:.0f}c: {breakeven*100:.2f}%")


if __name__ == "__main__":
    main()
