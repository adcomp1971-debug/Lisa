---
name: research-workflow
description: "Academic and web research: arXiv discovery, news aggregation, deep multi-source research via Brave/Firecrawl/Tavily."
category: research
version: 1.3.0
author: Hermes Agent
---

# Research Workflow Umbrella

Structured information gathering from academic and web sources.

## 1. Academic Research (`arxiv`)
Search arXiv papers by keyword, author, category, or ID.
- Use for: literature reviews, finding baseline models, checking state-of-the-art on specific algorithms.
- Output format: Title, Authors, Abstract, Link, and a 2-sentence "Why it matters" summary.

## 2. News & Current Events (`news`)
| Tool | Best for | Notes |
|------|----------|-------|
| SerpAPI (`mcp_serpapi_search`) | Google News, current events | Direct Google results. engine: "google_news" |
| Brave News (`mcp_brave_search_brave_news_search`) | News articles, breaking news | Freshness filter available |
| Tavily (`mcp_tavily_tavily_search`) | AI-researched summaries, multi-source synthesis | Живёт с 28.09 (свой скрипт + mcp SDK 2.0) |

**SerpAPI отключён** (keepalive падал) — для новостей рабочий путь: Brave Web/News Search (`freshness: pd`), затем Firecrawl по топ-истории.

### Workflow
```
mcp_serpapi_search(params={
  "q": "<query>",
  "engine": "google_news",
  "gl": "us",
  "hl": "en",
  "num": 5
})
```

### Digest format (when delivering to user)
```
**🇺🇸 [Country/topic heading]**
1. **[Source Name]** — «Headline»
   Date | Author
   [snippet if needed]

**🇺🇦 [Next topic]**
...
```

Extract from SerpAPI/Brave response: `title`, `source.name`, `date`, `authors`, `link`, `snippet`. Each news result maps to one digest item. Always show source — it's the user's primary signal for credibility.

### Pitfalls
- **News source order: Brave Web Search → Exa.** Brave Web Search (with `freshness: pd`, `count: 15`) gives real headlines. Brave News Search gives low-quality/affiliated sources. **Exa CAN work for news** if the query targets current events — it found detailed real reporting (France24, Al Jazeera, Gulf News, WION) on the Iran deal. Use Exa for depth on the top story after Brave gives the overview.
- **No fake news.** If the day is quiet, say so. Never fabricate details.
- **Large responses.** SerpAPI Google News responses can be 100-200KB. Parse in Python to extract title/source/date/snippet — don't dump raw JSON.
- **API key redaction.** When writing scripts that reference API keys inline, the `***` auto-redaction in Hermes tool output corrupts string literals. Always build auth headers via variable concatenation before passing to subprocess, and read keys from `.env` in Python rather than inlining in shell commands.

## 3. Deep Web Research

Multi-source information gathering. For quick routing decisions by query type, **load `super-search`** — it has the full decision table (10 query types → optimal MCP).

### Search MCP servers — фактическое состояние (сверено 04.10.2026; источник истины — `hermes mcp list`)

| MCP | Статус | Best for |
|-----|--------|----------|
| **brave-search** | подключён | News, images, local places, freshness filters, general queries |
| **firecrawl** | подключён | Full page scrape, structured extraction (JSON schema), crawl/map sites, JS-rendered content |
| **playwright** (Browser) | подключён | Interactive pages, JS-heavy SPAs, multi-step workflows |
| **tavily** | подключён (свой скрипт, mcp SDK 2.0) | Deep multi-source research, extract с raw content |
| github, sqlite-vpnbot, source-library, progress-harness, agentmail | подключены (не поисковые) | — |
| **exa** | MCP отсутствует (`EXA_API_KEY` в .env неиспользован) | Semantic search, company research |
| **serpapi** | отключён (keepalive падал) | — |

Не полагаться на старые таблицы и память: состояние MCP гниёт быстро, проверять `hermes mcp list`.

### Workflow priorities
1. **Quick answer / news** → `mcp_brave_search_brave_web_search` / `mcp_brave_search_brave_news_search`
2. **Find sources with content** → `mcp_firecrawl_firecrawl_search`
3. **Deep dive** → `mcp_tavily_tavily_research` for multi-source synthesis
4. **Specific page scrape** → `mcp_firecrawl_firecrawl_scrape` (best single-page scraper)
5. **Structured data** → `mcp_firecrawl_firecrawl_extract` with JSON schema
6. **Semantic / company search** → `mcp_exa_web_search_exa`
7. **Interactive** → Browser tools for JavaScript-heavy pages

### Pitfalls
- **Browser is slow.** Reserve for pages that block other extractors.
- **Tavily research is rate-limited.** 20 req/min. Use sparingly.
- **arXiv PDFs** — use `web_extract` with the PDF URL directly (converts to markdown).
- **Firecrawl crawl** is CPU-intensive — limit `maxDiscoveryDepth` and `limit` to avoid timeouts.
- **Exa hosted URL** needs SSE transport (handled automatically by gateway). API key in query param.

## 4. OSINT War / Conflict Coverage

When the user asks for СВО/Ukraine war news "без пропаганды как осинтер":
- Cross-reference ISW + DeepStateMap + ACLED + Reuters
- Present territory data from both sources with noted discrepancies
- Track manpower, deep strikes, tech changes, international context
- Full workflow and format: `references/osint-war-coverage.md`
