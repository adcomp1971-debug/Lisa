# OSINT War Coverage (СВО/Ukraine)

## When to use

User asks for war/conflict news "без пропаганды", "как осинтер" — OSINT-style, cross-referenced, no spin.

## Sources (by reliability)

### Primary OSINT
| Source | What | URL |
|--------|------|-----|
| **ISW** (Institute for Study of War) | Daily Russian Offensive Campaign Assessments — most detailed tactical analysis | `understandingwar.org/research/...` |
| **DeepStateMap** | Crowdsourced frontline control map | `deepstatemap.live` |
| **Russia Matters** (Harvard) | Russia-Ukraine War Report Card — weekly territory math, cross-references ISW + DeepState | `russiamatters.org` |
| **ACLED** | Event-based conflict monitor with infrastructure tagging | `acleddata.com/monitor/ukraine-conflict-monitor` |

### Mainstream (verified)
| Source | Strength |
|--------|----------|
| **Reuters** | Wire service, straight facts, no commentary |
| **BBC** | Good on-the-ground reporting |
| **The Guardian** | Detailed war briefings daily |
| **AP News** | Wire service |

### Ukrainian (disclosure: pro-Ukraine bias)
| Source | Strength |
|--------|----------|
| **Kyiv Independent** | Independent English-language, boots on ground |
| **Ukrinform** | State news agency — use for official claims |
| **Kyiv Post** | Independent |

## Workflow

### 1. Broad sweep (Brave Web Search)
```python
mcp_brave_search_brave_web_search(
    query="<topic>",
    freshness="pd",    # past 24h
    count=15
)
```

Key queries to search (each covers different angles):
- `"Ukraine war frontline updates"` — general daily
- `"ISW Ukraine war assessment"` — ISW's latest
- `"DeepStateMap Ukraine frontline"` — territory changes
- `"Russia oil refinery strike Ukraine"` — deep strikes

### 2. Depth on top story
Use `web_search` (Exa) or `web_extract` on the ISW or Reuters article for the main story.

### 3. Format

```markdown
## 📰 СВО: дайджест OSINT — DD месяца

*Источники: ISW, DeepStateMap, Russia Matters, ACLED, Reuters, BBC*

---

### 1. 📍 Фронт: [главное направление]

[3-5 предложений: какое направление, статус, оценка ISW]
[➡ ссылка на ISW assessment]

**Другие направления:**
- [Направление 1] — [статус]
- [Направление 2] — [статус]

### 2. 💀 Потери и мобилизация

| | Данные |
|---|---|
| **Потери РФ (Укрінформ)** | ~XXX,XXX с 24.02.2022 (+XXX за сутки) |
| **Рекрутинг РФ vs потери** | [данные от Сирского/ISW] |

### 3. 🔥 [Сторона] удары вглубь

- [Цель 1] — [детали]
- [Цель 2] — [детали]

[Ответная реакция: цитаты сторон]

### 4. 📊 Территория: расхождение данных

**DeepState:** [net gain/loss]
**ISW:** [net gain/loss]
*Примечание: почему расходятся (разные методики подсчёта)*

### 5. 🤖 Технологии войны

[Новое оружие, AI, дроны, РЭБ]

### 6. 🌍 Международный фон

[G7, ЕС, дипломатия, экономика]
```

### Style rules
- **No propaganda.** Present both sides' claims. Label sources with disclosure when they have inherent bias.
- **Mention when data conflicts.** ISW vs DeepState territory numbers often differ — note it and explain why.
- **Quote officials directly** when relevant, but separate their claims from OSINT-confirmed facts.
- **Civilian casualties** — only from UN/verified sources (OHCHR, HRMMU). Note when UN figures represent records (e.g. May 2026: 274 killed, 1,763 injured — highest since April 2022).
- **No emotional framing.** Numbers, not adjectives.
- **Report spillover events** — drifting USVs/drones into NATO countries (Romania, Greece) are notable OSINT signals even if small.

## Pitfalls

- **ISW assessments can lag by 1-2 days** — they publish daily but the latest might be from yesterday
- **DeepState is conservative** — only maps what's geolocation-confirmed, so always lags real frontline
- **Russian MOD claims** are routinely fabricated for cognitive warfare (ISW explicitly calls this out)
- **Ukrainian MOD claims** can also be inflated for morale — always cross-reference with OSINT
- **Loss numbers** (personnel) are estimates. Ukrinform gives Russian losses, Ukraine doesn't publish own regularly. Zelensky gave ~55,000 Ukrainian KIA in Feb 2026.
- **Civilian casualty UN reports** cover calendar months, not real-time — May 2026 data came mid-June
