# Interactive Email Workflow (Vasily / Personal Agent)

## When this applies

When the user (Alex) asks Vasily to:
- Check email and give a summary
- Reply to a specific email
- Handle ongoing correspondence (read, reply, wait for response, repeat)

## Key constraint: approve-before-send

Alex must review and approve EVERY outgoing email. Never send blindly.

## Workflow steps

### 1. Check email — on demand or morning 08:00

```
himalaya envelope list --page-size 20
```

Parse output: flag emails by category:
- 💳 Bills/subscriptions (DeeVid, OpenAI, AWS, Google, Stripe receipts)
- ⚠️ Security (password resets, new device logins, linked accounts)
- 💼 Job/employer (Upwork, Habr, responses)
- 📦 Packages (AliExpress, eBay, tracking updates)
- 📰 Newsletters/marketing (Tripadvisor, Zapier promos — mention but brief)

Group by category in the summary. Always note:
- Sender name
- Subject
- Key detail (amount, action required, sender)
- Whether action is needed

### 2. Read a specific email for reply

```
himalaya message read <ID>
```

Read the FULL thread. Understand context before drafting.

### 3. Draft a reply

```bash
cat << 'EOF' | himalaya template send
From: adcomp1971@gmail.com
To: recipient@example.com
Subject: Re: <original subject>

<draft body here>
EOF
```

Then use `text_to_speech` to read the draft aloud so Alex can confirm the tone.

### 4. Send after approval

Alex says "да" or "отправляй" → run the `himalaya template send` command.
Alex says "перепиши" → revise and re-present.

### 5. Ongoing correspondence

When Alex says "вступи в переписку по письму N":
1. Read the full thread: `himalaya message read <ID>`
2. Draft a reply
3. Present for approval
4. Send after approval
5. Wait for next message in thread → read → draft → present → send → repeat

At each step, present the EXISTING thread context + the proposed reply. Don't make Alex re-read emails he already saw.

## Pitfalls

- **Reply to Gmail:** use `himalaya template reply <ID>` then pipe to `himalaya template send`
- **Folder alias for Sent:** Russian Gmail uses `[Gmail]/Отправленные`, not `Sent Mail`
- **Himalaya v1.2.0 bug:** `folder.aliases` (plural, dotted) not `folder.alias` (singular, section). Wrong format causes SMTP success + crash on save-to-Sent = no error to user but reply disappears
- **Duplicate sends:** if send command crashes after SMTP (Sent folder alias issue), the email was DELIVERED. Do NOT retry — Alex gets duplicate. Fix the folder alias first.
- **Tone verification:** ALWAYS read draft aloud before showing. Alex doesn't want HTML preview — wants to hear how it sounds.
- **Language:** Alex writes in Russian. Replies must match the language of the original email.
- **Do NOT summarize known-safe senders (NVIDIA password reset, Anthropic Claude deactivation) as alerts** unless the user specifically asks. These were confirmed as Alex's own actions on 14 Jun 2026.
