---
name: vision-analyzer
description: "Vision: deepseek-flash (auxiliary.vision), fallback Gemini 3.6 Flash."
version: 2.1.0
---

# Vision Analyzer

## Триггер (критически важно — не пропускать)

**При получении изображения от пользователя — НЕМЕДЛЕННО запустить vision-analyze.py.**

Сигналы: пользователь прислал фото/скриншот, сказал «посмотри», «взгляни», «глянь», «что это», переслал картинку. Не ждать.

## Порядок действий

1. Найти файл изображения: `/root/.hermes/cache/images/img_*.jpg`
2. Выполнить: `python3 /root/.hermes/scripts/vision-analyze.py /путь/к/изображению.jpg`
3. Использовать результат — не цитировать голосовое сообщение пользователя в ответе

## Рабочая модель: DeepSeek Flash (reasoning + vision)

- Модель: `deepseek-flash` — именно она в `auxiliary.vision.model` (config.yaml). Проверено живьём 2026-09-13: скрипт отдал непустой разбор изображения.
- `deepseek-v4-flash-vision-exp` — устарела с 2026-09-11, из конфига убрана. `deepseek-v4-flash` / `v4-pro` картинки не принимают вообще.
- Ключ: `DEEPSEEK_API_KEY`
- `max_tokens` ≥ 1500 — иначе thinking съедает ответ
- Скрипт: `python3 /root/.hermes/scripts/vision-analyze.py /путь.jpg`
- `auxiliary.vision` в config.yaml: provider deepseek, model deepseek-flash
- Gateway подхватит после рестарта (делает Алекс)

## Fallback: Gemini 3.6 Flash

Скрипт сам падает на Gemini, если DS пустой/ошибка.

## Не пытаться

- **deepseek-v4-flash / v4-pro** — «This model does not support image»
- LongCat, GLM — текста, картинок не видят

## Проверка перед использованием

```bash
python3 /root/.hermes/scripts/vision-analyze.py /путь/к/картинке.jpg
```

Если ошибка — проверить `GEMINI_API_KEY` в `.env` и `auxiliary.vision` в `config.yaml`.

## Технические детали

- **Эндпоинт:** `https://generativelanguage.googleapis.com/v1beta/openai/chat/completions`
- **Формат:** OpenAI-совместимый (`image_url` с base64)
- **Модель:** `gemini-3.6-flash` для fallback-вызовов (берём стабильную 3.6; 3.8-flash нестабильна 2/5)
- **Ключ:** `GEMINI_API_KEY` из `.env`
