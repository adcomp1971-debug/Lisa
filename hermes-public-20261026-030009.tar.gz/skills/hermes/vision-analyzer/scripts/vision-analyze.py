#!/usr/bin/env python3
"""Analyze image using Grok 4.3 via xAI API"""
import base64, json, urllib.request, sys

path = sys.argv[1]
with open(path, 'rb') as f:
    b64 = base64.b64encode(f.read()).decode()

key = ''
with open('/root/.hermes/.env') as f:
    for line in f:
        line = line.strip()
        if line.startswith('XAI_API_KEY=') or line.startswith('xai_api_key='):
            key = line.split('=', 1)[1]
            break
if not key:
    print('ERROR: no xAI API key in .env (XAI_API_KEY or xai_api_key).')
    print('SuperGrok OAuth requires native vision_analyze tool, not this script.')
    print('Set XAI_API_KEY in .env for curl fallback, or fix OAuth config.')
    sys.exit(1)

data = {
    'model': 'grok-4.3',
    'messages': [{
        'role': 'user',
        'content': [
            {'type': 'image_url', 'image_url': {'url': f'data:image/jpeg;base64,{b64}'}},
            {'type': 'text', 'text': 'What is in this image? Describe briefly.'}
        ]
    }],
    'max_tokens': 200
}

req = urllib.request.Request(
    'https://api.x.ai/v1/chat/completions',
    data=json.dumps(data).encode(),
    headers={
        'Authorization': f'Bearer {key}',
        'Content-Type': 'application/json'
    }
)
resp = urllib.request.urlopen(req, timeout=30)
d = json.loads(resp.read())
msg = d['choices'][0]['message']
print(msg.get('content', msg.get('reasoning_content', 'NO_TEXT')))
