---
name: autonomous-coding
description: "Autonomous AI coding workflows: delegation to Codex CLI/Claude Code, relay architecture, config, wrapper scripts, Claude Code via Anthropic relay, Buratino workers, and cost model."
category: software-development
version: 2.1.0
author: Hermes Agent
related_skills: [ai-coding-tools]
---

# Autonomous Coding Umbrella

Делегирование задач кодинга специализированным CLI-агентам (Codex CLI, Claude Code), управление релейной инфраструктурой, воркерами и конфигурацией.

## 1. Execution Rules

- **Pause & Report:** Всегда остановиться и сообщить статус перед деструктивными изменениями.
- **Read-First:** Начать с read-only анализа перед модификацией.
- **Verification:** Не останавливаться после написания стаба — код должен быть реально выполнен и проверен.

## 2. Relay Architecture

4 релея (Rust, Axum) в `/root/codex-relay-rust/` — один бинарник, параметризуется env: `CODEX_RELAY_PORT`, `CODEX_RELAY_UPSTREAM`, `CODEX_RELAY_API_KEY`.

| Порт | Сервис | Модель | API | WS | Назначение |
|------|--------|--------|-----|----|------------|
| `:4446` | `codex-relay.service` | deepseek-v4-pro | Responses | ✅ 101 | Запасной кодинг |
| `:4447` | `codex-relay-longcat.service` | LongCat-2.0 | Responses | ✅ 101 | **Основной** |
| `:4448` | `codex-relay-kimi.service` | kimi-k3 (Moonshot) | Responses | ✅ 101 | **Сложные задачи (замена GLM 5.2)** |
| `:4450` | `codex-relay-anthropic.service` | LongCat-2.0 | Anthropic | — | Для Claude Code |
| `:4453` | `codex-relay-anthropic-kimi.service` | kimi-k3 (Moonshot) | Anthropic | — | **Claude Code — сложные (замена GLM)** |

### Production запуск: Python wrapper + systemd

**Python wrapper** (`run-relay-*.py`) — читает ключ из `.env`, поднимает relay на заданном порту:
```python
#!/usr/bin/env python3
import os, subprocess
with open('/root/.hermes/.env') as f:
    for line in f:
        line = line.strip()
        if line.startswith('DEEPSEEK_API_KEY='):
            key = line.split('=', 1)[1].strip(); break
env = os.environ.copy()
env['CODEX_RELAY_PORT'] = '4446'
env['CODEX_RELAY_UPSTREAM'] = 'https://api.deepseek.com/v1'
env['CODEX_RELAY_API_KEY'] = key
proc = subprocess.Popen(['/root/codex-relay-rust/target/release/codex-relay'], env=env)
proc.wait()
```

**Systemd** (`/etc/systemd/system/codex-relay.service`):
```ini
[Unit]
Description=Codex-Relay proxy
After=network.target
[Service]
Type=simple
User=root
WorkingDirectory=/root/codex-relay-rust
ExecStart=/root/codex-relay-rust/run-relay.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload && systemctl enable --now codex-relay.service
curl -s http://127.0.0.1:4446/v1/models  # → 200
```

### WebSocket в Axum — метод-чейнинг (КРИТИЧЕСКИЙ ПИТФОЛЛ)

```rust
// ❌ POST перезаписывается GET → WS возвращает 405
.route("/v1/responses", post(handle_responses))
.route("/v1/responses", get(handle_ws_upgrade))

// ✅ Метод-чейнинг — работает
.route("/v1/responses", get(handle_ws_upgrade).post(handle_responses))

// ✅ Также для пути без /v1/ (Codex ≥0.139.0 бьёт /responses)
.route("/responses", get(handle_ws_upgrade).post(handle_responses))
```

**WS handler архитектура:** `src/ws.rs` — при WS upgrade создаёт две таски: forward (out_tx → ws_tx) и recv (ws_rx → proxy_ws_request). Каждое WS сообщение — JSON ResponsesRequest → проксируется как HTTP stream к upstream → SSE парсится и шлётся обратно как WS JSON события.

**Проверка:** `curl -H "Upgrade: websocket" -H "Connection: Upgrade" -w "%{http_code}" localhost:4447/v1/responses` → должно быть 101.

## 3. Wrapper Scripts (воркеры)

Установлены в `/usr/local/bin/`:

| Команда | Инструмент | Модель | Режим | Для чего |
|---------|-----------|--------|-------|----------|
| `codex` | Codex CLI | LongCat-2.0 | exec sandbox | Базовый кодинг (wrapper) |
| `codex-kimi` | Codex CLI | kimi-k3 | exec | **Сложный кодинг, архитектура** |
| `codex-lc` | Codex CLI | LongCat-2.0 | exec | Быстрые задачи, тесты |
| `codex-ds` | Codex CLI | DeepSeek V4 Pro | exec | Запасной кодинг |
| `claude-lc` | Claude Code | LongCat-2.0 | --print | Через stunnel :4451 |
| `claude-kimi` | Claude Code | kimi-k3 | --print | **Самое мощное** (stunnel :4452) |
| `buratino-codex` | Codex CLI | GLM 5.2 | workspace-write | Файлы Buratino |
| `buratino-codex-lc` | Codex CLI | LongCat-2.0 | workspace-write | Скрипты Buratino |
| `buratino-claude` | Claude Code | LongCat-2.0 | --print | Универсальный Buratino |
| `buratino-claude-glm` | Claude Code | GLM 5.2 | --print | Мощный Buratino |

**Codex wrapper** (`/usr/local/bin/codex`):
```bash
#!/bin/bash
source /root/.hermes/.env
export CODEX_RELAY_API_KEY="$LONGCAT_API_KEY"
exec codex "$@"
```

Прямые вызовы:
```bash
codex exec -c model='"LongCat-2.0"' -c model_provider='"longcat-relay"' --skip-git-repo-check "task"
codex exec -c model='"glm-5.2"' -c model_provider='"glm-relay"' --skip-git-repo-check "task"
```

## 4. Codex CLI Config

`~/.codex/config.toml`:
```toml
model = "LongCat-2.0"
model_provider = "longcat-relay"

[model_providers.longcat-relay]
name = "LongCat via Relay"
base_url = "http://127.0.0.1:4447/v1"       # ❗ /v1 ОБЯЗАТЕЛЕН
wire_api = "responses"                       # ❗ Не "chat"
env_key = "CODEX_RELAY_API_KEY"
requires_openai_auth = false                 # ❗ Всегда false

[model_providers.glm-relay]
name = "GLM 5.2 via Relay"
base_url = "http://127.0.0.1:4448/v1"
wire_api = "responses"
env_key = "CODEX_RELAY_API_KEY"
requires_openai_auth = false

[model_properties."LongCat-2.0"]
context_window = 131072
max_context_window = 262144
max_output_tokens = 16384
supports_parallel_tool_calls = true
supports_reasoning_summaries = true
input_modalities = ["text"]
```

### Критические питфоллы config.toml
1. **`base_url` без `/v1`** — Codex бьёт `/responses`, релей ждёт `/v1/responses` → 404 → fallback в OpenAI WS
2. **`requires_openai_auth = true`** (default) — Codex игнорирует base_url, требует OAuth
3. **`env_key` не совпадает** — relay скрипт vs config.toml → Codex не находит переменную
4. **`wire_api` не указан** — по умолчанию Chat Completions, нужен `responses`
5. **model_properties** — без context_window Codex неправильно считает лимиты

**CODEX_RELAY_API_KEY** — одна переменная на все релеи: `echo 'export CODEX_RELAY_API_KEY=1' >> ~/.bashrc`

## 5. Claude Code через LongCat relay

### Архитектура
```
Claude Code (claude-lc)
  → ANTHROPIC_BASE_URL=https://localhost:4451 (HTTPS)
  → stunnel (:4451, HTTPS → HTTP)
  → codex-relay-anthropic (:4450)
  → POST /v1/messages (Anthropic → Chat Completions)
  → api.longcat.chat (LongCat-2.0)
```

### Настройка
```bash
export ANTHROPIC_BASE_URL="https://localhost:4451"
export ANTHROPIC_API_KEY="<LONGCAT_KEY>"
export NODE_TLS_REJECT_UNAUTHORIZED=0
export ANTHROPIC_MODEL="LongCat-2.0"
export ANTHROPIC_DEFAULT_SONNET_MODEL="LongCat-2.0"
export ANTHROPIC_DEFAULT_OPUS_MODEL="LongCat-2.0"
export ANTHROPIC_DEFAULT_HAIKU_MODEL="LongCat-2.0"
```

`.claude/settings.json` (только для v2.0.5):
```json
{
  "anthropic-base-url": "http://localhost:4450",
  "anthropic-auth-token": "<LONGCAT_API_KEY>",
  "anthropic-api-key": "",
  "anthropic-model": "LongCat-2.0"
}
```

### Модельный маппинг (CRITICAL)
`anthropic.rs` конвертирует через `req.model.to_lowercase()`: `starts_with("claude-")`, `starts_with("longcat-")`, `contains("sonnet|opus|haiku")` → `CODEX_RELAY_FALLBACK_MODEL` env (default "LongCat-2.0").

### Критические питфоллы
- **v2.1.146+** НЕ поддерживает кастомные `anthropic-base-url` — settings.json работает ТОЛЬКО в v2.0.5
- `ANTHROPIC_API_KEY` ОБЯЗАТЕЛЬНО пустой — иначе Claude Code идёт в Anthropic напрямую
- Root не может `--dangerously-skip-permissions` — только `--permission-mode acceptEdits`
- `claude -p "текст"` может падать — использовать `echo "?" | claude -p`
- Stunnel не стартует через systemd (конфликт порта) — `stunnel /etc/stunnel/anthropic-relay.conf`
- **Диагностика:** `curl -s -X POST http://localhost:4450/v1/messages -H "Content-Type: application/json" -H "x-api-key: $KEY" -H "anthropic-version: 2023-06-01" -d '{"model":"LongCat-2.0","max_tokens":200,"messages":[{"role":"user","content":"hello"}]}'`

### Сравнение Codex CLI vs Claude Code

| Критерий | Codex CLI + GLM 5.2 | Claude Code + LongCat |
|----------|-------------------|----------------------|
| Простая задача | ~5с, `@lru_cache` | ~15с, mutable default |
| Сложная задача | ~34с, анализ | ~12с, no tools в --print |
| Batch режим | ✅ код | ⚠️ Q&A |
| Песочница | read-only | ✅ полный доступ |

## 6. Buratino Profile Workers

```bash
buratino-codex "Проанализируй pilot_pairs.json"    # GLM 5.2, workspace-write
echo "посчитай статистику" | buratino-claude        # LongCat, --print
```

### Питфолл: gateway не видит codex/claude (PATH)
Buratino gateway имеет `env_passthrough: []`. **Фикс:**
```yaml
terminal:
  env_passthrough:
    - PATH
```
После — `systemctl restart hermes-gateway-buratino`

## 7. LongCat-2.0 — Primary Coding Model

**LongCat-2.0** (Meituan) — 1.6T MoE (48B active, 1M контекст). SWE-bench Pro 59.5 vs GPT-5.5 58.6. MIT.

| Критерий | LongCat-2.0 | DeepSeek V4 Pro |
|----------|-------------|-----------------|
| SWE-bench Pro | **59.5** 🏆 | ~55 |
| Контекст | **1M** | 262K |
| Cache hits | **free** | нет |
| Время ответа | ~10s | **~2.3s** 🚀 |
| Цена output | $2.95/M | **$0.87/M** |

### Setup в Hermes config
```yaml
providers:
  longcat:
    api_key: ${LONGCAT_API_KEY}
    base_url: https://api.longcat.chat/openai/v1
delegation:
  model: LongCat-2.0
  provider: longcat
```

### Проверка
```bash
curl -s -H "Authorization: Bearer $LONGCAT_API_KEY" "https://api.longcat.chat/openai/v1/models"
hermes chat -m LongCat-2.0 --provider longcat -q "Reply OK"
```

### Баланс
- HTTP 402 + `Token 额度不足` — кончились токены. Пополнить: longcat.chat
- 50M токенов сгорают за 30 дней. Cache hits бесплатны.

## 8. Kimi K3 (Moonshot AI) — Complex Tasks

**Kimi K3** (Moonshot AI, Jul 2026) — 2.8T параметров, open-weight, **1M контекст**. Выебал Claude Fable 5 и GPT-5.6 Sol на бенчах (SWE-bench, coding benchmarks). Natively multimodal (vision + video), reasoning/thinking mode.

| Параметр | Kimi K3 | LongCat-2.0 (для сравнения) |
|----------|---------|------------------------------|
| Параметры | 2.8T | 1.6T MoE (48B active) |
| Контекст | 1,048,576 | 262,144 |
| Reasoning | ✅ thinking mode | ✅ reasoning_content |
| Vision/Video | ✅ нативно | ❌ |
| Цена input | ~$3/1M | $0.37/1M |
| Цена output | ~$15/1M | $2.95/1M |
| Релеинг | Responses API (:4448) + Anthropic (:4453) | Responses API (:4447) + Anthropic (:4450) |

### Setup

```bash
# API ключ в .env
echo 'KIMI_API_KEY=sk-...' >> /root/.hermes/.env

# Провайдер в config.yaml
# moonshot provider уже добавлен, base_url: https://api.moonshot.ai/v1

# Delegation
# model: kimi-k3, provider: moonshot
```

### Testing the relays

```bash
# Codex relay (:4448) — Responses API
curl -s -X POST "http://127.0.0.1:4448/v1/responses" \
  -H "Content-Type: application/json" \
  -d '{"model":"kimi-k3","input":"say OK","max_output_tokens":20}'

# Anthropic relay (:4453) — for Claude Code via stunnel :4452
curl -s -X POST "http://127.0.0.1:4453/v1/messages" \
  -H "Content-Type: application/json" \
  -H "x-api-key: test" -H "anthropic-version: 2023-06-01" \
  -d '{"model":"kimi-k3","max_tokens":50,"messages":[{"role":"user","content":"say OK"}]}'

# Direct API
curl -s https://api.moonshot.ai/v1/models \
  -H "Authorization: Bearer $KIMI_API_KEY"
```

### Relay wrapper scripts

**Codex relay** (`run-relay-kimi.py`):
```python
env['CODEX_RELAY_PORT'] = '4448'
env['CODEX_RELAY_UPSTREAM'] = 'https://api.moonshot.ai/v1'
env['CODEX_RELAY_API_KEY'] = key
env['CODEX_RELAY_FALLBACK_MODEL'] = 'kimi-k3'
```

**Anthropic relay** (`run-relay-anthropic-kimi.py`):
```python
env['CODEX_RELAY_PORT'] = '4453'
env['CODEX_RELAY_UPSTREAM'] = 'https://api.moonshot.ai/v1'
env['CODEX_RELAY_API_KEY'] = key
env['CODEX_RELAY_FALLBACK_MODEL'] = 'kimi-k3'
```

### Pitfalls
1. **Thinking-only mode** — на `reasoning_effort: "max"` (default) Kimi может не возвращать `content`, только `reasoning_content`. Для тестов с маленьким `max_tokens` — ставить `reasoning_effort: "low"`.
2. **Цена** — в 5-10x дороже LongCat-2.0. Использовать только для сложных задач (код-архитектура, анализ, делегация). Для рутины — Flash.
3. **Латентность** — сервера в Китае, пинг ~1-2с до первой буквы. Релеи буферизуют.
4. **GLM 5.2 заменён** — :4448 и :4453 теперь kimi-k3. GLM-релеи выключены.

## 8. Codex в Hermes — интеграция после OAuth

После OAuth-аутентификации зарегистрировать в Hermes:
```bash
hermes auth status openai-codex                    # logged in
codex --version                                    # 0.142.5+
hermes chat -m gpt-5.5 --provider openai-codex -q "Reply OK"  # тест
```
Добавить секцию в `~/.hermes/AGENTS.md`. **«Проверь кодекс» ≠ «проверь OpenAI API»** — тестировать через `--provider openai-codex`.

## 9. Context Files for Codex CLI

- **CLAUDE.md** — авто-inject в system prompt. Должен содержать: описание проекта, таблицы (архитектура, команды), что НЕ трогать, зависимости, секцию «For Codex CLI».
- **.codexrules** — лаконичные правила («спрашивай перед удалением», «pytest -q»).

## 10. Knowledge Graph (Graphiti + Neo4j)

- Neo4j в Docker на :7687, автостарт
- 65+ узлов, 87+ связей по 7 категориям
- Почасовая синхронизация Hermes memory → Neo4j
- Поиск: `python3 /root/scripts/graphiti_bridge.py query "текст"`

## 11. Cost Model

Все релеи используют одни API ключи. Пользовательская преференция: не платить OpenAI.

## 12. Pitfalls & Diagnostics

### CODEX_RELAY_API_KEY not set
Codex требует переменную `CODEX_RELAY_API_KEY`. Релей не валидирует. **Фикс:** `export CODEX_RELAY_API_KEY=1` в `/etc/profile.d/codex-relay.sh` и `~/.bashrc`.

### Порты релеев перепутаны
Скрипты: `run-relay.py`→:4446, `run-relay-longcat.py`→:4447, `run-relay-glm.py`→:4448. Если два скрипта на одном порту — первый побеждает, второй падает без ошибок.

```bash
systemctl status codex-relay codex-relay-longcat codex-relay-glm
ss -tlnp | grep 444
grep CODEX_RELAY_PORT /root/codex-relay-rust/run-relay-*.py
```

### Пустой ответ от reasoning-моделей
GLM/LongCat кладут ответ только в `reasoning_content`, не дублируют в `content`. Фикс в `stream.rs` (`had_content_delta`) и `translate.rs` (`.filter(|s| !s.is_empty()).or_else(|| reasoning_content)`).

### Delegation consistency
При смене провайдера delegation — менять ВСЕ параметры одновременно: model, base_url, api_key. Несоответствие → HTTP 400 «Unsupported model».

### Per-profile config drift
Изменения в `default` профиле НЕ применяются к `buratino` автоматически. Каждый профиль имеет свою копию delegation, fallback_providers, providers.

### xAI: OAuth vs API key
`XAI_API_KEY` биллится отдельно от SuperGrok. Для подписки — провайдер `xai-oauth` (не `xai`).

### Gateway vs non-gateway релеи
Не-gateway релеи можно рестартить из Hermes. Gateway — нельзя (SIGTERM блокируется).

### Питфоллы методов Axum (повтор)
`.route()` не мержит методы, а перезаписывает. Всегда method chaining: `get().post()`.

---

**Связанный скилл:** `ai-coding-tools` — pygount для метрик кодовой базы + OAuth аутентификация Codex CLI.
