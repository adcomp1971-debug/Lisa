# Knowledge Graph — Neo4j + Graphiti для памяти агентов

## Архитектура

```
Hermes Memory (key-value, 81 entries, 53%)
  → Graphiti Bridge (graphiti_bridge.py)
  → Neo4j (графовая БД)
  → Knowledge Graph: 65+ узлов, 87+ связей
    → Memory nodes (по категориям: project/person/tool/server/config/rule/knowledge)
    → Entity nodes (извлечённые сущности: Hermes, Codex, LongCat, Buratino, GLM...)
    → Category nodes (7 шт)
    → Relationships: BELONGS_TO, MENTIONS
```

## Компоненты

### Neo4j (графовая БД)
- Запущена в Docker: `graphiti-neo4j`
- Порт: `7687` (Bolt), `7474` (HTTP UI)
- Логин: `neo4j` / `graphiti123`
- Автостарт при ребуте: `docker update --restart=unless-stopped graphiti-neo4j`
- Образ: `neo4j:5-community` с плагином `apoc`

### Graphiti Bridge (Python)
- Пакет: `graphiti-core==0.29.2` + `neo4j==6.2.0`
- Скрипты:
  - `/root/scripts/graphiti_bridge.py` — поиск, статистика, инициализация
  - `/root/scripts/graphiti_load_memory.py` — загрузка реальной памяти
  - `/root/.hermes/scripts/graphiti-sync.py` — почасовая синхронизация (cron)
- Cron: `graphiti-sync` каждый час (no-agent)

## Использование

```bash
# Поиск по графу
python3 /root/scripts/graphiti_bridge.py query "Буратино"
python3 /root/scripts/graphiti_bridge.py query "релей codex GLM"

# Статистика
python3 /root/scripts/graphiti_bridge.py stats

# Перезагрузка графа (если данные устарели)
python3 /root/scripts/graphiti_load_memory.py --force
```

## Как это улучшает работу

- **Память не забывается при сбросе сессии** — граф хранится в Neo4j, не в Hermes memory
- **Связи между проектами** — проекты, люди и инструменты связаны через MENTIONS
- **Поиск по категориям** — можно найти все записи по проекту/человеку/инструменту
- **Не тупеет со временем** — граф масштабируется иначе чем линейная memory

## Поддерживаемые категории

| Категория | Описание |
|-----------|----------|
| project | Проекты (Buratino, Pianoid) |
| person | Люди (Алекс, Дима, Аня) |
| tool | Инструменты (Codex, Hermes, релеи) |
| server | Серверы (VPS, nginx, AWG) |
| config | Конфигурации (YAML, .env) |
| rule | Правила (запрещено, нельзя) |
| knowledge | Общие знания |

## Извлекаемые сущности

Технические: Hermes, Codex, Claude, LongCat, GLM, DeepSeek, Gateway, Relay, Nginx, Tailscale, Docker, Neo4j, Graphiti, MCP, API, Buratino, Pianoid, Vast, AWG, VPN, Telegram, GitHub, OpenAI, xAI, LLM

Люди: Алекс, Дима, Аня, Артём, Тимур, Женя, Лиса, Саша

## Питфоллы

1. **Регистрозависимость** — при поиске `"буратино"` (кириллица) не найдёт `"Buratino"` (латиница). Искать по латинскому названию.
2. **Размер графа** — 65 узлов для 30+ memory записей. Каждая запись создает Memory node + Entity node + Category node. Это нормально.
3. **Синхронизация** — cron раз в час. Новые memory записи попадают в граф в течение часа. Для немедленной синхронизации запустить скрипт вручную.
