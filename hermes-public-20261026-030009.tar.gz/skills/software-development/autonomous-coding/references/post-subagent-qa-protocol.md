# Post-Subagent QA Protocol

After delegating code generation to a subagent (especially for frontend/3D/visual work), **assume nothing works** until you verify it yourself. Subagents self-report success but often produce code with broken features.

## 1. The Trust Problem

Subagents (DeepSeek Flash, Codex, Claude Code) say "done" when:
- The file is written (even if broken)
- The syntax is valid (even if logic is wrong)
- The feature exists in code (even if not connected)

**Rule:** A subagent summary is a self-report, not a verified fact. Always verify externally.

## 2. QA Checklist (run after EVERY subagent delegation)

### Console Check
```javascript
// Load the page and check for errors
// 0 errors = minimum bar, but not sufficient
```

### Static Check
- [ ] All expected HTML elements exist (check snapshot/DOM)
- [ ] Event handlers are attached (click, touch, submit)
- [ ] API URLs point to correct hosts/ports
- [ ] WebSocket URL is correct
- [ ] JS variables are in scope (not accidentally local)

### Functional Check (for each feature)
- [ ] **Click 1:** Open page, click on a device → does info panel appear?
- [ ] **Click 2:** Click same device again → does it toggle? Does API get called?
- [ ] **Chat 1:** Type and send → does message appear in chat?
- [ ] **Chat 2:** Does API response get displayed?
- [ ] **Scenario 1:** Click a scenario button → does it execute?
- [ ] **Scenario 2:** Does Bus Monitor show the steps?
- [ ] **Mode switch:** Free → Lesson → Exam → does UI update?
- [ ] **WebSocket:** Is it connected? Does it receive init data?
- [ ] **3D:** Is the canvas rendering? Are objects visible?
- [ ] **Touch:** Can you simulate touch event? Does it trigger the same handler as click?

### API Check (if backend exists)
- [ ] GET endpoints return 200 with expected data
- [ ] POST endpoints accept and process requests
- [ ] WebSocket handshake succeeds
- [ ] WebSocket messages have expected event types

## 3. Common Subagent Failure Patterns

### Frontend/3D
| Pattern | Symptom | Fix |
|---------|---------|-----|
| No touch events | Works on desktop, fails on iPad | Add `touchstart` listener |
| Raycaster non-recursive | Invisible clickable zones don't register | `intersectObjects(meshes, true)` |
| Missing toggle control | Devices show info but can't be controlled | Add toggle button + second-click toggle |
| API calls to wrong port | CORS errors or 404s | Verify all fetch URLs |
| Duplicate messages | API response + WebSocket broadcast both added | Remove one source |
| `bool` as `int` | `True` → `int(True)` = 1 | Check `isinstance(val, bool)` BEFORE `int` |
| Device list without interaction | Static list, no click handlers | Add click → send WebSocket event |

### Backend
| Pattern | Symptom | Fix |
|---------|---------|-----|
| Route with slashes in params | `/api/state/1/1/3` → 404 | Use `{ga:path}` in FastAPI |
| Scenario engine without delays | All steps fire at once | Add `await asyncio.sleep()` between steps |
| Missing CORS | Frontend can't call API from different port | Add `CORSMiddleware(allow_origins=["*"])` |
| State reset on restart | All device states lost | Add `--no-reload` or persistence |

### Spec Compliance
| Pattern | Symptom | Fix |
|---------|---------|-----|
| "For example" → only examples | 2 devices instead of 19 | List ALL items, not examples |
| Vague positioning | Devices clumped at origin | Provide exact 3D coordinates |
| "Simple UI" → stripped down | Tailwind cards instead of 3D | Explicitly ban simplifications in spec |
| Missing types | All devices = `light` | List all 7 types with shapes and colors |

## 4. The "Angry User Protocol"

When a user says "всё не работает" / "this is all broken":
1. **Do NOT trust the subagent's output** — even if it compiled without errors
2. Load the page yourself and check every feature manually
3. Focus on: clicks, toggles, API calls, WebSocket, chat, mode switching
4. Fix the most visible issues first (what the user WILL try first)
5. Only then fix edge cases

The user trying your app for the first time will:
1. Click on something → if nothing happens, they're done
2. Try to turn something on/off → if it doesn't respond, they're done
3. Ask the AI a question → if it doesn't answer, they're done

**Prioritize the first-touch experience over everything else.**
