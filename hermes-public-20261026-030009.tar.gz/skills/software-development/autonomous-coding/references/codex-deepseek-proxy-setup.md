# Codex → DeepSeek V4 Pro via codex-relay

## Server Setup (GPU-qwen)

- codex-relay binary: `/root/codex-relay-rust/target/release/codex-relay`
- Python wrapper: `/root/codex-relay-rust/run-relay.py`
- systemd: `codex-relay.service` (port 4446)
- Codex config: `~/.codex/config.toml` (provider: deepseek-relay → `:4446/v1`)
- Key: base64 at `/tmp/ds_key.b64`, reads at runtime

## Pipeline

```
Codex CLI (Responses API) → codex-relay (:4446) → DeepSeek Chat API (/v1/chat/completions)
```

## Cost

DeepSeek V4 Pro: $0.435/1M input (cache miss), $0.87/1M output.
vs GPT-5.x via OpenAI: ~$15/1M output. ~**17x cheaper**.

## Key details from setup

- `wire_api = "chat"` deprecated in Codex 0.128+ — **must** use Responses API proxy
- Moon Bridge (Anthropic↔OpenAI transform) also works but requires DeepSeek Anthropic endpoint (`/anthropic`) — some API keys rejected there
- codex-relay `--print-config` flag exists in Rust build but NOT in npm version
- `requires_openai_auth = false` needed for non-OpenAI providers
- `env_key = "CODEX_RELAY_API_KEY"` — must be set at runtime
- `model_properties` section required or Codex warns about missing model metadata
- DeepSeek V4 Pro in thinking mode: all tokens may go to reasoning. Use `reasoning: {type: "disabled"}` in direct API calls or just let Codex handle it.
