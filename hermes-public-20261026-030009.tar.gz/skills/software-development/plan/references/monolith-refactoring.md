# Monolith-to-Module Refactoring Playbook

Used to break a 2256-line PyQt5 monolith into 20 modules. Protocol preserved, zero behavioral changes.

## 6-Phase Approach

### Phase 1: Extract constants + state dataclasses
- Move all `HARM_NUM = 256`, `CMD_GRAPH_M = 0x26` etc. into `constants.py`
- Group 50+ `self.attribute` fields into dataclasses (AudioState, ScanState, TuneState, etc.)
- Each dataclass = one logical subsystem
- **Safe:** no behavioral change, only relocation

### Phase 2: Extract core pure functions
- UDP protocol functions: `send_deka_coeff(sock, decka_coeff, tr_led, out_vol)`, `send_gen_frq(sock, freq, ratio)`, `send_generator_enable(sock, enabled)`
- DSP functions: `mac_value(a,b)`, `measure_complex_response_vector(...)`, `modal_projection(...)`
- Each function takes all needed state as parameters, returns results
- No `self.` access, no UI imports

### Phase 3: Extract side modules
- Audio capture: `AudioCapture` class wrapping `sounddevice.InputStream` + ring buffer
- Scope rendering: pure functions for curve computation, separate from pyqtgraph widgets
- These are self-contained — easy to extract first

### Phase 4: Extract algorithms into classes
- Each timer-driven state machine becomes its own class with a `tick()` method
- Stage-based flow preserved: `baseline_settle → baseline_read → candidate_settle → candidate_read → ...`
- Dependencies injected via constructor: `audio_capture`, `send_coeffs` callback, `get_audio_data` callback
- Classes communicate via callbacks (`on_done`, `on_log`, `on_status`), not by reaching into UI
- **Critical:** preserve exact algorithmic logic (MAC thresholds, energy rise formulas, coordinate descent step halving)

### Phase 5: Extract UI into widgets
- Each `build_*_group()` method → separate `QGroupBox` subclass
- Widgets expose `pyqtSignal` for user actions, getter/setter for values
- No business logic in UI — only layout + signal emission
- MainWindow assembles widgets and exposes delegates for controller access

### Phase 6: Assembly + tests
- `Controller` class wires UI ↔ algorithms ↔ audio ↔ UDP
- `main.py` creates `QApplication`, `MainWindow`, `Controller`
- Basic tests on pure functions (DSP, state transitions)
- **Syntax check every file** before declaring done

## When to use
- Monolithic class >1000 lines with mixed concerns (UI + protocol + algorithms)
- User wants "привести в нормальный вид сделать рефакторинг"
- Protocol must be preserved unchanged

## Pitfalls
- Don't try parallel delegation for interdependent modules — context gets too large, subagents time out
- Do phases 1-3 yourself (fast, safe), then decide on delegation for 4-5
- After each phase, verify syntax compiles — catch errors early
