# Skills Audit Workflow — Case Study 2026-06-08

## Context
Alex requested: "приведи аудит skills и аудит памяти всё что надо оптимизировать предложи план."
Memory was 94% full (11,329/12,000 chars). 132 skills across 22 categories with duplicates and stale entries.

## Methodology

### Phase 1 — Full Inventory
1. `skills_list()` — get all skills with categories and descriptions (no need for pagination)
2. Categorize by relevance to user's **current active stack**:
   - **Active**: used weekly or has an active cron/service
   - **Dormant**: might be needed later but not now
   - **Stale**: hardware/software no longer in use, experiments that didn't take off, one-off projects
3. Check `~/.hermes/skills/` directories for stale `.bak` files and orphaned categories

### Phase 2 — Duplicate Detection
Look for skill pairs with overlapping descriptions:
- `live-dashboard` vs `live-monitoring-dashboard` (same thing, different categories)
- `exa-deep-search` vs `web-research` (both about search stack)
- `stack-doctor` already merged INTO `it-evening-digest` but skill file still exists
- `email-agent` wraps `himalaya` — himalaya is a subset
- `coding-workspace` vs `aider`/`codex`/`claude-code` — these are separate tools, NOT duplicates

### Phase 3 — Stale Detection
Check for:
- Hardware that doesn't exist (FPGA, ESP32/PlantPot, CVI, drone sim — no hardware running)
- Features explicitly removed from stack (drone nginx location removed)
- Experiments user never asked about again (autoresearch-loop, anti-cheat)
- Niche tools never invoked (Tor hidden service, dark web, mom-test)

### Phase 4 — Memory Compression
Pattern from this session:
1. List all memory entries (use `_audit_marker` technique if `memory` tool available)
2. Find exact duplicates (same info, different phrasing)
3. Merge domain-split entries (e.g. Hermes Box had 2 entries: GitHub Pages + project details → 1 entry)
4. Remove stale facts (resolved issues, outdated version strings, irrelevant details like logrotate config)
5. Consolidate related entries into a single declarative fact

### Phase 5 — Backup Cleanup
```
find ~/.hermes/skills -name "*.bak*" -delete
```
Removed 7 stale backup files in this session.

## Results from 2026-06-08
- 18 skills identified as stale/removable (apple/*, drone-control, fpga, plantpot, cvi-code-extraction, pyqt5-refactoring, autoresearch-loop, anti-cheat, smart-space-design, video-align, architectural-viz, tor-hidden-service, dark-web-operations, mom-test)
- 6 pairs identified for merging (live-dashboard→live-monitoring, exa-deep-search→web-research, stack-doctor→it-evening-digest, himalaya→email-agent, server-backup+monitoring)
- 7 stale .bak files removed
- Memory: 37→... entries after dedup, 94%→...% capacity
- 4+ obsolete memory entries identified for removal
