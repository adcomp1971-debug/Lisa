# Hermes Session Database Schema

Location: `~/.hermes/state.db` (SQLite3)

This database stores all conversation sessions and messages. Useful for building tools that query past conversations programmatically.

## Tables

### `sessions`

| Column | Type | Description |
|--------|------|-------------|
| `id` | TEXT PK | Session ID (e.g. `20260515_034...`) |
| `source` | TEXT | Platform source (e.g. `telegram`) |
| `user_id` | TEXT | Platform user ID |
| `model` | TEXT | Model used |
| `model_config` | TEXT | Model config JSON |
| `system_prompt` | TEXT | System prompt used |
| `parent_session_id` | TEXT FK | Parent session (for sub-agents) |
| `started_at` | REAL | Unix timestamp |
| `ended_at` | REAL | Unix timestamp |
| `end_reason` | TEXT | Why session ended |
| `message_count` | INTEGER | Total messages |
| `tool_call_count` | INTEGER | Total tool calls |
| `input_tokens` | INTEGER | Tokens in |
| `output_tokens` | INTEGER | Tokens out |
| `cache_read_tokens` | INTEGER | Cache read tokens |
| `cache_write_tokens` | INTEGER | Cache write tokens |
| `reasoning_tokens` | INTEGER | Reasoning tokens |
| `billing_provider` | TEXT | Billing provider |
| `estimated_cost_usd` | REAL | Estimated cost |
| `actual_cost_usd` | REAL | Actual cost |
| `title` | TEXT | Session title (unique when set) |

### `messages`

| Column | Type | Description |
|--------|------|-------------|
| `id` | INTEGER PK | Auto-increment |
| `session_id` | TEXT FK | → sessions.id |
| `role` | TEXT | `user`, `assistant`, `tool` |
| `content` | TEXT | Message content |
| `tool_call_id` | TEXT | Tool call reference |
| `tool_calls` | TEXT | Tool calls JSON |
| `tool_name` | TEXT | Tool name |
| `timestamp` | REAL | Unix timestamp |
| `token_count` | INTEGER | Token count |
| `finish_reason` | TEXT | Stop reason |
| `reasoning` | TEXT | Reasoning text |
| `reasoning_content` | TEXT | Reasoning content |
| `reasoning_details` | TEXT | Reasoning details JSON |
| `codex_reasoning_items` | TEXT | Codex reasoning |
| `codex_message_items` | TEXT | Codex messages |
| `platform_message_id` | TEXT | Platform message ID |

### Indexes

- `idx_sessions_source` on `source`
- `idx_sessions_parent` on `parent_session_id`
- `idx_sessions_started` on `started_at DESC`
- `idx_sessions_title_unique` on `title` (UNIQUE)
- `idx_messages_session` on `(session_id, timestamp)`
- `idx_messages_platform_msg_id` on `(session_id, platform_message_id)`

### FTS (Full-Text Search)

- `messages_fts` — FTS5 index over `content || tool_name || tool_calls`
- `messages_fts_trigram` — Trigram FTS5 index (same content)
- Both auto-maintained via INSERT/UPDATE/DELETE triggers

## Common Queries

### Get recent sessions with summary stats

```sql
SELECT s.id, s.title, s.started_at, s.message_count,
       (SELECT COUNT(*) FROM messages m WHERE m.session_id = s.id AND m.role = 'user') as user_msgs,
       (SELECT COUNT(*) FROM messages m WHERE m.session_id = s.id AND m.role = 'assistant') as assistant_msgs
FROM sessions s
WHERE s.message_count > 0 AND s.title IS NOT NULL
ORDER BY s.started_at DESC
LIMIT 50;
```

### Get messages for a session (user + assistant only)

```sql
SELECT id, role, content, tool_name, timestamp
FROM messages
WHERE session_id = ?
  AND role IN ('user', 'assistant')
  AND content IS NOT NULL AND content != ''
ORDER BY timestamp ASC
LIMIT 100;
```

### Full-text search across messages

```sql
SELECT m.session_id, m.role, m.content, s.title
FROM messages_fts fts
JOIN messages m ON m.id = fts.rowid
JOIN sessions s ON s.id = m.session_id
WHERE messages_fts MATCH 'search term'
ORDER BY m.timestamp DESC
LIMIT 20;
```

## Timestamps

All timestamps are Unix epoch (REAL). Convert with:
```python
from datetime import datetime, timezone
dt = datetime.fromtimestamp(ts, tz=timezone.utc)
```
