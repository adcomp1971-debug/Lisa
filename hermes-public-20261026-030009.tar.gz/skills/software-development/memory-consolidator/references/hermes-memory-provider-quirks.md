# Hermes memory provider quirks

## Built-in provider value is empty string, not `built-in`

For Hermes built-in memory, the correct config is:

```yaml
memory:
  provider: ''
```

Do **not** set:

```yaml
memory:
  provider: built-in
```

If you set the literal string `built-in`, `hermes memory status` prints a misleading message like:

- `Built-in: always active`
- `Provider: built-in`
- `Plugin: NOT installed`
- `Install the 'built-in' memory plugin ...`

That does **not** mean built-in memory is unavailable. It means the CLI treats non-empty `provider` as a plugin name. Built-in mode is represented by an empty provider.

## Practical cleanup pattern when Mem0 is polluted

If Mem0 is full of session-log noise and the built-in memory files are already the better source of truth:

1. Compact `~/.hermes/memories/MEMORY.md` and `USER.md`.
2. If there are sibling profiles, compact their `memories/` files too.
3. Set `memory.provider` to empty string (`''`) in each affected profile.
4. Verify with `hermes memory status` that it now shows:
   - `Built-in: always active`
   - `Provider: (none — built-in only)`

This disables Mem0 as the active retrieval layer without needing remote deletion of old Mem0 records.

## Cross-profile edit guard

When cleaning another Hermes profile's memory from the current session, `write_file` / `patch` may block with a cross-profile soft guard. If the user explicitly approved the change, retry with:

- `cross_profile=True`

Use that only after explicit user direction, because it changes another profile's future behavior.

## Session artifact note

If you find odd files like `MEMORY.mdes`, do not delete blindly. First quarantine by renaming to an `.artifact.<timestamp>` name, then verify Hermes does not reference it anywhere before permanent removal.
