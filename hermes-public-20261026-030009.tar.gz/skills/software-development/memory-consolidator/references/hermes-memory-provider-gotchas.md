# Hermes memory provider gotchas

## Built-in memory is selected by an empty provider

Field-verified behavior:
- `hermes memory status` always prints `Built-in: always active`.
- The true switch for built-in-only mode is `memory.provider: ''` (empty string / unset).
- Setting `memory.provider: built-in` is **wrong** for current Hermes CLI behavior: the status command then searches for a plugin literally named `built-in` and reports `Plugin: NOT installed`, which is misleading.

## Safe migration from mem0 back to built-in

Use this when Mem0 became noisy with session-log junk and you want local `MEMORY.md` / `USER.md` to be authoritative again.

1. Back up each affected profile's `config.yaml`.
2. For each profile independently, set:
   ```yaml
   memory:
     provider: ''
   ```
3. Verify local memory files actually exist and are curated:
   - `~/.hermes/memories/MEMORY.md`
   - `~/.hermes/memories/USER.md`
   - and the same under `~/.hermes/profiles/<name>/memories/` for named profiles.
4. Run `hermes memory status` and confirm:
   - `Built-in: always active`
   - `Provider: (none — built-in only)`

## Multi-profile caution

Profiles are isolated. Fixing the root profile does **not** fix named profiles automatically.

When disabling Mem0 noise, check every active profile separately:
- root `~/.hermes/config.yaml`
- `~/.hermes/profiles/<name>/config.yaml`

Also make sure the named profile's own `MEMORY.md` / `USER.md` are not stale, otherwise the profile will stop using Mem0 junk only to fall back to outdated built-in notes.
