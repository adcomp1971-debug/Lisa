# Memory Audit Case Study — 7 June 2026

## Before → After
| Metric | Before | After | Change |
|--------|--------|-------|--------|
| Memory entries | 33 | 26 | −7 (21%) |
| Memory chars | 11,342 (94%) | 8,032 (66%) | −3,310 (29%) |
| User profile | 2,237 (55%) | 2,237 (55%) | untouched |

## What was removed
- PX4 port detail (merged into Drone Sim entry)
- Nginx sites-enabled (was duplicate of Nginx config entry)
- Qwen 3.7 Plus standalone (info merged into Worker Stack entry)
- 3 duplicates of worker stack / routing enforcement
- Himalaya config duplicate (merged into a single Gmail entry)
- Audit markers (dummy entries for DB-text discovery)

## What was updated
- Vasily cron schedule: stale frequencies → current (1h/2h/6h/daily)
- Job search: Lemon.io status → rejected, wrote Emily
- NVIDIA benchmark: daily → weekly
- Gmail folder alias: Sent Mail → Отправленные (Russian locale)
- Worker stack: now includes Qwen 3.7 Plus details
- Python Core test: compressed from 300→150 chars

## Technique used
1. Add `_audit_marker` via memory(action='add', content='_audit_marker') to get exact DB text
2. Scan for duplicates: same domain in multiple entries, prefixed variations
3. Remove duplicates, keeping the most current/nuanced version
4. Replace stale entries with updated facts
5. Remove audit marker last
6. No mem0 layer present (built-in only) — one less surface to audit
