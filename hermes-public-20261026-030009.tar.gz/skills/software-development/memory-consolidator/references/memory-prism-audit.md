# Memory Prism Audit — Cross-Reference Contradiction Detection

## What It Is

A structured multi-file audit that cross-references all Hermes memory layers against each other and against the live config. Uses Prism methodology: structural extraction → decay analysis → contradiction hunt → adversarial self-correction.

## When to Use

- User says "проверь память", "аудит памяти", "призм память"
- After significant config changes (model switches, provider changes, fallback updates)
- When Hermes behaves inconsistently with documented preferences
- As part of full-stack audit

## Files to Check

| File | Role | Format |
|------|------|--------|
| `~/.hermes/memories/MEMORY.md` | Agent's persistent knowledge | Markdown, `§`-separated |
| `~/.hermes/memories/USER.md` | User profile/preferences | Single text block |
| `~/.hermes/config.yaml` | Live configuration | YAML |
| `~/.hermes/soul.md` | Agent identity | Markdown |

## Pass 1: Structural Extraction

Classify every claim in MEMORY.md:

| Type | Example | Action |
|------|---------|--------|
| **Факт окружения** | "x-ui порт 49624", "peer 10.9.0.10" | Verify against runtime |
| **Правило работы** | "Стоп = полная остановка", "не врать о прогрессе" | Must be preserved |
| **Предпочтение** | "Русский только", ".txt sendDocument" | Must be preserved |
| **Сессионная заметка** | "Disk cleanup 25 Jun", "Config fixes 25 Jun" | CANDIDATE FOR REMOVAL |

## Pass 2: Decay Analysis

For each paragraph, determine age and freshness:

- **Вечные**: правила работы, предпочтения пользователя
- **Медленные**: VPN конфигурация, пути проектов
- **Требуют верификации**: модель по умолчанию, fallback chain, API endpoints
- **Мусор**: сессионные заметки >3 дней (выполненные задачи, audit results)

**Red flag**: Any claim about current model/provider that doesn't match config.yaml.

## Pass 3: Contradiction Matrix

Cross-reference every claim across all 4 files. Key conflict domains:

1. **Model default** — MEMORY.md vs USER.md vs config.yaml:model.default
2. **Fallback chain** — MEMORY.md vs config.yaml:fallback_providers (count + order)
3. **base_url** — MEMORY.md vs config.yaml:model.base_url
4. **Provider state** — "GLM active" in memory vs zero balance reality
5. **Skill count** — soul.md claim vs actual skills_list count

Each contradiction gets: location (line/file), severity (CRITICAL/СРЕДНИЙ/НИЗКИЙ), fixability.

## Pass 4: Adversarial (Mandatory)

Attack own findings:
- What evidence would DISPROVE each contradiction claim?
- Did I overclaim? (stated as structural when actually fixable)
- Did I underclaim? (missed something the analysis implies)
- What did ALL passes take for granted?

## Verification Pattern

After fixes, run 15-check verification:
- Stale claims must be gone
- Correct claims must be present  
- Cross-file consistency (no file contradicts another)
- Size sanity (5000 < MEMORY.md < 20000 bytes)

## Case Study: 26 Jun 2026

**Found:** 6 contradictions including CRITICAL model mismatch (memory said Flash, config said Pro), base_url mismatch (memory said x.ai, config said deepseek.com), stale session notes.

**Fixed:** Updated all 3 files (MEMORY.md, USER.md, soul.md), removed ~30 lines of session debris (MEMORY.md: 15817 → 14395 bytes), verified 12/12 checks passed.

**User clarification mid-fix:** Flash and Pro share same API key → fallback must use DIFFERENT providers. Pro is manual choice, not hard default. Updated all files accordingly.
