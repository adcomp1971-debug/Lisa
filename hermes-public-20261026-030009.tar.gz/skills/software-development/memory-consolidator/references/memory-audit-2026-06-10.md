# Memory Audit — 10 June 2026

## Context
Full memory audit requested by Alex after stack upgrades (SOUL.md, image gen, fallback chain, Browser Use).

## Results

| Layer | Before | After | Δ |
|-------|--------|-------|-----|
| MEMORY.md | 16,067 bytes / 84 lines | 13,965 bytes / 78 lines | −2,102 bytes (−13%) |
| USER.md | 6,476 bytes / 24 lines | unchanged | — |
| Mem0 | API 400 (broken) | — | — |

## What was removed from MEMORY.md

| Entry | Reason |
|-------|--------|
| Old fallback chain (line 51) | Replaced with new Gemini-first chain |
| «79%, лимит 12K+4K» | Numbers stale; kept preference rule |
| «Фабл 5 план выполнен 09 Jun» | Completed task detail |
| «Fable 5 v3 in progress 10 Jun» | Session-specific detail |
| job_id from vpn-auto-doctor | Not needed in memory |
| Browser Use key acquisition | Procedural, not declarative |
| Fallback reconfiguration notes | Procedural, already in config skill |
| Bot token details | Simplified to essentials |

## What was added

- USER.md line 25: «Критично важна стабильность — чтобы агент не выпадал из эфира»

## Technique: cleaning MEMORY.md

1. Read full file via `read_file`
2. Classify each `§`-separated entry: ACTIVE / STALE / PROCEDURAL
3. Delete STALE entries (completed tasks, stale numbers, job_id)
4. Delete PROCEDURAL entries (belongs in skills, not memory)
5. For ENTRIES TO KEEP BUT SHRINK: remove verbose detail, keep facts only
6. Never delete safety rules, infrastructure configs, or user preferences
7. Verify file size after each batch

## Mem0 status (June 2026)

API returns HTTP 400: «One of the filters: app_id, user_id, agent_id, run_id is required!» — Mem0 now requires identification parameters that Hermes doesn't configure. Provider is dead. Recommend disabling via `memory.provider: ''`.
