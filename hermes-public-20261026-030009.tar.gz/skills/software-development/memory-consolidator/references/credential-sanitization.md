# Credential Sanitization in Memory Audit

## Problem

Persistent memory accumulates credentials: API keys, bot tokens, database passwords. These are usually injected during setup/onboarding (when you configure a provider and store "that it's configured" but accidentally include the key). Once stored, they're injected into **every** system prompt — a security exposure.

## Scan Targets

During memory audit, check for these credential patterns:

| Credential Type | Pattern | Example |
|----------------|---------|---------|
| OpenAI/Anthropic API keys | `sk-...`, `sk-ant-...` | `***...` |
| Telegram bot tokens | `\d+:***` | `8789564071:***` |
| HuggingFace tokens | `hf_...` | `hf_ABCDEF...` |
| xAI/Grok keys | `xai-...` | — |
| Database passwords | `password=...`, `pass: ...` | — |
| SSH keys | `-----BEGIN OPENSSH PRIVATE KEY-----` | — |
| JWT tokens | `eyJ...` | — |
| OAuth tokens | `ya29...`, `ghp_...` | — |

## Procedure

### 1. Scan entries for credential patterns

Read the full memory and user profile content (from system prompt). Scan each entry for known credential prefixes.

If the `memory` tool is unavailable (cron/no_agent), read the raw files:

```bash
# Memory
cat ~/.hermes/memories/MEMORY.md

# User profile
cat ~/.hermes/memories/USER.md
```

### 2. Classify each found credential

- **Full key visible** — the complete key/token is in memory
- **Partially redacted** — e.g. `sk-ant-...` or `8789564071:***` (digits visible)
- **Placeholder** — only mentions that something exists, no sensitive data

### 3. Sanitize via memory(action='replace')

**DO NOT just remove the entry entirely.** The fact that "X provider is configured" is useful. Strip only the sensitive parts:

```
BEFORE: "Anthropic API ключ ***... подключен. Провайдер anthropic."
AFTER:  "Anthropic провайдер подключён напрямую (провайдер anthropic). Fable 5 — только с разрешения."
```

**Keep:** functional info (provider name, how to use, restrictions)
**Remove:** key digits, token strings, any credential that lets someone authenticate

### 4. Check for duplicates

The same credential often appears in multiple entries:
- Fallback chain description
- Standalone "API keys" entry
- Provider-specific notes

Consolidate into ONE entry. Remove the rest.

### 5. Cross-check user profile

User profile (`target='user'`) can also accumulate credentials — especially if you saved "how the provider was set up" there. Scan and sanitize the same way. User profile has a tighter character limit (7,000 chars) so consolidation is doubly important.

### 6. Verify after cleanup

After replace/remove operations, re-read the prompt-injected memory or check the memory file to confirm no credential patterns remain.

## Common Cases Found in Practice

### Case 1: Anthropic API key in 3 places
- Fallback chain entry: "Anthropic API ключ sk-ant-... подключен напрямую"
- Standalone Anthropic entry: "Anthropic API ключ sk-ant-... подключён (провайдер anthropic)"
- User profile: "Anthropic ключ sk-ant-..."

**Fix:** Consolidate all three into one entry in memory. No need for user profile copy.

### Case 2: Telegram bot token in memory
- Entry: "@AmseujBot = главный бот. Токен: 8789564071:***"

**Fix:** Remove the token part. Keep "@AmseujBot = главный Hermes gateway Telegram бот" — the fact that this bot exists is useful, the token value is not.

### Case 3: Liskaanka bot token in memory
- Entry: "Текущий токен в памяти процесса: 8848710683:***"

**Fix:** Replace with just the fact that the bot exists and where its code is. Remove all token references.

## Results to Report

After sanitization, report:

- Found N credential instances in memory
- M in user profile
- Sanitized: N+M entries (keys removed, functional info kept)
- Duplicates consolidated: D entries removed
- Space freed: X chars (Y%)
