# Session Search & Compaction Interplay

## The Bug

After context compaction, `session_search` returns 0 results for conversations that happened in the *parent* session — even though the messages exist in the FTS5 index.

## Root Cause

In `tools/session_search_tool.py`, the `_discover` function skips sessions from the current lineage:

```python
if current_lineage_root and resolved_sid == current_lineage_root:
    continue  # ← skips parent sessions
```

This is correct when the parent context is still in the active window, but **wrong after compaction** — after compaction, the parent context has been evicted and is no longer available to the agent.

## Fix (applied 27 May 2026)

```python
# Before the lineage skip, check if current session is a compaction child:
has_compaction = False
if current_session_id:
    current_meta = db.get_session(current_session_id) or {}
    has_compaction = bool(current_meta.get("parent_session_id"))

# Skip lineage only if this is NOT a compacted session:
if current_lineage_root and resolved_sid == current_lineage_root and not has_compaction:
    continue
```

The fix is in hermes-agent `tools/session_search_tool.py` at the start of the `_discover` function. It may need re-application after `hermes update`.

## Verification

After fix, `session_search("deepseek-tui")` should find sessions from the parent lineage that contain the query term.
