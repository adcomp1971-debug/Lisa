### Phase F — Mem0 Audit & Cleanup

**Контекст:** Mem0 — семантический слой памяти, хранящийся через API (нет локальной БД). `mem0_conclude` добавляет записи, но **delete API отсутствует**. Записи, добавленные через `mem0_conclude`, нельзя удалить стандартными инструментами.

**Аудит:**
1. `mem0_profile` — посмотреть количество записей.
2. `mem0_search(query='all facts', top_k=50)` — получить полный список.
3. Классифицировать каждую запись:
   - ✅ **Факт** — durable knowledge (предпочтения, константы, правила)
   - ❌ **Лог сессии** — «User asked to...», «User expressed need...» — МУСОР
   - ❌ **Авто-сохранение** — «User set default model...», «User requested PDF...» — МУСОР

**Mem0 API change (June 2026):** Ранее API Mem0 возвращал 429 при превышении лимитов Hobby-плана (лимит adds/retrieval). Теперь API возвращает 400 с требованием `app_id`, `user_id`, `agent_id` или `run_id` — идентификаторы, которые Hermes не передаёт. Mem0 полностью неработоспособен как провайдер памяти. `hermes memory status` может показывать `Provider: mem0`, но API запросы падают с 400. Рекомендация: отключить Mem0 через `memory.provider: ''` в каждом профиле, вернуться на built-in.

**Типичная картина:** Mem0 содержит почти исключительно мусор — авто-сохранения сессионных событий, которые `mem0_conclude` записывает без фильтрации. Полезные факты (если есть) уже дублируются в persistent memory.

**Действия при мусорном Mem0:**
1. Задокументировать в отчёте: количество записей, процент мусора.
2. **Попытаться прямой доступ к БД:** `python3 -c "import sqlite3; db = sqlite3.connect('/root/.hermes/mem0.db'); ..."` — если файл существует, можно очистить таблицы.
3. Если БД нет (API-based) — зафиксировать как ограничение.
4. **Рекомендация:** прекратить использовать `mem0_conclude` для авто-сохранения. Либо отключить в конфиге, либо использовать только для явных пользовательских «запомни».

**When Mem0 useful:** only if user explicitly asks «запомни это в Mem0». Авто-сохранение сессионных логов — анти-паттерн.

**Built-in provider gotcha (field-verified):** для возврата на встроенную память Hermes `memory.provider` должен быть пустой строкой `''`, а не строкой `built-in`. `hermes memory status` всегда печатает `Built-in: always active`; если записать `provider: built-in`, CLI начинает искать одноимённый plugin и показывает ложный статус `Plugin: NOT installed`, хотя встроенная память и так работает. Практический safe-switch с `mem0` на built-in: (1) backup `config.yaml` у каждого затронутого профиля, (2) выставить `memory.provider: ''` для каждого профиля отдельно, (3) убедиться, что локальные `memories/MEMORY.md` и `USER.md` актуальны, (4) проверить, что `hermes memory status` показывает `Provider: (none — built-in only)`. См. `references/hermes-memory-provider-gotchas.md`.

**Когда сжатия недостаточно — увеличить лимиты:**
Если после консолидации память всё ещё >80% заполнена, увеличить лимиты через конфиг:
```bash
hermes config set memory.memory_char_limit 3000
hermes config set memory.user_char_limit 2000
```
Изменения подхватятся после `/reset` или нового сообщения. Это безопаснее, чем агрессивное удаление записей — сохраняет полезные факты и даёт запас на будущее.

**Fallback when `memory` tool is unavailable (common in cron environments):**
- Read `~/.hermes/memories/MEMORY.md` and `~/.hermes/memories/USER.md` directly via `read_file`.
- Analyse for duplicate/redundant entries split by `§` delimiter.
- List identified merge candidates in the report's Memory Compression section with before/after proposed text.
- Do NOT attempt `write_file` to memory files directly — note as "identified, not applied; will retry next run."
- The next run (or a manual session where the tool is available) can apply them.
- See `references/hermes-memory-provider-quirks.md` for Hermes-specific gotchas when moving a profile off Mem0 onto built-in memory.

## Manual Full Run Playbook (`MANUAL_FULL`)

1. Сообщить пользователю план (inventory всех 4 слоёв → dry-run → backup → apply → verify → report).
2. Выполнить dry-run и показать список:
   - что будет объединено (skills),
   - что будет удалено (skills + memory entries),
   - что будет сжато в памяти,
   - состояние Mem0 (записи, классификация, возможность очистки),
   - оценка освобождения места.
3. Сделать backup.
4. Применить изменения пакетами (small batches).
5. После каждого пакета валидация целостности (skill exists, links valid, no broken references).
6. Выпустить итоговый отчёт по всем слоям.

## Weekly Auto Run Playbook (`AUTO_WEEKLY`)

1. Inventory + similarity scan.
2. Только безопасные merge/cleanup.
3. Backup.
4. Применение low-risk изменений.
5. Отчёт с блоком `PENDING_CONFIRMATION` для risky/critical кандидатов.

## Report Template (обязательный)
После каждой консолидации выводить:

1) Summary
- Skills before: N
- Skills after: M
- Net change: M-N

2) Merged
