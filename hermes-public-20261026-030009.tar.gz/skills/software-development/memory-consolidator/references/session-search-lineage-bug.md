# session_search + compaction lineage bug

**Обнаружен:** 27 мая 2026, при попытке найти разговор про CodeWhale.

## Симптомы

`session_search` возвращает 0 результатов для тем, которые точно есть в родительских сессиях (после compaction). FTS5-индекс содержит данные, прямой SQL находит, но tool — нет.

## Root cause

`session_search_tool.py`, функция `_discover()`, строки 320-322:

```python
# Skip the current session lineage
if current_lineage_root and resolved_sid == current_lineage_root:
    continue
```

Логика: если сессия в той же lineage что и текущая — пропустить (предполагается что контекст и так в памяти). **Но после compaction родительский контекст вырезан** — агент его не видит, а search всё равно пропускает.

## Механика

```
Сессия 041003 (CodeWhale разговор) — 74 сообщения, 1.6M токенов
  ├─ compaction → child 043727 (11 msg)
  ├─ compaction → child 044804 (19 msg)  
  └─ compaction → child 112103 (21 msg) ← текущая

session_search("codewhale") из 112103:
  FTS5 находит сообщения в 041003 ✓
  _resolve_to_parent(041003) = 041003
  current_lineage_root = _resolve_to_parent(112103) = 041003
  041003 == 041003 → continue (пропуск!) ✗
```

## Фикс

```python
# В _discover(), перед строкой 320:
current_meta = db.get_session(current_session_id) if current_session_id else {}
has_compaction = bool(current_meta.get("parent_session_id"))

# Заменить строки 321-322:
if current_lineage_root and resolved_sid == current_lineage_root and not has_compaction:
    continue
```

Логика: если текущая сессия — compaction-child (есть `parent_session_id`), то родительские сессии **не пропускаем** (их контекст уже вырезан).

## Тест-кейс

```bash
# 1. Создать длинную сессию с ключевым словом
# 2. Дождаться compaction (threshold превышен)
# 3. В child-сессии: session_search("ключевое_слово")
# До фикса: 0 результатов
# После фикса: находит родительскую сессию
```

## Файлы

- `/usr/local/lib/hermes-agent/tools/session_search_tool.py` — `_discover()`, строки 311-324
- `/usr/local/lib/hermes-agent/hermes_state.py` — `_resolve_to_parent()`, `search_messages()`
