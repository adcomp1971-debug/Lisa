# Graphiti + Neo4j — Knowledge Graph для памяти агентов

## Архитектура
- **Neo4j** (5-community) — графовая БД, запущена в Docker
- **Graphiti** (graphiti-core v0.29.2) — temporal knowledge graph поверх Neo4j
- **Порты:** 7687 (bolt), 7474 (HTTP webui)
- **Данные:** ~65 узлов, ~88 связей (текущее состояние)

## Установка
```bash
docker run -d --name graphiti-neo4j -p 7687:7687 -p 7474:7474 \
  -e NEO4J_AUTH=neo4j/graphiti123 \
  -e NEO4J_PLUGINS='["apoc"]' \
  neo4j:5-community

pip install graphiti-core
```

## Скрипты
- `/root/scripts/graphiti_bridge.py` — поиск/статистика
- `/root/.hermes/scripts/graphiti-sync.py` — cron-синхронизация (каждый час)

## Использование
```bash
python3 /root/scripts/graphiti_bridge.py stats        # статистика
python3 /root/scripts/graphiti_bridge.py query "текст" # поиск
```
