---
name: memory-consolidator
description: "Use when consolidating Hermes skills and persistent memory into a cleaner, deduplicated, safer knowledge base with backups, weekly automation, and manual full-run reporting."
version: 1.5.2
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [memory, skills, consolidation, deduplication, maintenance, automation, reporting]
    related_skills: [self-improver, hermes-agent]
---

# Memory Consolidator

## Overview
Главный мета-скилл для управления качеством базы навыков и всех слоёв памяти Hermes.

Он делает 6 вещей:
1) консолидация и дедупликация скиллов,
2) очистка/сжатие persistent memory (без потери важных фактов),
3) аудит Mem0 memory (семантический слой) — выявление мусорных записей,
4) **Skills Quick Health Check** — быстрая проверка целостности библиотеки скиллов (версии, противоречия, мёртвые ссылки, устаревший контент),
5) обязательные backup + safety checks,
6) подробная отчётность по результатам по всем слоям.

**Prism-аудит памяти:** для перекрёстной проверки MEMORY.md ↔ USER.md ↔ config.yaml ↔ soul.md с поиском противоречий и decay-анализом — см. `references/memory-prism-audit.md`.

**Четыре слоя памяти Hermes:**
| Слой | Инструмент | Хранилище | Очистка |
|------|-----------|-----------|---------|
| Persistent Memory | `memory` (add/replace/remove) | `~/.hermes/memories/MEMORY.md` + `USER.md` | ✅ replace/remove |
| Mem0 Memory | `mem0_conclude` / `mem0_search` / `mem0_profile` | API-based (нет локальной БД) | ❌ delete API отсутствует |
| Session DB | `session_search` | SQLite FTS5 | ❌ read-only |
| Skills | `skill_manage` / `skill_view` | `~/.hermes/skills/` | ✅ patch/edit/delete |

Поддерживает 2 режима:
- `AUTO_WEEKLY` — безопасная еженедельная автоматическая консолидация,
- `MANUAL_FULL` — ручной полный прогон по запросу пользователя с расширенным отчётом.

## When to Use
- Когда библиотека скиллов растёт и появляются похожие/дублирующиеся навыки.
- Когда нужно быстро проверить целостность скиллов перед релизом/аудитом.
- Когда в памяти накапливаются повторы, шум, устаревшие формулировки.
- Когда нужен полный аудит всех слоёв памяти: persistent + Mem0 + session DB + skills.
- Когда нужен регулярный maintenance knowledge base с измеримым эффектом.
- Когда session_search не находит разговоры после compaction — см. `references/session-search-compaction.md`.

Не использовать для:
- единичной правки одного конкретного скилла (лучше `skill_manage(action='patch')` напрямую),
- удаления критичных навыков без подтверждения пользователя.

## Core Guarantees
1. Всегда делать backup перед изменениями.
2. Никогда не удалять важные навыки втихую.
3. Любые рискованные удаления — только после явного подтверждения пользователя.
4. Всегда отдавать структурированный отчёт «до/после/эффект».

## Safety Model

### 1) Классификация навыков
Перед удалением или merge каждый скилл маркируется:
- `CRITICAL` — системные, инфраструктурные, безопасность, VPN/prod, базовые оркестраторы.
- `IMPORTANT` — активно используемые и/или широкого назначения.
- `NORMAL` — обычные доменные навыки.
- `STALE` — неиспользуемые/дублирующие/низкой ценности.

Минимальный protected-set (не удалять автоматически):
- `hermes-agent`
- `vpn-safe`
- `vpn-manager`
- `self-improver`
- любые pinned skills (если помечены как pinned)

### 2) Правило подтверждения
Если затрагивается `CRITICAL`/`IMPORTANT` удалением, выполнять только через явное подтверждение пользователя в формате:
- `YES, DO IT` или `ДА, ДЕЛАЙ`

До подтверждения — только план и dry-run отчёт.

### 3) Автоматический режим
`AUTO_WEEKLY` не удаляет critical/important.
Разрешено автоматически:
- merge явных дублей,
- удаление только `STALE` с низким риском,
- memory dedupe без потери фактов.

## Skills Quick Health Check

Быстрая проверка целостности библиотеки скиллов. Выполняется перед или вместо полной консолидации, когда нужен «аудит скиллов» без глубокого merge.

### Чек-лист (4 пункта)

#### 1. Version completeness — все скиллы имеют версию?

```bash
cd /root/.hermes/skills && python3 -c "
import os
missing = []
for root, dirs, files in os.walk('.'):
    if 'SKILL.md' in files:
        path = os.path.join(root, 'SKILL.md')
        with open(path) as f:
            c = f.read()
        if c.startswith('---'):
            end = c.find('---', 3)
            if end > 0 and 'version:' not in c[3:end]:
                missing.append(path)
print(f'Without version: {len(missing)}')
for m in missing: print(f'  {m}')
"
```

Если > 0 — проставить версию `1.0.0` через скрипт (см. Batch Version Fix ниже).

#### 2. Cross-skill contradictions — одинаковые команды описаны по-разному

Проверить пересекающиеся скиллы на противоречия:
- **awg showconf (сверено 11.10.2026):** согласовано — awg-operations и vpn-manager оба разрешают `awg showconf` для runtime→файл, но оба требуют сразу вернуть `Address` (showconf теряет Address/MTU/DNS). Держать это требование в обоих.
- **Способы добавления AWG пира (сверено 11.10.2026):** авторитет — `awg-operations`: Способ 1 (рекомендуемый) `awg set … peer`, Способ 2 `awg addconf` с фрагментом; после любого — дописать секцию в `awg0.conf`. Общее правило, которое обязательно во всех скиллах: интерфейс НЕ рестартить. Не считать `awg set` ошибкой — это рабочая рекомендация скилла.
- **NAT/MASQUERADE:** команды должны быть одинаковыми во всех скиллах
- **UFW rules для AWG:** должны совпадать в vpn-manager, vpn-auto-doctor, server-ops

Проверка grep:
```bash
grep -rn 'showconf' /root/.hermes/skills/ --include='SKILL.md' | grep -v 'Pitfall\|НЕ ИСПОЛЬЗУЙ\|Вариант'
# Если showconf упоминается по-разному — есть противоречие
```

**Fix:** при противоречии выбрать авторитетный скилл (обычно vpn-manager как umbrella), привести остальные к единому standard.

#### 3. Dead related_skills — скиллы ссылаются на несуществующие

```bash
cd /root/.hermes/skills && python3 -c "
import os, yaml, re
existing = set()
for root, dirs, files in os.walk('.'):
    if 'SKILL.md' in files:
        rel = os.path.relpath(os.path.join(root, 'SKILL.md'), '.')
        name_part = rel.rsplit('/', 1)[0] if '/' in rel else rel.replace('/SKILL.md','')
        existing.add(os.path.basename(name_part))

dead = []
for root, dirs, files in os.walk('.'):
    if 'SKILL.md' in files:
        path = os.path.join(root, 'SKILL.md')
        with open(path) as f:
            content = f.read()
        # Extract related_skills from frontmatter
        if content.startswith('---'):
            end = content.find('---', 3)
            if end > 0:
                front = content[3:end]
                m = re.search(r'related_skills:\s*\[([^\]]*)\]', front)
                if m:
                    refs = [r.strip().strip(\"'\") for r in m.group(1).split(',') if r.strip()]
                    for ref in refs:
                        if ref and ref not in existing:
                            rel = os.path.relpath(path, '.')
                            dead.append(f'  {rel} → {ref}')
                            print(f'DEAD: {rel} → {ref}')
print(f'\\nTotal dead links: {len(dead)}')
"
```

**Fix:** удалить мёртвые ссылки или заменить на существующие.

#### 4. Stale/outdated content markers

Проверить маркеры устаревания в содержимом скиллов:
- `DISABLED`, `NOT IN USE` — если блок помечен как неиспользуемый >30 дней, удалить
- `DEPRECATED` — если альтернатива реализована, удалить секцию
- Даты вроде `(May 2026)` — если прошло >2 месяцев, проверить актуальность
- Ссылки на серверные параметры (IP, public key, short IDs) — если захардкожены, отметить риск

### Batch Version Fix (для 1)

```bash
cd /root/.hermes/skills && python3 -c "
import os
count = 0
for root, dirs, files in os.walk('.'):
    if 'SKILL.md' in files:
        path = os.path.join(root, 'SKILL.md')
        with open(path) as f:
            content = f.read()
        if content.startswith('---'):
            end = content.find('---', 3)
            if end > 0 and 'version:' not in content[3:end]:
                front = content[3:end]
                lines = front.split(chr(10))
                insert_after = 0
                for i, line in enumerate(lines):
                    if line.startswith('description:') or line.startswith('name:'):
                        insert_after = i + 1
                if insert_after == 0:
                    insert_after = 1
                lines.insert(insert_after, 'version: 1.0.0')
                new_front = chr(10).join(lines)
                new_content = '---' + new_front + '---' + content[end+3:]
                with open(path, 'w') as f:
                    f.write(new_content)
                count += 1
print(f'Fixed: {count} skills')
"
```

### Skills Health Check Report Template

```
## Skills Health Check
- Version completeness: N/M (M without version → список)
- Cross-skill contradictions: N found → список
- Dead related_skills: N found → список
- Stale/outdated markers: N found → список
```

## Backup Protocol (обязателен)
Перед любыми изменениями:
1. Создать timestamp.
2. Backup каталога skills.
3. Сохранить снапшот плана изменений (что именно будет merge/delete/patch).

Рекомендуемый путь:
- `~/.hermes/backups/memory-consolidator/<timestamp>/`

Минимум в backup:
- архив `skills/` или копии изменяемых SKILL.md,
- JSON/MD отчёт dry-run,
- список операций для rollback.

## Consolidation Algorithm

### Phase A — Inventory (все 4 слоя)

**Persistent Memory:**
1. Добавить `_audit_marker` через `memory(action='add', content='_audit_marker', target='memory')` — это вернёт полный список записей в их точном БД-формате (pitfall #6).
2. Сохранить точные тексты для последующих `replace`/`remove`.
3. Прочитать `~/.hermes/memories/MEMORY.md` и `USER.md` через `read_file` как резервный источник.
4. Замерить `memory_char_limit` и `user_char_limit` из конфига.
5. Если у пользователя есть named profiles, аудит памяти делать ПО ПРОФИЛЯМ, а не только по root `~/.hermes/`: у каждого профиля свои `memories/`, свой `config.yaml` и свой provider state. Минимум проверить default + все профили, которые реально участвуют в задаче.
6. Для user-facing memory audit сразу собирать конкретику: размеры файлов, активный provider, переполнение лимитов, список устаревших блоков, и отдельно помечать `read-only` это был прогон или уже `applied`.

**Mem0 Memory:**
1. `mem0_profile` — количество записей и сводка.
2. `mem0_search(query='all facts', top_k=50)` — полный список с текстами.
3. Классифицировать каждую запись: факт / лог сессии / авто-сохранение / мусор.

**Session DB:**
1. `session_search()` — browse последних сессий.
2. `session_search(limit=10, query='...', sort='newest')` — поиск по ключевым темам.

**Skills:**
1. Сначала выполнить **Skills Quick Health Check** (см. выше) — проверить версии, противоречия, мёртвые ссылки, устаревший контент.
2. Получить полный список через `skills_list`.
3. Для каждого кандидата загрузить `skill_view`.
4. Собрать индекс: name, category, description, tags, related_skills, size (chars), last-touch (если доступно).

### Phase B — Similarity Detection
Два уровня поиска дублей:

**Level 1 — Cross-skill duplicates (между разными скиллами):**
Найти группы кандидатов на merge:
- точные дубли по смыслу/названию,
- сильное пересечение триггеров (`When to Use`),
- близкие теги + одинаковые workflow-паттерны,
- «узкий клон» скилла, который уже покрывается более сильным umbrella-скиллом.

**Level 2 — Internal duplication (внутри одного SKILL.md):**
При загрузке `skill_view` проверять:
- повторяющиеся секции с одинаковым или почти одинаковым содержанием (например, два списка одних и тех же паттернов — один полный, один сокращённый),
- дублирующиеся заголовки секций с пересекающимся содержимым,
- «остаточные» секции — когда старый вариант секции не удалён после того как был переписан в более полную версию.

Внутренние дубли — low-risk, применять сразу без подтверждения (patch внутри файла, не delete скилла).

Практика:
- Сначала формировать предложения merge (dry-run),
- Потом применять только high-confidence пары/кластеры.

### Phase C — Merge Strategy
Для каждой группы:
1. Выбрать `target umbrella skill` (обычно самый полный и актуальный).
2. **Перенести уникальные полезные части — ТОЛЬКО ДОБАВЛЕНИЕМ, без удаления строк оригинала.** Техника:
   - Взять самый полный/актуальный скилл (или его бэкап) как неизменяемую основу.
   - Добавлять новые секции/пункты через `patch` вставкой между существующими секциями — never удаляя или перезаписывая существующие строки.
   - Допустимо только: обновление frontmatter (version, description), добавление новых секций, добавление новых пунктов в существующие списки.
   - НЕЛЬЗЯ: переписывать существующие секции «в более кратком виде», удалять целые блоки команд, заменять существующие таблицы на «более компактные» версии.
3. **Валидация merge:** запустить `diff -u backup/base/file merged/file` — в выводе должны быть ТОЛЬКО строки `+` (добавления). Ни одной строки `-` (кроме апдейта версии/описания во frontmatter). Если есть `-` с командами, секциями или pitfalls — merge уничтожил контент, откатить и сделать заново.
4. Убрать противоречия и дубли внутри target (только если это не затрагивает строки из шага 2).
5. Обновить `metadata.hermes.related_skills`.
6. Проверить читаемость и проверяемость шагов.
7. Перед удалением источников — показать пользователю diff и подтверждение.

Удаление источников после merge:
- только когда перенос подтверждён,
- использовать `skill_manage(action='delete', absorbed_into='<target>')`.

### Phase D — Stale/Low-value Cleanup
Кандидаты на удаление:
- пустые или почти пустые навыки,
- устаревшие версии, полностью поглощённые umbrella-скиллом,
- явные шумовые навыки без использования и ценности.

Никогда не удалять защищённые навыки автоматически.

### Phase E — Memory Compression

**Цель:** уменьшить шум без потери важных фактов.

**AutoResearch-оптимизация:** этот скилл был успешно сжат через `autoresearch-loop` (−21% chars, +42% SCORE, 12/12 итераций успешны). Оптимизационные паттерны: слияние дубликатов, удаление мета-языка, сжатие примеров. См. `autoresearch-loop` skill для методологии.

**Принцип отбора — «только то, что делает Гермеса сильнее»:**
- ✅ Сохранять: safety-правила, инфраструктурные константы, баги с workaround, предпочтения пользователя
- ❌ Удалять: логи, исторические инциденты, справочную информацию, одноразовые факты
- Вопрос для каждой записи: «Это сделает Гермеса эффективнее в следующей сессии, или это просто лог?»

**Структурированная память (update 2026-05-29):** MEMORY.md теперь содержит `##` заголовки (VPN, Модели и routing, Правила работы, Доставка на iPad, Проекты, Сервисы, Инфраструктура/прочее). Это значит:
- `memory-stat` upgrade trigger #2 (заголовки) — выполнено.
- Staleness станет измеримой, когда появятся датированные блоки.
- Dedup проще: каждая секция — один домен, дубли видны сразу.
- При консолидации сканировать каждую `##` секцию отдельно, не смешивать домены.

**Новая конвенция дат (с 2026-07-10):** Каждая новая запись памяти начинается с даты `[YYYY-MM-DD]`. Старые записи не ретроактивно датировать. Это позволяет отслеживать staleness без полных аудитов.

**Принцип «скиллы вместо памяти»:**
- Процедурные знания (как сделать X) → в скиллы
- Декларативные факты (что есть Y, где лежит Z) → в память
- Если запись памяти содержит инструкцию или workflow → перенести в соответствующий скилл, из памяти удалить
- Критерий для каждой записи: «Это сделает Гермеса эффективнее в следующей сессии, или это просто лог/история/справочник?»

**Правило сохранения проектов (абсолютное):** При любой консолидации/сжатии памяти ВСЕГДА сохранять полные определения проектов: название, расположение, ключевые участники, статус. Сжимать можно технические детали (версии, точные команды, историю изменений), но не сам факт существования проекта. «Что это за проект, где лежит, кто делает» — неприкосновенно.

**Практическое наблюдение:** При высокой заполненности памяти (90%+) основная экономия достигается не созданием новых скиллов, а чистой компрессией самой памяти — удалением дубликатов, устаревших версий, слиянием разрозненных фактов об одном домене в одну запись. Большинство процедурных знаний уже покрыто существующими скиллами; проверять их перед созданием новых.

**Практика:** при консолидации сканировать память на предмет процедурных записей.

**Действия:**
- объединять дублирующиеся записи памяти в одну декларативную запись,
- удалять устаревшие формулировки после замены,
- укорачивать длинные записи до компактной факт-формы,
- Не трогать предпочтения пользователя и критичные safety-факты.
- **Credential scanning:** перед любой консолидацией проверять память на API ключи, токены, пароли. См. `references/credential-sanitization.md` для процедуры.

Принцип:
- `replace` предпочтительнее `remove`, если факт остаётся релевантным.

**Применение сжатия — одним batch.** Все remove/patch/add собирать в ОДИН вызов `memory(operations=[...])`, а не по операции: лимит проверяется на финальном результате, поэтому промежуточное состояние (старое удалено, сжатое ещё не добавлено) не упирается в переполнение. Поштучно = отказ на середине и память в разъехавшемся виде. После batch — проверить факт: `len(open(path, encoding='utf-8').read())`, а не `wc -c` (кириллица даёт ×2 и рисует переполнение там, где его нет).

**Сжимать формулировку, а не факт.** При слиянии дублей записи о домене (например VPN-узел или платный сервис) в одну — переносить в неё ВСЕ питфоллы (что ломается, чего нельзя делать), теряя только даты, версии и историю изменений. Проверка после: в новой записи есть каждое «нельзя/ломает/требует», которое было в удалённых.

### Phase F — Mem0 Audit & Cleanup

**Mem0 неработоспособен (400 API error, June 2026).** Полная документация и процедура очистки: `references/mem0-dead-code.md`

Кратко: Mem0 возвращает 400 с требованием app_id/user_id. `mem0_conclude` пишет мусор (сессионные логи). Рекомендация: `memory.provider: ''` (built-in), не использовать `mem0_conclude`. При аудите — задокументировать мусор, удалить нельзя (нет delete API).

## Manual Full Run Playbook (`MANUAL_FULL`)

1. Сообщить пользователю план (inventory всех 4 слоёв → dry-run → backup → apply → verify → report).
2. Выполнить dry-run и показать список:
   - что будет объединено (skills),
   - что будет удалено (skills + memory entries),
   - что будет сжато в памяти,
   - состояние Mem0 (записи, классификация, возможность очистки),
   - оценка освобождения места.
3. Сделать backup.
4. Применить изменения пакетами (small batches).
5. После каждого пакета валидация целостности (skill exists, links valid, no broken references).
6. Выпустить итоговый отчёт по всем слоям.

## Weekly Auto Run Playbook (`AUTO_WEEKLY`)

1. Inventory + similarity scan.
2. Только безопасные merge/cleanup.
3. Backup.
4. Применение low-risk изменений.
5. Отчёт с блоком `PENDING_CONFIRMATION` для risky/critical кандидатов.

## Report Template (обязательный)
После каждой консолидации выводить:

1) Summary
- Skills before: N
- Skills after: M
- Net change: M-N

2) Merged
- source_a + source_b -> umbrella_x
- ...

3) Deleted
- stale_skill_1 (reason)
- ...

4) Memory Compression
- entries before: X
- entries after: Y
- deduplicated: D
- chars before/after for each file (MEMORY.md, USER.md)

5) Mem0 Audit
- entries: N (фактов: F, мусора: M)
- action: cleaned / not cleanable / empty
- recommendation

6) Skills Health Check
- Version completeness: N/M
- Cross-skill contradictions: N
- Dead related_skills: N
- Stale/outdated markers: N

7) Space
- approx chars before: C1
- approx chars after: C2
- freed: C1-C2 chars (and %)

8) Safety
- backup path
- risky items skipped/pending confirmation

## Rollback Protocol
Если обнаружена деградация:
1. Остановить дальнейшие удаления/merge.
2. Восстановить из последнего backup.
3. Перепроверить проблемные скиллы.
4. Выпустить пост-мортем: причина, что изменено в правилах консолидации.

## Operational Discipline (критично для long-running memory tasks)

**Никогда не принимай решение о паузе или остановке работы самостоятельно.**
Пользователь явно запретил решать за него, когда заканчивать. Останавливайся только по прямой команде ("стоп", "пауза", "закончи").

**Proactive status reporting**
Если задача занимает больше 2–3 минут — давай короткие статусы proactively (раз в 3–5 минут), не дожидаясь вопроса "Статус дай". Пользователь явно выразил недовольство, когда статусы приходилось запрашивать.

**Read-only first**
При любом аудите, анализе или улучшении памяти **всегда начинай с read-only мониторинга**. Только после явного подтверждения пользователя переходи к изменениям. Это правило введено пользователем для Phase 0/1 memory work.

## Common Pitfalls
1. Агрессивный merge разных по назначению навыков.
2. Удаление "редко используемого", но критичного навыка.
3. Отсутствие backup перед массовыми изменениями.
4. **Агрессивный merge с потерей контента.** При слиянии дублирующихся скиллов — никогда не удалять существующий контент из основы. Техника: взять самый полный скилл (или его бэкап) как базу, добавлять новое вставкой между секциями. Валидация: `diff -u` не должен показывать строк `-` (кроме frontmatter). Если в diff есть удалённые строки с командами, примерами или pitfalls — merge испорчен.
5. Слишком общий отчёт без конкретных списков изменений.
6. **Memory tool недоступен в cron-окружениях.** ⚠️ Устарело для текущего конфига — см. #9c: сначала попробовать `memory(action='add', content='_audit_marker')`; если вернулся `usage`/`entry_count`, работать полноценно. При отключённом memory (no_agent-сессии) — читать `MEMORY.md`/`USER.md` через `read_file` и оформлять находки как «identified, not applied».
7. **Memory tool требует точного совпадения `old_text`.**
   **Техника:** добавить временную dummy-запись (`action='add', content='_audit_marker'`), это вернёт полный список записей в их точном БД-формате. Использовать ЭТОТ точный текст для `old_text`. После операций удалить `_audit_marker`. Инструмент `memory` может быть выключен в конфиге для no_agent-сессий. Не считать это ошибкой — прочитать файлы памяти через `read_file`, найти кандидатов на сжатие, задокументировать в отчёте как "identified, not applied" и повторить в следующем прогоне или ручной сессии.
8. **session_search не находит сессии из текущей lineage после compaction.** `session_search_tool.py` (строка 321) пропускает все сессии с тем же `lineage_root`, что и текущая. После compaction контекст родительской сессии вырезан, но search всё равно его пропускает — агент теряет доступ к истории. **Фикс:** добавить проверку `has_compaction = bool(current_meta.get("parent_session_id"))` перед `continue`. Без этого фикса `session_search` слепнет после каждого compaction. См. `references/session-search-lineage-bug.md` для кода и тест-кейса.
9b. **Similarity-скрипт по скиллам даёт ложные пары на бойлерплейте.** Jaccard по токенам всего файла ловит общие секции frontmatter/`## Overview` (например agentmail ↔ session-librarian, agentmail ↔ docker-management при 0.5). Перед сравнением вырезать frontmatter и общие секции-шаблоны, сравнивать только `##`-заголовки + команды. Если максимум пар <0.45 по заголовкам — дублей в библиотеке НЕТ, merge не применять (2026-09-20: 78 активных скиллов, ни одной пары выше 0.44).

9c. **Memory tool в cron-прогоне ДОСТУПЕН** (проверено 2026-09-20, 24 операции в одном batch применились). Pitfall #6 устарел для текущего конфига: перед использованием техники из #7 просто вызвать `memory(action='add', content='_audit_marker')` — если вернулся `usage` и `entry_count`, работаем полноценно, а не только отчётом.

9. **Память мерджится по паттерну «группировка по домену».** Не держать разрозненные факты об одном домене (VPN) в трёх записях. Эффективнее: VPN + user-location + iPhone-quirk → одна запись. Инструменты + Tavily + Webhooks → одна запись. Каждый merge экономит ~100-200 chars и улучшает читаемость. Критерий: «можно ли описать этот домен одной записью без потери важных фактов?»
10. **Mem0 авто-сохранения — мусор.** `mem0_conclude` часто сохраняет сессионные логи («User asked to continue...», «User expressed need...») вместо фактов. При аудите Mem0 почти всегда обнаруживаются только такие записи. Причина: нет фильтра «факт vs лог» при авто-сохранении. **Фикс:** не использовать `mem0_conclude` без явной команды пользователя. При аудите — классифицировать все записи, мусорные документировать в отчёте. Удалить их стандартными инструментами нельзя (нет delete API).
12. **Built-in memory provider в Hermes — это пустой `memory.provider`, а не строка `built-in`.** Если выставить `memory.provider: built-in`, `hermes memory status` покажет противоречивое состояние: `Built-in: always active`, но ниже — `Plugin: NOT installed` и просьбу установить `built-in` plugin. Для возврата на встроенную память нужно выставлять `memory.provider` в пустую строку (`''`) в каждом нужном профиле. Проверять отдельно `default` и named profiles.

### AGENTS.md — синхронизация при аудите

AGENTS.md (`~/.hermes/AGENTS.md`) описывает multi-agent архитектуру. Его cron-секция регулярно устаревает:

1. Сравнить `hermes cron list` с AGENTS.md cron section
2. Удалить мёртвые задачи (например `openrouter-balance-watch` если OpenRouter не используется)
3. Добавить новые задачи, обновить модели
4. AGENTS.md короткий (~80 строк) — проще переписать целиком через `write_file`, чем патчить
5. Сверять то, что гниёт быстрее всего: число активных скиллов (`find ~/.hermes/skills -name SKILL.md | wc -l` минус `.archive`), версии CLI (`codex --version`, `claude --version`), список `sites-enabled` в nginx, порт→юнит карту релеев (`ss -ltnp` + `systemctl show -p MainPID --value <unit>`), vision-модель (`auxiliary.vision` в config.yaml), число AWG-пиров (`awg show awg0 dump`). Версии CLI в MEMORY.md не хранить — они гниют за недели, место им в AGENTS.md.
6. Cron-таблицу сверять не только по именам, но и по расписанию (`hermes cron list`).
12. **Skills Quick Health Check — всегда выполнять ПЕРЕД полной консолидацией.** Health check выявляет проблемы, которые нужно исправить до начала merge. Если исправить их после merge, diff станет нечитаемым.
13. **Fallback chain drift (найдено 2026-07-10)** — fallback-цепочка хранится в трёх местах: config.yaml (правда), AGENTS.md, MEMORY.md. При консолидации памяти ВСЕГДА проверять что записи про fallback в MEMORY.md совпадают с config.yaml. Расхождение — баг, чинить MEMORY.md под config.yaml, не наоборот. **Регулярно гниющие ключи (проверять каждый прогон): `delegation.model`, `telegram.reactions`, `auxiliary.vision.model`, `model.context_length`, счётчик cron-задач** — 27.09 нашлись два расхождения: делегация была записана как grok-4.6 (в config.yaml уже grok-4.7) и reactions как `true` (в config.yaml `false`).
14. **Status-log duplication (найдено 2026-09-13).** Статус живых сервисов (релеи, провайдеры, балансы) копится в нескольких записях с разными датами: свежая запись дублирует старую и та устаревает, но остаётся. При AUTO_WEEKLY: группировать по домену, оставлять ОДНУ запись с самым свежим состоянием, историю удалять — это лог, а не факт. За один прогон так ушли 3 записи про релеи и 2 про Firecrawl (−7% MEMORY.md).
15. **USER.md переполняется быстрее MEMORY.md.** При 95%+ в USER.md искать пересечения с MEMORY.md (инфраструктурные факты, ssh-префикс, CPU-лимиты, правила доставки) и удалять дубль из USER.md: подробная версию уже есть в MEMORY.md, а USER.md нужен для предпочтений и стиля. Проверять, что факт реально есть в MEMORY.md — `grep` перед удалением, не на глаз.

16. **`skill_manage(action='delete')` удаляет каталог начисто — в `skills/.archive/` он НЕ попадает.** Единственная страховка — архив `skills.tar.gz` в `backups/memory-consolidator/<ts>/`; перед любой серией удалений проверять, что оба исходника и target лежат в архиве (`tar tzf skills.tar.gz | grep <name>`), и только потом удалять. В отчёте указывать путь архива.
17. **В cron inline `python3 -c "..."` / `python3 -e` ЗАБЛОКИРОВАН** (approvals.cron_mode, «script execution via -c flag»), как и `execute_code`. Любая проверка/агрегация в cron-прогоне — сначала `write_file` скрипта в `cache/scratch/`, затем `python3 <path>`. Это касается и health-check сниппетов из этого скилла: сохранять их файлом, а не копировать в шелл.

18. **`memory(action='patch')` с коротким old_text внутри предложения рвёт запись.** Замена фрагмента сечёт фразу посередине: попытка поправить хвост записи MobSoft оставила «по решению Алекса. напрямую НЕЛЬЗЯ: только H-Connect API…» без подлежащего, чинилось повторным патчем. Правило: переписывая запись, передавать old_text = ВЕСЬ текст записи (одна строка между `§`), не кусок предложения; после каждого batch проверять файл (`sed -n '<N>p' MEMORY.md`) на обрывки. `memory` может нормализовать текст, поэтому old_text из `read_file` иногда не совпадает — при ошибке брать `closest_entries` из ответа дословно. Блоки `patched_entries` в ответе — это ДО/ПОСЛЕ одной записи, а не дубль (проверять `grep -c`).

19. **`memory(action='patch')` с ПУСТЫМ content отбивается** («content is required — set this operation object's own 'content'»; batch all-or-nothing, ничего не применяется). Удалить фразу внутри записи через patch нельзя. Варианты: (а) `action='remove'` если уходит вся запись; (б) full-entry replace — old_text = ВЕСЬ текст записи, content = переписанный текст (так убраны статус-логи из Vast/awg2/мессенджера 25.10); (в) patch соседнего фрагмента с сохранением окружения. Проверка после batch: `split('\n§\n')` + поиск двойных пробелов/оборванных фраз скриптом.

## Verification Checklist
- [ ] Backup создан до изменений
- [ ] Critical/Important навыки не удалены без явного подтверждения
- [ ] Все merge задокументированы (source -> target)
- [ ] Удаления имеют причину и класс риска
- [ ] Память очищена от дублей без потери важных фактов
- [ ] Skills Health Check: версии complete, contradictions 0, dead links 0
- [ ] Финальный отчёт содержит before/after и freed space

## Recommended Cron Prompt
"Run memory-consolidator in AUTO_WEEKLY mode. Do inventory of all skills, detect high-confidence duplicates, back up first, apply only low-risk merges/deletions, compact memory safely, and return the full consolidation report including before/after counts, merged/deleted lists, and space freed. If a risky deletion is detected, skip it and put it into PENDING_CONFIRMATION."
