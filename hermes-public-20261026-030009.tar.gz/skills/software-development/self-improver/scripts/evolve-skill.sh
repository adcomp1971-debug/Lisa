#!/usr/bin/env bash
# evolve-skill.sh — weekly self-evolution: round-robin through skills
# Installed by Fable 5 plan (June 2026)
# Cron: weekly-self-evolution, Sun 05:00, no_agent=true

set -euo pipefail

ENV_FILE="$HOME/.hermes/.env"
STATE_FILE="/tmp/evolve-state.txt"
SCRIPT_LOG="/root/.hermes/logs/evolve-skill.log"
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)

# Skills in round-robin order (only those with SKILL.md)
SKILLS=("web-research" "task-router-production" "systematic-debugging")
NUM_SKILLS=${#SKILLS[@]}

# Source API key
[ -f "$ENV_FILE" ] && source "$ENV_FILE" 2>/dev/null || true
: "${OPENROUTER_API_KEY:?OPENROUTER_API_KEY not found}"

# Determine which skill to evolve (round-robin)
if [ -f "$STATE_FILE" ]; then
    IDX=$(cat "$STATE_FILE" 2>/dev/null || echo -1)
    IDX=$(( (IDX + 1) % NUM_SKILLS ))
else
    IDX=0
fi

SKILL="${SKILLS[$IDX]}"
echo "$IDX" > "$STATE_FILE"

echo "$TS Starting evolution: $SKILL (index $IDX/$NUM_SKILLS)" >> "$SCRIPT_LOG"

cd /root/hermes-agent-self-evolution
export HERMES_AGENT_REPO=/usr/local/lib/hermes-agent

EVOLVE_OUTPUT=$(python3 -m evolution.skills.evolve_skill \
  --skill "$SKILL" \
  --iterations 3 \
  --eval-source synthetic \
  --optimizer-model "openrouter/google/gemini-2.5-flash" \
  --eval-model "openrouter/google/gemini-2.5-flash" 2>&1) || true

echo "$TS --- Evolution output (last 15 lines) ---" >> "$SCRIPT_LOG"
echo "$EVOLVE_OUTPUT" | tail -15 >> "$SCRIPT_LOG"

# Extract scores
BASELINE=$(echo "$EVOLVE_OUTPUT" | grep -oP 'Baseline score: \K[\d.]+' | tail -1 || echo "0")
EVOLVED=$(echo "$EVOLVE_OUTPUT" | grep -oP 'Evolved score: \K[\d.]+' | tail -1 || echo "0")
BEST=$(echo "$EVOLVE_OUTPUT" | grep -oP 'Best score so far: \K[\d.]+' | tail -1 || echo "0")

echo "$TS Baseline: $BASELINE, Best: $BEST" >> "$SCRIPT_LOG"

IMPROVEMENT=$(echo "$BEST - $BASELINE" | bc -l 2>/dev/null || echo "0")
echo "$TS Improvement: $IMPROVEMENT points" >> "$SCRIPT_LOG"

THRESHOLD=10.0

CANDIDATE=$(find "/root/hermes-agent-self-evolution/output/$SKILL" -name 'evolved*.md' 2>/dev/null | sort | tail -1)

if [ -z "$CANDIDATE" ]; then
    echo "$TS No evolved candidate found" >> "$SCRIPT_LOG"
    exit 1
fi

if [ "$(echo "$IMPROVEMENT >= $THRESHOLD" | bc -l 2>/dev/null)" = "1" ]; then
    SKILL_PATH=$(find /root/.hermes/skills -maxdepth 3 -type d -name "$SKILL" 2>/dev/null | head -1)
    if [ -n "$SKILL_PATH" ] && [ -f "$SKILL_PATH/SKILL.md" ]; then
        cp "$CANDIDATE" "$SKILL_PATH/evolved-candidate.md"
        echo "$TS ✅ Improvement $IMPROVEMENT pts >= $THRESHOLD — saved candidate to $SKILL_PATH/evolved-candidate.md" >> "$SCRIPT_LOG"
    else
        cp "$CANDIDATE" "/tmp/evolve-$SKILL-candidate.md"
        echo "$TS ✅ Candidate saved to /tmp/evolve-$SKILL-candidate.md" >> "$SCRIPT_LOG"
    fi
else
    cp "$CANDIDATE" "/tmp/evolve-$SKILL-candidate.md"
    echo "$TS 📎 Improvement $IMPROVEMENT pts < $THRESHOLD — candidate to /tmp (not applied)" >> "$SCRIPT_LOG"
fi
