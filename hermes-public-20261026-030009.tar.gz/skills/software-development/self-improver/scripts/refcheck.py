#!/usr/bin/env python3
"""Reference checker for the Hermes skill library.

Usage: python3 refcheck.py [--verbose]

Why this exists: naive `grep -o 'references/[^ ]*'` produces a wall of false
positives, because (a) trailing punctuation is captured into the path,
(b) supporting files legitimately live in OTHER skills' dirs or in the global
~/.hermes/scripts/, and (c) placeholder lines like `assets/...` are prose.

Rule: a referenced file is "missing" only if its basename is not found ANYWHERE
under the skills tree or the script dirs. Report those, with the owning skill.
"""
import os, re, sys, collections

SK = os.path.expanduser("~/.hermes/skills")
SEARCH_ROOTS = [
    SK,
    os.path.expanduser("~/.hermes/scripts"),
    "/root/scripts",
    "/usr/local/lib/hermes-agent/scripts",
]
PREFIXES = ("references/", "scripts/", "templates/", "assets/")
PLACEHOLDER = re.compile(r"(\.\.\.|…|\bN\b|<|\*)$")


def index_files():
    idx = {}
    for R in SEARCH_ROOTS:
        if not os.path.isdir(R):
            continue
        for root, dirs, files in os.walk(R):
            if "/.git" in root:
                continue
            for f in files:
                idx.setdefault(f, []).append(os.path.join(root, f))
    return idx


def active_skills():
    out = []
    for root, dirs, files in os.walk(SK):
        if "SKILL.md" in files and "/.archive" not in root:
            out.append(os.path.join(root, "SKILL.md"))
    return out


def main():
    verbose = "--verbose" in sys.argv
    idx = index_files()
    missing, checked = [], 0
    for p in sorted(active_skills()):
        rel_skill = os.path.relpath(os.path.dirname(p), SK)
        body = open(p, encoding="utf-8", errors="replace").read()
        refs = set()
        for pref in PREFIXES:
            for m in re.findall(re.escape(pref) + r"[A-Za-z0-9_.\-/]*", body):
                m = m.rstrip(".,;:)]}\u00ab\u00bb`'\"")
                if PLACEHOLDER.search(m.split("/")[-1]):
                    continue
                if len(m.split("/")[-1]) < 4:
                    continue
                refs.add(m)
        for ref in refs:
            checked += 1
            base = os.path.basename(ref)
            local = os.path.join(os.path.dirname(p), ref)
            if os.path.exists(local) or base in idx:
                if verbose and base in idx and not os.path.exists(local):
                    print(f"OK(other) {rel_skill} -> {ref}  [{idx[base][0]}]")
                continue
            # assets/ внутри панели 3x-ui (go:embed) — это пути на удалённом хосте,
            # а не файлы репозитория: показываем как REMOTE, не считаем пропажей.
            if ref.startswith("assets/"):
                missing.append((rel_skill, ref, "REMOTE"))
                continue
            missing.append((rel_skill, ref, "MISS"))
    print(f"active skills: {len(active_skills())}, refs checked: {checked}, missing: {len(missing)}")
    real = 0
    for sk, ref, kind in missing:
        print(f"{kind} {sk:38s} {ref}")
        if kind == "MISS":
            real += 1
    return 1 if real else 0


if __name__ == "__main__":
    sys.exit(main())
