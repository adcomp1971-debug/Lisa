## Self-Evolution Pipeline (GEPA + DSPy)

The `hermes-agent-self-evolution` repo at `/root/hermes-agent-self-evolution/` provides genetic-algorithm skill optimization using DSPy + GEPA (ICLR 2026 Oral). Phase 1 optimizes SKILL.md files.

### Setup

Self-Evolution uses DSPy + litellm, which routes by model name prefix. OpenRouter works reliably; DeepSeek direct (`OPENAI_BASE_URL`) fails because litellm validates model IDs.

**Working setup (OpenRouter):**

```bash
# 0. Ensure the package is installed in the venv (once after clone)
cd /root/hermes-agent-self-evolution
.venv/bin/pip3 install -e .   # installs click, dspy, litellm, optuna

# 1. Source API key
source /root/.hermes/.env 2>/dev/null
export OPENROUTER_API_KEY
export HERMES_AGENT_REPO=/usr/local/lib/hermes-agent

# 2. (if needed) Symlinks in the repo skills/ dir block rglob
#    Evolution uses Path.rglob("SKILL.md") which doesn't follow symlinks.
#    Break the symlink and create a real directory:
#      rm /usr/local/lib/hermes-agent/skills/<category>/<skill-name>
#      mkdir -p /usr/local/lib/hermes-agent/skills/<category>/<skill-name>
#      cp ~/.hermes/skills/<category>/<skill-name>/SKILL.md /usr/local/lib/hermes-agent/skills/<category>/<skill-name>/

# 3. Run evolution
cd /root/hermes-agent-self-evolution
python -m evolution.skills.evolve_skill \
  --skill <name> \
  --iterations 3 \
  --eval-source synthetic \
  --optimizer-model "openrouter/google/gemini-2.5-flash" \
  --eval-model "openrouter/google/gemini-2.5-flash"
```

**What happens:**
- DSPy generates a synthetic eval dataset (train/val/holdout)
- Default (MIPROv2): optimizes instructions + few-shot examples
- With `--method gepa`: attempts text-level mutations via GEPA + `reflection_lm`
- Validates constraints (size ≤15K, growth ≤20%, YAML structure)
- Saves evolved variant to `output/<name>/evolved_FAILED.md` if constraints fail

### Cost
- ~$0.10-0.50 per run (Gemini 2.5 Flash via OpenRouter, 3 iterations). Cheap.

### What MIPROv2 actually optimizes
Unlike GEPA (which mutates the skill text), MIPROv2 optimizes the **instruction prompt + few-shot examples** for using the skill. The skill text itself stays unchanged (0% growth by design). The score improvement reflects better LLM understanding of when/how to apply the skill, not changes to the skill content.

## GEPA now available (wrapper adapter, Jun 2026)

GEPA imports, creates, and runs. The adaptation required:
1. A 5-argument metric wrapper `gepa_metric(gold, pred, trace, pred_name, pred_trace)` in `evolution/core/fitness.py` that ignores extra args and delegates to `skill_fitness_metric`
2. `--method gepa|miprov2` flag in `evolve_skill.py` (default: miprov2)
3. `reflection_lm` parameter passed to GEPA constructor (required — it generates mutation proposals)

### When to use which
- **MIPROv2 (default)**: instruction-level optimization. Faster, cheaper. Proven on web-research (+53%) and task-router-production (+12.5%).
- **GEPA (text-level)**: attempts to mutate the skill body. In testing (3 iterations on task-router-production), GEPA proposed a mutation but scored lower than baseline (30.8% vs 32.3%), so it kept the original. For 3-iteration runs, MIPROv2 is comparable or better. With 10+ iterations GEPA may outperform — test before committing.

### Known Pitfalls

1. **GEPA wrapper required**: GEPA requires a 5-argument metric `(gold, pred, trace, pred_name, pred_trace)`. The default `skill_fitness_metric` has a 3-argument signature. Use the `gepa_metric` wrapper adapter. Pass `--method gepa` to use it; default is `miprov2`. GEPA also requires `reflection_lm` — pass the configured `dspy.LM(...)` instance.

2. **Symlinks block rglob**: `Path.rglob("SKILL.md")` doesn't follow symlinks in Python 3.11. The Hermes agent repo at `/usr/local/lib/hermes-agent/skills/` has symlinks to `~/.hermes/skills/` for user-created skills. **Fix:** remove the symlink, create a real directory, copy the SKILL.md there:
   ```bash
   rm /usr/local/lib/hermes-agent/skills/<category>/<skill-name>
   mkdir -p /usr/local/lib/hermes-agent/skills/<category>/<skill-name>
   cp ~/.hermes/skills/<category>/<skill-name>/SKILL.md /usr/local/lib/hermes-agent/skills/<category>/<skill-name>/
   ```

3. **Size limit (15KB)**: evolved skill body must be ≤15,000 chars. If the base skill is close, compress first. This session compressed web-research from 22.5K → 7K chars.

4. **Constraint `skill_structure` always fails on body**: the validator checks `body` (content after YAML frontmatter) for `---`, `name:`, `description:`. Body correctly starts with `# Title`, not `---`. The failure is **expected and harmless**. The evolved variant still saves to `output/<name>/evolved_FAILED.md` — inspect it manually.

5. **`--hermes-repo /root/.hermes` doesn't work**: the evolution code expects a repo directory with `skills/` subdir. The user config dir `~/.hermes/` has a different layout. Use `HERMES_AGENT_REPO=/usr/local/lib/hermes-agent` env var instead.

6. **API key loading**: subprocesses don't auto-load Hermes `.env`. Source it explicitly before running:
   ```bash
   source /root/.hermes/.env 2>/dev/null
   export OPENROUTER_API_KEY
   ```

7. **OpenRouter model naming**: use exact OpenRouter model IDs (`openrouter/google/gemini-2.5-flash`). Add preview suffixes only if the model actually requires one. Check available models at openrouter.ai/api/v1/models.

8. **`pip` missing from `uv`-created venv**: the venv at `hermes-agent-self-evolution/.venv` may have no `pip` binary (only `pip3`/`pip3.11`). Use `pip3` or bootstrap it:
   ```bash
   /root/hermes-agent-self-evolution/.venv/bin/python -m ensurepip --upgrade
   ```
   Then install packages with `python -m pip install …` (not bare `pip`). If you get `ModuleNotFoundError: No module named 'click'`, run `pip install -e .` from the repo root to install all dependencies.

9. **`optuna` not in pyproject.toml**: MIPROv2 optimizer requires the `optuna` package but `pyproject.toml` only lists `dspy>=3.0.0` as a dependency (optuna is an optional extra). Install it explicitly:
   ```bash
   /root/hermes-agent-self-evolution/.venv/bin/python -m pip install optuna
   ```
   Without it, MIPROv2 fails with: `ImportError: MIPROv2 requires optional dependency 'optuna'.`

### Quick Test (1 iteration, dry run first)
```bash
# Dry run — validates setup without running optimization:
source /root/.hermes/.env 2>/dev/null
export OPENROUTER_API_KEY
export HERMES_AGENT_REPO=/usr/local/lib/hermes-agent
cd /root/hermes-agent-self-evolution
python -m evolution.skills.evolve_skill \
  --skill web-research \
  --iterations 1 \
  --eval-source synthetic \
  --optimizer-model "openrouter/google/gemini-2.5-flash" \
  --eval-model "openrouter/google/gemini-2.5-flash" \
  --dry-run

# Full run with MIPROv2 (default, recommended — 3 iterations, ~3 min):
python -m evolution.skills.evolve_skill \
  --skill web-research \
  --iterations 3 \
  --eval-source synthetic \
  --optimizer-model "openrouter/google/gemini-2.5-flash" \
  --eval-model "openrouter/google/gemini-2.5-flash"

# GEPA run (text-level mutations, experimental):
python -m evolution.skills.evolve_skill \
  --skill task-router-production \
  --method gepa \
  --iterations 3 \
  --eval-source synthetic \
  --optimizer-model "openrouter/google/gemini-2.5-flash" \
  --eval-model "openrouter/google/gemini-2.5-flash"
```

### Results Interpretation
- DSPy metric: 0-100% scale. Baseline ~33-42%, evolved typically ~48-52%. This is a **relative** score measured on the holdout set.
- Constraint-failed output → `output/<name>/evolved_FAILED.md`. **This is the normal output** — the skill content is preserved but the frontmatter validation on `body` always fails by design.
- Inspect the output manually: `cat output/<name>/evolved_FAILED.md`
- The skill text itself doesn't change (MIPROv2 optimizes instructions, not text). To see a diff, compare `skill_view(name)` output before and after.
- Apply threshold: only apply if score improved ≥8 points (smaller deltas are noise).

## Common Pitfalls
1. Editing skills based on anecdotes without evidence.
2. Expanding skills endlessly instead of improving clarity.
3. Ignoring outdated related_skills links.
4. Failing to update checklists after new failure classes emerge.
5. **OpenRouter key limit**: GPT-5.5 via OpenRouter hits total key limits under batch load (403 errors mid-iteration). For batch optimization, prefer DeepSeek Flash (cheap, reliable) or Gemini 3.1 Pro Preview (free). Single-skill optimization can use any model.
6. **Applying marginal improvements**: only copy `best.md` → real skill if SCORE improved by ≥8 points. Smaller deltas are noise — skip them. For cron auto-optimization, this threshold prevents churn.
7. **Reward hacking prevention**: use multi-metric scoring (not just chars). For skills: verify structure elements preserved. For memory: verify ALL fact categories, not just 3 critical ones. For code: tests must pass, benchmark must be deterministic.
8. **VPN/production OFF LIMITS**: never optimize vpn-manager, vpn-auto-doctor, vpn-safe, gatebox, or any skill touching live VPN clients.

## Verification Checklist
- [ ] Weekly review cadence is active
- [ ] Prioritization uses both usage and failure signals
- [ ] Each patch ties to a specific observed issue
- [ ] Updated skills include tighter triggers and verifiable steps
- [ ] Changes are summarized with rationale for future audits

## One-Shot Prompt Template
"Review skills updated or used this week. Identify top reliability gaps, patch the most impactful 1-3 skills, and produce a changelog with evidence, fixes, and verification updates."
