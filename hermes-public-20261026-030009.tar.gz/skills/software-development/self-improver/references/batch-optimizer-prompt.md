# Batch Skill Optimizer — Subagent Prompt Template

Copy-paste for `delegate_task` when optimizing skills in batch.

## Subagent Config

```yaml
toolsets: ["terminal", "file"]
```

## Task Structure

```json
{
  "goal": "Оптимизируй навык <SKILL_NAME> из песочницы. 12 итераций: читай SKILL.md в <SANDBOX_PATH>/SKILL.md, улучшай (сокращай воду, добавляй конкретику, улучшай структуру), применяй через patch. После каждых 4 итераций — SCORE (0-100): ясность, полнота, применимость. Сохрани лучшую версию в <SANDBOX_PATH>/best.md. Только песочница. Не меняй core-функциональность. Ответ: размер до/после, SCORE до/после, успешных итераций, ключевые изменения.",
  "context": "Оптимизируешь devops-скилл '<SKILL_NAME>'. Файл: <SANDBOX_PATH>/SKILL.md. Бэкап: original_backup.md. Запрещено трогать VPN-скиллы и прод. Стиль: коротко, по делу, без воды."
}
```

## Variables to Fill

| Variable | Example |
|---|---|
| `<SKILL_NAME>` | `accelerate` |
| `<SANDBOX_PATH>` | `/opt/hermes-sandbox/experiments/skill-wave1/accelerate` |

## Batch Launch Pattern

3 parallel → 2 parallel per wave (max 3 concurrent subagents):

```python
# Wave: first 3
delegate_task(tasks=[task1, task2, task3])

# Wave: remaining 2
delegate_task(tasks=[task4, task5])
```

## SCORE Rubric

- **Clarity (0-100)**: how well the skill communicates what to do
- **Completeness (0-100)**: coverage of triggers, edge cases, pitfalls
- **Applicability (0-100)**: how directly the instructions translate to action

## Optimization Moves (by priority)

1. **Remove water**: verbose explanations, duplicated intros, filler words
2. **Add structure**: tables instead of prose, bold headers, decision flows
3. **Tighten triggers**: merge "When to use" + "Don't use" into compact bullets
4. **Concrete commands**: replace "you should verify" with actual bash snippets
5. **Pitfall compression**: merge overlapping warnings, remove obvious ones
6. **Quick Reference**: add a compact lookup table at the end

## Anti-Moves (do NOT do)

- Do not change core logic or remove key commands
- Do not rewrite entire skill — patch incrementally
- Do not touch VPN skills (gatebox, vpn-*, ios-mobileconfig-vpn)
- Do not modify originals in `~/.hermes/skills/`
- Do not add new features — only improve existing content

## Model Selection

| Model | Batch? | Notes |
|---|---|---|
| DeepSeek V4 Flash | ✅ preferred | Cheap ($0.14/M), reliable, used in Waves 1-2 |
| Gemini 3.1 Pro Preview | ✅ good | Free, no key limits |
| GPT-5.5 (OpenRouter) | ❌ avoid | Hits total key limits under batch load (403 mid-iteration) |
| Claude Sonnet 4 | ⚠️ single only | Expensive, use for single-skill or HERMES.md only |

## HERMES.md Variant

Same task structure but with extra constraints in context:

```json
{
  "context": "Оптимизируешь HERMES.md — файл личности Гермеса. КРИТИЧНО: не трогай VPN-правила, не меняй смысл, не удаляй правила безопасности. Только форма.",
  "goal": "Оптимизируй HERMES.md. 12 итераций. SCORE каждые 4. Сохрани best.md. Ответ: размер до/после, SCORE, ключевые изменения."
}
```

**Post-apply verification**: `grep -c "vpn-safe\\|YES, DO IT" best.md` — must match original count.
