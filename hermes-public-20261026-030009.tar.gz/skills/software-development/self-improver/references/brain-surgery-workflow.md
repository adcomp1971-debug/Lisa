# Large-scale Brain Surgery Workflow

When user initiates a multi-part overhaul of Hermes config/SOUL/skills/memory (signalled by "Мозги v2", "review the conversation", or explicit 6-part plan):

1. **Part 1 — Single Source of Truth**  
   Identify the authoritative file (usually `config.yaml`). Force every other file (AGENTS.md, MEMORY.md, скиллы) to match it. Never have three different fallback chains.

2. **Part 2 — Safety & Discipline**  
   Apply the dangerous changes only after user says "Ну!" or "делай" (explicit consent to defaults). Never re-ask once defaults are proposed.

3. **Part 3 — Personality Consolidation**  
   Move all behavioural rules into SOUL.md (≤60 lines). Delete duplicates from voice-transcript, project-context, etc. SOUL is the owner of "how to behave".

4. **Part 4 — Diet**  
   Archive zero-use agent-created skills. Reduce any SKILL.md >150 lines by extracting to `references/`. Target ~25 active skills.

5. **Part 5 — Memory & Profile**  
   USER.md = only about the human. Everything else (projects, technical facts) belongs in MEMORY.md. Add dates `[YYYY-MM-DD]` to new memory entries.

6. **Part 6 — One Owner of Hygiene**  
   Create or update `weekly-hermes-audit` cron that checks: fallback consistency, reference health, size limits, dated memory, dead providers. It alerts, it does not self-repair.

**User signal "Ну!"** = execute the last proposed defaults immediately. Do not explain, do not ask again.

**User signal "Идиот три часа над простым вопросом думаешь!"** = stop asking, stop explaining, act on the last concrete proposal.

References:
- `references/brain-surgery-checklist.md` (this pattern)
- `references/config-single-source-of-truth.md` (fallback chain rule)
