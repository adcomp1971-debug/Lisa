# Diagnostic Commands — Evidence Collection for Self-Improver

Repeatable commands for the "Collect evidence" phase of the weekly improvement loop.
Run these from `terminal` — they scan filesystem and session DB without loading full skill contents into context.

## 1. Recently Modified Skills

Find skills that changed in the past N days, sorted by most recent:

```bash
find ~/.hermes/skills -name "SKILL.md" -printf '%TY-%Tm-%Td %TH:%TM %s %p\n' | sort -rn | head -40
```

Column format: `YYYY-MM-DD HH:MM SIZE_BYTES /path/to/SKILL.md`.

Use to: identify which skills were patched, created, or updated since the last review. Focus on 24-72h window.

**Filter by date** (skills modified since a specific date):
```bash
find ~/.hermes/skills -name "SKILL.md" -newer /tmp/reference_date -printf '...'
touch /tmp/reference_date  # set new baseline
```

## 2. Detect Duplicate Sections Within a Skill

Quick test for internal duplication (same heading appearing more than once):

```bash
grep -c "^## Urgent action trigger" path/to/SKILL.md
# Output: 2 => duplicate!
```

For all H2 headings:
```bash
grep "^## " path/to/SKILL.md | sort | uniq -c | sort -rn | head -10
# Output: "2 ## Section Name" = duplicate detected
```

For sub-headings (H3):
```bash
grep "^### " path/to/SKILL.md | sort | uniq -c | sort -rn | head -10
```

## 3. Size Baseline (Before/After Tracking)

Record sizes before and after patches:

```bash
wc -c ~/.hermes/skills/<category>/<name>/SKILL.md
```

Compare against previous run's reported sizes from the changelog.

## 4. Session Search for Failure Signals

Find sessions where a skill was used and may have failed:

```bash
# From inside Hermes: use session_search tool
session_search(query="skill_name correction error fix", limit=5, sort="newest")
```

The session DB is the best source of truth for real-world failures. Cross-reference with file timestamps — a skill modified at the same time as a failure session is a strong signal.

## 5. Verify No Protected Skills Were Touched

After any modifications, ensure VPN/production skills are intact:

```bash
for skill in vpn-manager gatebox vpn-auto-doctor ios-mobileconfig-vpn vpn-safe; do
  [ -f "$HOME/.hermes/skills/devops/$skill/SKILL.md" ] && echo "✓ $skill exists" || echo "✗ $skill MISSING"
done
```

## 6. Calculate Total Space Freed

After patching, sum up savings:

```bash
echo "=== Size deltas ==="
# Get latest sizes
find ~/.hermes/skills -name "SKILL.md" | xargs wc -c | sort -rn | head -5
```

Compare against previous run's report from session_search.

## Usage Pattern

Primary: run commands 1-3 at the start of each self-improver session to build the evidence foundation.
Secondary: command 5 as the final safety check before producing the changelog.
