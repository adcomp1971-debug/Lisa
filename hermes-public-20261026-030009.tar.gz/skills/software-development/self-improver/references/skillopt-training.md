## SkillOpt — Systematic Text-Space Skill Optimizer (Microsoft Research)

SkillOpt (`microsoft/SkillOpt`, v0.1.0 on PyPI) trains skills with the discipline of weight-space optimization: a separate optimizer model converts scored rollouts into bounded add/delete/replace edits on a single skill document, accepted only when validation score strictly improves. **Outperforms GEPA, TextGrad, EvoSkill, Trace2Skill on all 52 evaluated cells.** Code: https://github.com/microsoft/SkillOpt — Docs: https://microsoft.github.io/SkillOpt/

### How it works (6-stage loop)

| Stage | Analogy | Action |
|-------|---------|--------|
| Rollout | Forward pass | Frozen target model runs tasks with current skill, records scored trajectories |
| Reflect | Backward pass | Optimizer analyzes failure/success minibatches separately |
| Aggregate | Gradient accumulation | Hierarchical merge of patches |
| Select | Weight clipping | Rank and select top edits under budget |
| Update | Weight update | Bounded add/delete/replace on skill document |
| Gate | Validation | Accept only if held-out score strictly improves |

**Stability mechanisms:** textual learning rate (edit budget), rejected-edit buffer, epoch-wise slow/meta update, optimizer-side meta skill.

### Installing

```bash
git clone https://github.com/microsoft/SkillOpt.git
python -m venv ~/skillopt-venv
source ~/skillopt-venv/bin/activate
pip install skillopt
# OR from repo (for scripts/):
cd SkillOpt && pip install -e .
```

### Configuring models for non-Azure backends (Grok, DeepSeek, etc.)

SkillOpt's `openai_chat` backend (`azure_openai.py`) actually wraps the OpenAI SDK. It supports both Azure OpenAI and OpenAI-compatible APIs via auth mode switching. For non-Azure APIs (xAI/Grok, DeepSeek, OpenAI direct), use `openai_compatible` auth mode.

**Required env vars (all MUST be set before launching Python):**

```bash
# Shared endpoint & key
export AZURE_OPENAI_ENDPOINT="https://api.x.ai/v1"    # or https://api.deepseek.com/v1
export AZURE_OPENAI_API_KEY="$XAI_KEY"                 # or $DEEPSEEK_API_KEY
export AZURE_OPENAI_AUTH_MODE="openai_compatible"      # tells _make_client to use OpenAI(), not AzureOpenAI()

# Per-role overrides (same values when both use same provider)
export OPTIMIZER_AZURE_OPENAI_ENDPOINT="${AZURE_OPENAI_ENDPOINT}"
export OPTIMIZER_AZURE_OPENAI_AUTH_MODE="${AZURE_OPENAI_AUTH_MODE}"
export OPTIMIZER_AZURE_OPENAI_API_KEY="${AZURE_OPENAI_API_KEY}"
export TARGET_AZURE_OPENAI_ENDPOINT="${AZURE_OPENAI_ENDPOINT}"
export TARGET_AZURE_OPENAI_AUTH_MODE="${AZURE_OPENAI_AUTH_MODE}"
export TARGET_AZURE_OPENAI_API_KEY="${AZURE_OPENAI_API_KEY}"

# Model deployments (model names for xAI/DeepSeek, NOT Azure deployments!)
export OPTIMIZER_DEPLOYMENT="grok-4.20-0309-reasoning"  # or "deepseek-chat"
export TARGET_DEPLOYMENT="grok-4.3"                     # or "deepseek-chat"
```

**Why auth_mode matters:** When `auth_mode = "openai_compatible"`, `_make_client()` creates a plain `OpenAI()` client with your `base_url` and `api_key`. Without it, it defaults to `azure_cli` auth mode which tries Azure AD token acquisition and fails.

**Config structure** (hierarchical YAML with `_base_` inheritance):

```yaml
_base_: ../../_base_/default.yaml

model:
  azure_openai_endpoint: https://api.x.ai/v1
  azure_openai_auth_mode: openai_compatible
  optimizer_azure_openai_endpoint: https://api.x.ai/v1
  optimizer_azure_openai_auth_mode: openai_compatible
  target_azure_openai_endpoint: https://api.x.ai/v1
  target_azure_openai_auth_mode: openai_compatible
  optimizer: grok-4.20-0309-reasoning
  target: grok-4.3
  optimizer_backend: openai_chat
  target_backend: openai_chat
  reasoning_effort: ""     # ← GROK DOES NOT SUPPORT reasoningEffort PARAMETER!
```

**CRITICAL pitfall — `reasoning_effort` with Grok:** xAI models (grok-4.3, grok-4.20-0309-reasoning) do NOT support the `reasoningEffort` parameter that SkillOpt sends. Set `reasoning_effort: ""` (empty string) in the config to skip it. Otherwise you get: `Error code: 400 - 'Model grok-4.20-0309-reasoning does not support parameter reasoningEffort.'`

### Running (verified working sequence)

```bash
# 1. Activate venv
source ~/skillopt-venv/bin/activate

# 2. Set PYTHONPATH to SkillOpt repo root (needed for scripts/ and configs/)
export PYTHONPATH="/path/to/SkillOpt:${PYTHONPATH:-}"

# 3. Set ALL env vars (see matrix above)
export XAI_KEY="..."
export AZURE_OPENAI_ENDPOINT="https://api.x.ai/v1"
export AZURE_OPENAI_API_KEY="$XAI_KEY"
export AZURE_OPENAI_AUTH_MODE="openai_compatible"
export OPTIMIZER_AZURE_OPENAI_ENDPOINT="${AZURE_OPENAI_ENDPOINT}"
export OPTIMIZER_AZURE_OPENAI_AUTH_MODE="${AZURE_OPENAI_AUTH_MODE}"
export OPTIMIZER_AZURE_OPENAI_API_KEY="${AZURE_OPENAI_API_KEY}"
export TARGET_AZURE_OPENAI_ENDPOINT="${AZURE_OPENAI_ENDPOINT}"
export TARGET_AZURE_OPENAI_AUTH_MODE="${AZURE_OPENAI_AUTH_MODE}"
export TARGET_AZURE_OPENAI_API_KEY="${AZURE_OPENAI_API_KEY}"
export OPTIMIZER_DEPLOYMENT="grok-4.20-0309-reasoning"
export TARGET_DEPLOYMENT="grok-4.3"

# 4. Run
cd /path/to/SkillOpt
python scripts/train.py \
  --config configs/searchqa/xai_test.yaml \
  --out_root /path/to/outputs
```

### Fallback chain (Grok → DeepSeek)

Both use `openai_chat` backend with the same env vars. Implement fallback via a wrapper script that swaps env vars on API error:

```bash
#!/usr/bin/env bash
# skillopt-run.sh — run with Grok, fallback to DeepSeek on 400/429/5xx
set -euo pipefail

PRIMARY_URL="https://api.x.ai/v1"
PRIMARY_KEY="..."
FALLBACK_URL="https://api.deepseek.com/v1"
FALLBACK_KEY="..."

run_with() {
  local endpoint="$1" key="$2"
  export AZURE_OPENAI_ENDPOINT="$endpoint"
  export AZURE_OPENAI_API_KEY="$key"
  export AZURE_OPENAI_AUTH_MODE="openai_compatible"
  export OPTIMIZER_DEPLOYMENT="grok-4.20-0309-reasoning"
  export TARGET_DEPLOYMENT="grok-4.3"
  python scripts/train.py "$@"
}

run_with "$PRIMARY_URL" "$PRIMARY_KEY" "$@" \
  || { echo "→ Fallback to DeepSeek"; \
       run_with "$FALLBACK_URL" "$FALLBACK_KEY" "$@"; }
```

### Model selection

| Role | Recommendation | Why |
|------|---------------|-----|
| Target (rollouts) | DeepSeek V4 Flash, Grok 4.3 | Cheap ($0.15/M or free). Many calls needed. |
| Optimizer (reflection) | Grok 4.20 reasoning, DeepSeek V4 Pro | Needs reasoning to analyze trajectories and propose edits. Fewer calls. |
| Analyst (reflection within optimizer) | Same as optimizer | Part of the same reflection pipeline. |

### How the backend routing works

SkillOpt has TWO levels of backend selection:

1. **`optimizer_backend` / `target_backend`** (from config/`backend_config.py`) — chooses which module handles calls: `openai_chat` → `azure_openai.py`, `claude_chat` → `claude_backend.py`, `qwen_chat` → `qwen_backend.py`, etc.
2. **`auth_mode`** (inside `azure_openai.py`) — when backend is `openai_chat`, auth_mode determines if it creates an `AzureOpenAI()` client (Azure) or a plain `OpenAI()` client (openai_compatible).

The deployment names come from `OPTIMIZER_DEPLOYMENT` / `TARGET_DEPLOYMENT` env vars, NOT from the endpoint URL itself.

Both optimizer and target clients use the SAME `AZURE_OPENAI_ENDPOINT` and `AZURE_OPENAI_API_KEY` when both use `openai_chat` backend. Per-role overrides exist but are only needed when using different providers.

### Deploying the optimized skill

Training outputs a `best_skill.md` (300–2000 tokens) — drop it as any skill file. Zero extra inference cost.

### SkillOpt-Sleep (deployment-time companion)

Plugins for Claude Code, Codex, Copilot that give the agent a nightly sleep cycle:
1. Harvest session transcripts
2. Mine recurring tasks
3. Replay offline
4. Consolidate (reflect → bounded edit → gate on real held-out tasks)
5. Stage proposal → user adopts

```bash
# From the SkillOpt repo:
bash plugins/codex/install.sh    # Codex → /sleep
```

## Self-Evolution Pipeline (GEPA + DSPy)

The `hermes-agent-self-evolution` repo at `/root/hermes-agent-self-evolution/` provides genetic-algorithm skill optimization using DSPy + GEPA (ICLR 2026 Oral). Phase 1 optimizes SKILL.md files.

### Setup

Self-Evolution uses DSPy + litellm, which routes by model name prefix. OpenRouter works reliably; DeepSeek direct (`OPENAI_BASE_URL`) fails because litellm validates model IDs.

