---
name: code-sandbox
description: "Run risky/untrusted code in an isolated Docker sandbox."
version: 1.0.0
author: Hermes Agent
metadata:
  hermes:
    tags: [sandbox, docker, isolation, security, code-execution]
---

# Code Sandbox

Неизвестный/рискованный код (сгенерированный LLM, скачанный, экспериментальный) запускать **только** через `hermes-sandbox` — не в основном терминале. Основной терминал = прод-система (gateway, VPN, `/root/.hermes`, секреты); падение/вред из него ломает живые сервисы.

## Использование

```bash
hermes-sandbox run /path/script.py     # запустить файл (.py/.sh/.js) — монтируется ro
hermes-sandbox sh "команда"            # bash-команда
hermes-sandbox py < script.py          # Python из stdin
echo '<код>' | hermes-sandbox py
hermes-sandbox net /path/script.py     # с сетью (по умолчанию сеть ВЫКЛЮЧЕНА)
hermes-sandbox test                    # самопроверка изоляции
```

Переменные: `SANDBOX_TIMEOUT` (30с), `SANDBOX_MEM` (512m), `SANDBOX_CPUS` (1), `SANDBOX_NET` (none/bridge).

## Что гарантировано (проверено)

| Проверка | Результат |
|---|---|
| `/root/.hermes`, прод-файлы | Permission denied |
| Сеть (по умолчанию) | Network is unreachable |
| Пользователь | uid=1001 (non-root), non-privileged |
| Лимит памяти 512М (запрос 900М) | OOM-kill, rc=137 |
| Таймаут 10с (бесконечный цикл) | прервано через 10с |
| Мусорные контейнеры после | 0 |

Параметры изоляции: `--network none`, `--memory`, `--cpus`, `--pids-limit 128`, `--read-only` + tmpfs `/tmp`, `--security-opt no-new-privileges`, `--cap-drop ALL`, `-u 1001:1001`.

## Питфоллы

- **`timeout N docker run` НЕ работает**: docker CLI игнорирует SIGTERM, контейнер остаётся жить и жрёт CPU (проверено: 84% CPU × 5 мин на бесконечном цикле, нагрузка до 1.16). В `hermes-sandbox` контейнер убивает отдельный фоновый процесс по имени — не убирать эту логику.
- **`--read-only` + монтирование файла**: рабочая директория `/work` только для чтения, писать можно лишь в `/tmp` (tmpfs 64 МБ).
- **Образ**: `hermes-sandbox:latest` (Python 3.12.13, bash, node) — на базе `hermes-box/agent:local` + user `sandbox`. Пересобрать: `docker build -t hermes-sandbox:latest /root/sandbox/`.
- **Не использовать для прод-задач**: VPN, nginx, gateway, systemd — из sandbox недоступны (это цель, не баг).
- **Hostinger 4 CPU**: не запускать больше 1-2 контейнеров разом, `--cpus 2` максимум — иначе Hermes начнёт отваливаться (load > 6).

## Когда НЕ нужен

Простые read-only команды (`ls`, `grep`, `cat`), работа с прод-сервисами, правка конфигов — основной терминал. Sandbox — для кода, который может упасть, зависнуть или навредить.
