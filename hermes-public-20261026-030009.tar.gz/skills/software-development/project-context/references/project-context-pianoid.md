# Buratino (Pianoid v5) — Project Context

## Project Root
`/root/buratino/`

## What it is
Expressive MIDI generation from dry score. Custom model from scratch (no external pretrained).
Two-stage macro/micro training. MIDI only — no audio rendering.

## Architecture: Two-Stage Macro/Micro
- **Stage 1 (Macro):** predict tempo curve, dynamic contour, phrase shaping from MusicXML structure
- **Stage 2 (Micro):** predict per-note residuals (Δonset, Δvelocity, Δarticulation per-voice) conditioned on macro context
- Macro encoder fine-tuned in Stage 2 (LR 1:10, NOT frozen)

## Dataset: ASAP only
- 235 pieces, 1067 pairs, 921 performers, 17 composers
- Has: xml_score.musicxml + midi_score.mid + performer*.mid
- MAESTRO NOT used (no scores, only performance MIDI)
- Path: `/root/buratino/data/asap-dataset/`

## Alignment: DTW via parangonar (97%)
- Old greedy matching: 47% (lost 53% data)
- DTW (DualDTWNoteMatcher): 97% correspondence

## Key Files
```
PROMPT.md              ← main design doc
STATUS.md              ← current status
data/asap-dataset/     ← ASAP dataset
src/                   ← v5 code (to be written)
ref/                   ← v4.3 code for reference (do NOT run)
checkpoints/           ← v5 checkpoints
```

## Model Workflow
- GLM 5.2: writes code, architecture, Prism verification
- DeepSeek V4 Flash: monitors training on Vast, sends MIDI
- DeepSeek V4 Pro: fallback

## Critical Rules
- All old versions (v3/v4/v4.1/v4.3/pianoid-dima) DELETED. Do NOT reference old paths.
- Pianist Transformer removed — custom model only.
- MIDI only — no audio rendering (no FluidR3/FluidSynth).
- Per-voice articulation — Δarticulation within each voice, not mixed.
- Checkpoints NOT to be touched.
- Architectural decisions by Alex only.
