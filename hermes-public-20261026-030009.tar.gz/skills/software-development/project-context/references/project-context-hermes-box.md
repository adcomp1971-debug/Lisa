# Hermes Box — Project Context (absorbed from project-context-hermes-box)

## Project Root
`/root/hermes-box/`

## Architecture
Docker Compose stack: Ollama + Open WebUI + Hermes Agent + RAG + Tailscale.

## Tiers
| Tier | Profile | GPU | Model |
|------|---------|-----|-------|
| Small Office | `basic` | RTX 3060/4060 or CPU | Qwen 2.5 7B |
| Business | `gpu` | 2× RTX 4090 / A100 | Qwen 2.5 32B |

## Services
| Service | Port | Role |
|---------|------|------|
| Ollama | 11434 | LLM inference |
| Open WebUI | 3000 | Chat UI |
| Hermes Agent | 8787 | Orchestration |
| RAG | 8002 | Document Q&A |

## Commands
```bash
docker compose --profile basic up -d    # CPU-only
docker compose --profile gpu up -d      # With GPU
./scripts/health-check.sh               # Health check
```
