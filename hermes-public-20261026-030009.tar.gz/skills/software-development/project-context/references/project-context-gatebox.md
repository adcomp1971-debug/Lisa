# GateBox — Project Context (absorbed from project-context-gatebox)

## Project Root
`/var/www/gatebox/` (static files and web app)
`/opt/vpnbot/` (Python backend + Telegram bot)

## Architecture
VPN config distribution web app. Users access a landing page, watch videos, receive VLESS Reality VPN configs. Telegram bot for client management.

```[User Browser] → Nginx (:80/:443) → /var/www/gatebox/ (static HTML/CSS/JS)
→ /api/ → :5010 (FastAPI)
```

## Key Files
- `/var/www/gatebox/index.html` — main landing page (brutalist dark, `#050508` bg)
- `/opt/vpnbot/gatebox_api.py` — FastAPI on :5010
- `/opt/vpnbot/bot.py` — Telegram bot (1333 lines)
- `/etc/nginx/sites-available/gatebox` — Nginx config

## Domain
`https://gpu-qwen.tail0c8f2f.ts.net` (Tailscale Funnel)

## XRay VLESS Reality
- Server: `76.13.77.105:443`
- SNI: `www.icloud.com`
- Flow: `xtls-rprx-vision`
