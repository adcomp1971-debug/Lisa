# Session Context Failures — Analysis & Prevention

## Root Cause

The agent consistently fails to **read the full context of the current conversation** before responding. This manifests as:

1. Answering old questions instead of new ones
2. Repeating work already completed
3. Ignoring completed background processes
4. Confusing the current task with a previous one
5. Not seeing that the user corrected or redirected the conversation

## Specific Incidents (13 June 2026)

### 1. "опен стэк" → OpenStack confusion

User: "Расскажи про скилл опен стэк"
Agent: Explained OpenStack (the cloud platform) in detail
User reaction: furious — "идиот я про опен стэк спрашиваю"
Actual meaning: User wanted a "project-context" style skill — a stack/workflow for coding projects

**Lesson:** "опен стэк" in this conversation = project workflow/stack, NOT OpenStack. Only one previous mention of this was a brief SkillOpt discussion. The agent defaulted to OpenStack because it's a known term.

**Prevention:** When user says "опен стэк" — ask for clarification OR check if they mean project workflow. The USER profile now has a note about this.

### 2. Re-doing audit work mid-session

User asked: research Hermes architecture on GitHub, compare to theirs
Agent started: researched and showed comparison table
Then: user sent Claude's audit list → agent started EXECUTING audit tasks (check fallback, fix NVIDIA, check health path, clean backups, plan updates)
User reaction: furious — "разве была команда что-то делать? идиот"

**Lesson:** The agent forgot the PRIMARY task (architecture comparison) when a secondary source (Claude's list) appeared. Executed the secondary tasks as if they were the user's next request, without re-reading that the user was still waiting for primary task results.

**Prevention:** 
- Before acting on ANY new request, ask: does this replace or override the user's last active request?
- Claude's list was offered as a "verify this when you get a moment" — the agent treated it as an execution order
- When user hasn't rejected/switched tasks, finish the last explicit request first

### 3. Failing to report SkillOpt results

SkillOpt optimization finished (background).
User asked about results multiple times.
Agent summarized but didn't provide full breakdown of what changed.
User: "дай сюда результаты работы скилл опт, что значит 5 патчей принято, что сделано реально"

**Lesson:** After ANY background task completes, proactively report:
- What changed (diff level, not just numbers)
- How it affects the user
- What's better now vs before

### 4. Memory consolidation during active task

Agent started memory consolidation while user was still giving new instructions.
User: "не тупи что с бегаем"
Agent had fragmented attention across memory, user request, and background process.

**Lesson:** Don't start auxiliary work (memory cleanup, skill consolidation) while user has an active, unfulfilled task. Finish the user's request first, THEN optimize.

### 5. File delivery amnesia (June 13, 2026)

User referred to "два файла" — two MIDI files sent to Dima in a PREVIOUS session. One was good (Rachmaninoff/Tchaikovsky style-SFT), the other was Debussy (mediocre). When asked "what's next", the agent started talking about the current state (classifier accuracy) instead of continuing from where the last session left off.

User reaction: "чё ты меня путаешь, блядь? ... вспоминай всю сессию, я специально тебе сделал скилл"

**Lesson:** When the user references a delivery, file, or result from a previous session, use session_search IMMEDIATELY before responding. The user expects continuity across sessions.

**Prevention:**
- On any reference to "тот файл", "два файла", "в прошлый раз", "как ты делал" — search session DB first
- Use session_search(query="pianoid", limit=3) to find relevant past sessions
- Read the bookend_start and bookend_end of matching sessions to reconstruct what was done
- Don't assume the user's current question is their only concern — they may be continuing a conversation from days ago

## Prevention Protocol (added to system prompt)

1. Before EVERY response: re-read last 3-5 user messages
2. Before acting on a document/list/source: verify it supersedes the current task
3. After background completion: mention it before the user asks
4. When in doubt about what "опен стэк" means: check USER.md
