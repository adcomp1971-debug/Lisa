---
name: ai-coding-tools
description: "Tools and workflows for AI-assisted software development: pygount codebase metrics, OAuth authentication for Codex CLI, and CLAUDE.md/project context patterns."
category: software-development
version: 3.0.0
author: Hermes Agent
related_skills: [autonomous-coding]
---

# AI Coding Tools — Setup & Workflows

Инструменты для конфигурации AI coding агентов (Codex CLI, Claude Code) и анализа кодовой базы перед AI-driven работой.

**Связанный скилл:** `autonomous-coding` — релеевая архитектура, wrapper scripts, config.toml, WS, stunnel, Anthropic relay, Buratino workers, cost model.

## 1. Codebase Metrics with pygount

Analyze repositories for lines of code, language breakdown, file counts, and code-vs-comment ratios.

### Когда использовать

- LOC (lines of code) count
- Language breakdown of a repo
- Code-vs-comment ratios
- "How big is this repo" questions

### Установка

```bash
pip install --break-system-packages pygount 2>/dev/null || pip install pygount
```

### Основная команда

```bash
cd /path/to/repo
pygount --format=summary \
  --folders-to-skip=".git,node_modules,venv,.venv,__pycache__,.cache,dist,build,.next,.tox,.eggs,*.egg-info" \
  .
```

**IMPORTANT:** Always use `--folders-to-skip`, otherwise pygount crawls dependency trees and hangs.

### Типовые исключения

- **Python:** `.git,venv,.venv,__pycache__,.cache,dist,build,.tox,.eggs,.mypy_cache`
- **JS/TS:** `.git,node_modules,dist,build,.next,.cache,.turbo,coverage`
- **Catch-all:** `.git,node_modules,venv,.venv,__pycache__,.cache,dist,build,.next,.tox,vendor,third_party`

### Фильтр по языку

```bash
pygount --suffix=py --format=summary .         # only Python
pygount --suffix=py,yaml,yml --format=summary . # Python + YAML
```

### Детальный вывод

```bash
# Пофайлово + сортировка по кол-ву кода
pygount --folders-to-skip=".git,node_modules,venv" . | sort -t$'\t' -k1 -nr | head -20
```

### Форматы вывода

```bash
pygount --format=summary .    # таблица (рекомендуется)
pygount --format=json .       # JSON для программирования
```

### Интерпретация результатов

- **Language** — обнаруженный язык
- **Files** — количество файлов
- **Code** — строки кода
- **Comment** — строки комментариев
- **%** — процент от общего

Специальные псевдо-языки: `__empty__`, `__binary__`, `__generated__`, `__duplicate__`, `__unknown__`

### Pitfalls

1. **Всегда исключайте .git, node_modules, venv** — без `--folders-to-skip` pygount зависает на минуты
2. **Markdown показывает 0 строк кода** — pygount классифицирует Markdown как комментарии
3. **JSON — низкие числа** — pygount консервативно считает JSON; используйте `wc -l` для точности
4. **Большие монорепы** — используйте `--suffix` для таргетирования конкретных языков

## 2. Codex CLI — OAuth Authentication via Hermes

Аутентификация Codex CLI на сервере через Hermes (device-code flow).

### Когда нужно
- На сервере без браузера (SSH, VPS, headless)
- Codex CLI запускается локально или через systemd
- Нужен OAuth-логин без установленного браузера

### Процесс

```bash
# 1. Запустить device-code flow
hermes auth add openai-codex --manual-paste

# 2. Команда выдаст:
#    https://auth.openai.com/codex/device
#    Code: XXXX-XXXXX (с дефисом для читаемости)

# 3. Отправить пользователю:
#    - Ссылку в отдельном сообщении
#    - Код — отдельным .txt файлом
```

### 🚨 Критическое правило — код ТОЛЬКО БЕЗ ДЕФИСА

**Самая частая ошибка — код с дефисом.** В терминале он отображается `JUQN-D8C4P` (10 символов), но страница OpenAI ожидает ровно 9 символов без дефиса.

**ЧЕКЛИСТ ПЕРЕД ОТПРАВКОЙ (выполнять каждый раз):**

1. Запустить `hermes auth add openai-codex --manual-paste` → получить НОВЫЙ код
2. Из вывода считать код — с дефисом, напр. `JUQN-D8C4P` (10 символов)
3. **Удалить дефис:** `JUQN-D8C4P` → `JUQND8C4P` (9 символов)
4. **ПРОВЕРИТЬ:** длина == 9, `-` в строке нет
5. Написать `.txt` файл с кодом без дефиса (через `write_file` + `MEDIA:`)
6. Текстом отправить `https://auth.openai.com/codex/device`
7. После авторизации → `hermes auth status openai-codex` → `logged in`

**Если пользователь прислал ошибку (скриншот, «накосячил», «тупой»):**
1. **НЕ переотправлять старый код** — он недействителен
2. Перезапустить `hermes auth add openai-codex --manual-paste` → новый код → без дефиса → отправить

🚫 **НЕ ДЕЛАЙ:**
- Не отправляй код с дефисом — ошибка «Не удалось авторизовать устройство»
- Не переотправляй тот же код без дефиса — его перезатёр новый запуск
- Не смешивай код и ссылку в одном файле
- Не вставляй код в тело сообщения — только .txt
- Не проверяй через OpenAI API вместо Codex — см. раздел 4

```bash
# В терминале:   JUQN-D8C4P  ← с дефисом (10 символов)
# Отправлять:    JUQND8C4P   ← БЕЗ дефиса (9 символов)
```

### Pitfalls
1. **Код с дефисом не подходит** — OpenAI page ожидает ровно 9 символов. Дефис делает код 10-символьным, страница отвергает с ошибкой «Не удалось авторизовать устройство»
2. **Если код не подошёл** — не пытайся повторно отправить тот же код. Перезапусти `hermes auth add openai-codex --manual-paste`, получи новый, убери дефис, отправь
3. **Требование `--manual-paste`** — без этого флага пытается открыть браузер (не работает на headless)
4. **Только один активный код** — каждый новый запуск делает старый код недействительным
5. **Таймаут ~2 минуты** — процесс умирает, если не успеть. Перезапускать полностью
6. **Проверять авторизацию** — `hermes auth status openai-codex` → должен показать logged in

---

## 3. Codex в Hermes — интеграция после OAuth

После успешной аутентификации Codex CLI нужно зарегистрировать его в Hermes, чтобы модель была доступна для делегации и работы.

### Шаги

#### 1. Проверить OAuth статус
```bash
hermes auth status openai-codex
# → logged in
```

#### 2. Проверить Codex CLI
```bash
codex --version
# → codex-cli 0.142.5+
```

#### 3. Протестировать Codex через Hermes (критически важно — именно Codex, не OpenAI)
```bash
hermes chat -m gpt-5.5 --provider openai-codex -q "Reply OK. One word."
# → ожидается OK, <15 сек, HTTP 200
```
**Критическое правило:** когда пользователь говорит «проверь кодекс» — тестировать именно Codex (gpt-5.5 через openai-codex провайдер), а не OpenAI API (gpt-4o). Пользователь различает их и злится на подмену.

#### 4. Зарегистрировать в Hermes AGENTS.md
Добавить секцию в `~/.hermes/AGENTS.md`:
```markdown
## Codex (OpenAI Codex via Hermes)
- **CLI:** vX.X.X
- **OAuth:** авторизован (openai-codex-oauth-1)
- **Модель в Hermes:** `gpt-5.5` через `--provider openai-codex`
- **Роль:** изолированный кодер (тесты, скрипты, code review)
- **НЕ трогает:** прод-конфиги, systemd сервисы
```

#### 5. Добавить в Delegation (если нужно)
```markdown
- **Codex (gpt-5.5)** — subagent с model='gpt-5.5', provider='openai-codex' для сложного кода
```

### Когда отправлять в Codex vs делать самому
| Задача | Кто делает |
|--------|-----------|
| Сложный код без доступа к прод-секретам | Codex (через delegate_task) |
| Code review чужого кода | Codex |
| Юнит-тесты, линтинг, рефакторинг | Codex |
| Прод-конфиги (/etc/, /opt/vpnbot/, systemd) | Hermes (никогда Codex) |
| Инфраструктура (cron, VPN, мониторинг) | Hermes |
| Любая задача с секретами | Hermes |

### Pitfalls
1. **«Проверь кодекс» ≠ «Проверь OpenAI API»** — тестируй именно `--provider openai-codex --model gpt-5.5`, а не `--provider openai --model gpt-4o`. Пользователь замечает.
2. **Relay может быть мёртв** — если `~/.codex/config.toml` указывает на локальный relay-прокси (порт 4446), а прокси не запущен, Codex CLI напрямую не работает, хотя через Hermes OAuth работает. Не чинить relay без запроса — OAuth достаточно.
3. **AGENTS.md обновлять вручную** — после настройки Codex обновить AGENTS.md в ~/.hermes/ и ~/.codex/.

---

## 4. Context Files for Codex CLI

Codex CLI читает контекст проекта из двух файлов в корне проекта:

**CLAUDE.md (главный — 80% успеха)** — автоматически подхватывается Codex, injects содержимое в system prompt. Без него Codex «слепой».

Что должно быть в CLAUDE.md:
- Однострочное описание проекта
- Две ключевые таблицы: **архитектура** (компоненты, где лежат, статус) и **команды** (запуск, тесты, сборка)
- **Что НЕ трогать** — production checkpoint, обученные модели, данные
- Зависимости и способ установки
- **Секция «For Codex CLI»** — что делать в первую очередь, что проверять перед PR

**.codexrules** — более лаконичный файл для Codex-специфичных правил:
- «всегда спрашивай перед удалением файлов»
- «не трогай папку X»
- «используй pytest -q для тестов»

---

**Связанный скилл:** `autonomous-coding` — полная релеевая архитектура, config.toml, wrapper scripts, stunnel, Anthropic relay, Buratino workers.
