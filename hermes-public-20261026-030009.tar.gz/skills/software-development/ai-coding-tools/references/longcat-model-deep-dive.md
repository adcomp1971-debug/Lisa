# LongCat-2.0 — Model Deep Dive

## История

LongCat-2.0 — модель от Meituan (китайский гигант доставки). Релиз 30 июня 2026.
До официального анонса 2 месяца работала на OpenRouter **анонимно под именем "Owl Alpha"**,
где была топ-1 по популярности среди разработчиков.

Open source под **MIT лицензией**: https://github.com/meituan-longcat/LongCat-2.0

## Спецификация

| Параметр | Значение |
|----------|----------|
| Total params | 1.6T (Mixture of Experts) |
| Active per token | 33B–56B (~48B avg) |
| Context window | **1M токенов** (native) |
| Max output | 128K токенов |
| Training data | 35+ трлн токенов |
| Железо для обучения | 50K AI ASIC (китайские чипы, не NVIDIA) |
| Поддержка тулов | ✅ function calling, parallel tool calls |
| API форматы | OpenAI `/v1/chat/completions` + Anthropic `/v1/messages` |

## Архитектурные особенности

1. **LongCat Sparse Attention (LSA)** — эволюция DeepSeek Sparse Attention:
   - Streaming-aware Indexing — coalesced HBM access
   - Cross-Layer Indexing — одна индексация на несколько слоёв
   - Hierarchical Indexing — coarse-to-fine scoring
2. **N-gram Embedding** — расширение embedding space ~100× через N-gram комбинации
3. **Multi-Token Prediction (MTP)** — speculative decoding, 3-step MTP
4. **Muon optimizer** — обучение на китайских чипах

## Бенчмарки

### Code & Agentic

| Тест | LongCat-2.0 | GPT-5.5 | Gemini 3.1 Pro | Opus 4.6 | Opus 4.8 |
|------|-------------|---------|----------------|----------|----------|
| **SWE-bench Pro** | **59.5** 🏆 | 58.6 | 54.2 | 57.3 | 69.2 |
| **Terminal-Bench 2.1** | 70.8 | 73.8 | 70.7 | — | 78.9 |
| SWE-bench Multilingual | 77.3 | — | 76.9 | 77.8 | 84.8 |
| **FORTE** (агенты) | 73.2 | 77.8 | 70.3 | 73.2 | 77.2 |

**Ключевой вывод:** LongCat-2.0 **обходит GPT-5.5 на SWE-bench Pro** (реальные GitHub issues) — 59.5 vs 58.6.

### General & Reasoning

| Тест | LongCat-2.0 | GPT-5.5 | Gemini 3.1 Pro | Opus 4.6 |
|------|-------------|---------|----------------|----------|
| BrowseComp | 79.9 | 84.4 | 85.9 | 84.0 |
| GPQA-diamond | 88.9 | 93.6 | 94.3 | 91.3 |
| IFEval | 90.0 | 95.0 | 96.1 | 92.2 |
| IMO-AnswerBench | 81.8 | 79.5 | 90.0 | 75.3 |

**По общим знаниям/резинингу** — уступает GPT-5.5 и Gemini. Это специализированная **coding + agentic** модель.

## Цены

### Pay-as-you-go (предоплаченный баланс)

| Тип | Стандарт $/1M | Акция $/1M |
|-----|-----------|-----------|
| Input (uncached) | $0.75 | $0.30 |
| Input (cached) | **$0.015** 🔥 | $0.006 |
| Output | $2.95 | $1.20 |

### Token Packs (35B токенов за ¥13/мес)

Flash sale 4 раза в день по Пекину (10:00, 16:00, 21:00, 23:00).

### Актуальный статус в стеке (03.07.2026)

- **Codex по умолчанию**: LongCat-2.0 через релей :4447
- **Fallback #1**: LongCat-2.0 (первый после default модели)
- **Delegation**: LongCat-2.0 (longcat провайдер, заменён GLM)
- **50M токенов в пакете** — куплены, сгорят через 30 дней, модель основная
- **DeepSeek V4 Pro** — запасной через :4446
- **GLM 5.2** — только для анализа/планирования через :4448

## Сравнение с DeepSeek V4 Pro

| Характеристика | LongCat-2.0 | DeepSeek V4 Pro |
|---------------|-------------|-----------------|
| Архитектура | 1.6T MoE (48B active) | ~1T MoE |
| Контекст | **1M** | 262K |
| SWE-bench Pro | **59.5** | ~55 |
| Input цена | $0.75/M ($0.30) | **$0.435/M** |
| Output цена | $2.95/M ($1.20) | **$0.87/M** |
| Cache hits | **free** | нет |
| Open source | **MIT** | proprietary |
| Скорость (через relay) | ~10s | ~2.3s |

## Когда что выбрать

| Сценарий | LongCat-2.0 | DeepSeek V4 Pro |
|----------|-------------|-----------------|
| Быстрая правка/прототип | ❌ медленно | ✅ 2-3s |
| Сложный рефакторинг | ✅ 1M контекст | ⚠️ 262K |
| Agentic coding (много тулов) | ✅ strong | ✅ strong |
| Экономия | ✅ cache hits free | ✅ дешевле output |
| OpenRouter-style | ✅ был Owl Alpha #1 | — |

## Проверка

```bash
# Модель жива?
curl -s http://127.0.0.1:4447/v1/models

# Тест через relay
echo "Write a fibonacci function" | codex-lc exec --skip-git-repo-check -

# Прямой тест
curl -s -H "Authorization: Bearer $LONGCAT_API_KEY" \
  https://api.longcat.chat/openai/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"LongCat-2.0","messages":[{"role":"user","content":"hi"}],"max_tokens":10}'
```
