# LongCat API — Provider Reference

**Сайт:** https://longcat.chat/  
**Документация:** https://longcat.chat/platform/docs/  
**Эндпоинт:** `https://api.longcat.chat/openai/v1` (OpenAI-совместимый)  
**Модель:** `LongCat-2.0` (1.6T MoE, 33B-56B activated, 1M context, агентный кодинг)

## API Key

**Формат:** `ak_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

**Текущий (03.07.2026):** ключ в `.env` как `LONGCAT_API_KEY`.
50M токенов в пакете — сгорают через 30 дней. Модель основная для кодинга.

### Token Pack — Flash Sale (4 раза/день по Пекину)

| Время (UTC+8) | 10:00 | 16:00 | 21:00 | 23:00 |
|---------------|-------|-------|-------|-------|

Действуют 30 дней. Неиспользованные токены возвращаются принудительно по истечении.
**Cache hits не расходуют пакетные токены** — бесплатно.
Пакет сжигается раньше pay-as-you-go баланса.

**Расход:** ~10-500K токенов на сессию Codex. 50M пакет ≈ 100-500 сессий.

### Pay-As-You-Go (основной баланс)

| Тип | Стандарт $/1M | Акция $/1M |
|-----|-----------|-----------|
| Input (uncached) | $0.75 | $0.30 |
| Input (cached) | **$0.015** 🔥 | $0.006 |
| Output | $2.95 | $1.20 |


```bash
curl -s -H "Authorization: Bearer $LONGCAT_API_KEY" \
  "https://api.longcat.chat/openai/v1/models"
# → {"object":"list","data":[{"id":"LongCat-2.0","object":"model","owned_by":"LongCat"}]}
```

## Проверка наличия баланса

```bash
curl -s -w "\nHTTP: %{http_code}" \
  -H "Authorization: Bearer ak_..." \
  -H "Content-Type: application/json" \
  "https://api.longcat.chat/openai/v1/chat/completions" \
  -d '{"model":"LongCat-2.0","messages":[{"role":"user","content":"test"}],"max_tokens":5}'
```

**Успех:** HTTP 200 + ответ с контентом.  
**Нет баланса:** HTTP 402 + `{"error":{"code":"too_many_requests","message":"Token 额度不足...","type":"rate_limit_error"}}`  
*(402, но error.code="too_many_requests" — не путать с реальным rate-limiting)*

HINT: Пополнить баланс — зайти на longcat.chat в аккаунт, раздел оплаты.
Платёжный пароль (6 цифр) задаётся один раз при первой оплате.
