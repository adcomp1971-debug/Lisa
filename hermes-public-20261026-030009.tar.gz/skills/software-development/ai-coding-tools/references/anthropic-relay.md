# Anthropic Messages API Relay — Claude Code через LongCat

## Архитектура

```
Claude Code
  → ANTHROPIC_BASE_URL=https://localhost:4451
  → stunnel (HTTPS :4451 → HTTP :4450)
  → codex-relay-anthropic (:4450)
  → POST /v1/messages (Anthropic Messages API)
  → translate to Chat Completions
  → api.longcat.chat (LongCat-2.0)
```

## Компоненты

### 1. Anthropic relay (codex-relay-anthropic)
- Systemd: `codex-relay-anthropic.service`
- Порт: `:4450`
- Upstream: `https://api.longcat.chat/openai/v1`
- Модуль: `src/anthropic.rs`
- Модельный маппинг: `claude-*` → `LongCat-2.0`
- Config: `/root/codex-relay-rust/run-relay-anthropic.py`

### 2. Stunnel (HTTPS обёртка)
- Config: `/etc/stunnel/anthropic-relay.conf`
- Cert: `/etc/stunnel/anthropic.pem` (self-signed)
- Порт: `:4451` (HTTPS) → `:4450` (HTTP)
- Запуск: `stunnel /etc/stunnel/anthropic-relay.conf`
- Systemd: не настроен (нужен ручной запуск)

### 3. Claude Code wrapper
- Файл: `/usr/local/bin/claude-lc`
- Переменные:
  - `ANTHROPIC_BASE_URL=https://localhost:4451`
  - `ANTHROPIC_API_KEY=<LONGCAT_KEY>`
  - `NODE_TLS_REJECT_UNAUTHORIZED=0`

## Версия Claude Code
- Работает: **v2.0.5** (npm install -g @anthropic-ai/claude-code@2.0.5)
- НЕ работает: ≥2.1.146 (требуют OAuth и не принимают кастомные base-url)

## Использование
```bash
claude-lc "задача"                    # интерактивный
echo "hi" | claude-lc --print         # одноразовый
```

## Восстановление после рестарта сервера
```bash
stunnel /etc/stunnel/anthropic-relay.conf  # поднять HTTPS прокси
systemctl restart codex-relay-anthropic     # перезапустить relay
```

## Проблемы
- Stunnel нет в systemd — надо поднимать руками после ребута
- Self-signed cert → `NODE_TLS_REJECT_UNAUTHORIZED=0`
- Только LongCat-2.0 модель (другие модели Claude Code не маппятся)
