# Reasoning Model Fallback in codex-relay

## Проблема

Китайские reasoning-модели (GLM 5.2, LongCat-2.0, Kimi k2.6) кладут **финальный ответ** в `reasoning_content`, а `content` оставляют пустым. codex-relay изначально брал только `content` → возвращал пустой ответ Codex CLI.

## Диагностика

```bash
# Прямой запрос к Z.AI API — content пустой, ответ в reasoning_content
curl -s https://api.z.ai/api/paas/v4/chat/completions \
  -H "Authorization: Bearer $ZAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"glm-5.2","messages":[{"role":"user","content":"hi"}],"max_tokens":20}'

# → {"choices":[{"message":{"content":"","reasoning_content":"1.  **Analyze..."}}]}
```

Через релей то же самое — `/v1/responses` возвращает `"text":""`.

## Фикс

### 1. Non-streaming path (`translate.rs`)

```rust
// Было:
let text = choice.message.content.clone().unwrap_or_default();

// Стало:
let text = choice
    .message
    .content
    .clone()
    .filter(|s| !s.is_empty())
    .or_else(|| choice.message.reasoning_content.clone())
    .unwrap_or_default();
```

### 2. Streaming path (`stream.rs`)

Три изменения:

**a)** Добавить трекер `had_content_delta`:
```rust
let mut had_content_delta = false;
```

**b)** Установить флаг при получении content дельты:
```rust
if !content.is_empty() {
    had_content_delta = true;
    // ... остальная логика
}
```

**c)** В конце стрима — fallback на reasoning если не было content дельт:
```rust
let final_text = if had_content_delta {
    accumulated_text.clone()
} else if !accumulated_reasoning.is_empty() {
    accumulated_reasoning.clone()
} else {
    accumulated_text.clone()
};
```

И заменить все `&accumulated_text` в output events на `&final_text`.

### 3. Условие эмиссии message item

```rust
// Было — не срабатывало если not emitted_message_item:
if emitted_message_item { ... }

// Стало:
if emitted_message_item || !final_text.is_empty() { ... }
```

## Сборка и деплой

```bash
cd /root/codex-relay-rust
cargo build --release
systemctl restart codex-relay-glm codex-relay-longcat
```

## Проверка

```bash
# GLM через релей
curl -s http://127.0.0.1:4448/v1/responses \
  -H "Content-Type: application/json" \
  -d '{"model":"glm-5.2","input":"hi","max_output_tokens":20}' \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('output',[{}])[0].get('content',[{}])[0].get('text','NO_TEXT'))"

# → Должен вернуть текст, не NO_TEXT
```

## Какие модели затронуты

- GLM 5.2 (Z.AI) — ответ только в `reasoning_content`
- LongCat-2.0 — ответ только в `reasoning_content`  
- Kimi k2.6 — ответ частично в `reasoning_content`
- **НЕ затронуты:** DeepSeek V4 Pro/V4 Flash — дублируют ответ в `content`
