# Codex Provider Comparison: DS V4 Pro vs GLM 5.2 vs LongCat-2.0

## Тестовая задача одинаково для всех трёх

Прочитать /tmp/test_logs.json (13 записей, 3 уровня, 4 часа), сгруппировать по level,
посчитать по часам, нарисовать ASCII-график, сохранить в файл.

## Результаты (real benchmark, 2026-07-03)

| Схема | Время | Качество кода | График | Цена ~ | 
|-------|-------|---------------|--------|--------|
| **DS → codex** 🥇 | **33 сек** | рабочий 🟢 | `███` | **$0.003** |
| **GLM → codex** 🥈 | 83 сек | рабочий 🟢 | `#*!` | $0.03 |
| **LongCat → codex** 🥉 | **200 сек** 🐢 | рабочий 🟢 | `██▓▓░░` | $0.02 |

## Схемы

1. **DS → codex (прямая):** Hermes (DS Flash) → вызывает codex-ds через терминал
2. **GLM → codex (управление):** Hermes (DS Flash) → delegate_task → GLM 5.2 → вызывает codex-ds
3. **LongCat → codex (управление):** Hermes (DS Flash) → delegate_task → LongCat-2.0 → вызывает codex-ds

## Выводы

- **DS codex (33s, $0.003)** — быстрее и дешевле. Для быстрых задач.
- **GLM → codex (83s, $0.03)** — баланс скорости и качества. GLM подчищает косяки Codex.
- **LongCat → codex (200s)** — самый качественный результат, но в 6x медленнее DS. Только для ответственных сложных задач.

Для Алекса: на рутине codex-ds напрямую, для важного — GLM 5.2 управляет Codex.
LongCat — не использовать на кодинг, слишком медленно (токены/баланс есть, но ждать 3 мин вместо 33 сек).

## Как гонять тест заново

```bash
# Создать тестовые данные:
cat > /tmp/test_logs.json << 'EOF'
{"logs": [
  {"time": "2026-07-03T08:15:00", "level": "INFO", "msg": "Server started"},
  ...
]}
EOF

# Тест 1: DS Codex напрямую (фон + notify)
# Тест 2: delegate_task GLM 5.2 → codex-ds
# Тест 3: delegate_task LongCat-2.0 → codex-ds

# Сравнить время, качество и файлы:
ls -la /tmp/test_result_*.txt
cat /tmp/test_result_ds.txt
cat /tmp/test_result_glm_codex.txt
cat /tmp/test_result_lc.txt
```
