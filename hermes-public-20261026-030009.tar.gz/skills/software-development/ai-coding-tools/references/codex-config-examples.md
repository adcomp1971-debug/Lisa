# Примеры конфигов для Codex + DeepSeek

## 1. codex-relay (рекомендуемый)

### ~/.codex/config.toml
```toml
model = "deepseek-v4-pro"
model_provider = "deepseek-relay"

[model_providers.deepseek-relay]
name = "DeepSeek via Relay"
base_url = "http://127.0.0.1:4446/v1"
wire_api = "responses"
env_key = "CODEX_RELAY_API_KEY"    # ← relay читает это имя, не DEEPSEEK_API_KEY
requires_openai_auth = false

[model_properties."deepseek-v4-flash"]
context_window = 262144
max_context_window = 1048576
max_output_tokens = 384000
supports_parallel_tool_calls = true
supports_reasoning_summaries = true
input_modalities = ["text"]

[model_properties."deepseek-v4-pro"]
context_window = 262144
max_context_window = 1048576
max_output_tokens = 384000
supports_parallel_tool_calls = true
supports_reasoning_summaries = true
input_modalities = ["text"]
```

## 2. Moon Bridge config.yml

```yaml
mode: "Transform"
log:
  level: "info"
  format: "text"
server:
  addr: "127.0.0.1:38440"
persistence:
  active_provider: db_sqlite
cache:
  mode: "explicit"
  ttl: "5m"
defaults:
  model: "moonbridge"
  max_tokens: 65536
models:
  deepseek-v4-pro:
    context_window: 1000000
    max_output_tokens: 384000
    extensions:
      deepseek_v4:
        enabled: true
providers:
  deepseek:
    base_url: "https://api.deepseek.com/anthropic"
    api_key: "sk-..."
    version: "2023-06-01"
    offers:
      - model: deepseek-v4-pro
routes:
  moonbridge:
    model: deepseek-v4-pro
    provider: deepseek
```

## 3. Systemd — codex-relay

### Способ A (рекомендуемый): Python wrapper

`/root/codex-relay-rust/run-relay.py` — безопасно читает ключ из `.env`, экранирует shell:
```python
#!/usr/bin/env python3
import os, subprocess

with open('/root/.hermes/.env') as f:
    for line in f:
        line = line.strip()
        if line.startswith('DEEPSEEK_API_KEY='):
            key = line.split('=', 1)[1].strip()
            break
    else:
        raise RuntimeError("DEEPSEEK_API_KEY not found in .env")

env = os.environ.copy()
env['CODEX_RELAY_PORT'] = '4446'
env['CODEX_RELAY_UPSTREAM'] = 'https://api.deepseek.com/v1'
env['CODEX_RELAY_API_KEY'] = key

proc = subprocess.Popen(
    ['/root/codex-relay-rust/target/release/codex-relay'],
    env=env
)
proc.wait()
```

`/etc/systemd/system/codex-relay.service`:
```ini
[Unit]
Description=Codex-Relay — DeepSeek V4 Chat → Codex Responses proxy
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/codex-relay-rust
ExecStart=/root/codex-relay-rust/run-relay.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

⚠️ **Проблема:** При перезапуске старый процесс может висеть на порту. Лечение:
```bash
kill $(lsof -ti:4446) && systemctl restart codex-relay
```

### Способ B: EnvironmentFile (проще, но ключ может не подхватиться)

```ini
[Unit]
Description=Codex Relay — DeepSeek Chat Completions proxy
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/codex-relay-rust
# Проблема: relay ждёт CODEX_RELAY_API_KEY, но в .env лежит DEEPSEEK_API_KEY
ExecStart=/root/codex-relay-rust/target/release/codex-relay
Restart=always
RestartSec=5
Environment=CODEX_RELAY_PORT=4446
Environment=CODEX_RELAY_UPSTREAM=https://api.deepseek.com/v1
EnvironmentFile=-/root/.hermes/.env

[Install]
WantedBy=multi-user.target
```

**Недостаток B:** relay читает `CODEX_RELAY_API_KEY` из env, но `.env` содержит `DEEPSEEK_API_KEY`, а не `CODEX_RELAY_API_KEY`. Либо добавить обе переменные в `.env`, либо использовать Python wrapper.

### Codex CLI wrapper

Codex тоже нужна `CODEX_RELAY_API_KEY` в окружении (даже с `requires_openai_auth=false`):
```bash
cat > /usr/local/bin/codex-ds << 'EOF'
#!/bin/bash
source /root/.hermes/.env
export CODEX_RELAY_API_KEY="$DEEPSEEK_API_KEY"
exec codex "$@"
EOF
chmod +x /usr/local/bin/codex-ds
```

Запуск: `codex-ds exec "задача"` или просто `codex-ds` (интерактив).

## 4. DeepSeek API проверка

```bash
# Проверка доступности ключа
curl -s https://api.deepseek.com/v1/models \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY"

# Проверка работоспособности Chat API
curl -s https://api.deepseek.com/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"hi"}],"max_tokens":10}'

# Проверка Anthropic-совместимого эндпоинта
curl -s https://api.deepseek.com/anthropic/v1/messages \
  -H "Content-Type: application/json" \
  -H "x-api-key: $DEEPSEEK_API_KEY" \
  -d '{"model":"deepseek-v4-pro","max_tokens":10,"messages":[{"role":"user","content":"hi"}]}'
```

## 5. Цены DeepSeek (июнь 2026)

| Модель | Cache Hit Input | Cache Miss Input | Output |
|--------|----------------|-----------------|--------|
| V4 Flash | $0.0028/M | $0.14/M | $0.28/M |
| V4 Pro | $0.0036/M | $0.435/M | $0.87/M |

Сравнение: Sonnet 4.6 $15/M out — DeepSeek V4 Pro в 17x дешевле.
