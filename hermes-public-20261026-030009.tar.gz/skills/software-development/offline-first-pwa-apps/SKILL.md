---
name: offline-first-pwa-apps
description: Use when building or testing an offline-first mobile PWA.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [pwa, offline-first, flask, sqlite, field-sales, mobile]
    related_skills: [file-delivery-workflow, nginx-static-hosting, spec-driven-dev, project-context]
---

# Offline-first PWA apps (Flask API + installable shell)

For phone apps for staff who work without reliable signal (van-sales agent, courier, field collector).
The deliverable is a link the user adds to the home screen — no App Store, no Apple Developer fee, no native build.
Project instance: `references/israel-van-sales-hashavshevet.md` (MobSoft: field sales + חשבשבת accounting, `/root/mobsoft`).

## When to Use

- The user wants a phone app for staff/drivers/agents where the network is unreliable, and wants it installed from a link rather than an app store.
- Adding a feature to such an app (new screen, sync, printing, admin cabinet) on a Flask + SQLite + PWA stack.
- Debugging «на телефоне не то / не сохранилось / не ушло на сервер» in an app whose logic lives client-side.
- Verifying a mobile UI before showing it to the user: drive the real handlers in a mobile-emulated browser, including the offline path.
- Anything touching money, signatures or printable documents in a field app — the money and printing rules below are not optional.

## Architecture that works

- **One origin serves API and shell.** Flask serves `/api/*` and the static PWA at `/`, with SPA fallback (`GET /<path:path>` → file, else `index.html`). No CORS, no second host, service-worker scope trivially correct.
- **Serve with waitress, not the dev server:** `run.py` reading `HOST`/`PORT`/`THREADS` from env. Dev server dies under concurrent agent traffic and has no keep-alive.
- **Money as integers** (agorot/cents) in DB, JSON and JS; divide only when rendering. Floats on totals produce rounding complaints from the accountant.
- **Client-generated `uuid` is the sync key** and every mutating endpoint is idempotent (upsert on uuid). A retried offline queue must not double-post an order.
- **Field auth = personal numeric code** → token in the `Authorization` header, cached on the device. No passwords to type with dirty hands.
- **SQLite + WAL**, one connection per request, `PRAGMA foreign_keys=ON`.

## Offline-first client (the feature, not a nice-to-have)

- Cache token, agent, bootstrap payload, current day and the op queue in `localStorage` under prefixed keys.
- **Every mutation: apply locally → push op to queue → flush.** Never block the screen on the network.
- `flush()` on start, on network-restored, and from a manual «Связь/обновить» screen; server responses reconcile status, money and artifacts (signature file name).
- Show an explicit no-network indicator; keep the day's route usable from cache while offline.
- Login offline on first run is impossible by definition: say so in the UI instead of failing silently.
- Persist the login code→agent mapping so a returning user can be let in when the server is unreachable.

## Service worker: network-first, never cache-first for the shell

- **Cache-first on the app shell serves stale JS after every edit** — the symptom is a mystery `TypeError: App.someNewMethod is not a function` in the browser while the file on disk is correct. Use network-first with cache fallback for same-origin GETs, and treat the cache as offline fallback only.
- Bump the cache name when the shell changes; delete old caches in `activate`.
- Never cache `/api/`; the client owns its data copy. Return a 503 JSON body for API calls when offline.
- **When testing: unregister the SW and delete all caches once, then reload** — otherwise you keep exercising the previous bundle and chase ghosts.
- `manifest.webmanifest` with `lang` of the users' language, `display: standalone`, 192/512 icons. Icons from a hand-written SVG via `rsvg-convert` (no matplotlib/graphviz on this host).

## JSON contract pitfalls that cost real debugging time

- **Put the foreign key id flat next to the nested object** (`client_id` alongside `client`). A client that looks up `s.client_id` gets `undefined` and silently renders every row as «нет данных» — no error anywhere. Belt and braces: client-side `s.client_id ?? s.client?.id`.
- **Read enums against a whitelist, never a truthy fallback.** `this.pay = o?.payment || 'cash'` leaves nothing selected when the stored value is `'none'` (truthy). Use `['cash','check','credit','debt'].includes(o?.payment) ? o.payment : 'cash'`.
- Return the values the client keys on (the entered code, the uuid) in login/bootstrap payloads, not only derived display fields.
- SPA shell + static file names are part of the contract: run an HTTP e2e test (health, login, bootstrap, create order, deliver, print, admin export) in a file like `docs/e2e_test.py` and keep it runnable — click-throughs do not catch a 404 on `manifest.webmanifest`.

## Verify by driving the real UI, not curl

curl proves the API; the user judges the screen. Recipe:

1. `cdp('Emulation.setDeviceMetricsOverride', width=390, height=844, deviceScaleFactor=2, mobile=True)` — real phone viewport.
2. Drive the app's **own handlers** (`js("App.login()")`, `js("App.addProduct(id)")`) so the tap path is exercised, and clear `localStorage` first for a clean run.
3. Assert on the DOM: element counts, label texts, totals, and `getComputedStyle(document.body).direction` for RTL.
4. **Offline path:** `cdp('Network.emulateNetworkConditions', offline=True, latency=0, downloadThroughput=0, uploadThroughput=0)` → mutate → check queue length grew and status applied locally → back online → `js("App.flush()")` → **re-fetch `/api/bootstrap` and assert the server state** (status/payment/artifact). Optimistic local state is not proof of sync.
5. **Screenshots:** `capture_screenshot()`; for tall pages it can time out — take it via raw CDP `cdp('Page.captureScreenshot', format='png', captureBeyondViewport=False)` and write the base64 to the file yourself. Save the set under `docs/screens/`.
6. Signature pads: draw on the canvas with `ctx.bezierCurveTo` and assert `toDataURL('image/png').length` grew — that proves the canvas is wired without a stylus.

## Run / reload loop

- Start: `cd <proj> && (setsid env HOST=0.0.0.0 PORT=<port> ./venv/bin/python run.py > /tmp/<proj>.log 2>&1 &)`; keep a `scripts/<proj>ctl.sh start|stop|restart|status|log` next to it.
- **Never `pkill -f run.py` to restart.** The pattern also matches the shell running the command, so the call returns SIGTERM (exit -15) instead of output. Find the listener and kill it: `ss -ltnp | grep ':PORT' | grep -oP 'pid=\K[0-9]+' | head -1`, then `kill <PID>`; start the new one under `setsid` so it survives the tool call.
- Bind `0.0.0.0` for staff phones but keep the port closed in UFW unless the user asks; hand over the tailnet URL `http://<tailscale-ip>:<port>/` for home-screen install.
- **Opening it to the internet (nginx/Funnel) is the user's decision** — the payload is customer/accounting data. Present the option, do not do it unasked.
- **Test external reachability from outside** (check-host.net TCP check) — `curl` to your own public IP can succeed through hairpin NAT while the outside world times out, which reads as «работает» and then fails for the customer.

## Delivery

- UI screenshots to Telegram: `python3 /root/send_photo_inline.py <png> "<caption>"`, one file per send; general file/delivery rules live in `file-delivery-workflow`.
- Commands for the user: one-line, copy-pasteable in chat; multi-line → `.txt`. `MEDIA:` paths do not arrive on his iPad.
- Project `README.md`: what is verified **and how it was checked**, how to run, what is deliberately not done yet, and the open questions for the user. Tables belong in the file, never in a chat message.
- Report only what you actually exercised, list the not-done items explicitly, and end with «открой у себя и скажи что видишь» — server-side PASS is not acceptance.
