# Israeli van-sales / field-sales + חשבשבת (Hashavshevet)

Domain depth for the field-sales app class (MobSoft instance lives at `/root/mobsoft`).

## The job to be done

The agent loads goods into his own car in the morning, drives his own route, and per stop: opens the shop card → sees/receives the order → unloads → closes the visit with money (cash or cheque) → customer signs → the delivery note (`תעודת משלוח`) prints. Realistic scale for a small business in Israel: ~4 agents, up to 30 stops/day each (≈120 visits/day) — trivial server load, the hard part is offline behaviour and printing.

## חשבשבת integration — hard limits

- חשבשבת is the Israeli ERP/accounting suite the accountant runs (office, Windows + MS SQL Server).
- **Never write directly into the live חשבשבת DB.** There are exactly two supported paths:
  1. **H-Connect API** (`api.h-erp.co.il`) — needs version **SP3 2022+**, a separate חשבשבת server, and a **paid monthly add-on** installed by their own installer. Developer support packages are sold in blocks (min ~10 h × 400 ₪ + VAT). Customer/product/price reads first, then documents on the way back.
  2. **File interface** — generate `movein.dat` (documents in) / `heshin.dat` (invoices) and let the accountant load them manually. Free, slower, no vendor dependency; the practical fallback while the add-on question is open.
- Do not start integration work before knowing the installed version and whether the accountant will pay for the add-on — everything else is guesswork.
- Off-the-shelf competitors to study rather than buy: Magicnet (`מג'יקנט`), SMB Soft «Mobile 2 Sales», Amodat «VAN-SALE».

## Where the data must live

Bookkeeping and customer data stay in the office (the accountant's machine/DB); the server outside is only the access channel for the phones. Say this out loud when proposing hosting — it decides the port-exposure question.

## Hebrew delivery note (`תעודת משלוח`) and money

- Body direction **RTL** (`<html dir="rtl">`), mix Hebrew + Russian labels so both the agent and the office can read it.
- Fields that matter: document number, date, agent, customer name, **customer code in חשבשבת** (`קוד לקוח`), address, phone, payment type (`מזומן` / צ׳ק), table with `מק״ט` (SKU), description, `כמות` (qty), `מחיר` (price), `סה״כ` (line total), then `סה״כ לפני מע״מ` / `מע״מ 17%` / `סה״כ לתשלום`.
- **VAT is 17%** — compute net and VAT from the gross total and verify the arithmetic in the test (e.g. 34.00 → 29.06 + 4.94).
- Product SKU in the app **is** the חשבשבת item code; the customer code in the app maps to `קוד לקוח`.
- **Reading photos/scans of Hebrew documents is a vision-model choice, not a generic capability.** Our deepseek-flash vision reads a Hebrew delivery note correctly in ~5 s; a larger open VL model garbled `תעודת משלוח` into `חשבונית מס` while still reading every number right. A/B any candidate on a controlled image with known text before trusting it with invoices — method in `model-evaluation`.
- Print route: HTML → `window.print()` / iOS «Поделиться» → «Печать» (**AirPrint**). Bluetooth thermal printers are unreachable from a browser — never promise them.
- `alert()`/`confirm()` are unreliable inside an installed PWA — use in-page modals.

## Questions to settle before writing integration code

1. חשבשבת version + is an installer available + will the accountant pay for the H-Connect add-on.
2. Printer model (must be AirPrint/Wi-Fi) — printing is a hard requirement, not a phase-2 item.
3. Agents' phones: iPhone or Android (decides whether install instructions and printing are iOS-specific).
4. UI language for the agents: Russian / Hebrew / both.

## Data model that proved workable

`agents` (code UNIQUE, name, car, is_owner, active) · `products` (sku = חשבשבת code, name_he, name_ru, unit `יח׳`, barcode, price_agor, active) · `clients` (`hsv_id` = customer code, name, city, addr, phone) · `route_stops` (agent, day, seq, client) · `orders` (uuid, client, agent, day, status `ordered|delivered|paid|cancelled`, payment, paid_agor, signature path) · `order_items` (product, qty_ordered, qty_delivered, price_agor, discount_pct) · `stock` (agent's car) · event log for logins/failures.
Order lifecycle: `ordered` (sent from the phone/office) → `delivered` (unloaded, signed) → `paid` (money taken, cheque/cash recorded).
