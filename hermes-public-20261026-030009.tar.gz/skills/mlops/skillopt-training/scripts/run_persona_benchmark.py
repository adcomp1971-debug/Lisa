#!/usr/bin/env python3
"""
Hermes Personality Benchmark Runner (DeepSeek-only).

Tests agent behavior across 10 tasks covering:
- Context retention (remembering facts across turns)
- Following constraints (language, format)
- Reasoning depth (not superficial answers)
- Multi-step dependencies
- Self-correction
- Prioritization

Uses DeepSeek-reasoner as LLM-as-judge and template-based reflect.
"""
import os, sys, subprocess, time

TIMESTAMP = str(int(time.time()))
OUT_ROOT = f"/root/SkillOpt/outputs/hermes_persona_{TIMESTAMP}"

def get_key(name):
    with open('/root/.hermes/.env') as f:
        for line in f:
            if line.startswith(name + '='):
                return line.split('=', 1)[1].strip()
    raise ValueError(f"{name} not found in .env")

ds_key = get_key('DEEPSEEK_API_KEY')

env = os.environ.copy()
env['PYTHONPATH'] = '/root/SkillOpt:' + env.get('PYTHONPATH', '')

# All DeepSeek — no Grok needed
env['AZURE_OPENAI_ENDPOINT'] = 'https://api.deepseek.com/v1'
env['AZURE_OPENAI_API_KEY'] = ds_key
env['AZURE_OPENAI_AUTH_MODE'] = 'openai_compatible'
env['OPTIMIZER_AZURE_OPENAI_ENDPOINT'] = 'https://api.deepseek.com/v1'
env['OPTIMIZER_AZURE_OPENAI_API_KEY'] = ds_key
env['OPTIMIZER_AZURE_OPENAI_AUTH_MODE'] = 'openai_compatible'
env['OPTIMIZER_DEPLOYMENT'] = 'deepseek-chat'
env['TARGET_AZURE_OPENAI_ENDPOINT'] = 'https://api.deepseek.com/v1'
env['TARGET_AZURE_OPENAI_API_KEY'] = ds_key
env['TARGET_AZURE_OPENAI_AUTH_MODE'] = 'openai_compatible'
env['TARGET_DEPLOYMENT'] = 'deepseek-chat'

print("=" * 60)
print("Hermes Personality Benchmark (DeepSeek-only)")
print("=" * 60)
print(f"Target: DeepSeek @ {env['TARGET_DEPLOYMENT']}")
print(f"Judge: DeepSeek-reasoner")
print(f"Reflect: Template-based (no LLM)")
print(f"Tasks: 10 (context, depth, constraints, coding, planning)")
print(f"Config: configs/hermes_persona/default.yaml")
print(f"Output: {OUT_ROOT}")
print("=" * 60)

result = subprocess.run(
    ['python', 'scripts/train.py',
     '--config', 'configs/hermes_persona/default.yaml',
     '--out_root', OUT_ROOT],
    cwd='/root/SkillOpt', env=env, capture_output=True, text=True
)

out = result.stdout
print(out[-3000:] if len(out) > 3000 else out)
if result.stderr:
    print("STDERR:", result.stderr[:2000])

print(f"\nExit: {result.returncode}")
sys.exit(result.returncode)
