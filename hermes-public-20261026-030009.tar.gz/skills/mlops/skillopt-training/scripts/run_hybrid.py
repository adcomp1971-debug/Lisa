#!/usr/bin/env python3
"""
SkillOpt hybrid backend runner.

Reads API keys from .env, sets up env vars for target (DeepSeek, cheap)
and optimizer (Grok, free via SuperGrok), launches train.py.

Usage:
    python run_hybrid.py [benchmark_name]

Defaults to 'searchqa' if no arg given.
Benchmarks available: searchqa, hermes_persona, alfworld, ...
"""
import os, sys, subprocess, time

BENCHMARK = sys.argv[1] if len(sys.argv) > 1 else "searchqa"
CONFIG = f"configs/{BENCHMARK}/default.yaml"
TIMESTAMP = str(int(time.time()))
OUT_ROOT = f"/root/SkillOpt/outputs/{BENCHMARK}_{TIMESTAMP}"

# Read keys from .env
def get_key(name):
    with open('/root/.hermes/.env') as f:
        for line in f:
            if line.startswith(name + '='):
                return line.split('=', 1)[1].strip()
    raise ValueError(f"{name} not found in .env")

ds_key = get_key('DEEPSEEK_API_KEY')
xai_key = get_key('XAI_API_KEY')

# Build env
env = os.environ.copy()
env['PYTHONPATH'] = '/root/SkillOpt:' + env.get('PYTHONPATH', '')

# Optimizer -> Grok (free via SuperGrok)
env['AZURE_OPENAI_ENDPOINT'] = 'https://api.x.ai/v1'
env['AZURE_OPENAI_API_KEY'] = xai_key
env['AZURE_OPENAI_AUTH_MODE'] = 'openai_compatible'
env['OPTIMIZER_AZURE_OPENAI_ENDPOINT'] = 'https://api.x.ai/v1'
env['OPTIMIZER_AZURE_OPENAI_API_KEY'] = xai_key
env['OPTIMIZER_AZURE_OPENAI_AUTH_MODE'] = 'openai_compatible'
env['OPTIMIZER_DEPLOYMENT'] = 'grok-4.20-0309-reasoning'

# Target -> DeepSeek (cheap)
env['TARGET_AZURE_OPENAI_ENDPOINT'] = 'https://api.deepseek.com/v1'
env['TARGET_AZURE_OPENAI_API_KEY'] = ds_key
env['TARGET_AZURE_OPENAI_AUTH_MODE'] = 'openai_compatible'
env['TARGET_DEPLOYMENT'] = 'deepseek-chat'

print(f"Target: DeepSeek @ {env['TARGET_DEPLOYMENT']}", flush=True)
print(f"Optimizer: Grok @ {env['OPTIMIZER_DEPLOYMENT']}", flush=True)
print(f"Benchmark: {BENCHMARK}", flush=True)
print(f"Config: {CONFIG}", flush=True)
print(f"Output: {OUT_ROOT}", flush=True)
print("=" * 60, flush=True)

result = subprocess.run(
    ['python', 'scripts/train.py',
     '--config', CONFIG,
     '--out_root', OUT_ROOT],
    cwd='/root/SkillOpt', env=env, capture_output=True, text=True
)

# Print tail
out = result.stdout
print(out[-3000:] if len(out) > 3000 else out, flush=True)

if result.stderr:
    print("STDERR:", result.stderr[:2000], flush=True)

print(f"\nExit: {result.returncode}", flush=True)
sys.exit(result.returncode)
