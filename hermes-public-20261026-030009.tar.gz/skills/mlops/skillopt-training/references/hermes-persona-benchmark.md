# Hermes Persona Benchmark

Оптимизация поведения Hermes через SkillOpt: улучшение удержания контекста,
глубины ответов, следования инструкциям и использования инструментов.

## Архитектура (DeepSeek-only + Template reflect)

```
┌──────────────────────────────────────────────────────────────┐
│  SkillOpt Training Loop (DeepSeek-only)                      │
│                                                               │
│  1. Rollout: DeepSeek V4 Flash отвечает на задачи             │
│     с текущим skill.md (system prompt)                        │
│  2. Judge: DeepSeek-reasoner оценивает каждый ответ           │
│     по checklist критериям (pass/fail)                        │
│  3. Reflect: Template-based (без LLM) — категоризирует        │
│     failures, генерирует append/insert_after патчи           │
│  4. Gate: candidate skill — accept/reject по валидации        │
│  5. Slow update + Meta skill: консолидация знаний             │
└──────────────────────────────────────────────────────────────┘
```

## Template-based reflection

`skillopt/envs/hermes_persona/reflect.py` содержит `run_custom_reflect`:

1. Собирает failed категории из результатов rollout-а
2. Маппит на шаблонные правила (7 категорий)
3. Генерирует `op: "append"` или `op: "insert_after"` патчи
4. Сохраняет в `patches/patch_000.json`

**Ни одного LLM вызова** — работает детерминированно за <1ms.

## Результаты прогонов (июнь 2026)

### Baseline (initial persona)
- Train hard: 0.0-1.0 (вариативно, зависит от батча)
- Val hard: 0.5 (50% задач пройдено)
- Test hard: 1.0 (единственная тестовая задача)

### С template-based reflect (3 эпохи, 6 steps)
- `accept=0, reject=3, skip=3` — патчи генерируются, но reject-ятся validation gate
- `best_score=0.5000` (baseline)
- Wall time: ~463-724 сек (полный цикл)

### Почему reject?
1. **Слишком маленький датасет** — 7 train + 2 val + 1 test задачи
2. **Binary hard scoring** — 1.0 только если ВСЕ критерии пройдены
3. **Добавление правил в system prompt** не меняет поведение на 1-2 конкретных тестах
4. Validation gate сравнивает hard score — нужен статистически значимый прирост

## Ключевые файлы

| Путь | Назначение |
|------|-----------|
| `skillopt/envs/hermes_persona/adapter.py` | EnvAdapter — связывает rollout/evaluate/reflect |
| `skillopt/envs/hermes_persona/reflect.py` | **Template-based reflect** — ядро, без LLM |
| `skillopt/envs/hermes_persona/evaluator.py` | LLM-as-judge на DeepSeek-reasoner |
| `skillopt/envs/hermes_persona/rollout.py` | Запуск DeepSeek V4 Flash на задачах |
| `skillopt/envs/hermes_persona/dataloader.py` | Загрузка и сплит датасета |
| `skillopt/envs/hermes_persona/data/tasks.json` | Датасет: 10 задач по 7 категориям |
| `configs/hermes_persona/default.yaml` | Конфиг (target=DeepSeek, template reflect) |
| `run_hermes_persona.py` | Runner — все env vars, запуск train.py |

## Известные ограничения

1. **Template-based reflect adds rules but can't remove or refine** — только append/insert_after. Для удаления устаревших правил нужна hand-crafted чистка.
2. **Validation gate на маленьком датасете reject-ит правильные патчи** — решение: `use_gate: false` для force-accept, или расширить датасет до 20+ задач.
3. **Нет доступа к tools в evaluation mode** — агент не может использовать web_search, terminal, browser. Задачи на tool use всегда фейлятся.
4. **Только русские правила** — чеклисты и ключевые слова заточены на русский язык.
