# DSPy Self-Evolution — Skill Improvement via GEPA/MIPROv2

Complementary approach to SkillOpt for auto-improving Hermes skills. Uses DSPy's
GEPA or MIPROv2 optimizers to mutate skill text and evaluate against synthetic
or golden datasets.

## Project Location

```
/root/hermes-agent-self-evolution/
├── evolution/
│   ├── core/          ─ Config, dataset builder, fitness metrics, constraints
│   ├── skills/        ─ evolve_skill.py, skill_module.py
│   └── __init__.py
├── datasets/          ─ Generated synthetic datasets (per skill)
├── output/            ─ Evolved skills with metrics (per skill, per timestamp)
├── .venv/             ─ venv with dspy==3.2.1 installed
└── pyproject.toml
```

## Quick Launch

```bash
cd /root/hermes-agent-self-evolution
source /root/.hermes/.env
export OPENROUTER_API_KEY
export HERMES_AGENT_REPO=/usr/local/lib/hermes-agent

.venv/bin/python3 -m evolution.skills.evolve_skill \
  --skill <skill-name> \
  --iterations 3 \
  --eval-source synthetic \
  --optimizer-model "openrouter/google/gemini-2.5-flash" \
  --eval-model "openrouter/google/gemini-2.5-flash"
```

## CRITICAL: User Skills Not Found by `find_skill()`

The `find_skill()` function in `evolution/skills/skill_module.py` only searches
the Hermes repo's bundled skills at `/usr/local/lib/hermes-agent/skills/`.

**User skills live in `~/.hermes/skills/`** ─ the evolution tool cannot see them
by default.

### Root Cause

`find_skill()` uses `Path.rglob('SKILL.md')` which, in Python 3.11, does **not**
follow symlinks (the `follow_symlinks` parameter was added in Python 3.13+).
The repo's skills/ directory has symlinks like:
```
/usr/local/lib/hermes-agent/skills/media/youtube-workflow -> /root/.hermes/skills/media/youtube-workflow
```

### Fix A ─ Copy skills directly (recommended, simpler)

```bash
# If repo already has a symlink, remove it first
rm /usr/local/lib/hermes-agent/skills/<category>/<skill-name>

# Copy the full skill directory (or just SKILL.md)
cp -r ~/.hermes/skills/<category>/<skill-name>/ \
   /usr/local/lib/hermes-agent/skills/<category>/<skill-name>/
```

`find_skill()` only needs SKILL.md, but `cp -r` also brings references/ and
scripts/ which avoids surprises.

### Fix B ─ Patch `find_skill()` to follow symlinks

In `evolution/skills/skill_module.py`, replace:
```python
for skill_md in skills_dir.rglob("SKILL.md"):
```
with `os.walk(followlinks=True)`:
```python
import os
for root, dirs, files in os.walk(str(skills_dir), followlinks=True):
    if "SKILL.md" in files:
        skill_md = Path(root) / "SKILL.md"
```

### Verify the fix

```bash
python3 -c "
from pathlib import Path
import os
path = Path('/usr/local/lib/hermes-agent/skills')
count = 0
for root, dirs, files in os.walk(str(path), followlinks=True):
    if 'SKILL.md' in files:
        count += 1
        print(f'{Path(root).name} -> SKILL.md')
print(f'Total: {count} skills found')
"
```

## Output Structure

After a successful run:
```
output/<skill-name>/<timestamp>/
  baseline_skill.md     ─ Original skill (for diff)
  evolved_skill.md      ─ DSPy-evolved version
  metrics.json          ─ Scores, sizes, improvement delta
```

When constraint validation fails (expected), the output saves to:
```
output/<skill-name>/evolved_FAILED.md
```
This file has proper YAML frontmatter and is valid ─ inspect it manually.

## Key Differences from SkillOpt

| Aspect | SkillOpt | DSPy Self-Evolution |
|---|---|---|
| Framework | Microsoft SkillOpt | DSPy (GEPA / MIPROv2) |
| Mutation | Trajectory-driven edits via checklist reflection | Text-level mutations via optimizer |
| Eval | Rollout on benchmark tasks | LLM-as-judge on synthetic/golden dataset |
| Val. gate | Optional (use_gate) | Constraint validator (size, growth) |
| Dataset | Built-in benchmarks (SearchQA) | Synthetic (generated from skill text) |
| Cost | ~$0.15/M tokens (DeepSeek) | ~Gemini 2.5 Flash via OpenRouter |
| Iterations | 3-6 steps | 3-10 MIPROv2 steps |

## Proven Runs

All runs used MIPROv2 with `--eval-source synthetic` and Gemini 2.5 Flash via
OpenRouter. MIPROv2 optimizes instructions + few-shot examples, not skill body
(0% growth by design). All saved to `evolved_FAILED.md` ─ inspect manually.

| Skill | Category | Iter | Best Score | Improvement | Time | Date |
|---|---|---|---|---|---|---|
| web-research | media | 3 | ~50% | +53% over baseline | ~180s | 2026-06-13 |
| task-router-production | productivity | 3 | ~48% | +12.5% over baseline | ~180s | 2026-06-13 |
| youtube-workflow | media | 3 | 59.64% | +7.79pp from ~51.85% | 102.6s | 2026-06-15 |
| email-agent | email | 3 | 62.42% | +8.78pp from ~53.64% | 81.9s | 2026-06-15 |
