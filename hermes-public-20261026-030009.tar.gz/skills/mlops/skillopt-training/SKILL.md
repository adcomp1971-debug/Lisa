---
name: skillopt-training
description: "Auto-improve Hermes skills via SkillOpt optimization. Two backends: DeepSeek-only (current, preferred) or hybrid DeepSeek+Grok (legacy). Template-based reflection for persona benchmarks."
version: 2.0.0
---

# SkillOpt Training Workflow

Run the SkillOpt framework from `microsoft/SkillOpt` to train/improve agent skills via trajectory-driven edits with validation gates.

## Prerequisites

- Installed: `pip install skillopt` (or repo at `/root/SkillOpt/`)
- Repo: `git clone https://github.com/microsoft/SkillOpt.git /root/SkillOpt/`
- Venv: `/root/skillopt-venv/`
- API keys in `/root/.hermes/.env`: `DEEPSEEK_API_KEY`, `XAI_API_KEY`

## Architecture

### Two proven backends

| Backend | Target (rollouts) | Optimizer (judge) | Reflect | Cost |
|---------|-------------------|--------------------|---------|------|
| **DeepSeek-only** (current) | DeepSeek `deepseek-chat` (V4 Flash) | DeepSeek `deepseek-reasoner` | **Template-based** (no LLM) | ~$0.15/M tokens |
| Hybrid (legacy) | DeepSeek V4 Flash | Grok-4.20-reasoning (SuperGrok, free) | LLM analyst | Free |

**DeepSeek-only** is the preferred pipeline — simpler, no cross-provider auth issues, and the template-based reflect is deterministic.

**Template-based reflection** (`run_custom_reflect`) completely replaces the LLM analyst — maps failed checklist categories to concrete skill edits using a rule table, no LLM call needed.

### Template-based reflect categories

| Category | Triggers | Edit produced |
|----------|----------|--------------|
| `context_retention` | контекст, помнить, ранее, шаг | Add "Context Retention" section with reference rules |
| `following_constraints` | язык, русск, markdown, бабушк | Add "Following Constraints" section with format rules |
| `reasoning_depth` | глубок, анализ, причин, log, ошибок | Add "Depth of Analysis" section with structure rules |
| `tool_use` | поиск, браузер, инструмент, курс, проверь | Add "Tool Use" section with verification rules |
| `coding` | код, функци, модуль, python | Add "Code Consistency" section with preservation rules |
| `planning` | порядк, приоритет, план | Add "Planning & Prioritization" section |
| `self_correction` | ошибк, перепроверь, предыдущ, коррекци | Add "Self-Correction" section |

## Quick Launch

### Recommended: All-DeepSeek with template reflect

```bash
# Write key to temp file
grep ^DEEPSEEK_API_KEY /root/.hermes/.env | cut -d= -f2- > /tmp/ds_key.txt

# Run (DeepSeek target + DeepSeek judge + template reflect)
cd /root/SkillOpt
source /root/skillopt-venv/bin/activate
python run_hermes_persona.py

# Or using the skill's script
python /root/.hermes/skills/mlops/skillopt-training/scripts/run_persona_benchmark.py
```

### Legacy: Hybrid (Grok optimizer + DeepSeek target)

```bash
# Write keys to temp files (one-time)
grep ^DEEPSEEK_API_KEY /root/.hermes/.env | cut -d= -f2- > /tmp/ds_key.txt
grep ^XAI_API_KEY /root/.hermes/.env | cut -d= -f2- > /tmp/xai_key.txt

cd /root/SkillOpt
source /root/skillopt-venv/bin/activate
python /root/.hermes/skills/mlops/skillopt-training/scripts/run_hybrid.py hermes_persona
```

**IMPORTANT:** Always use Python scripts (not bash exports) for setting API keys. Shell
quoting with `export VAR=***` is fragile — API key values can contain special chars
that break parsing, and terminal masking can inject invisible characters. The scripts
under `scripts/` handle this correctly via Python subprocess `env=` dict.

### Available runner scripts

| Script | Purpose | Backend |
|--------|---------|---------|
| `scripts/run_hybrid.py` | Run any benchmark with DeepSeek target + Grok optimizer. Args: `[benchmark_name]` (default: searchqa) | Hybrid (legacy) |
| `scripts/run_persona_benchmark.py` | Run Hermes personality benchmark (context, depth, constraints tasks) | DeepSeek-only (current) |
| `run_hermes_persona.py` | Root-level runner in /root/SkillOpt/ — fixed config, all DeepSeek + template reflect | DeepSeek-only |

## Config Template

Create `configs/<benchmark>/default.yaml`:

```yaml
_base_: ../_base_/default.yaml

model:
  azure_openai_endpoint: https://api.x.ai/v1
  azure_openai_auth_mode: openai_compatible
  optimizer_azure_openai_endpoint: https://api.x.ai/v1
  optimizer_azure_openai_auth_mode: openai_compatible
  target_azure_openai_endpoint: https://api.deepseek.com/v1
  target_azure_openai_auth_mode: openai_compatible
  optimizer: grok-4.20-0309-reasoning
  target: deepseek-chat
  optimizer_backend: openai_chat
  target_backend: openai_chat
  reasoning_effort: ""

train:
  train_size: 10
  batch_size: 5
  num_epochs: 3

gradient:
  minibatch_size: 4
  merge_batch_size: 4

optimizer:
  learning_rate: 2

env:
  name: <benchmark_name>
  skill_init: skillopt/envs/<benchmark>/skills/initial.md
  max_turns: 1
  max_completion_tokens: 4096
  workers: 4
```

## Adding a New Benchmark

### Standard (SearchQA-style)

1. Create `skillopt/envs/<name>/` with:
   - `dataloader.py` — load/parse task data
   - `rollout.py` — run agent on task with current skill
   - `adapter.py` — EnvAdapter subclass
   - `evaluator.py` — scorer/verifier for task
   - `skills/initial.md` — starting skill (can be empty boilerplate)
   - `reflect.py` — optional custom reflection logic

- Register adapter in соответствующем runner script из `scripts/` (`_register_builtins()`)

3. Create config in `configs/<name>/default.yaml`

4. Set `split_mode: ratio` with train/val splits

### LLM-as-Judge (Hermes Persona-style)

For benchmarks where answers are open-ended (not exact-match), use a judge model
to score responses against a checklist:

1. Create tasks as JSON with `instruction`, `context` (optional), `checklist` (array of criteria)
2. Evaluator calls `chat_optimizer` (Grok-4.20-reasoning) to score each criterion pass/fail
3. `hard` = 1.0 only if ALL criteria pass; `soft` = ratio passed
4. The rollout function must add `hard`/`soft` to each result dict (trainer's
   `compute_score()` reads these keys)
5. Import the evaluator in `rollout.py` and call `evaluate(response, task)` after
   getting each response

**Known limitation:** The default reflect prompts can't derive skill edits from
checklist-based scores. They work best with right/wrong answer formats.

### Configs available in this repo

| Config | Description |
|--------|-------------|
| `configs/searchqa/xai_test.yaml` | SearchQA with Grok-only (for testing xAI API) |
| `configs/hermes_persona/default.yaml` | Hermes behavior optimization (context, depth, constraints) |

## Convergence Detection & Early Termination

SkillOpt can enter a dead cycle where it's alive but making zero progress. Know the signs.

### Telltale signs of convergence

| Signal | What to check | Command |
|--------|---------------|---------|
| 0 patches for 3+ consecutive steps | `runtime_state.json: current_score` unchanged | `cat <out_root>/runtime_state.json` |
| CPU < 1% | Process sleeping on API calls, not computing | `ps -p <PID> -o pid,stat,etime,%cpu,cputime` |
| Skill length stable | No new content added across steps | `wc -c <out_root>/skills/skill_v*.md` |
| Empty slow_update logs | Log files exist but empty | `cat <out_root>/slow_update/epoch_*/log.txt` |
| All skip_no_patches | `history.json` shows consecutive `action: skip_no_patches` | `grep action <out_root>/history.json` |

### What this looks like in practice

```
Pid  STAT   ELAPSED  %CPU  CPUTIME
957736 Sl    09:25    0.3   00:00:02
```

Process alive for 9+ minutes but only 2 seconds CPU time — almost entirely blocked on API calls that return "nothing to improve." `history.json` shows steps 3-6 all with `action: skip_no_patches`.

### Action on detection

1. **Kill the process:**
   ```bash
   kill <PID>
   # Verify gone:
   ps aux | grep train.py | grep -v grep
   ```

2. **Preserve the result:** The `best_skill.md` has the optimal version reached so far. The latest skill file in `skills/` may have the `SLOW_UPDATE` section with additional rules not merged into best:
   ```bash
   diff <out_root>/best_skill.md <out_root>/skills/skill_v$(cat <out_root>/runtime_state.json | python3 -c "import sys,json; print(json.load(sys.stdin)['last_completed_step'])").md
   ```

3. **Apply best skill to Hermes:** The generated persona is optimized for Hermes' system prompt. Compare it against the current persona and merge any improvements.

4. **Log outcome:** Note final score, steps completed, and whether convergence was reached or if the run was interrupted. This helps decide if a future run needs different hyperparameters (larger benchmark, different judge model).

### Why convergence happens

- **Template-based reflect finds nothing new** — once all common failure modes (context retention, following constraints, depth, tool use) are covered in the skill text, no checklist category triggers any edit.
- **LLM judge scores don't distinguish improvements** — with a small validation set (3-4 tasks) and binary scoring (all-pass = 1.0, any fail = 0.0), DeepSeek evaluator can't statistically differentiate between persona candidates.
- **Slow_update mode cycles through epochs** — after initial rollout+edit epochs, SkillOpt enters slow_update which runs the same rollout loop without the edit pipeline. This produces no patches by design.

### When NOT to stop

- If CPU is >5% and wall time is accumulating — the process is actively computing rollouts, not stuck.
- If steps 1-2 produced patches but step 3 hasn't finished yet — wait for 3+ consecutive zero-patch steps.
- If output files in `steps/` are actively being written (check `ls -lt` timestamps).

## Pitfalls

### API Key / Auth Setup

- **DO NOT use bash `export` for API keys.** Shell quoting with `export VAR=***` is
  fragile — API key values get corrupted, terminal masking injects invisible chars.
  Always use Python `subprocess.run(env=...)` dict or write keys to temp files.
- **Azure OpenAI auth mode** must be `openai_compatible` for non-Azure backends
  (xAI, DeepSeek, etc.). All three roles (default, optimizer, target) need it set,
  or the `_make_client()` function falls through to Azure AD token provider.
- Both `OPTIMIZER_DEPLOYMENT` and `TARGET_DEPLOYMENT` must be set as env vars
  (not just config model names). The config's `model.optimizer` and `model.target`
  are used by the trainer to set these env vars, but if the trainer hasn't called
  `set_optimizer_deployment()/set_target_deployment()` yet, the azure_openai
  module uses default `gpt-4o`.
- **DO NOT** set `reasoning_effort` to non-empty for xAI models — they don't support
  the `reasoningEffort` parameter. Use `""` (empty string) to disable.

### Reflection / Editing

- **Default reflect prompts produce 0 patches for persona optimization.** The
  default `error_system`/`success_system` prompts in SkillOpt are tuned for
  SearchQA-style tasks (factual right/wrong answers). For system-prompt optimization
  (context retention, depth, constraints), the analyst model can't translate
  checklist failures into concrete skill edits. **Solution:** use template-based
  reflect (`run_custom_reflect` in `skillopt/envs/hermes_persona/reflect.py`)
  which maps failed categories to concrete `append`/`insert_after` edits — no
  LLM call needed.
- **Template-based reflect generates correct patches** that SkillOpt applies
  correctly (supports `op: append`, `insert_after`, `replace`, `delete`). The
  validation gate then evaluates the candidate skill rollout — patches that don't
  measurably improve the score get `reject` status.
- **CONFIRMED WORKING — Run v1 (2026-06-13):** Template-based reflect generated 2+
  patches per step, 5 out of 6 steps accepted (use_gate=false). The generated
  persona rules are saved in `references/hermes-persona-generated.md` and
  include: context retention rules, planning prioritization, constraint following,
  and a working memory protocol (see SLOW_UPDATE block). Total run: 737s, 195K
  tokens, 136 calls.
- **CONFIRMED WORKING — Run v3 (final, 2026-06-13):** 2 force_accept (context
  retention rules: exact-word quoting, pre-answer history check, multi-step
  tracking) + 4 skip_no_patches (convergence). Best score 0.5. Persona
  optimization concluded — binary scoring on a 10-task dataset cannot
  distinguish further improvements. Next SkillOpt runs should target concrete
  operational skills (vpn-auto-doctor, xray-add-client) where evaluators can
  measure deterministic success/failure.
- **gate config bug:** `use_gate: false` in config only works if it's at TOP level after flattening. In structured configs with `_base_`, the value gets nested under `evaluation.use_gate`. The flatten_config correctly maps `evaluation.use_gate` → `use_gate`, but ONLY if the base config doesn't override it. To be safe, pass `--cfg-options evaluation.use_gate=false` on CLI.

## Related Techniques

### DSPy Self-Evolution

A complementary approach to skill improvement using DSPy's GEPA/MIPROv2 optimizers.
Project: `/root/hermes-agent-self-evolution/`. Key differences from SkillOpt:
- Text-level mutations via DSPy (not trajectory-driven edits)
- Evaluates against synthetic datasets (not benchmark rollouts)
- Constraint validator (size, growth) replaces rollout gates

**⚠️ Critical pitfall — user skills invisible to find_skill():**
`find_skill()` in `evolution/skills/skill_module.py` uses `Path.rglob('SKILL.md')`
which does NOT follow symlinks in Python 3.11. User skills in `~/.hermes/skills/`
cannot be found. Fix: copy skills into the repo's skills/ dir or patch with
`os.walk(followlinks=True)`. Full details: `references/dspy-self-evolution.md`
- **Output cache (`sel_cache`) persists in process memory.** Running the same config path to the same `--out_root` reuses previous rollout results via `cand_hash` cache. This can cause steps 4-6 to appear instantly (2s rather than 120s) and produces misleading step histories. **Always use a fresh `--out_root` directory** between training runs. The `step_record.json` from cached results will have `timing.evaluate_s: 0.0` which is a red flag.
- **Validation gate rejects even correct patches on small benchmarks.** With
  1-3 validation items and binary hard scoring (1.0 if ALL pass, else 0.0),
  adding rules to a system prompt can't statistically improve the score. Fixes:
  (a) `use_gate: false` in config to force-accept all patches, (b) larger
  benchmark (20+ tasks), (c) `soft` gate that accepts on soft score improvement.
- **Output directory caching:** Running `run_hermes_persona.py` to the same
  `--out_root` twice loads cached runtime state and produces misleading results.
  Always `rm -rf outputs/<name>` between runs, or use a new directory.
- **`_base_` inheritance can override local config.** Configs use `_base_: ../_base_/default.yaml`.
  If the base config has `evaluation.use_gate: true` and yours has `use_gate: false`, the
  base WINS after merge unless you explicitly set it in the local config. Always check
  `_base_` before assuming your settings will be respected. The `_DeepMerge` is recursive
  so nested keys from base persist if not overridden.
- **Output cache (`sel_cache`) persists in process memory.** Running the same config path
  to the same `--out_root` reuses previous rollout results via `cand_hash` cache. This
  can cause steps 4-6 to appear instantly (2s rather than 120s) and produces
  misleading step histories. **Always use a fresh directory** between training runs.
  The `step_record.json` from cached results will have `timing.evaluate_s: 0.0` which
  is a red flag.
- **LLM-as-judge scoring** uses `chat_optimizer` (DeepSeek-reasoner by default).
  Adds ~2-5 seconds per evaluation call. For 10 tasks × 10 steps = ~300-500s
  judge overhead.
