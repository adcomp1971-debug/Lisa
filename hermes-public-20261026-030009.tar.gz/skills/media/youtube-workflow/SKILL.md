---
name: youtube-workflow
description: "Complete YouTube workflow: content extraction (transcripts, summaries) and channel monitoring (RSS scouting, cron delivery)."
category: media
version: 1.0.0
author: Hermes Agent
---

# YouTube Workflow Umbrella

This skill covers the entire YouTube content lifecycle. Use the relevant subsection based on your current task.

## 1. Content Extraction (`youtube-content`)
Transform YouTube transcripts into structured content (chapters, summaries, Twitter threads, blog posts).

- **Fetch:** `python3 scripts/fetch_transcript.py "URL" --text-only --timestamps`
- **Language:** Use `--language tr,en` for specific language with fallback chain.
- **Fallbacks:** If API is blocked (common on cloud VPS), use the 5-tier fallback:
  1. Browser description + JSON-LD metadata extraction (always works, provides chapter timestamps).
  2. `youtube-transcript-proxy` (Invidious mirrors).
  3. `youtube-audio-transcribe` (faster-whisper, takes 5-30 min).
  4. `video-summary-web-fallback` (search web for existing summaries).

**Output Formats:** Chapters, Summary, Chapter summaries, X/Thread format, Blog post.

## 2. Channel Monitoring / Scouting (`youtube-scout`)
Automated detection of new videos on specified YouTube channels via RSS + SQLite deduplication + cron delivery.

- **RSS URL pattern:** `https://www.youtube.com/feeds/videos.xml?channel_id=UC...`
- **Workflow:** Script checks RSS, saves unseen `video_id` to SQLite, outputs concise digest.
- **Cron (no_agent):** Fast, title-only delivery. Pass `--since 48` to limit to last 48h (prevents massive first-run dumps).
- **Cron (LLM):** Slower, uses `web_extract` on new video URLs to pull full description + chapters, then generates a Russian-language technical summary with "Key features" and "Useful takeaways".

**Finding Channel IDs:** Navigate to `https://www.youtube.com/@ChannelName`, extract `ytInitialData.metadata.channelMetadataRenderer.externalId` via `browser_console`.

## Linked Resources
- `scripts/fetch_transcript.py` (core transcript fetching)
- `scripts/fetch_transcript.py` (см. раздел 2 для RSS мониторинга)
- `references/output-formats.md` (formatting guidelines for summaries/threads)
- `references/full-script.md` (complete scout script example)

## Pitfalls
- **Cloud IP blocks:** YouTube aggressively blocks cloud IP ranges for direct transcript API. Default to Tier 0.5 (browser extraction) or Tier 1 (proxy) immediately.
- **Auto-dubbed videos:** Have NO caption tracks. Tier 2 (audio transcription) will transcribe the low-quality dubbed audio. Use Tier 0.5 (browser metadata) instead.
- **Long videos (>1h):** Chunk transcripts into 40K-character overlapping segments before summarizing.
- **First cron run:** Collects ALL videos in RSS. Always use `--since 48` for recurring cron jobs.