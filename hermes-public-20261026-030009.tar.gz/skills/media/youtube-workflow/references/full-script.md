# Полный скрипт YouTube Scout

Расположение: `~/.hermes/scripts/youtube-scout.py`

```python
#!/usr/bin/env python3
"""YouTube Scout — мониторинг AI-каналов через RSS."""

import sqlite3, urllib.request, urllib.error, xml.etree.ElementTree as ET
import json, sys, os, time
from datetime import datetime, timezone, timedelta

DB_PATH = os.path.expanduser("~/.hermes/youtube_scout.db")

CHANNELS = [
    {"id": "UCXUPKJO5MZQN11PqgIvyuvQ", "name": "Andrej Karpathy", "tags": ["deep learning", "LLM", "neural nets"]},
    {"id": "UCNJ1Ymd5yFuUPtn21xtRbbw", "name": "AI Explained", "tags": ["AI breakthroughs", "LLM", "research"]},
    {"id": "UCbfYPyITQ-7l4upoX8nvctg", "name": "Two Minute Papers", "tags": ["research", "papers", "neural nets"]},
    {"id": "UCZHmQk67mSJgfCCTn7xBfew", "name": "Yannic Kilcher", "tags": ["deep learning", "ML research"]},
    {"id": "UCzz6ructab1U44QPI3HpZEQ", "name": "Stanford MLSys Seminars", "tags": ["ML systems", "academia"]},
    {"id": "UCcIXc5mJsHVYTZR1maL5l9w", "name": "DeepLearningAI", "tags": ["deep learning", "education"]},
    {"id": "UCBHcMCGaiJhv-ESTcWGJPcw", "name": "NVIDIA Developer", "tags": ["GPU", "NVIDIA", "AI infra"]},
    {"id": "UCtAcpQcYerN8xxZJYTfWBMw", "name": "Umar Jamil", "tags": ["deep learning", "coding"]},
    {"id": "UCqcbQf6yw5KzRoDDcZ_wBSw", "name": "Wes Roth", "tags": ["AI news", "research"]},
]

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS videos (
        video_id TEXT PRIMARY KEY, channel_id TEXT, channel_name TEXT,
        title TEXT, url TEXT, description TEXT, published TEXT,
        detected_at TEXT, transcript_status TEXT DEFAULT 'pending', tags TEXT
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS digests (
        id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT,
        new_count INTEGER, content TEXT
    )""")
    conn.commit()
    return conn

def fetch_rss(channel_id):
    url = f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    resp = urllib.request.urlopen(req, timeout=15)
    root = ET.fromstring(resp.read())
    ns = {"atom": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015"}
    entries = []
    channel_name = root.findtext("atom:title", "", ns)
    for entry in root.findall("atom:entry", ns):
        vid = entry.findtext("yt:videoId", "", ns)
        entries.append({
            "video_id": vid,
            "channel_id": channel_id,
            "channel_name": channel_name,
            "title": entry.findtext("atom:title", "", ns),
            "url": f"https://youtube.com/watch?v={vid}",
            "description": (entry.findtext("media:group/media:description", "", ns) or "")[:2000],
            "published": entry.findtext("atom:published", "", ns),
        })
    return entries

def do_check(since_hours=None):
    conn = init_db()
    cursor = conn.cursor()
    cutoff = datetime.now(timezone.utc) - timedelta(hours=since_hours) if since_hours else None
    all_new = []
    for ch in CHANNELS:
        for entry in fetch_rss(ch["id"]):
            if cutoff:
                try:
                    pub = datetime.fromisoformat(entry["published"].replace("Z","+00:00"))
                    if pub < cutoff: continue
                except: pass
            if cursor.execute("SELECT 1 FROM videos WHERE video_id=?", (entry["video_id"],)).fetchone():
                continue
            cursor.execute("""INSERT OR IGNORE INTO videos VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (entry["video_id"], entry["channel_id"], entry["channel_name"], entry["title"],
                 entry["url"], entry["description"][:2000], entry["published"],
                 datetime.now(timezone.utc).isoformat(), "pending",
                 ", ".join(ch["tags"])))
            all_new.append(entry)
        time.sleep(0.5)
    conn.commit()
    if not all_new:
        print("📡 YouTube Scout — новых видео не найдено")
        conn.close()
        return
    all_new.sort(key=lambda e: e.get("published",""), reverse=True)
    print(f"📡 YouTube Scout — {len(all_new)} новых видео\n")
    for e in all_new:
        try:
            dt = datetime.fromisoformat(e["published"].replace("Z","+00:00"))
            pub_str = dt.strftime("%d %b %Y, %H:%M")
        except: pub_str = str(e["published"])[:10]
        print(f"▎{e['title']}\n  {e['channel_name']} · {pub_str}\n  {e['url']}")
        if e.get("description"):
            print(f"  {e['description'][:500]}")
        print()
    conn.execute("INSERT INTO digests VALUES (NULL,?,?,?)",
        (datetime.now(timezone.utc).isoformat(), len(all_new),
         f"Найдено {len(all_new)} новых видео"))
    conn.commit()
    conn.close()

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--check":
        since = None
        if "--since" in sys.argv:
            idx = sys.argv.index("--since")
            since = int(sys.argv[idx+1]) if len(sys.argv) > idx+1 else 48
        do_check(since)
    else:
        do_check()
```

## Cron job

```bash
# Создание (через Hermes API):
cronjob(action='create',
    name='youtube-scout-daily',
    schedule='0 10 * * *',
    script='youtube-scout.py',
    no_agent=True,
    deliver='origin')
```

## Варианты

- `--since N` — показать только видео за последние N часов (для быстрого теста)
- `--digest` — показать последние 20 видео из БД (для просмотра истории)
- По умолчанию `--check` — показывает только невиданные ранее видео
