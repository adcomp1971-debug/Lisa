---
name: video-subtitles
description: "Use when a video needs subtitles or Russian translation."
category: media
version: 1.1.0
author: Hermes Agent
---

# Video → subtitles / translation

## When to Use

Когда просят «переведи это видео» или «сделай русские субтитры» по ссылке (Facebook Reel, YouTube, Instagram, X и т.п.). Выход — файл `.srt` + текстовый перевод в чат.

**Сначала** `yt-dlp --dump-json "<URL>"` — в `title`/`description` часто уже лежит полный текст (рецепт, цитата): тогда достаточно перевести, аудио и STT не нужны. Facebook Reel резолвится как generic → facebook:reel → facebook.

## Порядок

1. **Скачать видео+аудио** — `yt-dlp` берёт почти любой источник без cookies (публичные Reels/Shorts/TikTok идут напрямую; приватные/сторис могут требовать cookies):

```bash
cd /root/.hermes/cache/scratch && yt-dlp -o "vid.%(ext)s" -f "bv*+ba/b" "<URL>"
```

Facebook share-ссылки (`/share/r/...`) yt-dlp сам редиректит на `/reel/<id>`. Метаданные — `yt-dlp --dump-json "<URL>"`: там `title`/`description`, а у рецептов/инструкций часто и готовый текст автора (его переводить точнее, чем распознанную речь).

2. **Извлечь аудио в 16k mono wav** (нужно для whisper):

```bash
FF=/root/.hermes/tools/ffmpeg-9.0.1-linux-x64/bin
$FF/ffmpeg -y -v error -i vid.mp4 -ac 1 -ar 16000 -vn vid.wav
$FF/ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1 vid.wav
```

3. **Транскрибировать через OpenAI whisper-1 API** (нужен `OPENAI_API_KEY` из `/root/.hermes/.env`; быстрее локального faster-whisper, без скачивания модели):

```bash
set -a && source /root/.hermes/.env && set +a
curl -s --max-time 180 https://api.openai.com/v1/audio/transcriptions \
  -H "Authorization: Bearer $OPENAI_API_KEY" \
  -F "file=@vid.wav" -F "model=whisper-1" \
  -F "response_format=verbose_json" -F "language=<код>" -o transcript.json
```

`response_format=verbose_json` отдаёт `segments[]` со `start`/`end` (секунды) — из них собираются таймкоды .srt. `language` задавать, если знаешь язык (улучшает точность); без него whisper определит сам.

4. **Перевести сегменты на русский и собрать .srt** (сегмент → номер → `HH:MM:SS,mmm --> HH:MM:SS,mmm` → текст → пустая строка). Перевод — сам агент (знает польский/англ/итд); для незнакомого языка прогнать текст через LLM. Миллисекунды: `ms = int(round(sec*1000))` → `h=ms//3600000; m=ms%3600000//60000; s=ms%60000//1000; ms3=ms%1000`.

5. **Отдать файл и текст**: `.srt` через `/root/send_file.py` (сохранить расширение `.srt` — иначе не наложится), плюс текстовый перевод в чат.

## Питфоллы

- **Facebook Reel в мобильном браузере не воспроизводится** — страница пишет «Загрузка истории приостановлена. Откройте Facebook». Это ограничение FB (Reel только в приложении), не проблема ссылки. Если клиент не может смотреть — отправить скачанный `.mp4` через `sendVideo` (`curl -F "video=@..." -F "chat_id=..."`), а не чинить ссылку.
- **Groq whisper (`whisper-large-v3-turbo`) может быть недоступен** (invalid API key в этом окружении) — рабочий путь OpenAI `whisper-1`. Проверять ключ перед выбором бэкенда, не закладываться на Groq.
- **`/root/send_file.py` хардкодит `Content-Type: text/plain` + `sendDocument`** — для `.srt` это ок (файл дойдёт), но видео `.mp4` слать `sendVideo` (нативный плеер), а не sendDocument.
- **Искажения whisper** («krajski» вместо «rajski») — сверять транскрипцию с `title`/`description` из `--dump-json`, где текст дан автором точно.
- **`.srt` отдавать с расширением `.srt`, а не `.txt`** — иначе в плеер не наложить; это исключение из общего правила «конфиги → .txt». Пользователю нужны оба: файл и текстовый перевод в чат.
