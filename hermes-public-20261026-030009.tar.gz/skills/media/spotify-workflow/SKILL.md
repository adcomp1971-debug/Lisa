---
name: spotify-workflow
description: "Spotify automation: playback control, search, queue management, playlist curation, and DJ set building."
category: media
version: 1.0.0
author: Hermes Agent
---

# Spotify Workflow Umbrella

This skill covers all Spotify-related automation and interaction.

## 1. Core Playback & Library (`spotify`)
- **Playback:** play, pause, next, previous, seek, set volume, set repeat/shuffle.
- **Search:** Find tracks, albums, artists, or playlists by query.
- **Library:** List, save, or remove saved tracks and albums.
- **Devices:** List available Spotify Connect devices and transfer playback.

## 2. DJ Set Curation (`dj-spotify`)
Build structured DJ sets on Spotify:
- **3-Phase Playlists:** Warmup → Peak → Cooldown.
- **Genre Search:** Batch-fill playlists based on genre, BPM, or mood.
- **Crossfade Setup:** Configure crossfade duration for seamless transitions.
- **Voice-control shorthand:** Quick commands to adjust the vibe without manual searching.

## Pitfalls
- **Device availability:** Playback commands will fail if no active Spotify Connect device is selected. Always run `spotify_devices(action='list')` first to verify an active device, or use `spotify_devices(action='transfer')` to target a specific one.
- **Market restrictions:** Some tracks are not available in all regions. Always pass the `market` parameter (e.g., `US`, `RU`) when searching or retrieving library items to avoid 404 errors.
- **Rate limits:** Spotify API has strict rate limits on rapid successive calls (e.g., adding 50 tracks one by one). Use batch operations (`uris` array) whenever possible.