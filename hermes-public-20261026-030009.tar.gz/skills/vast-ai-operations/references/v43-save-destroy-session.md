# v4.3 / v5 Save & Destroy — Session Reference (Jun 2026)

## Save-Before-Destroy Summary (27 Jun 2026 session)

**Instance 42728219** — 30 macro checkpoints + dataset (2.4 GB total)
- Label: pianoid-v5
- GPU: RTX 4090
- Cost: $0.344/h, 12+ hours running, GPU 0%

**Instance 42601962** — forgotten/unlabelled, same setup, 29+ hours, GPU 0%

### What worked

1. **Small files (82 MB dataset + 86 KB log)** — `vastai copy` foreground, 15 MB/s, instant
2. **2.3 GB checkpoints (30×76 MB)** — `vastai copy` background with notify_on_complete, 4-7 MB/s, ~8 min total
3. **Destroy** — `yes | vastai destroy instance <ID>` — accepts stdin pipe ✅

### What didn't work
- `vastai copy` destination path that already exists (even 0-byte stub) → `FileExistsError`. Fix: `rm -f` the local file first.
- SSH proxy (`ssh3.vast.ai`) — repeatedly timed out during `banner exchange`
- `vastai ssh` and `vastai execute` — **do not exist**
- Direct rsync with `--rsh` — `Permission denied (publickey)` on some Vast hosts

### Speed comparison (updated)

| Method | Usable for | Speed | Reliable? |
|--------|-----------|-------|-----------|
| `vastai copy` rsync-daemon, <100 MB | Small files | 10-15 MB/s | ✅ |
| `vastai copy` rsync-daemon, 100 MB-3 GB | Checkpoints, datasets | 4-7 MB/s | ⚠️ Transient break, retry works |
| SSH proxy direct rsync | Any | 100 KB/s-3 MB/s | ❌ Timeouts, flaky |
| `vastai copy` >3 GB | Large archives | Unknown (not tested) | ❌ May break at ~79% |

### Key lessons
- Prefer `vastai copy` (direct rsync-daemon) over SSH proxy for any file transfer
- Use background mode for anything >100 MB (foreground timeout 600s)
- Always check ALL instances — not just labelled ones. Forgotten instances burn $8-10/day
- Update STATUS.md after saving — stale status text causes user frustration
