# Moonshot (Kimi) Provider Setup

## Endpoint

`https://api.moonshot.ai/v1` — OpenAI-compatible.

### Модели (на Jul 2026)

| Модель | Контекст | Особенности |
|--------|----------|-------------|
| `kimi-k3` | 1,048,576 (1M) | 2.8T params, reasoning, vision, video **НОВЫЙ** |
| `kimi-k2.7-code` | 262,144 | Кодинг-модель |
| `kimi-k2.7-code-highspeed` | 262,144 | 260 tok/s, 6x быстрее |
| `kimi-k2.6` | 262,144 | Предыдущая генерация |

## Config.yaml

```yaml
providers:
  moonshot:
    api_key: ${KIMI_API_KEY}
    base_url: https://api.moonshot.ai/v1
    request_timeout_seconds: 600
    stale_timeout_seconds: 300
```

## .env

```
KIMI_API_KEY=sk-...
```

## API ключ

Формат: `sk-<hash>` (35+ символов). Получить: https://platform.kimi.ai/

## Проверка

```bash
curl -s https://api.moonshot.ai/v1/models \
  -H "Authorization: Bearer $KIMI_API_KEY" | python3 -m json.tool
```

## Reasoning

Kimi K3 использует `supports_thinking_type: "only"` — думает сначала, потом отвечает. Ответ в `reasoning_content` (думалка) и `content` (финальный ответ).

Параметры reasoning:
- `reasoning_effort`: `low` | `high` | `max` (default)
- На `max` может не вернуть `content` при маленьком `max_tokens`
- Для простых запросов — `reasoning_effort: "low"` экономит токены

```json
curl -s -X POST "https://api.moonshot.ai/v1/chat/completions" \
  -H "Authorization: Bearer $KIMI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"kimi-k3","messages":[{"role":"user","content":"hello"}],"max_tokens":100,"reasoning_effort":"low"}'
```

## Цены

~$3/$15 per 1M токенов (input/output). Дороже DeepSeek/LongCat.
Использовать только для сложных задач — кодинг-архитектура, анализ, делегация.
