# Hermes Memory System Quirks

Discovered 26 Jun 2026 during Prism audit of memory files.

## 1. Tool char_limit ≠ actual memory injection

**Symptom:** `memory` tool rejects writes: "memory would be at X/2,200 chars — over the limit". But `MEMORY.md` is 10KB+ and the system prompt clearly injects all of it.

**Root cause:** The `memory` tool enforces `memory_char_limit` (config.yaml, default 2200). But the built-in memory provider reads from `~/.hermes/memories/MEMORY.md` and injects the ENTIRE file into the system prompt regardless of the limit.

**Implication:** The tool gatekeeps writes but doesn't gatekeep reads. You can have a 15KB MEMORY.md that the tool refuses to touch, yet every session sees all 15KB.

**Workaround:** Edit MEMORY.md directly (write_file) to bypass the tool limit. But this breaks the memory tool's ability to manage entries.

**Fix:** Either:
- Raise `memory_char_limit` to match actual file size (e.g. 16000)
- Or aggressively prune MEMORY.md to fit under the limit

## 2. Memory files location

The built-in provider uses:
- `~/.hermes/memories/MEMORY.md` — agent memory (NOT `~/.hermes/MEMORY.md`)
- `~/.hermes/memories/USER.md` — user profile (NOT `~/.hermes/USER.md`)

The `memory` tool's `current_entries` output lists the actual injected content — use this to verify what the agent sees vs what's on disk.

## 3. Memory vs config.yaml divergence danger

Memory files (MEMORY.md, USER.md) are NOT synced with config.yaml. When config changes (model, fallback chain, base_url), memory files retain stale claims. On every audit, cross-check:

- `model.default` in config.yaml vs memory claims about "Default model"
- `base_url` in config.yaml vs memory claims about routing
- `fallback_providers` in config.yaml vs memory claims about fallback order

**Session 26 Jun 2026 found:** memory said "Flash default" while config had "Pro". Memory said "x.ai gateway" while config had "api.deepseek.com". Memory listed 6 fallbacks while config had 4.

## 4. Same-key fallback principle

If primary model uses provider X, putting another model from provider X in the fallback chain is useless — same API key, same failure mode. Fallback chain entries should use DIFFERENT providers with DIFFERENT keys.

**Example (wrong):**
```
primary: deepseek-v4-pro (DeepSeek key)
fallback: deepseek-v4-flash (same DeepSeek key)
```
If DeepSeek API is down, both fail. Wasted fallback slot.

**Example (right):**
```
primary: deepseek-v4-pro (DeepSeek key)
fallback: gpt-4o-mini (OpenAI key) → grok-4.3 (xAI key) → gemini (Google key)
```

## 5. Per-task model selection (user preference)

Alex does NOT want a hard-coded "default model". Flash or Pro is chosen per-task based on complexity. The `model.default` in config.yaml is a starting point, not a rigid assignment.

**Session 26 Jun 2026 clarification:** "Флэш и про я сам включаю от задачи зависит" — user selects model per task. Config may have one as default for gateway auto-routing, but agent should not treat it as locked.
