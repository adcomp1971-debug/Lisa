# ML Project Profile Configuration + Multi-Profile Gateway

## Когда нужно

У вас есть ML-проект (Pianoid/Buratino, тренировки на Vast.ai), и стандартные лимиты Hermes (timeout 180с, tool_output 50k/2k) не подходят. Вариантов два:
1. **Править default profile** — затрагивает всю рутину (VPN, дайджесты, cron)
2. **Создать отдельный профиль** `--clone` — изоляция ML-настроек

**Предпочтение пользователя:** отдельный профиль + отдельный Telegram-бот.

## Какие настройки менять

```yaml
# terminal.timeout: 600 (вместо 180) — data-prep не умирает
terminal:
  timeout: 600

# tool_output: 200k/8000 (вместо 50k/2000) — агент видит полную диагностику
tool_output:
  max_bytes: 200000
  max_lines: 8000

# kanban.auto_decompose: false — ML-пайплайн без самодробления
kanban:
  auto_decompose: false

# environment_hint — инструкция про Vast-дисциплину
agent:
  environment_hint: >
    ML project. Training runs on Vast.ai via ssh+tmux (not local).
    Data-prep needs long timeouts — use background + notify.
    Model weights/datasets go to external storage, not checkpoints.
    Delegation only for isolated testable scripts.
```

## Создание профиля

```bash
hermes profile create <name> --clone --description "ML project description"
# Потом править ~/.hermes/profiles/<name>/config.yaml под проект
```

## ⚠️ Питфол: Python version mismatch

Hermes использует Python **3.11** внутри venv (`/usr/local/lib/hermes-agent/venv/bin/python3`), а голый `pip` указывает на системный **Python 3.12**. Пакеты ставятся в другой site-packages и Hermes их не видит.

**Правильно:**
```bash
/usr/local/lib/hermes-agent/venv/bin/python3 -m pip install <package>
```

**Неправильно (Hermes не увидит пакеты):**
```bash
pip install <package>
```

## Multi-Profile Gateway

Каждый Hermes-профиль может иметь **свой Telegram-бот** с отдельным токеном.

### Настройка

1. Создать бота через @BotFather → получить токен
2. Прописать токен в `.env` профиля:
   ```bash
   sed -i 's|^TELEGRAM_BOT_TOKEN=.*|TELEGRAM_BOT_TOKEN=<token>|' ~/.hermes/profiles/<name>/.env
   ```
3. Создать systemd-сервис:

```ini
# /etc/systemd/system/hermes-gateway-<name>.service
[Unit]
Description=Hermes Gateway - <name> profile
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Group=root
ExecStart=/usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main gateway run --profile <name>
WorkingDirectory=/root/.hermes
Environment="HERMES_HOME=/root/.hermes"
ExecStartPre=-/bin/sh -c 'rm -f /root/.hermes/gateway.pid /root/.hermes/gateway.lock'
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

4. Запустить:
```bash
systemctl daemon-reload
systemctl enable hermes-gateway-<name>
systemctl start hermes-gateway-<name>
```

### ⚠️ Ограничение

Нельзя запускать/останавливать gateway изнутри gateway-сессии — блокируется защитой от suicide.
Команды `systemctl start/stop/restart hermes-gateway-*` выполнять ТОЛЬКО из отдельного терминала
(Blink Shell, SSH, no_agent cron).

## Проверка

```bash
# Токен корректный?
source ~/.hermes/profiles/<name>/.env && curl -s "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe" | python3 -c "import sys,json; print(json.load(sys.stdin)['result']['username'])"

# Сервис запущен?
systemctl status hermes-gateway-<name> --no-pager

# Пакеты установлены в venv?
/usr/local/lib/hermes-agent/venv/bin/python3 -c "import <package>; print('OK')"
```
