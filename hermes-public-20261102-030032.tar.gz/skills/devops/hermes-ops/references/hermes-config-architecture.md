# Hermes Config Debug — Provider & MCP Architecture Notes

**Дата:** 26 июня 2026  
**Контекст:** Исправление model.base_url для DeepSeek, exa-mcp-server naming, browser.cloud_provider

## Provider base_url vs model.base_url

**Проблема:** `model.base_url` в конфиге наследуется ВСЕМИ auxiliary вызовами (web_extract, compression, skills_hub, approval, mcp, title_generation, triage_specifier, kanban_decomposer, profile_describer, curator, session_search). Если model.base_url указывает на x.ai, то все вспомогательные deepseek-вызовы тоже идут через x.ai, даже если deepseek провайдер имеет свой ключ.

**Решение:** 
1. Убрать `model.base_url` (оставить пустым)
2. Прописать `base_url` непосредственно внутри каждого провайдера:
```yaml
model:
  base_url: ''   # пустой — наследуется от провайдера

providers:
  deepseek:
    base_url: https://api.deepseek.com/v1
    api_key_env: DEEPSEEK_API_KEY
```

**Почему это важно:** auxiliary модели (compression, session_search, approval и т.д.) НЕ используют fallback цепочку. Они идут напрямую к провайдеру. Если base_url не указан нигде — они используют model.base_url.

## exa-mcp-server naming

**Проблема:** Пакет называется `@exa-labs/exa-mcp-server`, НЕ `exa-mcp-server`.

**Правильный синтаксис:**
```yaml
mcp_servers:
  exa:
    command: npx
    args: [-y, @exa-labs/exa-mcp-server]
```

**Симптомы неправильного имени:** MCP сервер молча не стартует. Никаких ошибок в логах — просто 0 инструментов от этого MCP.

## browser.cloud_provider

**Правило:** Если MCP сервер `browser-use` не подключён — `cloud_provider` должен быть `none`. Иначе Hermes пытается подключиться к несуществующему MCP и браузер не работает.

```yaml
browser:
  engine: auto
  cloud_provider: none   # если browser-use MCP не установлен
```

Если используется Playwright MCP (`@playwright/mcp`) — `engine: auto` его подхватит, `cloud_provider` не нужен.

## state.db VACUUM

`VACUUM` не уменьшает файл, если в нём нет фрагментации. 253 MB для 12k сообщений и 356 сессий — нормально. SQLite держит терабайты.
