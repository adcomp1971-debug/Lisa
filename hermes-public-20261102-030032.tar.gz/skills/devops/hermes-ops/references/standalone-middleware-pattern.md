# Standalone Middleware Pattern for Hermes Agent

## What

Создание **обособленных скриптов**, расширяющих поведение Hermes Agent без изменения его продакшен-кода (core, gateway, middleware, config).

Пользовательский принцип (важно): **"Никаких изменений в продакшен-коде Hermes — только standalone скрипт который можно вызывать отдельно."**

## Когда использовать

- Нужен monitor/auto-offload tool results (context compression, логирование, rate limiting)
- Нужна pre/post-обработка данных вне основного цикла
- Нужно протестировать новое поведение без риска сломать основной пайплайн
- Нужен cron-based или directory-watcher механизм

## Паттерн

```
Tool result → [Standalone Script] → Pointer / Compressed / Summary
                    ↓
            /tmp/hermes-context/<uuid>.json
```

### 1. Core loop (monitor + threshold)
```python
MAX_RESULT_LENGTH = 15_000  # chars ≈ 4000 tokens
OFFLOAD_DIR = Path("/tmp/hermes-context")

def check_tool_result(tool_name: str, content: str) -> tuple[str, int]:
    if len(content) <= MAX_RESULT_LENGTH:
        return content, 0  # passthrough
    
    uid = uuid.uuid4().hex[:12]
    out_path = OFFLOAD_DIR / f"{uid}.json"
    payload = {
        "schema": "hermes-tool-result-v1",
        "tool": tool_name,
        "original_length": len(content),
        "timestamp": int(time.time()),
        "preview": short_preview(content, 10),  # first 10 lines
        "data": content,
    }
    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2))
    
    placeholder = f"[OFFLOAD: {out_path}  tool={tool_name}  {len(content)}chars]"
    return placeholder, 1  # exit code 1 = was offloaded
```

### 2. Трёхуровневая сигнализация (exit codes)
| Code | Значение | Действие |
|------|----------|----------|
| 0 | All OK | Использовать как есть |
| 1 | Single offload | Заменить на `[OFFLOAD:]` placeholder |
| 80 | Context ≥ 80% | Запустить compress-files для старых tool calls |
| 99 | Context ≥ 95% | Summarise session + offload дамп |

### 3. Compress-files (старые tool calls)
- Walk messages reverse, **protect last N** (default 20)
- Replace `write_file`/`edit_file`/`browser_navigate` content with file pointer
- Threshold: ratio ≥ 0.8 → compress

### 4. Summarise (overflow fallback)
- Dump full messages to JSON
- Create skeletal Markdown log (first 3 lines per message)
- Return `[SESSION-OVERFLOW: summary=<path>  json_dump=<path>  messages=<N>]`

## Ad-hoc Verification Workflow

Для каждого standalone скрипта — **временный верификационный скрипт**:

```python
# /tmp/hermes-verify-<topic>.py
import subprocess
from pathlib import Path
import tempfile, json

def run(cmd, input_data=None):
    r = subprocess.run(["python3", SCRIPT] + cmd, 
                       input=input_data, capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr

def test_check_small():
    code, out, _ = run(["check", "--tool-name", "test"], "tiny\n")
    assert code == 0 and out.strip() == "tiny"

def test_check_big():
    big = "x" * 20000
    code, out, _ = run(["check", "--tool-name", "scrape"], big)
    assert code == 1
    assert "/tmp/hermes-context/" in out

# ... run all tests ...
print("— All ad-hoc verifications passed —")
```

**Правила:**
- Имя файла: `hermes-verify-<topic>.py` в `/tmp/`
- Удалить после проверки (не коммитить)
- Покрыть каждый режим и каждый exit code
- Проверить: файлы реально создаются, content сохраняется, preview обрезан корректно, protection last-N работает
- Результат сообщить пользователю как "ad-hoc verification" (не "suite green")

## Pitfall — не делать

- ❌ Не добавлять LLM-зависимости в middleware (LLM summarisation = agent's job, не скрипта)
- ❌ Не коммитить верификационные скрипты — они одноразовые
- ❌ Не смешивать threshold: 15000 chars для single result ≠ 80% для context window
- ❌ Не трогать последние N сообщений при compress-files — они могут быть нужны прямо сейчас

## Интеграция в Hermes pipeline

```bash
# Posle kazhdogo tool call:
result=$(cat /tmp/tool-output.txt)
code=$(python3 /root/.hermes/scripts/context_offload.py check \
       --tool-name "$tool" --input-file /tmp/tool-output.txt)
case $? in
  0) ;; # use as-is
  1) result="$code" ;; # use OFFLOAD placeholder
esac
```

## Пример из практики

Файл: `/root/.hermes/scripts/context_offload.py` — Context Compression Middleware. Offload tool results, estimate context, compress old file calls, summarise overflow. Все 5 режимов покрыты ad-hoc тестами (7 тестов, 0 failures).
