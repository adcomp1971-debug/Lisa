# Диагностика молчащего Telegram бота — сбой API провайдера

Когда бот не отвечает в Telegram, первая мысль — gateway упал. Но часто проблема в API провайдере, а gateway жив.

## Сценарий: провайдер кончился (HTTP 429 / balance exhausted)

**Симптом:** Бот молчит или отвечает с огромной задержкой. Gateway active, Telegram connected, но в чат приходит "тишина".

**Диагностика:**

1. **Проверить gateway статус:**
   ```bash
   systemctl status hermes-gateway --no-pager | head -12
   ```

2. **Проверить gateway log (INFO уровень):**
   ```bash
   tail -30 /root/.hermes/logs/gateway.log
   ```
   Ищи `RateLimitError`, `429`, `Insufficient balance`, `timeout`, `payment`, `credit`.

3. **Проверить журнал systemd (только WARNING+ERROR):**
   ```bash
   journalctl -u hermes-gateway --since "5 min ago" --no-pager | grep -iE "error|429|401|500|timeout|fail|token|invalid|balance|credit|payment"
   ```
   Внимание: `journalctl` через opentelemetry-instrument показывает только WARNING+ — INFO-логи только в файле `/root/.hermes/logs/gateway.log`.

4. **Проверить API провайдера напрямую:**
   ```bash
   source ~/.hermes/.env
   curl -s -w "\nHTTP:%{http_code}" https://api.deepseek.com/v1/models -H "Authorization: Bearer $DEEPSEEK_API_KEY"
   ```
   HTTP 200 = ок. HTTP 429 = баланс кончился.

5. **Проверить что за модель стоит:**
   ```bash
   grep -A3 '^model:' /root/.hermes/config.yaml
   ```

## Симптом: бот отвечает, но с огромной задержкой (минуты)

**Отличие от молчащего бота:** Бот не молчит, но ответ приходит через 5-40 минут. В gateway.log видны `time=900+s api_calls=1` (один API вызов, но огромное время).

**Причина:** Default модель в config.yaml указывает на провайдера с нулевым балансом. Каждое входящее сообщение:
1. Пытается запустить default модель → HTTP 429 (Insufficient balance)
2. Ждёт ~2с, ретрай → снова 429
3. Фолбэк на следующий провайдер — работает
4. Если внутри сессии много API вызовов (делегация, тулзы), каждый может фолбэчиться — множитель задержки

**Диагностика:**
```bash
# 1. Какая модель стоит дефолтом?
grep -A2 '^model:' /root/.hermes/config.yaml

# 2. Есть ли 429 в логах?
grep -c '429\|Insufficient balance\|RateLimitError' /root/.hermes/logs/errors.log | tail -20

# 3. Сколько времени уходит на ответы?
grep 'response ready.*time=' /root/.hermes/logs/gateway.log | tail -10
```

## Решение: смена провайдера/модели

1. **Сменить модель и провайдера (скалярные значения — `hermes config set` работает):**
   ```bash
   hermes config set model.default deepseek-v4-pro
   hermes config set model.provider deepseek
   ```
   Для простых строковых/скалярных значений `hermes config set` **работает корректно**. Не использовать его только для списков/словарей (fallback_providers и подобных структур).

   Альтернатива — Python YAML edit (для комплексных изменений):
   ```bash
   python3 << 'PYEOF'
   import yaml
   with open('/root/.hermes/config.yaml') as f:
       config = yaml.safe_load(f)
   config['model']['default'] = 'deepseek-v4-flash'
   config['model']['provider'] = 'deepseek'
   with open('/root/.hermes/config.yaml', 'w') as f:
       yaml.dump(config, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
   PYEOF
   ```

2. **Перезапустить gateway:**
   `systemctl restart hermes-gateway` **НЕ РАБОТАЕТ** изнутри gateway-сессии — блокируется. Нужно:
   ```bash
   systemctl kill -s SIGKILL hermes-gateway
   ```
   После SIGKILL systemd auto-restart поднимет gateway заново (Restart=on-failure в юните).

   Проверить что встал:
   ```bash
   sleep 5 && systemctl status hermes-gateway --no-pager | head -5
   ```

3. **Проверить что Telegram подключился** (в `/root/.hermes/logs/gateway.log`):
   ```
   [Telegram] Connected to Telegram (polling mode)
   ✓ telegram connected
   ```

## Проблема: gateway застревает в "deactivating (stop-sigterm)"

Когда `systemctl restart` или `systemctl kill` не срабатывает чисто, gateway зависает в состоянии "deactivating" на время TimeoutStopSec (90 сек).

**Причина:** Gateway держит `drain_timeout=180s`, но systemd unit имеет `TimeoutStopSec=90s`. Systemd посылает SIGTERM → gateway не успевает завершиться за 90s → systemd SIGKILL. Это нормально, но процесс "зависания" выглядит страшно.

**Признак:** `systemctl status` показывает `deactivating (stop-sigterm)`.

**Решение:** 
```bash
systemctl kill -s SIGKILL hermes-gateway 2>/dev/null
sleep 3
systemctl status hermes-gateway --no-pager | head -5
```
После kill systemd автоматически запускает новый процесс.

**Долгосрочный фикс:** `hermes gateway service install --replace` обновит systemd unit с правильным TimeoutStopSec.

## Telegram token check
```bash
source ~/.hermes/.env && curl -s -o /dev/null -w "%{http_code}" "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe"
```
200 = токен жив. 401 = надо новый от BotFather.
