#!/usr/bin/env python3
"""Gateway guard: ensures drop-in with TimeoutStopSec + pre-start cleanup.
Runs independently of gateway — survives gateway crashes.
Fixes the recurring "already running" crash-loop problem.

Deployed as cron job (no_agent, every 5m).
Silent exit 0 when OK. Prints message + cleans up + starts gateway when fix applied.

IMPORTANT: Does NOT use pkill — that creates a self-perpetuating restart cycle.
Only removes lock files. systemd's KillMode=mixed handles process cleanup.
"""

import os
import sys

DROPIN_DIR = "/etc/systemd/system/hermes-gateway.service.d"
DROPIN_FILE = os.path.join(DROPIN_DIR, "timeout.conf")
HERMES_HOME = "/root/.hermes"

EXPECTED = f"""[Service]
TimeoutStopSec=210
ExecStartPre=-/bin/sh -c 'rm -f {HERMES_HOME}/gateway.pid {HERMES_HOME}/gateway.lock'
"""


def main():
    # Check if drop-in exists and matches
    try:
        current = open(DROPIN_FILE).read()
    except FileNotFoundError:
        current = ""

    if current.strip() == EXPECTED.strip():
        sys.exit(0)

    # Fix needed
    os.makedirs(DROPIN_DIR, exist_ok=True)
    with open(DROPIN_FILE, "w") as f:
        f.write(EXPECTED)

    os.system("systemctl daemon-reload")
    print(f"[gateway-guard] Drop-in fixed at {DROPIN_FILE}")

    # If gateway is dead, clean up lock files and start
    code = os.system("systemctl is-active --quiet hermes-gateway")
    if code != 0:
        print("[gateway-guard] Gateway not running, cleaning up and starting...")
        os.system(f"rm -f {HERMES_HOME}/gateway.pid {HERMES_HOME}/gateway.lock")
        os.system("systemctl reset-failed hermes-gateway 2>/dev/null")
        os.system("systemctl start hermes-gateway")


if __name__ == "__main__":
    main()
