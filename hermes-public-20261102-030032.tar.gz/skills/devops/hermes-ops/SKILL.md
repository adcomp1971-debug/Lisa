---
name: hermes-ops
description: "Hermes Agent operations: skill authoring, config optimization, and profile bot management."
category: devops
version: 2.2.0
author: Hermes Agent
---

# Hermes Operations Umbrella

This skill covers advanced administration, optimization, and extension of the Hermes Agent environment.

## Пользовательские правила взаимодействия (ALEX — нарушение = ярость)

### Никаких действий без обсуждения (КРИТИЧНО)
ВСЕГДА показывать план → ждать подтверждение → потом действовать.
Даже если кажется очевидным что нужно сделать.
НИКОГДА не запускать python3/sed/terminal команды для правки системных файлов
пока пользователь явно не скаши "делай"/"примени"/"да".
Если заблокировал → это не ошибка, это сигнал что нужно было обсудить сначала.
В сомнении → написать план в .txt файл и спросить.

### Постоянные обновления при работе
Когда Алекс сказал «делай» — НЕ МОЛЧАТЬ. Если >10 секунд без ответа → он пишет «ну». Отвечать статусом: «сек, гляну», «ещё работает», «сейчас проверю». Делегации ждать и сразу докладывать.

### Контекст — не переключаться
Алекс дал задачу — делать ТОЛЬКО её. Без аудита стека, релеев, скилов или предложений «а давай ещё». Закончил → «что дальше?». Переключение = «контекст не держишь, идиот».

### Делегирование воркерам (codex/claude)
Когда задача сложная (анализ кода, рефакторинг, многошаговая обработка данных) — использовать `delegate_task`, `codex-*` или `claude-*` воркеров, а не делать всё в основном контексте. Признаки: задача требует >5 шагов, включает сборку/обучение ML, или пользователь явно сказал «используй воркеров». Докладывать промежуточные результаты, не молчать.

### Умная модель для сложного
**Default — ВСЕГДА deepseek-v4-flash.** Kimi K3, LongCat-2.0, DS V4 Pro используются только когда пользователь явно сказал «перейди на умную модель», «используй кими», «подключи LongCat» или для делегации сложных задач (когда сам понимаешь что задача не для Flash). Не переключать модель по своей инициативе — пользователь сказал «дефолт дипсик флэш, кими только когда я скажу». «Перейди на умную модель» = переключиться на одну из: Kimi K3 / LongCat-2.0 / DS V4 Pro.

### Идеально или удаление
Пользователь сказал «Все сделай идеально ! Удалю!» — это не угроза, это спецификация. Каждое изменение конфига — идеально. Правило: если не можешь сделать идеально — скажи об этом ДО действия.

### Объяснения для нулевого
Если пользователь говорит «я нулевой» или «объясни элементарные вещи» — разжёвывать как для первого раза: где лежат файлы, какие команды писать, что означает каждая цифра. Не предполагать знания терминов (MLflow, DTW, alignment, loss, params). Аналогии из реальной жизни приветствуются.

### Формат в Telegram
- Никаких Markdown таблиц (pipe |) — только списки. Пользователь орёт на таблицы: "Таблиц без решения не делать!"
- .md на iPad не слать — только .txt (кириллица кракозябрами)
- .yaml файлы НЕ открываются на iPad — пересохранять как .txt перед sendDocument
- Файлы для копирования — .txt через sendDocument, НЕ инлайн
- Команды — по одной на .txt файл
- Ссылки — голый URL отдельно, пояснение вторым
- «Текстом!» = отправить .txt файлом через sendDocument, НЕ инлайн текст в сообщении
- «Пришли команду» = написать команду plaintext в ответе, НЕ пытаться выполнить через terminal/cat/echo

### «Ну!» = хватит спрашивать
Когда Алекс говорит «Ну!» — это сигнал: хватит задавать вопросы, делай с дефолтными значениями. Не переспрашивать, не уточнять, выбирать разумный дефолт и выполнять.

### Простые вопросы = простые ответы
Когда Алекс задаёт простой вопрос («когда рестартить?», «делать сейчас или потом?») — ответить ОДНОЙ строкой немедленно. Не анализировать, не расписывать варианты, не думать три часа. «После всех этапов» — достаточный ответ. Фрустрация «три часа над простым вопросом думаешь» = сигнал что ты перерезонировал.

### Рестарт gateway — команда текстом, НЕ через terminal
Если Алекс просит «пришли команду» для рестарта gateway — написать команду plaintext в ответе (`systemctl restart hermes-gateway`). НЕ пытаться выполнить через terminal/cat/echo — gateway блокирует любые команды, содержащие `systemctl restart hermes-gateway`, изнутри процесса (3 блокировки подряд = loop). Просто отдать текст команды.

## Domain — Alex's terminology

- **"Кодекс"** = OpenAI Codex (coding assistant), not model test or "code" in general
- **"Флэш"** = DeepSeek V4 Flash
- **"Гермес"** = Hermes Agent (the assistant itself)

## Table of Contents

| # | Section | Reference |
|---|---------|-----------|
| 1 | Gateway Crash Diagnostics | `references/gateway-restart-safety.md`, `references/gateway-pid-crash-loop.md` |
| 2 | Multi-Gateway Deployment | `references/multi-gateway-deployment.md` |
| 3 | Audit Checklist & Config Key Order | `references/full-audit-checklist.md`, `references/config-key-order.md` |
| 4 | Provider Cost Diagnostics | `references/cost-diagnostics.md` |
| 5 | Telegram Flood Prevention | `references/telegram-flood-prevention.md` |
| 6 | Provider Timeout Tuning | `references/provider-timeout-tuning.md` |
| 7 | Cost Optimization | `references/cost-optimization.md` |
| 8 | Config Hardening | `references/config-hardening.md` |
| 9 | Config Pitfalls & Gotchas | `references/config-pitfalls.md` |
| 10 | Config Edit via Python3 YAML | `references/config-edit-python3-yaml.md` |
| 10 | Memory Cleanup Triggers | `references/memory-cleanup.md`, `references/memory-cleanup-procedure.md` |
| 11 | State.db Maintenance | `references/state-db-maintenance.md` |
| 12 | Cron Output Viewing | `references/cron-output-viewing.md` |
| 13 | Skill Authoring & Installation | `references/skill-authoring.md` |
| 14 | Profile Bots | `references/profile-bots.md` |
| 15 | Cron Troubleshooting | `references/cron-troubleshooting.md`, `references/cron-model-provider-validation.md` |
| 16 | Session DB Recovery | `references/session-db-recovery.md` |
| 17 | API Key Validation | `references/api-key-validation.md` |
| 18 | Kanban Board Management | `references/kanban-management.md` |
| 19 | Workflow Authoring | `references/workflow-authoring.md` |
| 20 | Dynamic Workflows Plugin | `references/dynamic-workflows.md` |
| 21 | Feature Suggestion — Audit First | `references/feature-audit-first.md` |
| 22 | Gateway Troubleshooting | `references/gateway-troubleshooting.md` |
| 23 | Model Switching FAQ | `references/model-switching-faq.md` |
| 24 | CLI Workers & Daily Cost | `references/cli-workers.md` |
| 25 | DeepSeek Model Names | `references/deepseek-model-names.md` |
| 26 | Web Search Backend | `references/web-search-backend.md` |
| 27 | Cost-Optimized Orchestration | `references/cost-optimization.md` |
| 28 | Full Stack Audit | `references/full-stack-audit.md` |
| 29 | Skills Cleanup | `references/skills-cleanup.md` |
| 30 | CLI Resilience & SSH Recovery | `references/cli-crash-recovery.md` |
| 31 | Telegram Gateway Token Debugging | `references/telegram-token-debugging.md` |
| 32 | Config Recovery from Backup | `references/config-recovery.md` |
| 33 | Codex Relay Architecture & WS Fix | `references/codex-relay-architecture.md` |
| 34 | Provider Auto-Detection Fix (DeepSeek→OpenRouter) | `references/provider-auto-detection-fix.md`, `references/buratino-openrouter-401-fix.md` |
| 35 | Verification-First Protocol (R1-R4) | `references/verification-protocol-r1-r4.md` |
| 36 | Verify Previous Agent Fixes | `references/verify-previous-agent-workflow.md` |
| 37 | Anthropic Messages API Relay | `references/anthropic-relay-setup.md` |
| 37 | Claude Code Settings Template | `templates/claude-settings.json` |
| 38 | Knowledge Graph (Graphiti + Neo4j) | `references/knowledge-graph-graphiti.md` |
| 39 | Hermes Update Procedure & Conflict Resolution | `references/hermes-update-procedure.md`, `references/hermes-update-conflict-resolution.md` |
| 40 | AGENTS.md Maintenance | `references/agents-md-maintenance.md` |
| 41 | Maintenance Jul 2026 (stunnel, MLflow, config, orphans) | `references/hermes-maintenance-20260707.md` |
| 42 | MLflow Setup & Nginx Proxy | `references/mlflow-server-setup.md`, `references/mlflow-nginx-react-spa.md` |
| 43 | Brain Surgery — Config/Memory Sync | `references/brain-surgery-procedure.md` |
| 44 | Post-Update Drift Warnings | `references/hermes-update-drift-warning.md` |
| 46 | Session Continuity Tools | `references/session-continuity-tools.md` |
| 47 | Standalone Middleware Pattern | `references/standalone-middleware-pattern.md` |
| 48 | MCP Server Env Var Resolution | `references/mcp-env-var-resolution.md` |
| 49 | Moonshot (Kimi) Provider Setup | `references/moonshot-kimi-provider.md` |

## Quick Reference — Most Used Commands

### Gateway
```bash
systemctl status hermes-gateway
journalctl -u hermes-gateway --since "30 min ago" -n 20
systemctl is-active hermes-gateway
```

### Config
```bash
hermes config check
hermes fallback list
grep -c '^fallback_providers:' /root/.hermes/config.yaml   # should be 1
grep -c '^mcp_servers:' /root/.hermes/config.yaml          # should be 1
```

### Cron
```bash
hermes cron list
hermes sessions prune --older-than 30 --yes
```

### System
```bash
df -h /
free -h
docker ps --format 'table {{.Names}}\t{{.Status}}'
```

### Orphan Alias Cleanup
```bash
hermes doctor | grep orphan       # find orphan aliases
rm -f /root/.local/bin/<alias>    # remove orphan wrapper
# No hermes command to remove orphan alias — manual rm
```

### Fallback Chain Reorder
```bash
# Python3 heredoc: reorder fallback_providers array in config.yaml
# Then verify:
hermes fallback list
```

| 44 | Post-Update Drift Warnings | `references/hermes-update-drift-warning.md` |

## Key Rules

0. **Hostinger 4 CPU — абсолютный запрет.** Не запускать эмбеддинги nomic/llama-server, `ollama create`, индексацию Герметиста, LoRA/fine-tune на этом сервере. Load>6 → Telegram polling degraded, Hermes отваливается (повтор 19.08 и 20.08). Тяжёлое только Vast.ai. Сторож: `cpu-guard.sh` cron. Нарушение = отвал шлюза.

1. **NEVER use `hermes config set` on established config** — it DESTROYS the entire file. Use `sed -i` or Python heredoc.
2. **Always verify `.env` after edits** — `wc -l ~/.hermes/.env` and `grep -c 'VAR_NAME'`.
3. **Never restart gateway from inside gateway** — use cron no_agent workaround. Exception: `hermes update` now auto-restarts gateways safely (drains + restarts both hermes-gateway and buratino). After update, ALWAYS verify with the post-update checklist (see section 44).
4. **Always audit before suggesting features** — check what's already active first.
5. **Direct providers first, OpenRouter only as last resort** — cost optimization core rule.
6. **Multi-profile env isolation** — каждый профиль Hermes (buratino и т.д.) имеет свой terminal с собственным окружением. `env_passthrough: []` (default) не наследует PATH от родительского shell. Если gateway не видит бинарники (codex/claude) — добавь `PATH` в `env_passthrough`.
7. **Cron no_agent скрипты** — если скрипт только собирает данные/синхло (нет LLM), ставь `deliver: local`, чтобы не спамить в чат каждое срабатывание.
8. **Fallback chain drift (найдено 2026-07-10)** — fallback-цепочка описана в ТРЁХ местах: `config.yaml`, `AGENTS.md`, `MEMORY.md`. При любом изменении fallback ВСЕ ТРИ источника должны совпадать. `config.yaml` — единственный источник правды. После правки fallback всегда проверять: `grep -A8 "^fallback_providers:" config.yaml` vs `grep "Фоллбэк" AGENTS.md` vs `grep -i "fallback" memory/MEMORY.md`. Расхождение = баг.
9. **Мёртвые провайдеры** — провайдеры в `config.yaml` без model/fallback ссылок висят мёртвым грузом. Проверять: `grep -c "provider:" config.yaml` vs сколько реально used. nvidia/openai — типичные зомби.
10. **Systemd unit drift after `hermes update`** — TimeoutStopSec may be too short for drain_timeout. Check for "Stale systemd unit detected" warning and run `sudo hermes gateway install --force` if present.
11. **GLM balance check after restart** — if GLM is in fallback chain and balance is zero, expect HTTP 429 on startup. Hermes falls back, but monitor for balance exhaustion: `journalctl -u hermes-gateway.service --since "5 min ago" | grep "429\|余额不足"`.
12. **MCP stdio env var expansion** — Hermes does NOT expand `${VAR}` references in `env:` blocks for stdio MCP servers. The literal string `${AGENTMAIL_API_KEY}` is passed to the subprocess, which fails because it's not a valid key. Always put the real key value directly in `config.yaml`, or use a wrapper script that sources `.env` first. See `native-mcp` pitfall for details.
