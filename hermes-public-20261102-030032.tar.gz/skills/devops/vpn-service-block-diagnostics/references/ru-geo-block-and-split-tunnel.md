# РФ-сервисы при полном туннеле: гео-блок и split-tunnel

Жалоба «с VPN ничего не работает: ни Озон, ни Вайлдберриз, ни Яндекс». Туннель при этом живой. Диагноз — антибот российских сервисов по зарубежному exit-IP клиента.

## Измеренные сигнатуры (exit — дата-центр в Литве, AS47583 Hostinger)

| Хост | Код | Что видно |
|---|---|---|
| `ozon.ru` | 307 | Location `/?__rr=1` — антибот-редирект |
| `wildberries.ru` | **498** | в HTML `data-req-ip=<наш IP>` — антибот по IP |
| `ya.ru`, `market.yandex.ru` | 302 | Location на капчу / `?nr=1` |
| `avito.ru` | 429 | rate-limit/антибот |
| `lk.alfabank.ru` | 000 | банк не отвечает зарубежному IP вообще |
| `mail.ru`, `gosuslugi.ru` | 200 | работают с любого IP |

Разнобой кодов (307/498/302/429/000) при живом туннеле и свежем handshake = именно гео-блок по IP. Сервер и профиль при этом не трогать.

Мерить **с самого сервера**: он и есть exit клиента. Отдельный «зарубежный» стенд не нужен. Обязательно User-Agent мобильного Safari — с пустым UA многие отдают голый 403 и картина искажается.

## Что реально решает: split tunneling на клиенте

Правило: домены `.ru` и российские IP → DIRECT (с домашнего/мобильного IP), остальное → PROXY через наш вход. Тогда Ozon/WB/Яндекс/банки открываются, Telegram/YouTube/Instagram идут через нас, и переключать VPN не надо.

Серверная маршрутизация этого НЕ решает: если клиент отправил пакет в туннель, он выйдет с нашего зарубежного IP, что бы сервер дальше ни делал. Выбор только на устройстве.

Готовые базы под правило: `geoip:ru` + `domain:ru` (Streisand-формат), `GeoSite:category-ru` + `GeoIP:ru` (Happ/sing-box), `DOMAIN-SUFFIX,ru` + `GEOIP,RU` (Shadowrocket/Clash).

## Клиент без split tunneling — тупик, а не «надо настроить»

Проверять по официальной документации вендора, а не по названию приложения. Пример: **DefaultVPN** — альтернатива AmneziaVPN для российского App Store, и в доке Amnezia прямо: «it doesn't include split tunneling, subscription management, or self-hosted server options». Такому клиенту никакая ссылка и никакой сервер не помогут — надо менять клиент. Не отправлять человека крутить настройки внутри клиента, где такой настройки нет.

## Проверять наличие iOS-приложения в RU App Store (а не по совету из поиска)

```bash
# поиск по названию в storefront ru
curl -s "https://itunes.apple.com/search?term=Shadowrocket&country=ru&entity=software&limit=4" \
 | python3 -c "import sys,json;[print(r['trackName'],'|',r['sellerName'],'| id',r['trackId']) for r in json.load(sys.stdin)['results']]"

# проверка по конкретному id
curl -s "https://itunes.apple.com/lookup?id=932747118&country=ru" | head -c 400
```

`resultCount: 0` или пустой `results` = приложения в российском сторе нет. Питфолл: одноимённые подделки живут под теми же словами («Happ Plus VPN ++», «Foxray VPN» с 0 отзывов, «v2ray VPN ВПН v2raytun» — это инспектор конфигов, а не клиент) — сверять seller и id, а не название.

Состояние на момент обследования (storefront `ru`):

- **Shadowrocket** — 249 ₽, id `932747118`, правила по domain-suffix/CIDR/GeoIP, VLESS+Reality умеет. Самый предсказуемый вариант.
- **Karing** — бесплатно, id `6472431552`, на sing-box/Clash, правила и VLESS+Reality умеет.
- **Streisand, Happ, v2Box, Hiddify** — по id в `ru` не находятся; не советовать, человек не поставит.
- **DefaultVPN** — есть (id `6744725017`), VLESS/Reality умеет, split tunneling НЕТ.
- Готовый deeplink роутинга для Streisand (`streisand://import/route://<base64>`, профиль 🇷🇺 RU) ходит по сети, но приложению без установки бесполезен.

## Питфоллы

1. **Не перевыпускать профиль и не менять сервер** — при гео-блоке это ничего не меняет, а человека гоняет по кругу.
2. **«Включаю/выключаю VPN 100 раз»** — это клиент вручную делает split-tunnel. Не обвинять пользователя: выяснить модель клиента и дать клиент с правилами.
3. **Не обещать «полный туннель вылечит»** — полный туннель как раз причина: весь трафик уходит зарубежным IP.
4. **Не советовать приложение до проверки storefront** — иначе человек ищет в App Store то, чего там нет (особенно после чисток каталога).
5. Проверка «работает» — только по факту у человека: Ozon в браузере открылся, `2ip.ru` показал его московский IP, `api.ipify.org` — наш (когда включено правило).
6. **RuStore — Android-only, iOS-приложений там нет.** На просьбу «дай ссылку на <iOS-клиент> в RuStore» не искать и не отвечать «нет в каталоге» как о находке: проверять RuStore API (`https://backapi.rustore.ru/applicationData/v2/search/apps?query=<имя>&pageSize=20`) только чтобы подтвердить отсутствие, и сразу давать `apps.apple.com/ru/app/<slug>/id<trackId>` из `itunes` lookup. Для Android — APK с GitHub (Hiddify/v2rayNG) или Google Play, не RuStore-каталог VPN-клиентов.
