# nginx pitfalls #26-#35 (вынесено из SKILL.md 2026-09-23)

Практика nginx: определение реального конфига сайта, sub_filter vs патч фронтенда, `sub_filter_types`, `tee -a`, trailing slash в `proxy_pass`, большие аплоады, Tailscale Funnel `--set-path`, служебные vhost'ы на tailnet/VPN-IP, правка конфига python-заменой, статик-сайт из ZIP.

26. **GateBox: определи реальный файл через `ls -la` + `readlink -f` ПЕРЕД правкой — состояние менялось.** Правило #0 («правь `sites-available`, потом симлинк») верно только для НОВЫХ сайтов. У существующего `sites-enabled/<site>` бывает три вида: (а) симлинк на `sites-available/<site>`; (б) симлинк на внешний путь (напр. `/var/project/nginx/gatebox.conf`); (в) **регулярный файл** — так сейчас у `gatebox` (`ls -la` показывает размер и дату, стрелки `->` нет). В случае (в) правки в `sites-available/gatebox` не читаются вообще: новый `location` даёт молчаливый 404 при зелёном `nginx -t`. Порядок: `ls -la` + `readlink -f` → править ИМЕННО тот файл → бэкап рядом (`cp <file> /root/<site>-nginx.bak-$(date +%Y%m%d_%H%M%S)`) → `nginx -t` → `reload` → curl нового location.

    Verify with: `readlink -f /etc/nginx/sites-enabled/gatebox`
    
    If it points to `/var/project/nginx/gatebox.conf` — edit that file.
    If it points to `/etc/nginx/sites-available/gatebox` — edit that one.

27. **Frontend JS path patching vs nginx sub_filter — when you control the source.** When proxying a self-built or open-source web app behind an nginx sub-path (e.g. `/jarvis/`), you have TWO approaches:

    | Approach | When to use |
    |---|---|
    | **nginx sub_filter** (items 18–19, 22) | When you CANNOT modify the app's source (minified bundles, third-party) |
    | **Direct frontend patching** | When you own/control the source files — patch the HTML/JS directly |

    **Direct patching workflow:**

    ```bash
    # 1. Find all hardcoded paths in the JS
    search_files pattern='"/api/|"/ws|wss://|fetch\("|WebSocket\(' path=/path/to/frontend/ limit=50
    search_files pattern="'/api/|'/ws" path=/path/to/frontend/ limit=50

    # 2. For each found path, decide:
    #    - Should this go through nginx proxy? → prefix with /subpath/
    #    - Is this a different backend location? → route to correct nginx path

    # 3. Patch each path
    patch path=/path/to/frontend/index.html \
      old_string='fetch("/api/chat"' \
      new_string='fetch("/jarvis/api/chat"'

    patch path=/path/to/frontend/index.html \
      old_string='"/ws"' \
      new_string='"/jarvis/ws"'

    # 4. Also check: WebSocket URLs, kanban paths, dashboard iframe URLs
    ```

    **When to choose direct patching over sub_filter:**

    - The path conflicts with an EXISTING nginx location block (`/api/` → GateBox, `/ws` → KNX, etc.) — sub_filter can't override priority.
    - The app uses dynamically-constructed URLs from `location.*` that sub_filter would miss.
    - You want clean browser-side URLs without HTTP-layer rewriting overhead.
    - You own the source and can accept maintainability cost.

    **When to choose sub_filter over direct patching:**

    - Third-party/minified app you don't want to fork.
    - CI/CD would overwrite your patches on every deploy.
    - The app has many files or nested dependencies.

    **Verification after patching:**

    ```bash
    # 1. WebSocket endpoint returns 400+ on curl (expected — real WS handshake needed)
    curl -s -o /dev/null -w '%{http_code}' -H 'Upgrade: websocket' -H 'Connection: Upgrade' http://127.0.0.1/prefix/ws
    # 2. API endpoints return real data
    curl -s -b 'jarvis_token=TOKEN' http://127.0.0.1/prefix/api/usage | head -1
    # 3. No regressions on existing paths (GateBox, dashboard, etc.)
    for p in / /kuma/ /dash/ /api/; do echo "$p: $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1$p)"; done
    ```

28. **`sub_filter_types *` corrupts JS files — only use `text/html` (or omit, since `text/html` is the default).** Applying sub_filter to ALL content types (`sub_filter_types *` or listing `application/javascript`) makes nginx rewrite strings like `src="` and `href="` inside JavaScript source code, corrupting the bundle. **Symptom:** SPA page loads (200 HTML), shows splash/loading screen indefinitely, never hydrates. No JS console errors (file is syntactically invalid). **Fix:** always `sub_filter_types text/html;` only. Asset paths from `<script src>` and `<link href>` are in HTML, not JS.

29. **`tee -a` appends AFTER the closing `}` — corrupts nginx config silently.** When using `sudo tee -a /etc/nginx/sites-enabled/gatebox << 'EOF'` to add a new location block, the new content is appended AFTER the server block's closing `}`. The result: `nginx -t` fails with "unexpected end of file, expecting `}`". **Fix:** always rewrite the entire config from scratch. Copy the original (`head -<N-1> file`) then append the new block with proper nesting. Verify with `nginx -t` after every write.

30. **proxy_pass trailing-slash STRIPS the location prefix from the backend path.** `proxy_pass http://127.0.0.1:PORT/;` (WITH trailing slash) removes the matched `location` prefix from the URL before forwarding. So `location /upload/ { proxy_pass http://127.0.0.1:9999/; }` means `/upload/chunk` hits the backend as `/chunk`. If the backend checks `self.path == '/upload/chunk'` it returns 404. **Fix:** either (a) make the backend expect the stripped path (`/chunk`), or (b) remove the trailing slash from proxy_pass so the full path gets forwarded. This is a silent failure — `nginx -t` passes, backend logs show 404. Always curl-test new proxy locations through nginx (`http://localhost/<location>`) not just the backend directly (`http://localhost:PORT/`).

31. **Large upload endpoints need `client_max_body_size` + `proxy_request_buffering off`.** When proxying file uploads >1MB:

    **Простейший рабочий приёмник файла от пользователя** (когда не нужны чанки и прогресс-бар): Flask на `127.0.0.1:<port>` с HTML-формой `multipart/form-data` + `location /upload/` в server-блоке с УЖЕ открытым портом — заливка из Safari на iPad работает без всякого CLI. Обязательно: токен в query (`request.values.get("k")`), иначе страница на открытом порту пускает кого угодно; `app.config["MAX_CONTENT_LENGTH"]` на 2 ГБ; проверка обеих половин гейта (без токена 403, с токеном 200) и реальная заливка `curl -F "file=@/tmp/proba.bin" "<url>?k=$TOKEN"` + `ls -la` в папке приёма.

    Готовый шаблон приёмника (копировать, подставить токен): `templates/upload-receiver.py`.

    **Граница применимости:** Telegram Bot API принимает документы от пользователя только до 20 МБ («The document is too large… Maximum: 20 MB») — от 20 МБ до 2 ГБ вещь передаётся именно веб-приёмником, а не через чат. Ссылку на приёмник отдавать отдельным .txt-файлом (не текстом в чате) — на iPad URL из тела сообщения неудобно копировать.

    **Почему не `scp`:** `scp <файл> root@<host>:/path/` запускается НА ОТПРАВИТЕЛЕ. Если пользователь сидит в ssh-сессии на сервере, команда выполнится там, где файла нет (`scp: stat local: No such file or directory`, `find` возвращает пустую строку), и никакая серверная команда файл с планшета не достанет. Веб-приёмник надёжнее: работает из Safari, не требует открывать вторую локальную вкладку терминала и не зависит от того, в какой папке лежит файл.

    **Питфолл: не строить HTML-шаблон через `str.format()`** — CSS-скобки `{ ... }` парсятся как поля подстановки → KeyError → GET отдаёт 500, а POST сохраняет файл и тоже отдаёт 500. Использовать `str.replace()` с выделенными плейсхолдерами (`%%MSG%%`) и проверять `python3 -c "import ast;ast.parse(...)"` после правок.

    See [[nginx-static-hosting::references/chunked-upload-pattern.md]] for the full chunked upload with resume pattern — Python server code, JS client, nginx config, and all pitfalls (path stripping, Safari tab suspension, port reuse).
```nginx
location /upload/ {
    client_max_body_size 1024M;        # ← allows large file uploads (default 1MB)
    proxy_pass http://127.0.0.1:PORT/;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_request_buffering off;       # ← streams to backend without buffering entire body
}
```
Without `proxy_request_buffering off`, nginx buffers the entire request body on disk before sending to a 482MB backend file — burns 482MB disk + RAM, times out on slow mobile links. With it off, the backend receives data incrementally as the client uploads.

32. **Tailscale: `tailscale serve --set-path` on Funnel domain silently removes Funnel.** Adding a sub-path route via `tailscale serve --set-path /path/ http://localhost:PORT` on a Funnel-enabled domain prints `Removing Funnel for ...` and makes all routes tailnet-only. **Fix:** re-enable Funnel after: `tailscale funnel --bg -–yes`. **Prevention:** use `tailscale funnel` for sub-paths on Funnel domains, or verify `tailscale serve status` shows `(Funnel on)` after every change.

33. **Служебная страница + прокси к локальному сервису — только для своих: `listen` на tailnet/VPN IP, без TLS и без auth.** Когда нужно отдать пользователю страницу с командами/шпаргалкой и заодно дать ему доступ к API, который слушает `127.0.0.1` — не открывай порт в интернет:

    ```nginx
    server {
        listen 100.x.y.z:8093;   # tailscale IP сервера
        listen 10.9.0.1:8093;    # VPN-IP сервера (awg0)
        server_name _;
        root /var/www/<project>;
        index index.html;
        location / { try_files $uri $uri/ /index.html; }
        location /api/ {
            proxy_pass http://127.0.0.1:8642/;
            proxy_buffering off;            # иначе SSE-стриминг копится и не течёт
            proxy_read_timeout 600s;
        }
    }
    ```

    ```bash
    ufw allow in on tailscale0 to any port 8093 proto tcp
    ufw allow in on awg0      to any port 8093 proto tcp
    ```

    **Три обязательные проверки (все три, иначе «работает» — враньё):**
    ```bash
    curl -s -o /dev/null -w '%{http_code}\n' http://<tailscale-ip>:8093/      # 200
    curl -s -o /dev/null -w '%{http_code}\n' http://10.9.0.1:8093/            # 200
    curl -s -o /dev/null -w '%{http_code}\n' http://<PUBLIC_IP>:8093/          # 000 = закрыто снаружи
    ss -tlnp | grep 8093                                                       # bind на внутренние IP, НЕ 0.0.0.0
    ```

    Такой vhost не требует ни сертификата, ни `auth_basic` — снаружи он недостижим физически. **НЕ добавлять `ufw allow 8093/tcp`** хотя бы потому, что в такой прокси часто стоит ключ API сервиса: утечка ключа = полный доступ к сервису с выполнением команд. Давать пользователю ОБА адреса (tailnet и VPN) — у него могут быть подняты не оба канала.

34. **Правка nginx-конфига через `python3 - <<PY` с текстовой заменой — рабочий вариант, когда heredoc-перезапись рискованна.** `write_file`/`patch` по `/etc/nginx/` отклоняются — для новой vhost'ы пиши конфиг heredoc'ом, а для добавления одной строки в СУЩЕСТВУЮЩИЙ файл (второй `listen`) — короткий python-скрипт с идемпотентной проверкой:

    ```python
    src = open(p).read()
    if 'listen 10.9.0.1:8093;' not in src:
        src = src.replace('listen 100.x.y.z:8093;', 'listen 100.x.y.z:8093;\n    listen 10.9.0.1:8093;')
        open(p, 'w').write(src)
    ```

    Так не сносится остальной конфиг (см. правила #22 и #29). После любой такой правки — `nginx -t` и проверка обоих адресов, потом `reload`.



35. **Статичный сайт из ZIP: сначала определи базу ассетов, потом выбирай место.** Распакованный билд (Vite/React/Next-export) смотрит на файлы двумя способами: `./assets/...` (относительная база) или `/assets/...` (абсолютная). Проверять сразу:

    ```bash
    unzip -oq /root/incoming/<site>.zip -d /var/www/<site>
    grep -o 'src="[^"]*"\|href="[^"]*"' /var/www/<site>/index.html
    find /var/www/<site> -name index.html        # подпапки со своими index.html = отдельные страницы
    ```

    - **Относительная база** → сайт обязан жить в КОРНЕ порта/домена: `location / { try_files $uri $uri/ $uri.html /index.html; }`. Без `$uri.html` подпапки со своим `index.html` (напр. `/book/`) отдают 404. На подпути (`/site/`) относительная база ломается на вложенных страницах: их `./assets/` ищется внутри подпапки.
    - **Абсолютная база** → либо отдельный порт/домен, либо sub_filter + `<base href>` (правила #18-#20).
    - **Место:** на этом сервере лендинги живут на СВОИХ портах корнем (8091 shimla, 8092 anna-astrologer, 8094 pravda). Подпуть на :8080 плох — он занят GateBox и ломает относительную базу.
    - **Публичный доступ = `ufw allow <port>/tcp`.** Это firewall — отдельное подтверждение пользователя. До открытия сайт доступен только через tailscale0/awg0 (tailnet-адрес).
    - **Предупредить сразу:** на голом IP без TLS браузер пишет «Не защищено» — для «дай ссылку людям» предложи домен + certbot или бесплатный поддомен.
    - **Проверка после деплоя:** каждая ключевая точка с реальным размером `curl -s -o /dev/null -w '%{http_code} %{size_download}b' http://127.0.0.1:<port>/...` (сейчас `/`, вложенные страницы, `/assets/*.js`, `/img/*.jpg`) + полный свип соседних сайтов (#23) + внешняя проверка узлами (#10b). `200` на `/` без проверки ассетов ничего не значит — сломанная база даёт целый экран 404-х в браузере при зелёном сервере.
