# Dual Server Blocks — Same Port, Different Hostnames, Different Backends

## Problem

You have ONE port 80 but TWO services that BOTH need the root path `/`:

- **Service A** (GateBox): needs root for its landing page
- **Service B** (Hermes Dashboard): needs root for OAuth redirect URI (portal auto-appends `/auth/callback`)

A sub-path (`/dash/`) doesn't work for the OAuth callback because the portal generates `{base}/auth/callback`, not `{base}/dash/auth/callback`.

## Solution — server_name separation

Split by hostname. NGINX routes based on the `Host` header:

```nginx
# Server A: Dashboard on hstgr.cloud domain (root path for OAuth redirect)
server {
    listen 80;
    server_name srv1593922.hstgr.cloud srv1593922.hostingersite.com;
    location / {
        proxy_pass http://127.0.0.1:9118;  # Hermes Dashboard
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}

# Server B: GateBox on IP + catch-all (root) + Dashboard at /dash/
server {
    listen 80;
    server_name _ 76.13.77.105;
    root /var/www/gatebox;
    location / { try_files $uri $uri/ /index.html; }
    location /dash/ { proxy_pass http://127.0.0.1:9118; }
    location /auth/ { proxy_pass http://127.0.0.1:9118; }
}
```

## Why this works

- `Host: srv1593922.hstgr.cloud` → server block A → Dashboard at root
- `Host: 76.13.77.105` or unknown → server block B → GateBox at root
- OAuth callback `{base}/auth/callback` hits the Dashboard either way

## Order of server blocks

NGINX evaluates: exact match → wildcard → regex → `_` catch-all.
The named server block wins over `_` for its specific hostname.

## Pitfalls

- **DNS must resolve:** `dig +short srv1593922.hstgr.cloud` must return the server IP
- **Mobile paste truncation:** Long URLs in mobile browser input fields may truncate. Use shorter alternatives (IP address) when possible.
- **Both blocks on same port** — one file or separate files, NGINX merges by port.
- **OAuth callback location** — if using IP-based redirect URI, add `location /auth/ { proxy_pass ... }` on the catch-all server block too.
