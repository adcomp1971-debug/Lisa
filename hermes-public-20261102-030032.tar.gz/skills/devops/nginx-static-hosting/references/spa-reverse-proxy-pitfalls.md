# SPA Reverse Proxy — Pitfalls & Fixes

Hard-won lessons from proxying Hermes Dashboard, x-ui, and Uptime Kuma behind a single nginx on Tailscale Funnel.

## Pattern 1: SPA with absolute `/assets/` and `/api/` paths

**Problem:** Hermes Dashboard (Vite SPA) generates HTML with:
```html
<script src="/assets/index-B8nPArAs.js"></script>
<link href="/assets/index-DDdgSjAe.css">
```

When served at `/dash/`, the browser requests `https://domain/assets/index-...js` → nginx serves gatebox's index.html (SPA fallback) → JS parses as HTML → broken.

**Fix — sub_filter + asset/API location blocks:**

```nginx
# Main entry — rewrite paths in HTML
location /dash/ {
    rewrite ^/dash/(.*) /$1 break;
    proxy_pass http://127.0.0.1:9119;
    proxy_set_header Accept-Encoding "";
    proxy_http_version 1.1;
    sub_filter_once off;
    sub_filter_types text/html text/css application/javascript;
    sub_filter '"/assets/' '"/dash/assets/';
    sub_filter '"/api/'    '"/dash/api/';
    sub_filter "'/api/"    "'/dash/api/";
}

# Asset pass-through
location /dash/assets/ {
    rewrite ^/dash/assets/(.*) /assets/$1 break;
    proxy_pass http://127.0.0.1:9119;
}

# API pass-through
location /dash/api/ {
    rewrite ^/dash/api/(.*) /api/$1 break;
    proxy_pass http://127.0.0.1:9119;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_buffering off;
}
```

**Verification:** `curl -s http://127.0.0.1:80/dash/ | grep -c '/dash/assets/'` must return > 0.

## Pattern 2: SPA with internal base path (x-ui)

x-ui uses `/bSKXRhmWZZaWa2axfu/` as its base. All assets reference this absolute path. A single `/xui/` location is not enough.

**Fix — dual location blocks:** one for the entry rewrite, one for the internal base path.

```nginx
location /xui/ {
    rewrite ^/xui/(.*) /bSKXRhmWZZaWa2axfu/$1 break;
    # Схему бэкенда проверить фактом (см. admin-panel-access.md §1):
    #   curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:49624/<basePath>/
    #   curl -sk -o /dev/null -w '%{http_code}' https://127.0.0.1:49624/<basePath>/
    # 2026-09-23: панель отвечает по HTTP → proxy_pass http://, без proxy_ssl_*.
    # https:// на HTTP-панели = SSL_do_handshake() wrong version number → 502.
    proxy_pass http://127.0.0.1:49624;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_buffering off;
}

location /bSKXRhmWZZaWa2axfu/ {
    proxy_pass http://127.0.0.1:49624;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_buffering off;
}
```

**Verification:** `curl -s -o /dev/null -w '%{http_code} %{size_download}b' http://127.0.0.1:80/bSKXRhmWZZaWa2axfu/assets/ant-design-vue/antd.min.css` must return 200 with >10KB, not gatebox HTML.

## Pattern 3: Backend 302 redirects + JS API calls — Kuma full fix

**Problem A — redirects:** Uptime Kuma at `/kuma/` returns `Location: /dashboard` or `Location: http://127.0.0.1/dashboard`. `proxy_redirect` is fragile — `proxy_redirect / /kuma/;` corrupts absolute URLs by matching `http://`.

**Problem B — JavaScript API/Socket.IO calls NOT rewritten:** `sub_filter 'src="/'` etc. only rewrites HTML attributes. Kuma's JavaScript bundle contains string literals like `"/api/entry-page"` and `"/socket.io"`. These are NOT caught by `src="/` rules → browser requests go to GateBox API (port 5010) instead of Kuma (port 3001) → Kuma SPA router shows "Page not found" even though initial HTML loaded fine.

**Full fix:**

```nginx
absolute_redirect off;  # ← SERVER-LEVEL! Makes 'return 302' use relative URLs

location = /kuma {
    return 302 /kuma/dashboard;
}
location = /kuma/ {
    return 302 /kuma/dashboard;
}

location /kuma/ {
    rewrite ^/kuma/(.*) /$1 break;
    proxy_pass http://127.0.0.1:3001;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto https;
    proxy_set_header Accept-Encoding "";  # disable gzip so sub_filter works
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_buffering off;
    proxy_redirect http://127.0.0.1:3001/ /kuma/;
    sub_filter_once off;
    sub_filter_types text/css application/javascript text/javascript;
    # HTML attributes
    sub_filter 'src="/' 'src="/kuma/';
    sub_filter 'href="/' 'href="/kuma/';
    sub_filter 'action="/' 'action="/kuma/';
    # JS string literals — CRITICAL for Kuma's API/Socket.IO calls
    sub_filter '"/assets/'    '"/kuma/assets/';
    sub_filter '"/api/'       '"/kuma/api/';
    sub_filter '"/socket.io/' '"/kuma/socket.io/';
    sub_filter "'/api/"       "'/kuma/api/";
    sub_filter "'/socket.io/" "'/kuma/socket.io/";
}
```

**Why JS sub_filter matters:** Without `"/api/` → `"/kuma/api/` rules, Kuma's JavaScript calls `fetch("/api/entry-page")` → this hits GateBox API (port 5010, `location /api/` block) → GateBox returns 404 → Kuma SPA renders "Page not found". The initial HTML loaded fine (200), the redirect worked (302), but the SPA couldn't fetch its data.

## Pattern 4: No-cache headers disappear on SPA fallback

`location / { add_header Cache-Control ...; try_files /index.html; }` triggers internal redirect → headers cleared.

**Fix — exact-match location:** `location = / { add_header ...; try_files /index.html =404; }`

## Pattern 5: Vue Router `<base>` tag for client-side routing

**Problem:** SPAs using Vue Router (Kuma, any Vue app) read `<base href="...">` to determine mount path. At `/kuma/dashboard`, Vue Router sees the FULL path including prefix — doesn't match any route → shows SPA's own 404.

**Fix — inject `<base>` tag via sub_filter:**

```nginx
sub_filter '<head>' '<head><base href="/prefix/">';
```

**Symptom without `<base>`:** All network requests succeed (200 HTML, 200 JS, 200 API), SPA renders its OWN error page.

## Pattern 6: Socket.IO trailing-slash trap

Socket.IO client library hardcodes `"/socket.io"` (NO trailing slash). A sub_filter rule for `"/socket.io/"` (WITH slash) misses these.

**Fix — BOTH variants:**

```nginx
sub_filter '"/socket.io/'  '"/prefix/socket.io/';   # with slash
sub_filter '"/socket.io"' '"/prefix/socket.io"';    # WITHOUT slash
```

## Pattern 7: Separate server blocks per hostname (no sub-path)

**Когда использовать:** У вас есть выделенный hostname/поддомен для каждого приложения. Вместо sub-path прокси (`/dash/`, `/webui/`) делаете отдельный `server` блок на hostname.

**Преимущества:** Никаких sub_filter, rewrite, asset-path костылей. SPA работает на корню — всё как задумано разработчиком.

**Пример — Hermes Dashboard на hostinger URL, GateBox на IP:**

```nginx
# Dashboard на своём домене — корень
server {
    listen 80;
    server_name srv1593922.hstgr.cloud;
    
    location / {
        proxy_pass http://127.0.0.1:9118;
        proxy_set_header Host 127.0.0.1:9118;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}

# GateBox на IP — root, Dashboard на /dash/
server {
    listen 80;
    server_name _ 76.13.77.105;
    root /var/www/gatebox;
    index index.html;

    location /dash/ {
        rewrite ^/dash/(.*) /$1 break;
        proxy_pass http://127.0.0.1:9118;
        # ... sub_filter для asset-путей
    }

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

**Как это работает:** nginx выбирает server block по заголовку `Host`. Если запрос пришёл на `srv1593922.hstgr.cloud` → первый блок (Dashboard). Если на IP или неизвестный hostname → второй блок (GateBox).

**Проверка:**
```bash
curl -s -o /dev/null -w '%{http_code}' -H "Host: srv1593922.hstgr.cloud" http://127.0.0.1/
# → 200 (Dashboard)

curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1/
# → 200 (GateBox)
```

**Важно:** Если у вас Tailscale Funnel — он шлёт оригинальный Host header. Funnel URL (`gpu-qwen.tail0c8f2f.ts.net`) попадёт в default сервер (первый без `server_name _` или default_server). Убедитесь что default сервер отдаёт то что нужно для Funnel.


## Universal verification checklist

After ANY nginx config change, verify with real content:

```bash
# 1. Main page
curl -s http://127.0.0.1:80/ | grep -c '#ffe066'

# 2. All sub-paths
for p in / /dash/ /kuma/ /xui/ /webui/ /codx/; do
  echo "$p: $(curl -s -o /dev/null -w '%{http_code} %{size_download}b' http://127.0.0.1$p)"
done

# 3. Asset loading (not HTML fallback)
curl -s -o /dev/null -w '%{http_code} %{size_download}b' http://127.0.0.1:80/dash/assets/index-*.js
```

**Never tell the user "fixed" based on HTTP status codes alone.** A 200 can be gatebox's index.html served as a fallback for a missing asset. Always verify `%{size_download}` — CSS should be >10KB, JS >100KB, not ~3KB HTML.
