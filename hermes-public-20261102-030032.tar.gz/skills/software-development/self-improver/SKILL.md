---
name: self-improver
description: "Weekly review: skill patches, usage, failures."
version: 1.2.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [meta-skill, continuous-improvement, skill-maintenance, quality]
    related_skills: []
---

# Self Improver

## Overview
Meta-skill for systematic skill quality improvement. Runs a weekly review loop over skill edits, usage signals, and observed failures; then patches weak skills with concrete fixes.

## When to Use
- Maintaining a growing skill library over time
- Reducing drift, stale steps, and missing pitfalls
- Improving skill reliability based on real execution evidence
- **Large-scale brain surgery** (user initiates 6-part overhaul of config/SOUL/skills/memory)

Don’t use for:
- One-time tasks where no durable skill exists

## Weekly Improvement Loop
1) Collect evidence
- Gather recent skill patches/edits — run diagnostic commands from `references/diagnostic-commands.md` (file timestamps, duplicate section detection, size baselines)
- Structural QA одним скриптом: `python3 ~/.hermes/skills/software-development/self-improver/scripts/refcheck.py` — битые ссылки, `exit 1` если есть настоящие пропажи (см. питфол 12)
- Gather sessions where skills were used and failures occurred — use `session_search` with keywords
- Gather user corrections and repeated clarifications

2) Prioritize skills to review
- High usage + high failure = top priority
- Skills with repeated patch churn
- Skills with outdated commands/assumptions

3) Diagnose gaps
- Missing trigger boundaries
- Non-executable or ambiguous steps
- Missing pitfalls for observed failures
- Verification checklist not detecting regressions

4) Patch skills
- Tighten “When to Use / Don’t use”
- Replace vague steps with exact operational actions
- Add newly observed pitfalls + fixes
- Strengthen verification checklist with measurable checks

5) Validate
- Ensure frontmatter correctness and style consistency
- Ensure no breaking contradictions with related skills

6) Log improvements
- Summarize what changed and why
- Mark follow-ups for unresolved issues

## Review Heuristics
- Prefer small, targeted patches over large rewrites
- Encode lessons only after verification
- Remove duplicated guidance across similar skills
- Keep skill size compact enough for frequent loading

## Signals to Watch
- Repeated user correction on same skill area
- Tool failures not anticipated in pitfalls
- “What did you mean?” clarifications on steps
- High variance in outcomes using the same skill
- **Large-scale brain surgery initiated** (user says "Мозги v2", hands 6-part plan, or says "review the conversation and update the skill library") → load `references/brain-surgery-workflow.md`

## Batch Auto-Research Pipeline

For improving multiple skills at once — faster than manual review, safer than cron automation.

### When to Batch
- 5+ skills in a category need optimization
- Skills are safe (non-VPN, non-production-critical)
- You have free/cheap subagent compute (Gemini 3.1 Pro Preview = free)

### Pipeline (per wave of 3-5 skills)

1. **Sandbox**: copy skills to `/opt/hermes-sandbox/experiments/skill-waveN/<name>/`, make `original_backup.md`
2. **Batch 1** (3 parallel): `delegate_task` with 3 subagents, each gets one skill
3. **Batch 2** (2 parallel): remaining 2 skills
4. **Subagent config**: `toolsets: ["terminal", "file"]`, 12 iterations each, SCORE tracking every 4 iterations
5. **Apply**: copy `best.md` → `~/.hermes/skills/<category>/<name>/SKILL.md`

### Subagent Prompt Template
→ `references/batch-optimizer-prompt.md` — reusable delegate_task template, SCORE rubric, optimization moves and anti-moves.

### Results to Track
- Size before/after (bytes)
- SCORE delta (clarity, completeness, applicability)
- Successful iterations / failures
- Key changes summary
- **Apply threshold**: only apply if SCORE ≥ +8. Marginal gains (<8) are noise.

### HERMES.md Optimization
The personality file (`HERMES.md`) is also a valid target for the batch pipeline — treat it like any skill but with extra care:
- Preserve VPN rules and security instructions verbatim
- Verify with `grep -c "vpn-safe\|YES, DO IT"` before applying
- Target: compactness without meaning loss

### Constraints
- **Never** touch VPN skills (gatebox, vpn-manager, vpn-auto-doctor, ios-mobileconfig-vpn)
- Sandbox only — originals untouched until explicit apply step
- Core functionality preserved — only form/style improved

### Automated Script (round-robin cron)

A concrete implementation at `scripts/evolve-skill.sh` — installed as cron `weekly-self-evolution` (Sun 05:00, no_agent=true).
Evolves 3 skills in round-robin, applies only if improvement ≥10 points, otherwise saves candidate to /tmp.

Recommended weekly job:
- Schedule: every 7 days
- Prompt: analyze last week's skill edits + session outcomes, then patch top 1-3 skills
- Output: changelog summary and verification status

## SkillOpt — Systematic Text-Space Skill Optimizer (Microsoft Research)

**Дубликат скилла `skillopt-training`.** Полная документация: `references/skillopt-training.md`

Кратко: SkillOpt тренирует скиллы как веса — separate optimizer model converts scored rollouts into bounded add/delete/replace edits. Использовать `openai_compatible` auth mode для non-Azure провайдеров. CRITICAL: `reasoning_effort: ""` для Grok (не поддерживает параметр). Применять только если SCORE ≥ +8.

## Self-Evolution Pipeline (GEPA + DSPy)

Полная документация: `references/self-evolution-gepa-dspy.md`

Кратко: DSPy + GEPA (ICLR 2026) для genetic-algorithm skill optimization. MIPROv2 (default) — instruction-level, быстрее и дешевле. GEPA — text-level mutations, экспериментальный. Setup: OpenRouter (не DeepSeek direct), `HERMES_AGENT_REPO=/usr/local/lib/hermes-agent`, `pip install optuna` отдельно. Apply threshold: ≥8 points SCORE improvement.

## Common Pitfalls
1. Editing skills based on anecdotes without evidence.
2. Expanding skills endlessly instead of improving clarity.
3. Ignoring outdated related_skills links.
4. Failing to update checklists after new failure classes emerge.
5. **OpenRouter key limit**: GPT-5.5 via OpenRouter hits total key limits under batch load (403 errors mid-iteration). For batch optimization, prefer DeepSeek Flash (cheap, reliable) or Gemini 3.1 Pro Preview (free). Single-skill optimization can use any model.
6. **Applying marginal improvements**: only copy `best.md` → real skill if SCORE improved by ≥8 points. Smaller deltas are noise — skip them. For cron auto-optimization, this threshold prevents churn.
7. **Reward hacking prevention**: use multi-metric scoring (not just chars). For skills: verify structure elements preserved. For memory: verify ALL fact categories, not just 3 critical ones. For code: tests must pass, benchmark must be deterministic.
8. **VPN/production OFF LIMITS**: never optimize vpn-manager, vpn-auto-doctor, vpn-safe, gatebox, or any skill touching live VPN clients.
9. **User-owned skills off-limits to autonomous curation** (проверено 2026-08-02, 6 отказов в логах): фоновый curator/self-improver cron НЕ может патчить скиллы с `created_by=None` — `skill_manage` возвращает `Refusing background curator patch ... not curator-managed (created_by=None). User-owned skills are off-limits to autonomous curation`. Это касается career-workflow, hermes-ops, it-evening-digest, smart-router и др. Автономный cron может править ТОЛЬКО agent-created скиллы. Для user-owned — только отчёт с рекомендациями, правку делает Алекс.
10. **skill_view обязателен перед skill_manage в фоне**: background curator получает `Refusing background curator patch ... current SKILL.md content has not been loaded in this review turn` если патчит без предварительного `skill_view(name)`. В cron-режиме: сначала skill_view → потом patch, иначе отказ.
11. **Description budget 60 chars**: `skill_manage(create)` отклоняет описания >60 символов (`Description is N chars — new skills must fit the 60-char system-prompt budget`). Триггер первым предложением, до 60 символов, точка в конце. Замер 19.10.2026: у 34 из 81 активных скиллов описание длиннее 60 — все они попадают в системный промпт каждый ход (суммарно 7168 символов, обрезка до 60 сэкономила бы ~2715). Новые скиллы не создавать с длинным описанием, старые — только по разрешению (большинство user-owned).
12. **Проверка битых `references/*` даёт ложные срабатывания — проверять СКРИПТОМ, а не грепом.** Три источника лжи: (а) regex цепляет точку в конце фразы (путь выглядит как `<file>.md` + `.`), (б) файл живёт в соседнем скилле или в глобальном `~/.hermes/scripts/`, (в) плейсхолдеры вида `<assets>/...` в прозе. Штатный skill-линтер ловится на том же и ругается `dangling-reference` даже на примеры путей в тексте — это предупреждение, не блокер. 12.10 — 6 из 6 «битых» ложные, 19.10 — 19 из 20. Рабочий тест: `python3 ~/.hermes/skills/software-development/self-improver/scripts/refcheck.py` (индексирует всё дерево скиллов + `~/.hermes/scripts`, `exit 1` при реальных пропажах). 19.10 он нашёл 6 пропаж из 359 ссылок, из них 2 настоящие (у `xui-panel-ops` был описан несуществующий скрипт и удалённая ссылка на migration-файл).
13. **Обещанный в тексте скилла файл (скрипт/референс), которого нет на диске — худший вид бага:** агент в следующий раз честно пытается его запустить и теряет вызов. При ревизии проверять не только наличие ссылки, но и исполнимость обещания: либо файл создать и прогнать, либо честно убрать обещание.
14. **Бюджет вывода аудита: агрегаты, а не листинги.** 26.10 один `ls -la /etc/amnezia/amneziawg/` вернул 105 640 символов (≈30k токенов) и вытеснил из контекста половину аудита. В cron-аудите любой каталог с сотнями файлов читать только через `ls | wc -l`, `du -sh`, `find -newermt ... | head`, а содержимое — `grep -c`/скриптом с печатью сводки. Это же правило снимает главную статью расходов weekly-аудита (8.6M входных токенов за прогон).
15. **Сторож, который печатает одну и ту же аварию каждый час — это не сторож, а шум.** Дедуп нужен не только для «медленно растущих» метрик (молчащие пиры), но и для «вечных» критических: падение целого узла печатается каждый час без повторов (vpn-health-watch: `ssh недоступен` с ~06.10, ~500 сообщений). При аудите сторожей проверять: есть ли у КАЖДОЙ ветки problems свой ключ дедупа, или повторы идут вечно.
16. **Проверка ссылок должна уметь отличать пример из текста от обещания файла.** `refcheck.py` с 26.10 пропускает ссылки на строках с лексикой самого чекера (`MISS`, `OK(other)`, `dangling-reference`) и печатает их число как `SKIP` — иначе цитата из питфола 12 сама становится «битой ссылкой» (1 ложный MISS из 20 на прогоне 26.10).

## Large-scale Brain Surgery Workflow (class pattern)

When user initiates a multi-part overhaul of Hermes config/SOUL/skills/memory (signalled by "Мозги v2", "review the conversation", or explicit 6-part plan):

1. **Part 1 — Single Source of Truth**  
   Identify the authoritative file (usually `config.yaml`). Force every other file (AGENTS.md, MEMORY.md, sкиллы) to match it. Never have three different fallback chains.

2. **Part 2 — Safety & Discipline**  
   Apply the dangerous changes only after user says "Ну!" or "делай" (explicit consent to defaults). Never re-ask once defaults are proposed.

3. **Part 3 — Personality Consolidation**  
   Move all behavioural rules into SOUL.md (≤60 lines). Delete duplicates from voice-transcript, project-context, etc. SOUL is the owner of "how to behave".

4. **Part 4 — Diet**  
   Archive zero-use agent-created skills. Reduce any SKILL.md >150 lines by extracting to `references/`. Target ~25 active skills.

5. **Part 5 — Memory & Profile**  
   USER.md = only about the human. Everything else (projects, technical facts) belongs in MEMORY.md. Add dates `[YYYY-MM-DD]` to new memory entries.

6. **Part 6 — One Owner of Hygiene**  
   Create or update `weekly-hermes-audit` cron that checks: fallback consistency, reference health, size limits, dated memory, dead providers. It alerts, it does not self-repair.

**User signal "Ну!"** = execute the last proposed defaults immediately. Do not explain, do not ask again.

**User signal "Идиот три часа над простым вопросом думаешь!"** = stop asking, stop explaining, act on the last concrete proposal.

References:
- `scripts/refcheck.py` — проверка битых `references/`-ссылок по всему дереву скиллов (см. питфол 12)
- `references/brain-surgery-workflow.md` (this pattern)
- См. правило «Single Source of Truth» в самом this skill: config.yaml — единственный источник правды для конфигурации провайдеров и fallback.

## Verification Checklist
- [ ] Weekly review cadence is active
- [ ] Prioritization uses both usage and failure signals
- [ ] Each patch ties to a specific observed issue
- [ ] Updated skills include tighter triggers and verifiable steps
- [ ] Changes are summarized with rationale for future audits

## One-Shot Prompt Template
"Review skills updated or used this week. Identify top reliability gaps, patch the most impactful 1-3 skills, and produce a changelog with evidence, fixes, and verification updates."
